<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('spot_limit_orders', function (Blueprint $t) {
            $t->string('kind', 8)->default('limit')->after('side'); // limit | tp | sl
        });
    }

    public function down(): void
    {
        Schema::table('spot_limit_orders', function (Blueprint $t) {
            $t->dropColumn('kind');
        });
    }
};
