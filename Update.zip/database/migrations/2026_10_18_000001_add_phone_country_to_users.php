<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->string('phone', 24)->nullable()->after('email');   // international format, e.g. +923001234567
            $t->string('country', 80)->nullable()->after('phone'); // chosen at sign-up, pre-fills KYC
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->dropColumn(['phone', 'country']);
        });
    }
};
