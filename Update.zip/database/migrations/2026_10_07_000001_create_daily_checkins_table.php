<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('daily_checkins', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->date('day');                                   // UTC calendar day of the claim
            $table->unsignedTinyInteger('cycle_day');              // 1..7 position in the reward cycle
            $table->unsignedInteger('streak');                     // consecutive days including this one
            $table->string('asset', 16);
            $table->unsignedBigInteger('amount');                  // units credited
            $table->timestamps();
            $table->unique(['user_id', 'day']);
            $table->index(['user_id', 'id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('daily_checkins');
    }
};
