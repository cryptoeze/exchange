<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Withdrawals are reviewed and sent manually by an administrator. The amount is taken from the funding account when requested.
        Schema::create('withdrawals', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('asset', 16);
            $table->string('network', 16);
            $table->string('address', 128);
            $table->unsignedBigInteger('amount');   // units, what leaves the wallet
            $table->unsignedBigInteger('fee');      // units, network fee kept by the platform
            $table->unsignedBigInteger('net');      // units, what the recipient gets
            $table->string('status', 10)->default('pending'); // pending | completed | rejected | cancelled
            $table->string('tx_hash', 128)->nullable();
            $table->string('reason', 255)->nullable();
            $table->unsignedBigInteger('reviewed_by')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->string('idempotency_key', 96)->nullable()->unique();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
            $table->index('status');
        });

        // Receiving addresses shown to users for manual deposits. Managed by an administrator.
        Schema::create('manual_deposit_addresses', function (Blueprint $table): void {
            $table->id();
            $table->string('asset', 16);
            $table->string('network', 16);          // TRC20 | BEP20 | ...
            $table->string('label', 60);
            $table->string('address', 128)->default('');
            $table->unsignedBigInteger('min_units')->default(0);
            $table->string('note', 255)->nullable();
            $table->boolean('enabled')->default(false);
            $table->unsignedInteger('sort')->default(0);
            $table->timestamps();
        });

        Schema::create('manual_deposits', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('address_id')->constrained('manual_deposit_addresses')->cascadeOnDelete();
            $table->string('asset', 16);
            $table->string('network', 16);
            $table->unsignedBigInteger('claimed');   // amount the user says they sent
            $table->unsignedBigInteger('credited')->nullable();
            $table->string('txid', 128);
            $table->string('status', 10)->default('pending'); // pending | approved | rejected
            $table->string('reason', 255)->nullable();
            $table->unsignedBigInteger('reviewed_by')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
            $table->index('status');
            $table->index(['network', 'txid']);
        });

        $now = now();
        DB::table('manual_deposit_addresses')->insert([
            ['asset' => 'USDT', 'network' => 'TRC20', 'label' => 'Tron (TRC20)', 'address' => '', 'min_units' => 1_000_000_000, 'note' => null, 'enabled' => false, 'sort' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['asset' => 'USDT', 'network' => 'BEP20', 'label' => 'BNB Smart Chain (BEP20)', 'address' => '', 'min_units' => 1_000_000_000, 'note' => null, 'enabled' => false, 'sort' => 2, 'created_at' => $now, 'updated_at' => $now],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('manual_deposits');
        Schema::dropIfExists('manual_deposit_addresses');
        Schema::dropIfExists('withdrawals');
    }
};
