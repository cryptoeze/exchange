<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->text('two_factor_secret')->nullable();
            $t->boolean('two_factor_enabled')->default(false);
            $t->text('two_factor_recovery')->nullable();
            $t->string('admin_role', 12)->default('super'); // super | finance | support (only used when role = admin)
        });
        Schema::create('login_events', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->nullable()->index();
            $t->string('email', 190)->nullable();
            $t->string('area', 8)->default('web'); // web | admin
            $t->boolean('success')->default(true);
            $t->string('note', 40)->nullable();
            $t->string('ip', 45)->nullable();
            $t->string('agent', 190)->nullable();
            $t->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('login_events');
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['two_factor_secret', 'two_factor_enabled', 'two_factor_recovery', 'admin_role']));
    }
};
