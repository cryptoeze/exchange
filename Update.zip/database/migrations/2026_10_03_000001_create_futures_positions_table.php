<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('futures_positions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('symbol', 24);
            $table->string('side', 5);                       // long | short
            $table->unsignedSmallInteger('leverage');
            $table->unsignedBigInteger('margin');            // USDT units (1e-8), locked in the `futures` ledger account
            $table->unsignedBigInteger('entry_micro');       // entry price x 1e8
            $table->unsignedBigInteger('take_profit_micro')->nullable();
            $table->unsignedBigInteger('stop_loss_micro')->nullable();
            $table->string('status', 8)->default('open');    // open | closed
            $table->unsignedBigInteger('close_micro')->nullable();
            $table->string('close_reason', 12)->nullable();  // manual | tp | sl | liquidation
            $table->bigInteger('pnl')->nullable();           // gross PnL in units, before fees
            $table->unsignedBigInteger('fee_open')->default(0);
            $table->unsignedBigInteger('fee_close')->default(0);
            $table->string('idempotency_key', 96)->nullable()->unique();
            $table->timestamp('closed_at')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'status']);
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('futures_positions');
    }
};
