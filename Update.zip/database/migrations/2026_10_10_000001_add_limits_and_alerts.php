<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('bots', function (Blueprint $t) {
            $t->unsignedBigInteger('max_per_user')->nullable()->after('min_units');   // units of 1e-8, null = unlimited
            $t->unsignedBigInteger('capacity')->nullable()->after('max_per_user');    // total allocation cap
        });
        Schema::table('earn_products', function (Blueprint $t) {
            $t->unsignedBigInteger('max_per_user')->nullable()->after('min_units');
            $t->unsignedBigInteger('capacity')->nullable()->after('max_per_user');
        });
        Schema::table('futures_positions', function (Blueprint $t) {
            $t->timestamp('warned_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('futures_positions', fn (Blueprint $t) => $t->dropColumn('warned_at'));
        Schema::table('earn_products', fn (Blueprint $t) => $t->dropColumn(['max_per_user', 'capacity']));
        Schema::table('bots', fn (Blueprint $t) => $t->dropColumn(['max_per_user', 'capacity']));
    }
};
