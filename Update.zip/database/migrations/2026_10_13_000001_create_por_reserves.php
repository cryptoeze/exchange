<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('por_reserves', function (Blueprint $t) {
            $t->id();
            $t->string('asset', 16)->unique();
            $t->decimal('amount', 28, 8)->default(0);   // reported by the administrator
            $t->string('wallet', 190)->nullable();       // public address / explorer link, optional
            $t->timestamp('verified_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('por_reserves');
    }
};
