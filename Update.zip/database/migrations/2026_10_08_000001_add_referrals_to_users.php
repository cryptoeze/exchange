<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->string('referral_code', 12)->nullable()->unique()->after('role');
            $t->unsignedBigInteger('referred_by')->nullable()->index()->after('referral_code');
        });
        foreach (DB::table('users')->whereNull('referral_code')->pluck('id') as $id) {
            do { $code = strtoupper(Str::random(8)); } while (DB::table('users')->where('referral_code', $code)->exists());
            DB::table('users')->where('id', $id)->update(['referral_code' => $code]);
        }
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->dropUnique(['referral_code']);
            $t->dropColumn(['referral_code', 'referred_by']);
        });
    }
};
