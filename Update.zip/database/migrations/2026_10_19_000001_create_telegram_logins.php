<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** One-time admin login links issued by the Telegram bot's /login command. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('telegram_logins', function (Blueprint $t) {
            $t->id();
            $t->string('token', 64)->unique();
            $t->unsignedBigInteger('admin_id');
            $t->timestamp('expires_at');
            $t->timestamp('used_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('telegram_logins');
    }
};
