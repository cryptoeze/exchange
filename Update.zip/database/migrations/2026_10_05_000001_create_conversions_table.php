<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('conversions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('from_asset', 16);
            $table->string('to_asset', 16);
            $table->unsignedBigInteger('from_amount');
            $table->unsignedBigInteger('to_amount');
            $table->decimal('rate', 30, 12);          // to-asset received per 1 from-asset, taken on the server
            $table->string('idempotency_key', 96)->nullable()->unique();
            $table->timestamps();
            $table->index(['user_id', 'id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('conversions');
    }
};
