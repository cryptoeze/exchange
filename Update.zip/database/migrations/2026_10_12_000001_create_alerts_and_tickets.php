<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('price_alerts', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('symbol', 24);
            $t->string('direction', 5); // above | below
            $t->decimal('price', 24, 10);
            $t->timestamp('triggered_at')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['triggered_at', 'symbol']);
        });
        Schema::create('tickets', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('subject', 140);
            $t->string('category', 24)->default('other');
            $t->string('status', 10)->default('open')->index(); // open | answered | closed
            $t->timestamp('last_reply_at')->nullable();
            $t->timestamps();
        });
        Schema::create('ticket_messages', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('ticket_id')->index();
            $t->unsignedBigInteger('user_id');
            $t->boolean('is_staff')->default(false);
            $t->text('body');
            $t->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        foreach (['ticket_messages', 'tickets', 'price_alerts'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
