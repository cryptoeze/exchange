<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Only meaningful on the owner's own install (config('license.authority') === true, i.e. LICENSE_AUTHORITY=true
 * in that one .env). On a sold copy this table exists (same codebase) but is never written to or read from the
 * license:// side — that copy only ever calls out to the authority's /license-api/* endpoints with its own key.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('licenses', function (Blueprint $t) {
            $t->id();
            $t->string('key', 64)->unique();
            $t->string('domain', 191)->nullable(); // set on first successful activation; locked to that domain after
            $t->string('status', 16)->default('pending'); // pending (issued, not yet activated) | active | revoked
            $t->string('note', 191)->nullable(); // e.g. buyer name/email, for the owner's own records
            $t->timestamp('activated_at')->nullable();
            $t->timestamp('last_seen_at')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('licenses');
    }
};
