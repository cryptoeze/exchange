<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $t) {
            $t->string('key', 64)->primary();
            $t->text('value')->nullable();
            $t->timestamp('updated_at')->nullable();
        });
        Schema::create('user_notifications', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('type', 24)->default('info');
            $t->string('title', 140);
            $t->text('body')->nullable();
            $t->string('url', 190)->nullable();
            $t->timestamp('read_at')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['user_id', 'read_at']);
        });
        Schema::create('kyc_submissions', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('full_name', 120);
            $t->string('country', 80);
            $t->string('doc_type', 24);
            $t->string('doc_number', 64);
            $t->string('front_path');
            $t->string('selfie_path');
            $t->string('status', 12)->default('pending')->index();
            $t->string('reason', 255)->nullable();
            $t->unsignedBigInteger('reviewed_by')->nullable();
            $t->timestamp('reviewed_at')->nullable();
            $t->timestamps();
        });
        Schema::create('referral_rewards', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('referrer_id')->index();
            $t->unsignedBigInteger('referred_id')->index();
            $t->string('source_type', 24);
            $t->unsignedBigInteger('source_id');
            $t->string('asset', 12);
            $t->bigInteger('amount');
            $t->timestamp('created_at')->useCurrent();
            $t->unique(['source_type', 'source_id']);
        });
        Schema::table('users', function (Blueprint $t) {
            $t->string('status', 12)->default('active')->after('role');
            $t->string('kyc_status', 12)->default('none')->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['status', 'kyc_status']));
        foreach (['referral_rewards', 'kyc_submissions', 'user_notifications', 'settings'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
