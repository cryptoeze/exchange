<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Current balance per user / account / asset, in integer units of 1e-8.
        Schema::create('wallet_balances', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('account', 12);          // funding | trading | copy
            $table->string('asset', 16);
            $table->unsignedBigInteger('balance')->default(0);
            $table->timestamps();
            $table->unique(['user_id', 'account', 'asset'], 'wallet_balance_unique');
        });

        // Append-only journal. Every balance change writes exactly one row; rows are never updated or deleted.
        Schema::create('ledger_entries', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('account', 12);
            $table->string('asset', 16);
            $table->bigInteger('amount');            // signed delta, units of 1e-8
            $table->unsignedBigInteger('balance_after');
            $table->string('type', 32);              // admin_credit, admin_debit, transfer_in, transfer_out, spot_buy, spot_sell, fee
            $table->string('ref_type', 32)->nullable();
            $table->unsignedBigInteger('ref_id')->nullable();
            $table->string('idempotency_key', 96)->nullable()->unique();
            $table->unsignedBigInteger('created_by')->nullable(); // admin id for manual adjustments
            $table->string('note', 255)->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['user_id', 'created_at']);
        });

        Schema::create('spot_orders', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('symbol', 24);
            $table->string('base_asset', 16);
            $table->string('side', 4);               // buy | sell
            $table->unsignedBigInteger('price_micro'); // execution price * 1e8 (integer)
            $table->unsignedBigInteger('base_qty');    // units of 1e-8
            $table->unsignedBigInteger('quote_total'); // USDT units, before fee
            $table->unsignedBigInteger('fee');         // USDT units
            $table->string('status', 12)->default('filled');
            $table->string('idempotency_key', 96)->nullable()->unique();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
        });

        Schema::create('admin_audit_logs', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('admin_id');
            $table->string('action', 48);
            $table->unsignedBigInteger('target_user_id')->nullable();
            $table->json('details')->nullable();
            $table->string('ip', 45)->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['admin_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('admin_audit_logs');
        Schema::dropIfExists('spot_orders');
        Schema::dropIfExists('ledger_entries');
        Schema::dropIfExists('wallet_balances');
    }
};
