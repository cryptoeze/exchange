<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_market_favorites', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('symbol', 32);
            $table->string('market_type', 12);
            $table->timestamps();
            $table->unique(['user_id', 'symbol', 'market_type'], 'user_market_favorite_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_market_favorites');
    }
};
