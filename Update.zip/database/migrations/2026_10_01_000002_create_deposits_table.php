<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('deposits', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('order_id', 64)->unique();            // our reference sent to the provider
            $table->string('provider_payment_id', 64)->nullable()->unique();
            $table->string('pay_currency_code', 24);              // provider currency code, e.g. usdttrc20
            $table->string('asset', 16);                          // wallet ticker credited, e.g. USDT
            $table->string('network', 64);
            $table->string('pay_address', 191);
            $table->string('pay_extra_id', 64)->nullable();       // memo / tag when the chain needs one
            $table->string('expected_amount', 40)->nullable();
            $table->string('paid_amount', 40)->nullable();
            $table->string('status', 24)->default('waiting');     // waiting, confirming, confirmed, sending, finished, partially_paid, failed, refunded, expired
            $table->string('tx_hash', 191)->nullable();
            $table->unsignedBigInteger('credited_units')->default(0);
            $table->timestamp('credited_at')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('deposits');
    }
};
