<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Flexible staking products. Rates are set by an administrator; interest is paid into the user's funding account.
        Schema::create('earn_products', function (Blueprint $table): void {
            $table->id();
            $table->string('asset', 16);
            $table->string('name', 60);
            $table->decimal('apr_pct', 8, 4);             // yearly rate in percent, simple interest
            $table->unsignedBigInteger('min_units')->default(0); // minimum stake, units of 1e-8
            $table->boolean('enabled')->default(false);   // new stakes only; existing stakes keep earning
            $table->unsignedInteger('sort')->default(0);
            $table->timestamps();
        });

        Schema::create('earn_positions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('earn_product_id')->constrained('earn_products')->cascadeOnDelete();
            $table->unsignedBigInteger('principal')->default(0);
            $table->timestamp('last_accrued_at')->useCurrent();
            $table->timestamps();
            $table->unique(['user_id', 'earn_product_id']);
        });

        // Yield strategies ("bots"): capital is locked in the bots account; a fixed daily yield is paid per 24h cycle.
        Schema::create('bots', function (Blueprint $table): void {
            $table->id();
            $table->string('name', 60);
            $table->string('pair', 24);                   // label only, e.g. BTCUSDT
            $table->string('strategy', 40);
            $table->decimal('daily_yield_pct', 6, 3);
            $table->decimal('profit_share_pct', 5, 2)->default(0); // share kept by the platform, deducted from each payout
            $table->unsignedBigInteger('min_units')->default(0);
            $table->boolean('enabled')->default(false);
            $table->unsignedInteger('sort')->default(0);
            $table->timestamps();
        });

        Schema::create('bot_follows', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('bot_id')->constrained('bots')->cascadeOnDelete();
            $table->unsignedBigInteger('capital')->default(0);
            $table->string('status', 10)->default('active'); // active | stopped
            $table->boolean('auto_claim')->default(false);
            $table->timestamp('cycle_started_at')->useCurrent();
            $table->timestamps();
            $table->unique(['user_id', 'bot_id']);
            $table->index(['bot_id', 'status']);
        });

        Schema::create('bot_claims', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('bot_id')->constrained('bots')->cascadeOnDelete();
            $table->unsignedInteger('cycles');
            $table->unsignedBigInteger('capital');
            $table->unsignedBigInteger('gross');
            $table->unsignedBigInteger('share');
            $table->unsignedBigInteger('net');
            $table->timestamp('created_at')->useCurrent();
            $table->index(['user_id', 'created_at']);
        });

        // Disabled by default so nothing pays out until an administrator switches it on.
        DB::table('earn_products')->insert(['asset' => 'USDT', 'name' => 'USDT Flexible', 'apr_pct' => 3.5, 'min_units' => 100_000_000, 'enabled' => false, 'sort' => 1, 'created_at' => now(), 'updated_at' => now()]);
    }

    public function down(): void
    {
        Schema::dropIfExists('bot_claims');
        Schema::dropIfExists('bot_follows');
        Schema::dropIfExists('bots');
        Schema::dropIfExists('earn_positions');
        Schema::dropIfExists('earn_products');
    }
};
