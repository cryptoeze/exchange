<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('p2p_ads', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('side', 4);                      // sell = advertiser sells crypto, buy = advertiser buys crypto
            $t->string('coin', 12);
            $t->string('fiat', 8);
            $t->decimal('price', 24, 8);                 // fiat per 1 coin
            $t->unsignedBigInteger('total');             // coin units of 1e-8 when created
            $t->unsignedBigInteger('available');         // coin units still open for new orders
            $t->decimal('min_fiat', 20, 2);
            $t->decimal('max_fiat', 20, 2);
            $t->json('methods');                         // ["Bank Transfer", ...]
            $t->json('details')->nullable();             // sell ads: {"Bank Transfer": "IBAN ..."}
            $t->text('terms')->nullable();
            $t->unsignedSmallInteger('window_min')->default(15);
            $t->string('status', 8)->default('online');  // online | offline | closed
            $t->timestamps();
            $t->index(['status', 'side', 'coin', 'fiat']);
        });
        Schema::create('p2p_trades', function (Blueprint $t) {
            $t->id();
            $t->string('ref', 16)->unique();
            $t->unsignedBigInteger('ad_id')->index();
            $t->unsignedBigInteger('buyer_id')->index();
            $t->unsignedBigInteger('seller_id')->index();
            $t->string('coin', 12);
            $t->string('fiat', 8);
            $t->decimal('price', 24, 8);
            $t->unsignedBigInteger('qty');               // coin units held in escrow
            $t->decimal('fiat_amount', 20, 2);
            $t->string('method', 60);
            $t->text('pay_details')->nullable();         // where the buyer sends the money
            $t->string('status', 10)->default('pending'); // pending | paid | completed | cancelled | expired | disputed
            $t->string('resolution', 200)->nullable();
            $t->timestamp('expires_at');
            $t->timestamp('paid_at')->nullable();
            $t->timestamp('closed_at')->nullable();
            $t->timestamps();
            $t->index(['status', 'expires_at']);
        });
        Schema::create('p2p_messages', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('trade_id')->index();
            $t->unsignedBigInteger('user_id')->default(0); // 0 = system
            $t->text('body');
            $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('p2p_disputes', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('trade_id')->unique();
            $t->unsignedBigInteger('opened_by');
            $t->string('reason', 300);
            $t->string('status', 10)->default('open');
            $t->string('outcome', 10)->nullable();       // release | refund
            $t->string('note', 300)->nullable();
            $t->unsignedBigInteger('resolved_by')->nullable();
            $t->timestamp('resolved_at')->nullable();
            $t->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        foreach (['p2p_disputes', 'p2p_messages', 'p2p_trades', 'p2p_ads'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
