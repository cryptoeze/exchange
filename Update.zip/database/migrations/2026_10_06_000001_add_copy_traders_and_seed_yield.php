<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Copy traders reuse the yield engine of trading bots (same follow/claim/unfollow rules), told apart by `kind`.
        Schema::table('bots', function (Blueprint $table): void {
            $table->string('kind', 10)->default('bot')->after('id');   // bot | trader
            $table->string('bio', 255)->nullable();
            $table->string('direction', 5)->default('LONG');           // label only: LONG | SHORT
            $table->unsignedSmallInteger('leverage')->default(1);      // label only
            $table->index('kind');
        });

        $now = now();
        if (DB::table('bots')->count() === 0) {
            $row = fn (string $kind, string $name, string $pair, string $strategy, float $daily, float $share, int $min, int $sort, string $bio = '', string $dir = 'LONG', int $lev = 1) => [
                'kind' => $kind, 'name' => $name, 'pair' => $pair, 'strategy' => $strategy, 'daily_yield_pct' => $daily, 'profit_share_pct' => $share, 'min_units' => $min * 100_000_000,
                'enabled' => true, 'sort' => $sort, 'bio' => $bio ?: null, 'direction' => $dir, 'leverage' => $lev, 'created_at' => $now, 'updated_at' => $now,
            ];
            DB::table('bots')->insert([
                $row('bot', 'BTC Trend Grid', 'BTCUSDT', 'Futures grid', 1.0, 15, 10, 1),
                $row('bot', 'ETH Grid', 'ETHUSDT', 'Spot grid', 0.8, 15, 10, 2),
                $row('bot', 'SOL Swing', 'SOLUSDT', 'Swing', 1.2, 20, 10, 3),
                $row('bot', 'Stable Yield', 'USDCUSDT', 'Arbitrage', 0.3, 10, 10, 4),
                $row('trader', 'SOL Degen', 'SOLUSDT', 'Copy', 1.2, 18, 10, 11, 'Solana ecosystem maximalist. High beta, high reward.', 'LONG', 1),
                $row('trader', 'Whale Alpha', 'ETHUSDT', 'Copy', 0.9, 12, 10, 12, 'Macro-driven swing trader. ETH/BTC core, occasional alts.', 'LONG', 1),
                $row('trader', 'Futures Queen', 'BTCUSDT', 'Copy', 0.8, 14, 10, 13, 'Pro futures desk. Multi-pair systematic strategies.', 'LONG', 1),
                $row('trader', 'ETH Alpha', 'ETHUSDT', 'Copy', 0.7, 12, 10, 14, 'ETH-only trader. Rotates between ETH/BTC and ETH/USDT.', 'LONG', 1),
                $row('trader', 'Gold Scalper', 'XAUTUSDT', 'Copy', 0.6, 15, 10, 15, 'XAU/USDT pure scalper. Tight stops, high frequency.', 'LONG', 1),
                $row('trader', 'Short God', 'BTCUSDT', 'Copy', 0.5, 16, 10, 16, 'Bear market specialist. Asymmetric short setups only.', 'SHORT', 1),
                $row('trader', 'Macro Signal', 'BTCUSDT', 'Copy', 0.4, 8, 10, 17, 'Long-term macro plays driven by on-chain + global liquidity.', 'LONG', 1),
                $row('trader', 'BTC Steady', 'BTCUSDT', 'Copy', 0.3, 10, 10, 18, 'Conservative BTC trend follower. Capital preservation first.', 'LONG', 1),
            ]);
        }
        DB::table('earn_products')->where(['asset' => 'USDT', 'name' => 'USDT Flexible'])->update(['enabled' => true, 'updated_at' => $now]);
    }

    public function down(): void
    {
        Schema::table('bots', function (Blueprint $table): void {
            $table->dropIndex(['kind']);
            $table->dropColumn(['kind', 'bio', 'direction', 'leverage']);
        });
    }
};
