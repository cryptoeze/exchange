<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('spot_limit_orders', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('user_id')->index();
            $t->string('symbol', 24);
            $t->string('base_asset', 16);
            $t->string('side', 4);
            $t->decimal('limit_price', 24, 10);
            $t->unsignedBigInteger('qty');            // base units of 1e-8
            $t->string('reserve_asset', 16);
            $t->unsignedBigInteger('reserved');       // units held in the 'hold' account
            $t->string('status', 10)->default('open'); // open | filled | cancelled
            $t->unsignedBigInteger('spot_order_id')->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->timestamp('closed_at')->nullable();
            $t->index(['status', 'symbol']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spot_limit_orders');
    }
};
