#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

command -v php >/dev/null 2>&1 || { echo "PHP CLI is required (PHP 8.5)." >&2; exit 1; }
command -v composer >/dev/null 2>&1 || { echo "Composer 2 is required." >&2; exit 1; }

if [ ! -f .env ]; then cp .env.example .env; fi
composer install --no-dev --no-scripts
php artisan package:discover --ansi
if ! grep -q '^APP_KEY=base64:' .env; then php artisan key:generate --force; fi
php artisan storage:link --force 2>/dev/null || true

if [ -f public/build/manifest.json ]; then
    echo "Using the prebuilt frontend assets included in this release."
else
node_tmp=""
trap 'if [ -n "$node_tmp" ]; then rm -rf "$node_tmp"; fi' EXIT
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
    command -v curl >/dev/null 2>&1 || { echo "Node/npm are missing and curl is unavailable. Enable Node.js in hosting or install Node 24 LTS." >&2; exit 1; }
    php -r 'exit(class_exists("PharData") && function_exists("gzopen") && in_array("sha256", hash_algos(), true) ? 0 : 1);' || { echo "Node/npm are missing. PHP PharData, zlib, and SHA-256 support are needed to install the official temporary Node runtime." >&2; exit 1; }
    node_version=24.21.0
    case "$(uname -m)" in
        x86_64|amd64) node_arch=x64 ;;
        aarch64|arm64) node_arch=arm64 ;;
        *) echo "Unsupported server CPU for automatic Node setup: $(uname -m)" >&2; exit 1 ;;
    esac
    # Shared hosting may mount /tmp with noexec, so keep the runtime in the
    # account's home directory where downloaded binaries can be executed.
    node_cache="${HOME:-}/.cache"
    if [ -z "${HOME:-}" ] || [ ! -d "$HOME" ] || [ ! -w "$HOME" ]; then
        echo "HOME must point to a writable hosting account directory for temporary Node setup." >&2
        exit 1
    fi
    mkdir -p "$node_cache"
    node_tmp="$(mktemp -d "$node_cache/rushx-node.XXXXXX")"
    node_archive="node-v${node_version}-linux-${node_arch}.tar.gz"
    node_url="https://nodejs.org/dist/v${node_version}"
    curl -fsSL "$node_url/$node_archive" -o "$node_tmp/$node_archive"
    curl -fsSL "$node_url/SHASUMS256.txt" -o "$node_tmp/SHASUMS256.txt"
    cat > "$node_tmp/node-tools.php" <<'PHP'
<?php
[$script, $action, $directory, $archiveName] = $argv;
$archive = $directory.'/'.$archiveName;
if ($action === 'verify') {
    foreach (file($directory.'/SHASUMS256.txt', FILE_IGNORE_NEW_LINES) as $line) {
        if (preg_match('/^([a-f0-9]{64})\s+\*?'.preg_quote($archiveName, '/').'$/', $line, $match)) {
            exit(hash_equals(strtolower($match[1]), hash_file('sha256', $archive)) ? 0 : 1);
        }
    }
    fwrite(STDERR, "Official Node checksum not found.\n"); exit(1);
}
$input = gzopen($archive, 'rb'); $tarPath = $directory.'/node.tar'; $output = fopen($tarPath, 'wb');
if (!$input || !$output) { fwrite(STDERR, "Cannot unpack the Node archive.\n"); exit(1); }
while (!gzeof($input)) { $chunk = gzread($input, 1048576); if ($chunk === false || fwrite($output, $chunk) === false) exit(1); }
gzclose($input); fclose($output);
(new PharData($tarPath))->extractTo($directory, null, true);
PHP
    php "$node_tmp/node-tools.php" verify "$node_tmp" "$node_archive" || { echo "Official Node archive checksum verification failed." >&2; exit 1; }
    php "$node_tmp/node-tools.php" extract "$node_tmp" "$node_archive" || { echo "Could not extract the verified Node archive." >&2; exit 1; }
    PATH="$node_tmp/node-v${node_version}-linux-${node_arch}/bin:$PATH"
    export PATH
fi

npm install --no-audit --no-fund
npm run build
if [ -n "$node_tmp" ]; then rm -rf "$node_tmp"; fi
fi
mkdir -p bootstrap/cache storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs storage/app
chmod -R ug+rwX bootstrap/cache storage
rm -rf node_modules
echo "Ready. The root .htaccess serves the public/ folder. Enable HTTPS, then visit /install."
