<?php
/*
 * Notification e-mails + in-app notifications. Each event can be edited, switched off and test-sent in Admin → Email templates.
 * Placeholders in {braces} are replaced when the message is sent. Master switch: Admin → Settings → "Send emails to users".
 * Emails need working SMTP in .env (MAIL_MAILER=smtp, MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD, MAIL_FROM_ADDRESS).
 */
return [
    'enabled' => (bool) env('MAIL_NOTIFICATIONS', true),
    'events' => [
        'deposit_credited' => ['label' => 'Deposit credited', 'type' => 'success', 'url' => '/funding', 'cta' => 'View balance', 'vars' => ['name', 'amount', 'asset'],
            'subject' => 'Deposit received: {amount} {asset}', 'heading' => 'Your deposit has arrived', 'body' => "Hi {name},\n\nWe credited {amount} {asset} to your Funding account. It is ready to trade, convert or earn on."],
        'withdrawal_requested' => ['label' => 'Withdrawal requested', 'type' => 'info', 'url' => '/withdraw', 'cta' => 'View withdrawals', 'vars' => ['name', 'amount', 'asset', 'network', 'address'],
            'subject' => 'Withdrawal request received', 'heading' => 'We received your withdrawal request', 'body' => "Hi {name},\n\nYour request to withdraw {amount} {asset} on {network} to {address} is waiting for review. You will get another email as soon as it is sent.\n\nIf you did not make this request, contact support immediately."],
        'withdrawal_sent' => ['label' => 'Withdrawal sent', 'type' => 'success', 'url' => '/withdraw', 'cta' => 'View withdrawals', 'vars' => ['name', 'amount', 'asset', 'network', 'address', 'txid'],
            'subject' => 'Withdrawal sent: {amount} {asset}', 'heading' => 'Your withdrawal was sent', 'body' => "Hi {name},\n\n{amount} {asset} was sent on {network} to {address}.\nTransaction ID: {txid}"],
        'withdrawal_rejected' => ['label' => 'Withdrawal rejected', 'type' => 'warn', 'url' => '/withdraw', 'cta' => 'Open withdrawals', 'vars' => ['name', 'amount', 'asset', 'reason'],
            'subject' => 'Withdrawal rejected', 'heading' => 'Your withdrawal was rejected', 'body' => "Hi {name},\n\nYour withdrawal of {amount} {asset} could not be processed and the full amount was returned to your Funding account.\nReason: {reason}"],
        'kyc_approved' => ['label' => 'Identity verified', 'type' => 'success', 'url' => '/kyc', 'cta' => 'Open verification', 'vars' => ['name'],
            'subject' => 'Identity verification approved', 'heading' => 'You are verified', 'body' => "Hi {name},\n\nYour identity verification was approved. Withdrawal limits that need verification are now unlocked."],
        'kyc_rejected' => ['label' => 'Identity rejected', 'type' => 'warn', 'url' => '/kyc', 'cta' => 'Submit again', 'vars' => ['name', 'reason'],
            'subject' => 'Identity verification rejected', 'heading' => 'We could not verify you', 'body' => "Hi {name},\n\nYour identity verification was not approved.\nReason: {reason}\n\nYou can submit clearer documents at any time."],
        'referral_reward' => ['label' => 'Referral reward', 'type' => 'success', 'url' => '/refer', 'cta' => 'View referrals', 'vars' => ['name', 'amount', 'asset'],
            'subject' => 'You earned {amount} {asset} from a referral', 'heading' => 'Referral reward', 'body' => "Hi {name},\n\nA friend you invited made a deposit and you earned {amount} {asset}. It is already in your Funding account."],
        'price_alert' => ['label' => 'Price alert', 'type' => 'info', 'url' => '/alerts', 'cta' => 'View alerts', 'vars' => ['name', 'symbol', 'direction', 'target', 'price'],
            'subject' => 'Price alert: {symbol} {direction} {target}', 'heading' => '{symbol} reached your price', 'body' => "Hi {name},\n\n{symbol} {direction} {target}. Latest price: {price}."],
        'ticket_reply' => ['label' => 'Support ticket reply', 'type' => 'info', 'url' => '/tickets', 'cta' => 'Open ticket', 'vars' => ['name', 'subject'],
            'subject' => 'New reply on your ticket: {subject}', 'heading' => 'Support replied to you', 'body' => "Hi {name},\n\nOur support team replied to your ticket \"{subject}\". Open it to read the answer."],
        'p2p_order' => ['label' => 'P2P order update', 'type' => 'info', 'url' => '/p2p/orders', 'cta' => 'Open order', 'vars' => ['name', 'title', 'detail'],
            'subject' => '{title}', 'heading' => '{title}', 'body' => "Hi {name},\n\n{detail}"],
        'margin_warning' => ['label' => 'Low margin warning (futures)', 'type' => 'warn', 'url' => '/futures', 'cta' => 'Manage position', 'vars' => ['name', 'symbol', 'side', 'leverage', 'price', 'liq_price', 'left_pct'],
            'subject' => 'Margin warning: {symbol} {side} {leverage}x', 'heading' => 'Your position is close to liquidation', 'body' => "Hi {name},\n\nYour {side} {leverage}x position on {symbol} has only {left_pct}% of its safety margin left.\nCurrent price: {price}\nLiquidation price: {liq_price}\n\nAdd funds, reduce risk or close the position to avoid liquidation."],
        'liquidated' => ['label' => 'Position liquidated', 'type' => 'danger', 'url' => '/futures', 'cta' => 'Open futures', 'vars' => ['name', 'symbol', 'side', 'leverage', 'margin'],
            'subject' => 'Position liquidated: {symbol}', 'heading' => 'Your position was liquidated', 'body' => "Hi {name},\n\nYour {side} {leverage}x position on {symbol} reached its liquidation price and was closed. The margin of {margin} USDT was lost."],
        'position_closed' => ['label' => 'Take-profit / stop-loss hit', 'type' => 'info', 'url' => '/futures', 'cta' => 'View history', 'vars' => ['name', 'symbol', 'side', 'reason', 'pnl'],
            'subject' => '{reason}: {symbol}', 'heading' => 'Your position was closed', 'body' => "Hi {name},\n\nYour {side} position on {symbol} was closed by {reason}.\nResult: {pnl} USDT"],
    ],
];
