<?php
/* Peer-to-peer marketplace. Coins are held in escrow (ledger account "p2p") while an order is open. Admin → Settings overrides the on/off switch and fee. */
return [
    'enabled' => (bool) env('P2P_ENABLED', true),
    'fee_pct' => (float) env('P2P_FEE_PCT', 0),          // taken from the coin the buyer receives, 0 = free
    'max_ads' => 10,
    'max_open_orders' => 10,
    'coins' => ['USDT' => 2, 'USDC' => 2, 'BTC' => 6, 'ETH' => 5],   // display decimals
    'fiats' => [
        'USD' => ['US Dollar', '$'], 'EUR' => ['Euro', '€'], 'GBP' => ['British Pound', '£'], 'PKR' => ['Pakistani Rupee', 'Rs'], 'INR' => ['Indian Rupee', '₹'],
        'AED' => ['UAE Dirham', 'AED'], 'SAR' => ['Saudi Riyal', 'SAR'], 'BDT' => ['Bangladeshi Taka', '৳'], 'TRY' => ['Turkish Lira', '₺'], 'NGN' => ['Nigerian Naira', '₦'],
        'MAD' => ['Moroccan Dirham', 'DH'], 'EGP' => ['Egyptian Pound', 'E£'], 'KES' => ['Kenyan Shilling', 'KSh'], 'BRL' => ['Brazilian Real', 'R$'], 'CAD' => ['Canadian Dollar', 'C$'],
    ],
    'methods' => [
        'Bank Transfer', 'SWIFT Wire', 'SEPA Transfer', 'Faster Payments', 'Cash in Person', 'Cash Deposit', 'Western Union', 'MoneyGram',
        'JazzCash', 'Easypaisa', 'NayaPay', 'SadaPay', 'HBL', 'Meezan Bank', 'UBL', 'Bank Alfalah', 'Allied Bank',
        'UPI', 'IMPS', 'Paytm', 'PhonePe', 'Google Pay', 'bKash', 'Nagad',
        'PayPal', 'Wise', 'Revolut', 'Skrill', 'Payoneer', 'Zelle', 'Cash App', 'Venmo', 'Apple Pay',
        'Emirates NBD', 'Al Rajhi Bank', 'M-Pesa', 'MTN Mobile Money', 'Orange Money', 'Papara', 'Pix',
    ],
];
