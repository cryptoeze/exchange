<?php
/* Identity verification. When required, withdrawals need an approved KYC. Admin → Settings overrides this. */
return [
    'required_for_withdrawal' => (bool) env('KYC_REQUIRED_FOR_WITHDRAWAL', false),
];
