<?php
/* Feature switches controlled from .env. Set FEATURE_PNL_SHARE=true to show the profit/loss share card in Futures. */
return [
    'pnl_share' => (bool) env('FEATURE_PNL_SHARE', false),
];
