<?php

return [
    'nowpayments' => [
        'api_key' => env('NOWPAYMENTS_API_KEY'),
        'ipn_secret' => env('NOWPAYMENTS_IPN_SECRET'),
        'base_url' => rtrim((string) env('NOWPAYMENTS_BASE_URL', 'https://api.nowpayments.io'), '/'),
        'timeout' => 15,
    ],
];
