<?php

/*
 * Withdrawals are reviewed and sent manually by an administrator. 'fee' is kept by the platform and is deducted from the amount.
 * 'pattern' keys: evm (0x...), tron (T...), btc. Edit this list to add or remove assets and networks.
 */
$logo = fn (string $file) => "https://nowpayments.io/images/coins/{$file}";
$stable = fn () => [
    ['code' => 'TRC20', 'label' => 'Tron (TRC20)', 'fee' => 1.0, 'arrival' => '~ 2 min', 'pattern' => 'tron'],
    ['code' => 'BEP20', 'label' => 'BNB Smart Chain (BEP20)', 'fee' => 0.5, 'arrival' => '~ 1 min', 'pattern' => 'evm'],
    ['code' => 'ERC20', 'label' => 'Ethereum (ERC20)', 'fee' => 5.0, 'arrival' => '~ 5 min', 'pattern' => 'evm'],
    ['code' => 'POLYGON', 'label' => 'Polygon', 'fee' => 0.5, 'arrival' => '~ 2 min', 'pattern' => 'evm'],
];

return [
    'enabled' => (bool) env('WITHDRAWALS_ENABLED', true),
    'require_verified_email' => (bool) env('WITHDRAW_REQUIRE_VERIFIED_EMAIL', false),
    'max_pending' => (int) env('WITHDRAW_MAX_PENDING', 5),
    'patterns' => [
        'evm' => '/^0x[a-fA-F0-9]{40}$/',
        'tron' => '/^T[1-9A-HJ-NP-Za-km-z]{33}$/',
        'btc' => '/^(bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/',
    ],
    'assets' => [
        ['ticker' => 'USDT', 'name' => 'Tether USDT', 'logo' => $logo('usdttrc20.svg'), 'min' => 5.0, 'networks' => $stable()],
        ['ticker' => 'USDC', 'name' => 'USD Coin', 'logo' => $logo('usdc.svg'), 'min' => 5.0, 'networks' => $stable()],
        ['ticker' => 'BTC', 'name' => 'Bitcoin', 'logo' => $logo('btc.svg'), 'min' => 0.0005, 'networks' => [['code' => 'BTC', 'label' => 'Bitcoin', 'fee' => 0.00012, 'arrival' => '~ 30 min', 'pattern' => 'btc']]],
        ['ticker' => 'ETH', 'name' => 'Ethereum', 'logo' => $logo('eth.svg'), 'min' => 0.005, 'networks' => [['code' => 'ERC20', 'label' => 'Ethereum (ERC20)', 'fee' => 0.0015, 'arrival' => '~ 5 min', 'pattern' => 'evm']]],
    ],
];
