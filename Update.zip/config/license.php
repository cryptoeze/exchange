<?php

return [
    // true ONLY on the owner's own riseway.io install — this is what makes the Telegram /newkey, /keys, /revoke
    // commands and the /license-api/* endpoints actually do anything. Leave false (the default) on every sold
    // copy; the owner's Telegram bot token is never set in those .env files at all, so there is nothing to leak.
    'authority' => (bool) env('LICENSE_AUTHORITY', false),
    // Where a sold copy calls home to activate/check its key. Never needs to change — it's always the vendor's
    // own site, never something the buyer configures.
    'authority_url' => rtrim((string) env('LICENSE_AUTHORITY_URL', 'https://riseway.io'), '/'),
    // How many missed/failed check-ins before a copy locks itself (a transient network hiccup shouldn't lock
    // someone out). Each check-in is scheduled every 10 minutes (routes/console.php).
    'grace_failures' => 6,
];
