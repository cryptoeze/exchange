<?php

return [
    'provider' => env('MARKET_DATA_PROVIDER', 'bybit'),
    'base_url' => rtrim((string) env('MARKET_DATA_BASE_URL', 'https://api.bybit.com'), '/'),
    'timeout_seconds' => (int) env('MARKET_DATA_TIMEOUT_SECONDS', 4),
    'retry_attempts' => (int) env('MARKET_DATA_RETRY_ATTEMPTS', 1),
    'cache_seconds' => (int) env('MARKET_DATA_CACHE_SECONDS', 3),
    'stale_seconds' => (int) env('MARKET_DATA_STALE_SECONDS', 600),
    'instrument_cache_seconds' => (int) env('MARKET_DATA_INSTRUMENT_CACHE_SECONDS', 21600),
    'refresh_seconds' => (int) env('MARKET_DATA_REFRESH_SECONDS', 20),
    'new_listing_days' => (int) env('MARKET_DATA_NEW_LISTING_DAYS', 30),
    'page_size' => 50,
    'top_rank_limit' => 50,
];
