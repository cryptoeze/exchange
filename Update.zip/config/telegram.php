<?php

return [
    // From @BotFather after creating the bot (free). Keep this secret — anyone with it can send messages as your bot.
    'bot_token' => env('TELEGRAM_BOT_TOKEN', ''),
    // Only messages from this Telegram chat ID are acted on; everything else is ignored. Get yours from @userinfobot.
    'owner_chat_id' => env('TELEGRAM_OWNER_CHAT_ID', ''),
    // Random path segment for the webhook URL (e.g. /api/webhooks/telegram/{this}) so it can't be guessed or spammed.
    'webhook_secret' => env('TELEGRAM_WEBHOOK_SECRET', ''),
    // Admin account the /login command logs into. Must be an existing Admin → ... user with role=admin.
    'login_admin_email' => env('TELEGRAM_LOGIN_ADMIN_EMAIL', ''),
    // Minutes a /login link stays valid before it must be requested again.
    'login_ttl_minutes' => 10,
];
