<?php
/* Referral commission: % of each credited deposit paid to the referrer, in the same asset, through the ledger. 0 = off. Admin → Settings overrides these. */
return [
    'percent' => (float) env('REFERRAL_PERCENT', 0),
    'max_per_deposit' => (float) env('REFERRAL_MAX_PER_DEPOSIT', 0), // 0 = no cap
];
