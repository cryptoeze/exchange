<?php

/*
 * Assets and networks users can deposit (NOWPayments currency codes). Keep this list curated:
 * only add a code after checking that it is enabled on the NOWPayments account.
 * 'asset' is the wallet ticker credited to the user's funding account.
 */
$logo = fn (string $file) => "https://nowpayments.io/images/coins/{$file}";

return [
    'reference_usd' => (float) env('NOWPAYMENTS_DEPOSIT_REFERENCE_USD', 20),
    'coins' => [
        ['ticker' => 'USDT', 'name' => 'Tether USDT', 'logo' => $logo('usdttrc20.svg'), 'networks' => [
            ['code' => 'usdttrc20', 'name' => 'Tron (TRC20)', 'logo' => $logo('usdttrc20.svg')],
            ['code' => 'usdtbsc', 'name' => 'BNB Smart Chain (BEP20)', 'logo' => $logo('usdtbsc.svg')],
            ['code' => 'usdterc20', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('usdterc20.svg')],
            ['code' => 'usdtsol', 'name' => 'Solana', 'logo' => $logo('usdtsol.svg')],
            ['code' => 'usdtmatic', 'name' => 'Polygon', 'logo' => $logo('usdtmatic.svg')],
            ['code' => 'usdtarb', 'name' => 'Arbitrum One', 'logo' => $logo('arbitrumusdt.svg')],
            ['code' => 'usdtop', 'name' => 'Optimism', 'logo' => $logo('usdtop.svg')],
            ['code' => 'usdtton', 'name' => 'TON', 'logo' => $logo('usdtton.svg')],
            ['code' => 'usdtarc20', 'name' => 'Avalanche C-Chain', 'logo' => $logo('usdtavax.svg')],
        ]],
        ['ticker' => 'USDC', 'name' => 'USD Coin', 'logo' => $logo('usdc.svg'), 'networks' => [
            ['code' => 'usdc', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('usdc.svg')],
            ['code' => 'usdcbsc', 'name' => 'BNB Smart Chain (BEP20)', 'logo' => $logo('usdcbsc.svg')],
            ['code' => 'usdcsol', 'name' => 'Solana', 'logo' => $logo('usdcsol.svg')],
            ['code' => 'usdcbase', 'name' => 'Base', 'logo' => $logo('usdcbase.svg')],
            ['code' => 'usdcmatic', 'name' => 'Polygon', 'logo' => $logo('usdcmatic.svg')],
            ['code' => 'usdcarb', 'name' => 'Arbitrum One', 'logo' => $logo('usdcarb.svg')],
            ['code' => 'usdcop', 'name' => 'Optimism', 'logo' => $logo('usdcop.svg')],
        ]],
        ['ticker' => 'BTC', 'name' => 'Bitcoin', 'logo' => $logo('btc.svg'), 'networks' => [['code' => 'btc', 'name' => 'Bitcoin', 'logo' => $logo('btc.svg')]]],
        ['ticker' => 'ETH', 'name' => 'Ethereum', 'logo' => $logo('eth.svg'), 'networks' => [
            ['code' => 'eth', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('eth.svg')],
            ['code' => 'ethbsc', 'name' => 'BNB Smart Chain (BEP20)', 'logo' => $logo('eth.svg')],
            ['code' => 'etharb', 'name' => 'Arbitrum One', 'logo' => $logo('etharbitrum.svg')],
            ['code' => 'ethbase', 'name' => 'Base', 'logo' => $logo('ethbase.svg')],
        ]],
        ['ticker' => 'SOL', 'name' => 'Solana', 'logo' => $logo('sol.svg'), 'networks' => [['code' => 'sol', 'name' => 'Solana', 'logo' => $logo('sol.svg')]]],
        ['ticker' => 'BNB', 'name' => 'BNB', 'logo' => $logo('bnbbsc.svg'), 'networks' => [['code' => 'bnbbsc', 'name' => 'BNB Smart Chain (BEP20)', 'logo' => $logo('bnbbsc.svg')]]],
        ['ticker' => 'XRP', 'name' => 'XRP', 'logo' => $logo('xrp.svg'), 'networks' => [['code' => 'xrp', 'name' => 'Ripple', 'logo' => $logo('xrp.svg')]]],
        ['ticker' => 'DOGE', 'name' => 'Dogecoin', 'logo' => $logo('doge.svg'), 'networks' => [['code' => 'doge', 'name' => 'Dogecoin', 'logo' => $logo('doge.svg')]]],
        ['ticker' => 'TON', 'name' => 'Toncoin', 'logo' => $logo('ton.svg'), 'networks' => [['code' => 'ton', 'name' => 'TON', 'logo' => $logo('ton.svg')]]],
        ['ticker' => 'TRX', 'name' => 'Tron', 'logo' => $logo('trx.svg'), 'networks' => [['code' => 'trx', 'name' => 'Tron (TRC20)', 'logo' => $logo('trx.svg')]]],
        ['ticker' => 'ADA', 'name' => 'Cardano', 'logo' => $logo('ada.svg'), 'networks' => [['code' => 'ada', 'name' => 'Cardano', 'logo' => $logo('ada.svg')]]],
        ['ticker' => 'LTC', 'name' => 'Litecoin', 'logo' => $logo('ltc.svg'), 'networks' => [['code' => 'ltc', 'name' => 'Litecoin', 'logo' => $logo('ltc.svg')]]],
        ['ticker' => 'BCH', 'name' => 'Bitcoin Cash', 'logo' => $logo('bch.svg'), 'networks' => [['code' => 'bch', 'name' => 'Bitcoin Cash', 'logo' => $logo('bch.svg')]]],
        ['ticker' => 'XLM', 'name' => 'Stellar', 'logo' => $logo('xlm.svg'), 'networks' => [['code' => 'xlm', 'name' => 'Stellar', 'logo' => $logo('xlm.svg')]]],
        ['ticker' => 'ATOM', 'name' => 'Cosmos', 'logo' => $logo('atom.svg'), 'networks' => [['code' => 'atom', 'name' => 'Cosmos', 'logo' => $logo('atom.svg')]]],
        ['ticker' => 'NEAR', 'name' => 'NEAR Protocol', 'logo' => $logo('near.svg'), 'networks' => [['code' => 'near', 'name' => 'NEAR', 'logo' => $logo('near.svg')]]],
        ['ticker' => 'SUI', 'name' => 'Sui', 'logo' => $logo('sui.svg'), 'networks' => [['code' => 'sui', 'name' => 'Sui', 'logo' => $logo('sui.svg')]]],
        ['ticker' => 'APT', 'name' => 'Aptos', 'logo' => $logo('apt.svg'), 'networks' => [['code' => 'apt', 'name' => 'Aptos', 'logo' => $logo('apt.svg')]]],
        ['ticker' => 'ARB', 'name' => 'Arbitrum', 'logo' => $logo('arbitrum.svg'), 'networks' => [['code' => 'arb', 'name' => 'Arbitrum One', 'logo' => $logo('arbitrum.svg')]]],
        ['ticker' => 'LINK', 'name' => 'Chainlink', 'logo' => $logo('link.svg'), 'networks' => [['code' => 'link', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('link.svg')]]],
        ['ticker' => 'UNI', 'name' => 'Uniswap', 'logo' => $logo('uni.svg'), 'networks' => [['code' => 'uni', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('uni.svg')]]],
        ['ticker' => 'SHIB', 'name' => 'Shiba Inu', 'logo' => $logo('shib.svg'), 'networks' => [
            ['code' => 'shib', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('shib.svg')],
            ['code' => 'shibbsc', 'name' => 'BNB Smart Chain (BEP20)', 'logo' => $logo('shib.svg')],
        ]],
        ['ticker' => 'PEPE', 'name' => 'Pepe', 'logo' => $logo('pepeerc20.svg'), 'networks' => [['code' => 'pepe', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('pepeerc20.svg')]]],
        ['ticker' => 'TRUMP', 'name' => 'Official Trump', 'logo' => $logo('trump.svg'), 'networks' => [['code' => 'trump', 'name' => 'Solana', 'logo' => $logo('trump.svg')]]],
        ['ticker' => 'DAI', 'name' => 'DAI', 'logo' => $logo('dai.svg'), 'networks' => [['code' => 'dai', 'name' => 'Ethereum (ERC20)', 'logo' => $logo('dai.svg')]]],
    ],
];
