<?php
return ['driver'=>env('HASH_DRIVER','bcrypt'),'bcrypt'=>['rounds'=>env('BCRYPT_ROUNDS',12),'verify'=>true,'limit'=>null],'argon'=>['memory'=>65536,'threads'=>1,'time'=>4,'verify'=>true],'rehash_on_login'=>true,'default'=>['algo'=>PASSWORD_BCRYPT,'options'=>['cost'=>env('BCRYPT_ROUNDS',12)]]];
