<?php

return [
    // Fee charged on the USDT side of every spot fill (0.0002 = 0.02%).
    'spot_fee_rate' => (float) env('TRADING_SPOT_FEE_RATE', 0.0002),
    'spot_min_quote_usdt' => (float) env('TRADING_SPOT_MIN_QUOTE_USDT', 1),
    'spot_max_quote_usdt' => (float) env('TRADING_SPOT_MAX_QUOTE_USDT', 1000000),
    // Refuse to fill against a price snapshot older than this (provider outage protection).
    'max_price_age_seconds' => (int) env('TRADING_MAX_PRICE_AGE_SECONDS', 60),
    'quote_asset' => 'USDT',
];
