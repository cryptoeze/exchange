<?php

return [
    // Fee charged on the USDT side of every spot fill (0.0002 = 0.02%).
    'spot_fee_rate' => (float) env('TRADING_SPOT_FEE_RATE', 0.0002),
    'spot_min_quote_usdt' => (float) env('TRADING_SPOT_MIN_QUOTE_USDT', 1),
    'spot_max_quote_usdt' => (float) env('TRADING_SPOT_MAX_QUOTE_USDT', 1000000),
    // Refuse to fill against a price snapshot older than this (provider outage protection).
    'max_price_age_seconds' => (int) env('TRADING_MAX_PRICE_AGE_SECONDS', 60),
    'quote_asset' => 'USDT',
    // Futures (isolated margin, house-matched at the server-side Bybit price).
    'futures_enabled' => (bool) env('TRADING_FUTURES_ENABLED', true),
    'futures_fee_rate' => (float) env('TRADING_FUTURES_FEE_RATE', 0.0005),      // on notional, charged at open and at close
    'futures_max_leverage' => (int) env('TRADING_FUTURES_MAX_LEVERAGE', 100),
    'futures_min_margin_usdt' => (float) env('TRADING_FUTURES_MIN_MARGIN_USDT', 1),
    'futures_max_margin_usdt' => (float) env('TRADING_FUTURES_MAX_MARGIN_USDT', 100000),
    'futures_max_positions' => (int) env('TRADING_FUTURES_MAX_POSITIONS', 20),
    'futures_maintenance_rate' => (float) env('TRADING_FUTURES_MAINTENANCE_RATE', 0.005), // liquidation when margin+PnL <= notional x this
];
