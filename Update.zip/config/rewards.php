<?php

/*
 * Daily check-in reward, paid by the platform into the Funding account as real balance.
 * One claim per UTC day. Claiming on consecutive days moves through the 7-day cycle; a missed day restarts at day 1.
 * Amounts: comma separated list of 7 values, e.g. DAILY_REWARD_AMOUNTS=0.10,0.15,0.25,0.40,0.60,0.80,2.00
 */
$amounts = array_map('floatval', array_filter(array_map('trim', explode(',', (string) env('DAILY_REWARD_AMOUNTS', '0.10,0.15,0.25,0.40,0.60,0.80,2.00'))), 'strlen'));

return [
    'enabled' => (bool) env('DAILY_REWARD_ENABLED', true),
    'asset' => 'USDT',
    'amounts' => count($amounts) === 7 ? $amounts : [0.10, 0.15, 0.25, 0.40, 0.60, 0.80, 2.00],
];
