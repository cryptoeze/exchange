<?php

/*
 * Deposit bonus: a percentage of every credited deposit is added to the user's Funding account as real,
 * spendable, withdrawable balance (ledger type 'deposit_bonus'). Paid by the platform.
 * Switch off with DEPOSIT_BONUS_ENABLED=false. Each deposit can be bonused only once (idempotency key).
 */
return [
    'enabled' => (bool) env('DEPOSIT_BONUS_ENABLED', true),
    'percent' => (float) env('DEPOSIT_BONUS_PERCENT', 12),
    'first_only' => (bool) env('DEPOSIT_BONUS_FIRST_ONLY', false),
    'max_per_deposit' => (float) env('DEPOSIT_BONUS_MAX', 0), // in the deposited asset; 0 = no cap
];
