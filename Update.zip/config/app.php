<?php
return [
 'name'=>env('APP_NAME','RushX'),'support_email'=>env('SUPPORT_EMAIL',''),'maintenance_mode'=>false,'maintenance_message'=>'We are upgrading '.env('APP_NAME','RushX').'. Please check back shortly.','env'=>env('APP_ENV','production'),'debug'=>(bool)env('APP_DEBUG',false),'url'=>env('APP_URL','http://localhost'),'timezone'=>'UTC','locale'=>env('APP_LOCALE','en'),'fallback_locale'=>env('APP_FALLBACK_LOCALE','en'),'faker_locale'=>env('APP_FAKER_LOCALE','en_US'),'key'=>env('APP_KEY'),'cipher'=>'AES-256-CBC','previous_keys'=>array_filter(explode(',',env('APP_PREVIOUS_KEYS',''))),'maintenance'=>['driver'=>env('APP_MAINTENANCE_DRIVER','file'),'store'=>env('APP_MAINTENANCE_STORE','database')]
];
