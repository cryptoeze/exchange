<?php
/* Display-only conversion. Balances are always stored and traded in USD/USDT; PKR is shown as an approximation. */
return [
    'pkr_rate' => (float) env('PKR_RATE', 278),
];
