<?php
/* Master switches for the money gateways. Admin → Gateways overrides these. */
return [
    'auto_deposit' => (bool) env('GATEWAY_AUTO_DEPOSIT', true),
    'manual_deposit' => (bool) env('GATEWAY_MANUAL_DEPOSIT', true),
];
