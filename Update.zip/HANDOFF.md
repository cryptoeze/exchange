# RushX project handoff

Updated: 2026-09-30

## Project and deployed environment

- Laravel 13, PHP 8.5 target, Inertia 3, React, TypeScript, Tailwind CSS 4.
- Hostinger shared hosting domain: `riseway.io`; project root on server: `/home/u597262569/domains/riseway.io/public_html`.
- The project is extracted in `public_html`. Root `.htaccess` serves `public/` and protects application files. Always preserve server `.env` and `vendor/` when uploading an update.
- This local checkout has `composer.json` but no `composer.lock`. The live Hostinger folder already has its installed dependencies/lock from the prior deployment; preserve those. For a new clean install, generate and review a lock with PHP 8.5 Composer rather than borrowing one from a different project.
- User-facing installer is `/install`. User auth is `/login`; admin auth is separate at `/admin/login`.
- No Laravel runtime, PHP CLI, or Composer is available in this local workspace. PHP tests, PHP lint, and migrations cannot be run here.

## Current release scope

- Public landing page with shared RushX navigation, local Inter and JetBrains Mono fonts, provided coin icons, responsive layouts, and persistent light/dark theme.
- Shared header uses the reference order with Institutional, functional inline crypto search, outlined actions, real server-provided auth state, guest/auth-specific UI, authenticated profile/assets/utility menus, and mobile navigation. Theme remains reachable from the guest toolbar, authenticated profile menu, and mobile drawer.
- Authenticated account dashboard and separate Rushpay-style admin dashboard. Admin users/detail screens are read-only.
- New responsive Markets page with Spot/Crypto and Linear/Futures tabs, Favorites, category filters (All/Top/New/AI/Meme/DeFi/Layer 1), search, highlights, range bar, volume, pagination, price flashes, stale/loading/error states, mobile cards, and market details.
- Markets data is public and informational. Spot/Futures trading, chart history, AI bots, wallet, deposits, withdrawals, and balance mutation are not connected. Market trade links land on existing pages that explicitly explain this limitation.
- The main page's ticker preview and Markets page share the same Laravel market-data API.

## Market data architecture

- `config/market-data.php` + `.env.example` centralize provider and cache settings. Defaults use `MARKET_DATA_PROVIDER=bybit` and `MARKET_DATA_BASE_URL=https://api.bybit.com`.
- `app/Services/MarketDataService.php` fetches public `/v5/market/tickers` and `/v5/market/instruments-info` for `spot` and `linear`, pages through linear instrument metadata, filters active USDT pairs, normalizes the payload, sorts/ranks markets, derives highlights, caches snapshots briefly, and serves a marked stale last-good snapshot on provider failures.
- `GET /api/markets?type=spot|futures|both` is the single public internal endpoint. It is rate-limited and returns only normalized client-safe data.
- `config/market-assets.php` is the curated metadata boundary for names/categories/icons. Unknown assets are displayed by their symbols and are left uncategorized. “New” uses provider `launchTime` metadata.
- Public ticker data requires no API key, API secret, or SMTP. No provider secret exists in the browser.
- `GET/POST/DELETE /api/market-favorites` requires login. `user_market_favorites` is the only new market-related table; guests use localStorage. No live tickers are stored in MySQL.
- Admin > Settings reads cached `MarketDataService::health()` and shows provider, connection state, last update, market counts, cache interval, and whether credentials are needed. It does not expose credentials or edit `.env`.
- Bybit reference docs: [Get Tickers](https://bybit-exchange.github.io/docs/v5/market/tickers), [Get Instruments Info](https://bybit-exchange.github.io/docs/v5/market/instrument).

## Important files

- `routes/web.php`: installer, auth, platform pages, market API/favorites/detail routes, and admin routes.
- `app/Http/Controllers/MarketDataController.php`, `MarketFavoriteController.php`, `MarketDetailController.php`.
- `resources/js/pages/MarketsPage.tsx` and `MarketDetail.tsx`; reusable definitions in `resources/js/types/market.ts`; page styling in `resources/css/markets.css`.
- `resources/js/components/landing/MarketTable.tsx`: compact homepage spot ticker using the same `/api/markets` source.
- `app/Http/Controllers/AdminController.php`, `resources/js/pages/Admin/Section.tsx`: read-only admin settings/market health.
- `database/migrations/2026_09_30_000002_create_user_market_favorites_table.php`: additive favorites migration.
- `prepare-hosting.sh`, `UPDATE-INSTRUCTIONS.txt`: shared hosting preparation and update steps.

## Data and security boundaries

- Do not create or show fake prices, balances, trades, funding activity, or market provider health. An unavailable indicator is preferable to invented data.
- Never delete production users or mutate balances without explicit instructions, reviewed backup, and actual ledger/business rules.
- No wallet or transaction ledger exists. Admin deposits/withdrawals remain placeholders; do not implement manual financial credits/debits in this Markets task.
- Keep `.env`, `vendor/`, `node_modules/`, logs, sessions, and install lock out of ZIPs. Do not replace the server's existing `.env` or `vendor/` during extraction.
- Configure SMTP separately if welcome or password-reset email delivery is needed. Market data does not use SMTP.

## Verification status and deployment

- Passed locally: TypeScript `tsc --noEmit` and Vite production asset build.
- Not verifiable in this local environment: PHP syntax/lint, Laravel feature tests, actual Bybit live calls from the server, MySQL migration, user favorite persistence, and Hostinger runtime. Do not state these passed until run on a PHP-enabled environment.
- The endpoint tests are in `tests/Feature/MarketDataEndpointTest.php` and cover normalized spot/futures payloads plus a safe provider failure response.
- `Update.zip` contains prebuilt assets; upload/extract over `public_html` while preserving `.env` and `vendor/`, then run once from that directory:

  `composer dump-autoload --no-dev --no-scripts && php artisan migrate --force && php artisan optimize:clear`

- Then open `https://riseway.io/markets` and `/admin/settings`. If there is an error, inspect `storage/logs/laravel.log` and fix that before proceeding. No Node/npm is required on Hostinger for this release.

## Wallet ledger + spot trading (added 2026-10-01)
- Independent (house-matched) exchange: Bybit is used ONLY as the public price feed. The operator is the counterparty; profits are paid by the operator.
- Tables: `wallet_balances` (integer units of 1e-8), `ledger_entries` (append-only journal, unique idempotency_key), `spot_orders`, `admin_audit_logs`. Migration: `2026_10_01_000001_create_wallet_ledger_tables.php` (additive).
- Only `App\Services\LedgerService::apply()` may change a balance (row lock + journal row). `App\Support\Money` does exact integer parsing/formatting (no floats, no bcmath needed).
- `SpotTradingService` fills market orders at the SERVER-side price from `MarketDataService` (never a browser price), rejects stale prices, charges `TRADING_SPOT_FEE_RATE` on the USDT side. Spot holdings live in the `funding` account.
- Routes: `GET /api/wallet`, `POST /api/wallet/transfer` (funding<->trading USDT), `GET/POST /api/spot/orders`, admin `POST /admin/users/{user}/wallet` (credit/debit with mandatory reason, idempotency key, audit log).
- Pages: `/assets` = Overview (live valuation from /api/markets), `/spot` = Spot terminal (real balances/orders). Admin user page has a Wallet panel.
- Not built yet: futures, withdrawals workflow, KYC. (Deposits: see below.) Run `php vendor/bin/phpunit` (sqlite) — 11 tests cover ledger, idempotency, trading math, auth.

## Auto deposits (added 2026-10-01)
- Provider: NOWPayments. `App\Services\NowPaymentsClient` (HTTP + IPN HMAC-SHA512 check), `App\Services\DepositService` (create address, verify with provider API, credit once), `DepositController` (`GET/POST /api/deposits`, `GET /api/deposits/{order}`, webhook `POST /api/webhooks/nowpayments`, CSRF-exempt but signature-checked).
- Coins/networks: `config/deposit-coins.php` (curated). Only add a code after enabling it on the NOWPayments account.
- Credit rule: only status `finished` is credited, using `actually_paid`, to the funding wallet of the deposit's asset (ledger type `deposit`, idempotency key `deposit:{id}`). The webhook body is never trusted: the payment is re-read from the provider. `partially_paid` is NOT auto-credited; it shows "contact support" and needs admin handling.
- An open (`waiting`) address for the same currency is reused for 60 minutes.
- Page: `/deposit` (Deposit.tsx). Without NOWPAYMENTS_API_KEY the page shows "being set up" and the API returns 503.
- Tests: `tests/Feature/DepositTest.php` (Http::fake). Not yet exercised against the live NOWPayments API.

## Account pages (Funding, Trading, Analysis, Order center, Fees)
- `/funding`, `/trading` -> `AccountPage.tsx` (kind prop); `/analysis`, `/orders`, `/fees` -> `Analysis`, `OrderCenter`, `Fees`. `/dashboard` redirects to `/assets`.
- `GET /api/account/summary` (AccountController): deposits, withdrawals, 30-day volume/fees, trade count, win rate (average-cost method, null until a sell), fee rate. All from ledger/orders.
- `GET /api/spot/orders` accepts `side`, `days`, `q`, `before`, `limit` and returns `hasMore`.
- `GET /api/wallet?account=trading` returns Trading-account history.
- Header search (`HeaderSearch.tsx`) lists live spot/futures pairs from `/api/markets?type=both`.
- Not built yet: Grow/Earn, Bots, Convert, Withdraw, Futures trading.

## Earn (staking) and Bots (yield strategies)
- Tables: earn_products, earn_positions, bots, bot_follows, bot_claims (migration 2026_10_02_000001). New ledger accounts `earn` and `bots`.
- Earn: simple interest = principal x APR x elapsed seconds / year, paid into `funding` (type earn_interest). Settled lazily on stake/unstake/page view and by `php artisan earn:accrue`. Seeded product "USDT Flexible 3.5%" is DISABLED until an admin switches it on.
- Bots: each completed 24h cycle pays capital x daily yield, minus platform share, to `funding` (type bot_profit). Unclaimed backlog capped at 30 cycles. No random values. Auto-claim runs on page view and `php artisan bots:settle`. No bots are seeded.
- Admin: /admin/earn and /admin/bots (create/edit, enable/disable). Changing a rate first pays everyone at the old rate. All saves are audit-logged. Profits are paid by the platform, so the admin must keep a reserve.
- Optional cron (Hostinger): `* * * * * cd ~/public_html && php artisan schedule:run >> /dev/null 2>&1` runs both commands hourly.

## Futures (isolated margin, house-matched)
- Page `/futures` (FuturesPage.tsx); API `/api/futures/{state,open,close,tpsl}`; `FuturesService` is the only code that opens/closes positions. Margin moves trading -> `futures` ledger account, returns to `trading` with PnL on close (types futures_open / futures_close / futures_liquidation / futures_fee).
- Entry, close and trigger prices come from the SERVER market snapshot (Bybit linear), never from the browser. A user cannot lose more than the margin. Fee = TRADING_FUTURES_FEE_RATE x position size at open and at close.
- TP / SL / liquidation are enforced by `FuturesService::sweep()`: on every futures API call for that user, and globally by `php artisan futures:sweep` (scheduled every minute — run `schedule:run` from cron for positions of offline users). Liquidation when margin + PnL <= notional x TRADING_FUTURES_MAINTENANCE_RATE.
- Admin: /admin/futures shows open positions, long/short exposure, unrealized PnL owed, fees earned. Limits are in .env (TRADING_FUTURES_*).
- Market data cache is ~12s, so fills can be up to ~12s old; lower `market-data.cache_seconds` if tighter fills are needed.

## Withdraw, manual deposit, transfer, real-time speed
- **Withdraw** (`/withdraw`): assets/networks/fees/min in `config/withdraw.php`. Request moves the amount out of Funding immediately (`withdrawal_hold`); user can cancel while pending (refund). Admin `/admin/withdrawals`: send funds from your wallet, then "Mark sent" (optional TX hash) or "Reject & refund". Env: `WITHDRAWALS_ENABLED`, `WITHDRAW_MAX_PENDING`, `WITHDRAW_REQUIRE_VERIFIED_EMAIL`.
- **Manual USDT deposit** (Deposit page → "Manual USDT"): admin sets TRC20/BEP20 receiving addresses at `/admin/deposits` (seeded OFF with empty addresses; cannot be enabled without an address). User pays, submits amount + TXID; admin verifies in the wallet and clicks Credit (amount editable, credited once via idempotency key `manual-deposit:{id}`). Duplicate TXIDs are rejected. NOWPayments flow untouched.
- **Transfer** (`/transfer`): Funding <-> Trading USDT page (same API as before).
- **Speed**: `MARKET_DATA_CACHE_SECONDS` default 12 -> 3 (min 2), `TRADING_MAX_PRICE_AGE_SECONDS` 60 -> 20; browser polling is 1.5–3 s (wallet 3s, prices 2s, futures 1.5s, header search 2s). On shared hosting, lower cache = more Bybit calls; raise it in `.env` if Bybit rate-limits.
- Deploy: `php artisan migrate --force` (new migration `2026_10_04_000001`), `php artisan optimize:clear`.

## Convert, menu cleanup, futures chart
- **Convert** (`/convert`, logged-in): instant zero-fee conversion inside Funding at the SERVER price (browser price is only an estimate). Pairs via USDT prices; size limits reuse `trading.spot_min/max_quote_usdt`. Table `conversions` (migration `2026_10_05_000001`). API `GET/POST /api/convert`.
- Menu: DEX and Events & Options removed (Agent Trade Kit / Marketplace were never in this build). Copy trading stays (Soon).
- Futures chart: TradingView side toolbar, context menu and drawing tools disabled on all screens; only our own timeframe bar remains.

## Deposit bonus, profile menu, Grow/Wallet menus
- **Deposit bonus** (`config/bonus.php`): 12% of every credited deposit (NOWPayments on `finished`, manual on admin approval, based on the amount credited) is added to Funding as ordinary ledger balance (`deposit_bonus`), once per deposit (idempotent). Tradable, convertible, withdrawable. Env: `DEPOSIT_BONUS_ENABLED`, `DEPOSIT_BONUS_PERCENT` (12), `DEPOSIT_BONUS_FIRST_ONLY`, `DEPOSIT_BONUS_MAX`. Banner on the Deposit page.
- Profile menu: name + Verified badge, 8-digit UID (copy on click, `uidOf()` in RushXHeader), live Est. Total Value (Funding + Trading, hide/show eye).
- Menus: Grow has Earn sub-list (all -> /earn); Institutional replaced by Wallet (Deposit/Withdraw/Transfer/Convert).

## Copy trading + seeded catalogue
- **Copy Trading** (`/copy`): same yield engine as Trading Bots, told apart by `bots.kind` = `trader` (migration `2026_10_06_000001`). A follower allocates capital to a trader; every completed 24h cycle pays capital x daily return minus the trader's share to Funding; stop any time and capital returns. No fake PnL/win-rate: ROI shown = daily return x days live (what the engine actually pays), followers/AUM are real. Margin-per-trade / copy-mode / stop-loss from the old design are NOT included (they would do nothing).
- Admin: `/admin/traders` (name, bio, LONG/SHORT + leverage labels, daily return, trader share, min, open/closed). `/admin/bots` now lists only kind=bot.
- The migration SEEDS (only if `bots` is empty): 4 enabled bots (1.0/0.8/1.2/0.3 % per day) and 8 enabled copy traders (1.2 ... 0.3 % per day), and ENABLES the "USDT Flexible" Earn product (3.5% APR). All of this is paid from the platform to users — edit or close in Admin -> Earn / Bots / Copy traders before launch if the rates are not what you want.
- Manual deposit addresses are still empty/off (need your real TRC20/BEP20 addresses): Admin -> Deposits.

## Deploy (this combined release)
    composer dump-autoload --no-dev --no-scripts
    php artisan migrate --force        # 2026_10_04 (withdrawals/manual deposits), 2026_10_05 (conversions), 2026_10_06 (copy traders + seed)
    php artisan optimize:clear
    cron: * * * * * cd ~/public_html && php artisan schedule:run >> /dev/null 2>&1
    .env (optional): MARKET_DATA_CACHE_SECONDS=3  DEPOSIT_BONUS_PERCENT=12  WITHDRAWALS_ENABLED=true

## Cron + API keys (all in one)
- ONE cron line runs everything (Hostinger -> Advanced -> Cron Jobs, every minute): `* * * * * cd ~/public_html && php artisan schedule:run >> /dev/null 2>&1`
  It fires: `futures:sweep` every minute (TP/SL/liquidation), `earn:accrue` hourly, `bots:settle` hourly (also covers copy traders). Use the PHP 8.5 binary path if plain `php` is older, e.g. `/usr/bin/php8.5` (check in hPanel).
- Prices: NO key needed. The server reads Bybit's public market endpoints (`MARKET_DATA_BASE_URL=https://api.bybit.com`); live from the first request. `MARKET_DATA_API_KEY/SECRET` stay empty.
- NOWPayments: `NOWPAYMENTS_API_KEY` + `NOWPAYMENTS_IPN_SECRET` in `.env`; IPN URL in the NOWPayments dashboard: `https://riseway.io/api/webhooks/nowpayments`.
- Header menus open on mouse hover (desktop); touch devices keep tap-to-open.

## Light mode
- resources/css/light-theme.css (loaded last, wins by specificity): tinted canvas (#e7ebe2) instead of white, soft card shadows, stronger borders, deeper greens (#0a7b54) and reds, darker lime text accents. Tune the palette there.

## Mobile home + bottom nav
- `/dashboard` (post-login landing) is now `Home` (resources/js/pages/Home.tsx): on phones (<=820px) an app-style home (balance + eye, live ring, Today's PnL pill green/red, quick actions Deposit/Withdraw/Transfer/Convert/Copy, auto-scrolling promo cards, live market tabs Top 10/Gainers/New/Losers at 2s). On wider screens it forwards to /assets.
- `MobileNav` (Home, Markets, Trade, Earn, Assets) is shown only on phones; mounted on Home, Overview, Deposit, Withdraw, Transfer, Convert and the AccountLayout pages. Not mounted on Spot/Futures/Markets (they have their own full-screen layouts).
- Not copied from the reference (not real here): Rewards tab, P2P, scan icon, notification bell badge, TradFi tab, lottie animations.

## Mobile markets
- `/markets` on phones (<=820px) now shows `MobileMarkets` (MarketsPage.tsx + css/mobile-markets.css): large collapsing title, chips (Favorites / All / Top volume / Gainers / Losers / New), star favorites (same server-side favorites as desktop), live rows (list refreshes every ~3s), search drawer, tap a row for the detail sheet (price, 24h high/low/change, Trade -> /spot, Convert -> /convert), bottom nav. Desktop layout is untouched. Spot markets only on phone.

## Mobile futures
- On phones (<=820px) FuturesPage switches to an app layout (css/mobile-futures.css): section tabs (Convert/Spot/Futures/Bots/Copy), pair header with PERP chip, big coloured price + 24h stats, timeframe bar with neon underline, 300px chart, ONE shared form (Isolated, leverage, margin, 25/50/75/Max, TP/SL, leverage slider, fee/size, balance) with Buy/Long + Sell/Short buttons beside a compact order book with buy/sell ratio, positions as cards (PnL/ROE, TP/SL edit, Close), bottom nav. Desktop layout unchanged. Server rules (price, fees, liquidation) are identical for both layouts.

## Daily rewards (`/rewards`)
- One claim per UTC day, paid by the platform into Funding as real balance (ledger type `daily_reward`, idempotency key `daily-reward:{user}:{date}`). Consecutive days advance the 7-day cycle (default $0.10, 0.15, 0.25, 0.40, 0.60, 0.80, 2.00); a missed day restarts at day 1; after day 7 the cycle restarts. Table `daily_checkins` (migration `2026_10_07_000001`). API `GET /api/rewards`, `POST /api/rewards/claim`.
- Config: `DAILY_REWARD_ENABLED`, `DAILY_REWARD_AMOUNTS` (7 comma-separated numbers). Cost to the platform per active user per week = sum of the 7 amounts.
- Phone bottom nav now: Home, Markets, Trade, Rewards, Assets (Earn is in the Grow menu and on the Home cards).

## Mobile Assets (/assets, <=820px)
- `components/MobileAssets.tsx` + `css/mobile-assets.css`; Overview.tsx switches to it on phones (matchMedia). Real balances only; sparkline is a trend-direction icon from 24h change; Manage Coins hides coins (localStorage `rushx-hidden-coins`).

## Home balance card + mobile live chat
- Home: search, Add Funds, USD/PKR switch (config/currency.php, env PKR_RATE=278, display only). Quick-action row removed.
- Tidio launcher hidden on <=820px (app.blade.php); chat icon in Home/Assets/RushXHeader opens it via window.rushxChat(); closing hides it again.
