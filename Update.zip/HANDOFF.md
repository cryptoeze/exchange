# RushX project handoff

Updated: 2026-09-30

## Project and deployed environment

- Laravel 13, PHP 8.5 target, Inertia 3, React, TypeScript, Tailwind CSS 4.
- Hostinger shared hosting domain: `riseway.io`; project root on server: `/home/u597262569/domains/riseway.io/public_html`.
- The project is extracted in `public_html`. Root `.htaccess` serves `public/` and protects application files. Always preserve server `.env` and `vendor/` when uploading an update.
- This local checkout has `composer.json` but no `composer.lock`. The live Hostinger folder already has its installed dependencies/lock from the prior deployment; preserve those. For a new clean install, generate and review a lock with PHP 8.5 Composer rather than borrowing one from a different project.
- User-facing installer is `/install`. User auth is `/login`; admin auth is separate at `/admin/login`.
- No Laravel runtime, PHP CLI, or Composer is available in this local workspace. PHP tests, PHP lint, and migrations cannot be run here.

## Current release scope

- Public landing page with shared RushX navigation, local Inter and JetBrains Mono fonts, provided coin icons, responsive layouts, and persistent light/dark theme.
- Shared header uses the reference order with Institutional, functional inline crypto search, outlined actions, real server-provided auth state, guest/auth-specific UI, authenticated profile/assets/utility menus, and mobile navigation. Theme remains reachable from the guest toolbar, authenticated profile menu, and mobile drawer.
- Authenticated account dashboard and separate Rushpay-style admin dashboard. Admin users/detail screens are read-only.
- New responsive Markets page with Spot/Crypto and Linear/Futures tabs, Favorites, category filters (All/Top/New/AI/Meme/DeFi/Layer 1), search, highlights, range bar, volume, pagination, price flashes, stale/loading/error states, mobile cards, and market details.
- Markets data is public and informational. Spot/Futures trading, chart history, AI bots, wallet, deposits, withdrawals, and balance mutation are not connected. Market trade links land on existing pages that explicitly explain this limitation.
- The main page's ticker preview and Markets page share the same Laravel market-data API.

## Market data architecture

- `config/market-data.php` + `.env.example` centralize provider and cache settings. Defaults use `MARKET_DATA_PROVIDER=bybit` and `MARKET_DATA_BASE_URL=https://api.bybit.com`.
- `app/Services/MarketDataService.php` fetches public `/v5/market/tickers` and `/v5/market/instruments-info` for `spot` and `linear`, pages through linear instrument metadata, filters active USDT pairs, normalizes the payload, sorts/ranks markets, derives highlights, caches snapshots briefly, and serves a marked stale last-good snapshot on provider failures.
- `GET /api/markets?type=spot|futures|both` is the single public internal endpoint. It is rate-limited and returns only normalized client-safe data.
- `config/market-assets.php` is the curated metadata boundary for names/categories/icons. Unknown assets are displayed by their symbols and are left uncategorized. “New” uses provider `launchTime` metadata.
- Public ticker data requires no API key, API secret, or SMTP. No provider secret exists in the browser.
- `GET/POST/DELETE /api/market-favorites` requires login. `user_market_favorites` is the only new market-related table; guests use localStorage. No live tickers are stored in MySQL.
- Admin > Settings reads cached `MarketDataService::health()` and shows provider, connection state, last update, market counts, cache interval, and whether credentials are needed. It does not expose credentials or edit `.env`.
- Bybit reference docs: [Get Tickers](https://bybit-exchange.github.io/docs/v5/market/tickers), [Get Instruments Info](https://bybit-exchange.github.io/docs/v5/market/instrument).

## Important files

- `routes/web.php`: installer, auth, platform pages, market API/favorites/detail routes, and admin routes.
- `app/Http/Controllers/MarketDataController.php`, `MarketFavoriteController.php`, `MarketDetailController.php`.
- `resources/js/pages/MarketsPage.tsx` and `MarketDetail.tsx`; reusable definitions in `resources/js/types/market.ts`; page styling in `resources/css/markets.css`.
- `resources/js/components/landing/MarketTable.tsx`: compact homepage spot ticker using the same `/api/markets` source.
- `app/Http/Controllers/AdminController.php`, `resources/js/pages/Admin/Section.tsx`: read-only admin settings/market health.
- `database/migrations/2026_09_30_000002_create_user_market_favorites_table.php`: additive favorites migration.
- `prepare-hosting.sh`, `UPDATE-INSTRUCTIONS.txt`: shared hosting preparation and update steps.

## Data and security boundaries

- Do not create or show fake prices, balances, trades, funding activity, or market provider health. An unavailable indicator is preferable to invented data.
- Never delete production users or mutate balances without explicit instructions, reviewed backup, and actual ledger/business rules.
- No wallet or transaction ledger exists. Admin deposits/withdrawals remain placeholders; do not implement manual financial credits/debits in this Markets task.
- Keep `.env`, `vendor/`, `node_modules/`, logs, sessions, and install lock out of ZIPs. Do not replace the server's existing `.env` or `vendor/` during extraction.
- Configure SMTP separately if welcome or password-reset email delivery is needed. Market data does not use SMTP.

## Verification status and deployment

- Passed locally: TypeScript `tsc --noEmit` and Vite production asset build.
- Not verifiable in this local environment: PHP syntax/lint, Laravel feature tests, actual Bybit live calls from the server, MySQL migration, user favorite persistence, and Hostinger runtime. Do not state these passed until run on a PHP-enabled environment.
- The endpoint tests are in `tests/Feature/MarketDataEndpointTest.php` and cover normalized spot/futures payloads plus a safe provider failure response.
- `Update.zip` contains prebuilt assets; upload/extract over `public_html` while preserving `.env` and `vendor/`, then run once from that directory:

  `composer dump-autoload --no-dev --no-scripts && php artisan migrate --force && php artisan optimize:clear`

- Then open `https://riseway.io/markets` and `/admin/settings`. If there is an error, inspect `storage/logs/laravel.log` and fix that before proceeding. No Node/npm is required on Hostinger for this release.

## Wallet ledger + spot trading (added 2026-10-01)
- Independent (house-matched) exchange: Bybit is used ONLY as the public price feed. The operator is the counterparty; profits are paid by the operator.
- Tables: `wallet_balances` (integer units of 1e-8), `ledger_entries` (append-only journal, unique idempotency_key), `spot_orders`, `admin_audit_logs`. Migration: `2026_10_01_000001_create_wallet_ledger_tables.php` (additive).
- Only `App\Services\LedgerService::apply()` may change a balance (row lock + journal row). `App\Support\Money` does exact integer parsing/formatting (no floats, no bcmath needed).
- `SpotTradingService` fills market orders at the SERVER-side price from `MarketDataService` (never a browser price), rejects stale prices, charges `TRADING_SPOT_FEE_RATE` on the USDT side. Spot holdings live in the `funding` account.
- Routes: `GET /api/wallet`, `POST /api/wallet/transfer` (funding<->trading USDT), `GET/POST /api/spot/orders`, admin `POST /admin/users/{user}/wallet` (credit/debit with mandatory reason, idempotency key, audit log).
- Pages: `/assets` = Overview (live valuation from /api/markets), `/spot` = Spot terminal (real balances/orders). Admin user page has a Wallet panel.
- Not built yet: futures, withdrawals workflow, KYC. (Deposits: see below.) Run `php vendor/bin/phpunit` (sqlite) — 11 tests cover ledger, idempotency, trading math, auth.

## Auto deposits (added 2026-10-01)
- Provider: NOWPayments. `App\Services\NowPaymentsClient` (HTTP + IPN HMAC-SHA512 check), `App\Services\DepositService` (create address, verify with provider API, credit once), `DepositController` (`GET/POST /api/deposits`, `GET /api/deposits/{order}`, webhook `POST /api/webhooks/nowpayments`, CSRF-exempt but signature-checked).
- Coins/networks: `config/deposit-coins.php` (curated). Only add a code after enabling it on the NOWPayments account.
- Credit rule: only status `finished` is credited, using `actually_paid`, to the funding wallet of the deposit's asset (ledger type `deposit`, idempotency key `deposit:{id}`). The webhook body is never trusted: the payment is re-read from the provider. `partially_paid` is NOT auto-credited; it shows "contact support" and needs admin handling.
- An open (`waiting`) address for the same currency is reused for 60 minutes.
- Page: `/deposit` (Deposit.tsx). Without NOWPAYMENTS_API_KEY the page shows "being set up" and the API returns 503.
- Tests: `tests/Feature/DepositTest.php` (Http::fake). Not yet exercised against the live NOWPayments API.

## Account pages (Funding, Trading, Analysis, Order center, Fees)
- `/funding`, `/trading` -> `AccountPage.tsx` (kind prop); `/analysis`, `/orders`, `/fees` -> `Analysis`, `OrderCenter`, `Fees`. `/dashboard` redirects to `/assets`.
- `GET /api/account/summary` (AccountController): deposits, withdrawals, 30-day volume/fees, trade count, win rate (average-cost method, null until a sell), fee rate. All from ledger/orders.
- `GET /api/spot/orders` accepts `side`, `days`, `q`, `before`, `limit` and returns `hasMore`.
- `GET /api/wallet?account=trading` returns Trading-account history.
- Header search (`HeaderSearch.tsx`) lists live spot/futures pairs from `/api/markets?type=both`.
- Not built yet: Grow/Earn, Bots, Convert, Withdraw, Futures trading.

## Earn (staking) and Bots (yield strategies)
- Tables: earn_products, earn_positions, bots, bot_follows, bot_claims (migration 2026_10_02_000001). New ledger accounts `earn` and `bots`.
- Earn: simple interest = principal x APR x elapsed seconds / year, paid into `funding` (type earn_interest). Settled lazily on stake/unstake/page view and by `php artisan earn:accrue`. Seeded product "USDT Flexible 3.5%" is DISABLED until an admin switches it on.
- Bots: each completed 24h cycle pays capital x daily yield, minus platform share, to `funding` (type bot_profit). Unclaimed backlog capped at 30 cycles. No random values. Auto-claim runs on page view and `php artisan bots:settle`. No bots are seeded.
- Admin: /admin/earn and /admin/bots (create/edit, enable/disable). Changing a rate first pays everyone at the old rate. All saves are audit-logged. Profits are paid by the platform, so the admin must keep a reserve.
- Optional cron (Hostinger): `* * * * * cd ~/public_html && php artisan schedule:run >> /dev/null 2>&1` runs both commands hourly.

## Futures (isolated margin, house-matched)
- Page `/futures` (FuturesPage.tsx); API `/api/futures/{state,open,close,tpsl}`; `FuturesService` is the only code that opens/closes positions. Margin moves trading -> `futures` ledger account, returns to `trading` with PnL on close (types futures_open / futures_close / futures_liquidation / futures_fee).
- Entry, close and trigger prices come from the SERVER market snapshot (Bybit linear), never from the browser. A user cannot lose more than the margin. Fee = TRADING_FUTURES_FEE_RATE x position size at open and at close.
- TP / SL / liquidation are enforced by `FuturesService::sweep()`: on every futures API call for that user, and globally by `php artisan futures:sweep` (scheduled every minute — run `schedule:run` from cron for positions of offline users). Liquidation when margin + PnL <= notional x TRADING_FUTURES_MAINTENANCE_RATE.
- Admin: /admin/futures shows open positions, long/short exposure, unrealized PnL owed, fees earned. Limits are in .env (TRADING_FUTURES_*).
- Market data cache is ~12s, so fills can be up to ~12s old; lower `market-data.cache_seconds` if tighter fills are needed.
