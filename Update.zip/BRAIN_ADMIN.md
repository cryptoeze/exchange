# 🧠 BRAIN_ADMIN.md — RushX admin-side brain (read with BRAIN_USER.md)

> Purpose: after reading this file an AI/developer understands the whole admin console: sitemap, what each page does, which controller/route/component backs it, the shared UI kit, roles, audit trail and how to add/remove things.
> Companion files: `BRAIN_USER.md` (user side + architecture), `ADMIN_STRUCTURE.md` (short how-to), `HANDOFF.md` (change log). **Update this file after every admin change.**

## 1. Principles
1. **One place per thing.** Everything about a user lives in *User 360*; every money movement is in *Transactions*; every deposit/withdraw switch, fee and network is in *Gateways*.
2. **Everything is a list with the same anatomy:** `Page → Stats → Tabs → Panel → FilterBar → DataTable → Pager`. Filters live in the URL (shareable, survive refresh). Lists have CSV export where money is involved (`?export=1`).
3. **Real data only**, live-refreshing lists (dashboard every 15 s, list pages every 20 s with Live/Paused button; skipped while typing).
4. **Every sensitive action is audited** (`admin_audit_logs`) and money actions are idempotent/journaled through `LedgerService`.
5. Mobile: tables turn into stacked cards, sidebar becomes a drawer, top bar is compact (menu, title, bell, theme, logout icon).

## 2. Access, roles, guard
* Login: `/admin/login` (own blade `resources/views/admin/auth.blade.php`, optional 2FA code). Guard `admin`; user must have `role='admin'`.
* `admin_role`: **super** (everything) · **finance** (money, users, trading views, earn, PoR) · **support** (users, KYC, tickets, P2P, notifications, referrals, spot trades). Server gate: `EnsureAdmin::ROLE_PATHS` (first URL segment after `/admin/`). Frontend visibility: `roles` in `resources/js/admin/nav.ts`. **Keep both in sync.** Support cannot credit/debit wallets.
* Admin accounts are managed in *Admin team* (`AdminTeamController`), admin 2FA in *My security*. Admins never appear in the Users list.
* Maintenance mode (Settings → Site setup) blocks users but never `/admin*`.

## 3. Sitemap (sidebar group → page → what it does)
| Group | Page (URL) | Controller@method → React page | Key actions |
|---|---|---|---|
| Overview | Dashboard `/admin` | `AdminController@dashboard` → `Dashboard.tsx` (`AdminDashboardService`) | queue tiles (withdrawals, KYC, tickets, disputes, positions, limit orders), 9 metric cards (all clickable), latest signups & trades, auto-refresh |
| Users & compliance | Users `/admin/users` | `Admin\UsersController@index` → `Users.tsx` | stats, filters (q/status/KYC/email/sort/dates), CSV, row click → User 360 |
| | **User 360** `/admin/users/{id}?tab=` | `Admin\UsersController@show` → `UserShow.tsx` | tabs: overview · wallet · deposits · withdrawals · trading(spot/futures/limit/earn/bots) · p2p · kyc · security · referrals · support · manage |
| | KYC review `/admin/kyc` | `AdminOpsController@kyc` → `Kyc.tsx` | tabs pending/approved/rejected/all, photos (front/back/selfie via `/admin/kyc/{id}/{which}`), approve / reject+reason (notifies user, sets `users.kyc_status`) |
| | Referrals `/admin/referrals` | `AdminOpsController@referrals` → `Referrals.tsx` | referrers, invited counts, commission paid |
| | Support tickets `/admin/tickets` | `AdminTicketController` → `Tickets.tsx` | reply, change status |
| Money | **Transactions** `/admin/transactions` | `Admin\TransactionsController@index` → `Transactions.tsx` | whole ledger; filters category/type/asset/account/in-out/min/user/date; totals; CSV |
| | Deposits `/admin/deposits?tab=` | `AdminTreasuryController@deposits` → `Deposits.tsx` | tabs pending/approved/rejected/all/auto(NOWPayments); **Credit** (amount received) / **Reject** (reason) via `POST /admin/deposits/{id}`; credit also triggers bonus + referral commission + email |
| | Withdrawals `/admin/withdrawals?status=` | `AdminTreasuryController@withdrawals` → `Withdrawals.tsx` | tabs pending/completed/rejected/cancelled/all; **Mark sent** (TX hash) / **Reject & refund** via `POST /admin/withdrawals/{id}`; shows user KYC state |
| | **Gateways** `/admin/gateways?tab=` | `AdminOpsController@gateways` → `Gateways.tsx` | tabs overview (master switches) · deposit-auto (NOWPayments status + per-network on/off = `dep_off`) · deposit-manual (add/edit addresses, `POST /admin/deposits/address`) · withdraw (min/fee/on-off per network). Save bar posts `POST /admin/gateways` |
| | Proof of Reserves `/admin/por` | `ProofOfReservesController` (admin part) → `Por.tsx` | enter reserves per asset |
| Trading | Spot trades `/admin/trades` | `Admin\TradesController` → `Trades.tsx` | 24 h volume/fees, filters, CSV |
| | Futures `/admin/futures?tab=` | `AdminYieldController@futures` → `Futures.tsx` | exposure (long/short, unrealized), open/closed/all, filters by user/contract/side/close reason |
| | Limit & TP/SL `/admin/orders` | `AdminOpsController@orders` → `Orders.tsx` | resting orders, **Cancel** (refunds the hold) |
| | Markets on/off `/admin/markets` | `AdminOpsController@pairs` → `Pairs.tsx` | pause/resume a pair (spot + new futures) = setting `pairs_off` |
| | P2P desk `/admin/p2p` | `AdminP2pController` → `P2p.tsx` | resolve disputes (release/refund), close ads |
| Products | Earn `/admin/earn` | `AdminYieldController@earn/saveEarn` → `Earn.tsx` | products, APR, min, limits, on/off |
| | Bots `/admin/bots` | `AdminYieldController@bots/saveBot` → `Bots.tsx` | create/edit, daily yield, platform share, limits, followers, stop follower, settle now, delete |
| | Copy traders `/admin/traders` | `AdminYieldController@bots(..,'trader')` → `Bots.tsx` | same page, trader mode |
| Communication | Notifications `/admin/notifications` | `AdminOpsController@notifications` → `Notifications.tsx` | broadcast to all/segments |
| | Email templates `/admin/emails` | `AdminOpsController@emailTemplates` → `EmailTemplates.tsx` | edit subject/heading/body per event, test send |
| System | Settings `/admin/settings` | `AdminOpsController@settings` → `Settings.tsx` | auto-generated from `SettingsService::FIELDS` |
| | Admin team `/admin/team` | `AdminTeamController` → `Team.tsx` | add/remove admins, role |
| | Audit log `/admin/audit` | `AdminOpsController@audit_log` → `Audit.tsx` | who/what/when/IP, filters |
| | My security `/admin/security` | `AdminTeamController@security` → `Security.tsx` | change password, admin 2FA |
| Top bar | User finder, bell, theme, logout | `Layout.tsx`, `AdminOpsController@bell` | finder → `/admin/users?q=` ; bell polls `/admin/api/bell` |
Legacy: `/admin/p2pdesk` redirects to `/admin/p2p`.

### User-360 actions (all under `/admin/users/{user}/…`, all audited)
`wallet` (credit/debit, funding|trading|copy, reason required, idempotency key) · `status` (freeze/unfreeze) · `profile` (name, email, new password ≥10 chars, signs the user out) · `notify` (message to the bell) · `2fa-reset` · `signout` (all devices). Deposit/withdrawal/KYC actions reuse the generic endpoints above.

## 4. Shared admin building blocks
| What | Where |
|---|---|
| Sitemap, icons, roles, badge keys (**edit here to add/remove a menu item**) | `resources/js/admin/nav.ts` |
| UI kit: `Page, Panel, Stats/Stat, Tabs, FilterBar, DataTable(rowHref), Pager, Badge, Btn, Field/Input/Select/Switch, Copy, UserLink, Modal, ActionButton, KV, group()/usd()` | `resources/js/admin/kit.tsx` |
| Styles (`au-*`, uses `--ad-*` colour tokens, light/dark) | `resources/css/admin-ui.css` (+ legacy `admin-*` in `app.css`) |
| Layout (sidebar from nav.ts, section pill-tabs, finder, bell, Live toggle) | `resources/js/pages/Admin/Layout.tsx` |
| Server helpers: `adminProps`, `audit`, `paged` → `{page,last,total,per}`, `dateRange`, `like`, `pick`, `units`, `csv` | `app/Http/Controllers/Admin/Concerns/AdminHelpers.php` |
| Ledger categories | `app/Support/LedgerCategory.php` |
| Sidebar counters (`adminBadges`: withdrawals, deposits, kyc, tickets, disputes) | `HandleInertiaRequests` |
| Page registration | `resources/js/app.tsx` resolve map (`'Admin/Thing': AdminThing`) |
`ActionButton` = a button that either confirms (`confirmText`) or opens a modal with fields (reason, amount, TX hash) and POSTs to `url` with `data`.

## 5. Settings catalogue (Admin → Settings; defined in `SettingsService::FIELDS`)
**Fees & trading limits**
- `spot_fee` (rate) — Spot trading fee %
- `futures_fee` (rate) — Futures fee % (on position size)
- `futures_maint` (rate) — Futures maintenance margin %
- `futures_max_lev` (int) — Futures max leverage (x)
- `futures_min_margin` (float) — Futures min margin (USDT)
- `futures_max_margin` (float) — Futures max margin per position (USDT)
- `futures_enabled` (bool) — Futures trading on
- `spot_min_quote` (float) — Spot min order (USDT)
- `spot_max_quote` (float) — Spot max order (USDT)
- `margin_alert` (float) — Low-margin alert at % of buffer left
- `convert_enabled` (bool) — Convert on
- `convert_fee` (rate) — Convert fee %
- `transfer_enabled` (bool) — Internal transfers on

**Bonuses & rewards**
- `bonus_enabled` (bool) — Deposit bonus on
- `bonus_percent` (float) — Deposit bonus %
- `bonus_first_only` (bool) — Bonus on first deposit only
- `bonus_max` (float) — Max bonus per deposit (USD)
- `rewards_enabled` (bool) — Daily rewards on
- `rewards_amounts` (amounts) — Daily reward amounts (7 days)
- `referral_percent` (float) — Referral commission %
- `referral_max` (float) — Max commission per deposit (USD)

**Gateways & compliance**
- `withdraw_enabled` (bool) — Withdrawals on
- `kyc_required` (bool) — KYC required to withdraw
- `auto_deposit` (bool) — Auto deposits (NOWPayments) on
- `manual_deposit` (bool) — Manual deposits on

**P2P**
- `p2p_enabled` (bool) — P2P marketplace on
- `p2p_fee` (float) — P2P fee % (taken from the coin the buyer receives)

**Display & email**
- `mail_enabled` (bool) — Send emails to users
- `pkr_rate` (float) — PKR per 1 USD (display only)

**Site setup**
- `site_name` (text) — Site name
- `support_email` (text) — Support email
- `maintenance` (bool) — Maintenance mode
- `maintenance_msg` (text) — Maintenance message
- `site_logo` (file, not in FIELDS — own card at the top of the Settings page) — custom header logo. Uploaded to the `public` disk under `branding/`, path stored as the `site_logo` setting row. `SettingsService::apply()` turns it into `config('app.logo_url')`, shared to every Inertia page as the `siteLogo` prop and used by `RushXBrand.tsx` / `Landing.tsx`'s `Brand`. Empty → falls back to the built-in `rushx-mark.svg`. Routes: `POST /admin/settings/logo` (upload, max 1&nbsp;MB, png/jpg/webp/svg), `POST /admin/settings/logo/remove` (reset to default). Needs `php artisan storage:link` once per install (now also run by `prepare-hosting.sh`) so `public/storage` serves the file.

**Email (SMTP)**
- `smtp_host` (text) — SMTP host
- `smtp_port` (int) — SMTP port
- `smtp_user` (text) — SMTP username
- `smtp_pass` (secret) — SMTP password
- `smtp_scheme` (text) — SMTP security
- `mail_from` (text) — From address
- `mail_from_name` (text) — From name


Gateway-specific values (not in FIELDS): `wd_min.*`, `wd_fee.*.*`, `wd_off.*.*`, `dep_off`, `pairs_off`, `mailtpl.*`.

## 6. Audit trail
Table `admin_audit_logs(admin_id, action, target_user_id, details json, ip, created_at)`. Actions written today: `settings.save, settings.logo, settings.logo_remove, gateways.save, deposit_address.save, manual_deposit.approve|reject, withdrawal.complete|reject, kyc.approve|reject, user.edit, user.notify, user.2fa_reset, user.signout_all, user.frozen|user.active, wallet_credit, wallet_debit, pairs.save, order.cancel, earn_product_save, bot_save, bot_delete, bot_settle_now, bot_stop_follower, email_template.save, notification.broadcast, ticket.reply, p2p.resolve, p2p.close_ad, admin.save, admin.remove`. Secrets (SMTP password) are never logged.

## 7. Key flows (so you can change them safely)
* **Manual deposit:** user submits TXID → `manual_deposits(pending)` → admin *Credit* → ledger `deposit` (idempotency `manual-deposit:{id}`) → `BonusService::grantForDeposit` → `ReferralService::payForDeposit` → email/bell `deposit_credited`.
* **Withdrawal:** user request → ledger `withdrawal_hold` (funding −amount) + row `pending` (KYC gate if enabled) → admin *Mark sent* (status completed, TX hash, email) or *Reject* (ledger `withdrawal_refund`, idempotency `wd-refund:{id}`).
* **KYC:** user form → `kyc_submissions(pending)`, `users.kyc_status='pending'`, admins notified → approve/reject sets both, notifies user.
* **Auto deposit:** NOWPayments IPN webhook (`/api/webhooks/nowpayments`) credits `deposits`. Disabled networks (`dep_off`) are hidden from the user Deposit page.
* **Limit/TP/SL cancel by admin:** `LimitOrderService::cancel($admin,$id,true)` returns the `hold` amount to funding.

## 8. How to add / change / remove (checklists)
**Add a page:** controller (`use AdminHelpers`, filters from request, `paged()`), route in the `admin` group with `EnsureAdmin`, React page (copy `Trades.tsx`), register in `app.tsx`, add to `ADMIN_NAV`, add path segment to `EnsureAdmin::ROLE_PATHS` for finance/support if they need it, add a test in `tests/Feature/AdminStructureTest.php`, update this file.
**Add a User-360 tab:** key in `UsersController::TABS` + `tabXxx()` + component in `UserShow.tsx` + entry in its `<Tabs>`.
**Add a setting:** one row in `SettingsService::FIELDS` (+ config default). **Add a ledger type:** use it in `LedgerService::apply` and map it in `LedgerCategory`.
**Remove a page:** delete its nav item, route, controller method, React file and `app.tsx` entry; update this file.

## 9. Testing
`tests/Feature/AdminStructureTest.php` (users, 360 tabs, transactions, trades, deposits, withdrawals, gateways, KYC/futures/orders/audit/referrals, roles), `AdminOpsTest`, `AdminSetupTest` (settings, SMTP secret, maintenance, pairs, user edit, order cancel), `TreasuryTest`, `KycFormTest`. Use `assertInertia(fn (Assert $p) => $p->component('Admin/…')->where(...))`. Helper in tests: users with `status`/`admin_role` must be set with `DB::table('users')->update()` (not mass-assignable).

## 10. HTTP routes (admin side, generated)
```
GET        /admin                                         AdminController@dashboard
GET        /admin/api/bell                                AdminOpsController@bell
POST       /admin/api/bell/read                           AdminOpsController@bellRead
GET        /admin/audit                                   AdminOpsController@audit_log
GET        /admin/bots                                    AdminYieldController@bots
POST       /admin/bots                                    AdminYieldController@saveBot
POST       /admin/bots/{bot}/delete                       AdminYieldController@deleteBot
GET        /admin/bots/{bot}/followers                    AdminYieldController@followers
POST       /admin/bots/{bot}/followers/{user}/stop        AdminYieldController@stopFollower
POST       /admin/bots/{bot}/settle                       AdminYieldController@settleNow
GET        /admin/deposits                                AdminTreasuryController@deposits
POST       /admin/deposits/address                        AdminTreasuryController@saveAddress
POST       /admin/deposits/{id}                           AdminTreasuryController@reviewDeposit
GET        /admin/earn                                    AdminYieldController@earn
POST       /admin/earn                                    AdminYieldController@saveEarn
GET        /admin/emails                                  AdminOpsController@emailTemplates
POST       /admin/emails/{event}                          AdminOpsController@saveEmailTemplate
POST       /admin/emails/{event}/test                     AdminOpsController@testEmail
GET        /admin/futures                                 AdminYieldController@futures
GET        /admin/gateways                                AdminOpsController@gateways
POST       /admin/gateways                                AdminOpsController@saveGateways
GET        /admin/kyc                                     AdminOpsController@kyc
POST       /admin/kyc/{id}                                AdminOpsController@kycReview
GET        /admin/kyc/{id}/{which}                        AdminOpsController@kycFile
GET        /admin/login                                   AdminController@loginForm
POST       /admin/login                                   AdminController@login
POST       /admin/logout                                  AdminController@logout
GET        /admin/markets                                 AdminOpsController@pairs
POST       /admin/markets                                 AdminOpsController@savePairs
GET        /admin/notifications                           AdminOpsController@notifications
POST       /admin/notifications                           AdminOpsController@broadcast
GET        /admin/orders                                  AdminOpsController@orders
POST       /admin/orders/{id}/cancel                      AdminOpsController@cancelOrder
GET        /admin/p2p                                     AdminP2pController@index
POST       /admin/p2p/ads/{id}/close                      AdminP2pController@closeAd
POST       /admin/p2p/{ref}/resolve                       AdminP2pController@resolve
GET        /admin/por                                     ProofOfReservesController@admin
POST       /admin/por                                     ProofOfReservesController@save
GET        /admin/referrals                               AdminOpsController@referrals
GET        /admin/security                                AdminTeamController@security
POST       /admin/security/2fa/confirm                    TwoFactorController@confirm
POST       /admin/security/2fa/disable                    TwoFactorController@disable
POST       /admin/security/2fa/start                      TwoFactorController@start
GET        /admin/settings                                AdminOpsController@settings
POST       /admin/settings                                AdminOpsController@saveSettings
GET        /admin/team                                    AdminTeamController@index
POST       /admin/team                                    AdminTeamController@save
POST       /admin/team/{user}/remove                      AdminTeamController@remove
GET        /admin/tickets                                 AdminTicketController@index
POST       /admin/tickets/{id}/reply                      AdminTicketController@reply
POST       /admin/tickets/{id}/status                     AdminTicketController@status
GET        /admin/traders                                 Closure
GET        /admin/trades                                  Admin\TradesController@index
GET        /admin/transactions                            Admin\TransactionsController@index
GET        /admin/users                                   Admin\UsersController@index
GET        /admin/users/{user}                            Admin\UsersController@show
POST       /admin/users/{user}/2fa-reset                  Admin\UsersController@reset2fa
POST       /admin/users/{user}/notify                     Admin\UsersController@notify
POST       /admin/users/{user}/profile                    AdminOpsController@updateUser
POST       /admin/users/{user}/signout                    Admin\UsersController@signOutEverywhere
POST       /admin/users/{user}/status                     AdminOpsController@userStatus
POST       /admin/users/{user}/wallet                     AdminWalletController@adjust
GET        /admin/withdrawals                             AdminTreasuryController@withdrawals
POST       /admin/withdrawals/{id}                        AdminTreasuryController@reviewWithdrawal
GET        /admin/{section}                               AdminController@section
```

## 11. Maintenance rules
Update §3 when a page changes, §5 when settings change, §6 when a new audit action is added, §7 when a flow changes. Mirror anything user-visible in `BRAIN_USER.md`. Append a line to `HANDOFF.md`.
