# 🧠 BRAIN_USER.md — RushX user-side brain (read this first)

> Purpose: any AI (or developer) should be able to open **only this file + BRAIN_ADMIN.md** and understand how the platform works, what already exists, and where to change things. **Keep it updated after every change** (see "Maintenance rules" at the end).
> Companion files: `BRAIN_ADMIN.md` (admin side), `HANDOFF.md` (chronological change log per pack), `ADMIN_STRUCTURE.md` (admin sitemap/how-to), `SETUP.md` (install/update), `README.md`.

## 0. What this product is
RushX = an **independent, house-matched crypto exchange** for the owner's site (riseway.io; code also works on any domain).
* Bybit is used **only as a public price feed** (REST + public WebSocket). No Bybit trading, no user API keys.
* The platform itself is the counter-party: users trade against it at the live Bybit price; admin credits deposits and pays withdrawals manually.
* Languages: UI English. The owner talks in **Roman Urdu** and prefers **short** answers.

## 1. Owner's standing rules (do not break)
1. Don't remove anything the owner did not ask to remove. Fake-looking marketing claims on the landing page (70M+, $2.4T, 2M+ traders, "Regulated · 14 jurisdictions") stay until the owner says remove.
2. No "Account statement" item in the account sub-nav.
3. Remove a "Soon" badge only from features that are now live.
4. **Real/live data only** — no fake PnL, follower counts or balances. Money-paying features (commission, rates, bonuses) default **OFF** unless the owner specifies.
5. Mobile must feel like an app (bottom nav, header with back arrow, loader on navigation). Desktop AND mobile must both be good.
6. Give a zip (`Update.zip`) **only when the owner asks** ("jab kahoon tab zip dena").
7. Tidio live chat must not show (bubble/greeting) before a message icon is clicked; not loaded in admin.
8. Reference pages the owner sends (HTML/screenshots) should be matched or bettered.

## 2. Stack & hosting
* Laravel 13, PHP 8.5 on Hostinger shared hosting (local sandbox PHP 8.4), MySQL; Inertia 3 + React 19 + TypeScript, Vite 8, Tailwind import only for base; hand-written CSS per area in `resources/css/`.
* Charts: `lightweight-charts` v5 (own `LiveChart.tsx`, no indicators, TradingView logo hidden on phones).
* Prices: `MarketDataService` (Bybit public REST, cached few seconds) + browser WebSocket `wss://stream.bybit.com/v5/public/*` for live ticks.
* Deposits auto: NOWPayments (keys in `.env`); manual deposits: owner's own addresses.
* Email: Laravel Mail via SMTP (`.env` or Admin → Settings). Templates in `config/mail-templates.php` (admin-editable).
* Cron (Hostinger, every minute): `cd ~/public_html && php artisan schedule:run` → `routes/console.php` runs `earn:accrue`, `bots:settle` (hourly) and `futures:sweep`, `alerts:check`, `orders:fill`, `p2p:expire` (every minute). **Without cron: no liquidation/TP/SL, no limit/TP-SL fills, no price alerts, no P2P expiry.**
* Install: `/install` writes `.env` and runs migrations (needs `storage/app/installed.lock` ABSENT on a fresh host). Update on live site: extract zip over `public_html` (keep `.env`, `vendor/`) then `php artisan migrate --force && composer dump-autoload --no-dev --no-scripts && php artisan optimize:clear`.
* Throttle gotcha: always give each route its own limiter prefix: `throttle:N,M,unique.prefix`.

## 3. Core architecture (the 6 ideas that explain everything)
### 3.1 Money = integer ledger
* All amounts are **integers in units of 1e-8** (`App\Support\Money`: `toUnits('1.5')`, `format($units,$minDecimals)`). Never floats for balances.
* `App\Services\LedgerService::apply($userId,$account,$asset,$delta,$type,$meta)` is the **only** code allowed to change a balance (locked read-modify-write + append-only `ledger_entries` row). Call inside `DB::transaction`. `meta`: `ref_type, ref_id, idempotency_key, created_by, note`.
* Accounts (`LedgerService::ACCOUNTS`): `funding` (main wallet), `trading`, `copy`, `earn`, `bots`, `futures` (margin locked), `hold` (limit-order reserve), `p2p` (escrow).
* Ledger `type` values → categories in `App\Support\LedgerCategory` (deposit, withdrawal_hold/refund, transfer_in/out, spot_buy/sell, limit_hold/release/fill, futures_*, convert_in/out, earn_*, bot_*, p2p_*, daily_reward, deposit_bonus, referral_reward, admin_credit/debit).
### 3.2 Settings layer
* `settings` table (key/value) is layered over `config()` at boot by `SettingsService::apply()` (AppServiceProvider). `SettingsService::FIELDS` = `key => [config key, type, label, hint, group]`; types `bool|float|int|rate|amounts|text|secret|list`. `rate` is stored as percent, config as fraction; `secret` is stored encrypted (SMTP password).
* Extra keys outside FIELDS: `wd_min.{T}`, `wd_fee.{T}.{CODE}`, `wd_off.{T}.{CODE}` (withdraw networks), `dep_off` (disabled auto-deposit network codes), `pairs_off` (paused pairs), `mailtpl.{event}` (email templates JSON).
* To add a setting: add one row to `FIELDS` (+ default in the matching `config/*.php`). The Admin → Settings page renders it automatically.
### 3.3 Notifications + email
* `NotificationService::send($userId,$title,$body,$type,$url)` (in-app bell, table `user_notifications`), `::event($userId,$event,$vars)` renders an admin-editable template → in-app + email (`MailService`), `::admins(...)` notifies admins (admin bell).
### 3.4 Auth
* Users: guard `web`, `users.role='user'`. Admins: guard `admin` (same table, `role='admin'`, `admin_role` super|finance|support). Frozen users (`users.status='frozen'`) are logged out by `EnsureNotFrozen`. 2FA = TOTP (`TotpService`), login history in `login_events`.
* Sign-up collects: name, email, **country + mobile (country-code select)**, password, optional referral code. Country/phone are stored on `users` and **pre-fill and lock KYC**.
### 3.5 Live prices & trading engine
* Spot (`SpotTradingService`), limit/TP/SL (`LimitOrderService`, kinds `limit|tp|sl`, funds reserved in `hold`, filled by `orders:fill` and on page load), futures (`FuturesService`, isolated margin, long/short, leverage, TP/SL per position, liquidation by `futures:sweep`, margin-low warnings), convert (`ConvertController`, fee/on-off from settings), earn (`EarnService`), bots (`BotService`: fixed daily yield, platform share), P2P (`P2pService`, escrow in `p2p` account), referrals (`ReferralService`), bonuses/daily rewards (`BonusService`, `RewardController`).
* Orders are refused if the price snapshot is older than `trading.max_price_age_seconds`.
* Paused pairs (`trading.disabled_pairs`) block new spot orders and new futures positions.
### 3.6 Frontend shell
* Inertia pages are resolved from the explicit map in `resources/js/app.tsx` (add new pages there!). `app.tsx` also injects the global navigation loader `#rx-navload`.
* Shared Inertia props (`HandleInertiaRequests`): `auth.user {id,name,email,emailVerified,kyc}`, `adminRole`, `adminBadges`, `flash.status`.
* Theme: `useTheme()` in `lib/hooks.ts` (dark default, `rushx-theme` in localStorage). Light overrides in `light-theme.css`.

## 4. User pages (route → page → notes)
| Area | Page component | Notes |
|---|---|---|
| Landing + auth dialog | `Landing.tsx` | Sign-in / Sign-up (country+mobile+referral) / forgot / reset / 2FA step. Footer links are real pages. |
| Home (logged in) | `Home.tsx` + `MobileTopBar`, `QuickActions`, `BannerArt` | Phone: header with search, PKR chip, bell (animated, red badge), balance card, quick-action circles, banners, coin tabs. |
| Assets | `Overview.tsx`, `MobileAssets.tsx`, `AccountPage.tsx` (funding/trading), `AccountLayout.tsx` | `phoneBar` prop gives the shared phone header. |
| Markets | `MarketsPage.tsx`, `MarketDetail.tsx` | live from `/api/markets`. |
| Spot | `SpotPage.tsx` | Market / Limit / TP-SL tabs, open orders, LiveChart, HOLD average-buy line. |
| Futures | `FuturesPage.tsx` | LiveChart with position/Liq/TP/SL lines, funding/mark/OI stats row, order book toggle, optional PnL share card (`FEATURE_PNL_SHARE`). |
| Money | `Deposit.tsx`, `Withdraw.tsx`, `Transfer.tsx`, `Convert.tsx` | Deposit has history sheet; Withdraw honours KYC-required setting. All use `deposit.css` (`dp-*`, `tw-*`). |
| Earn / Bots / Copy | `Earn.tsx`, `Bots.tsx`, `CopyTrading.tsx` | |
| P2P | `P2p.tsx`, `P2pOrders.tsx`, `P2pOrder.tsx`, `P2pAds.tsx` (+ `lib/p2p.ts`) | |
| Account | `Profile.tsx` (verified tick next to name), `Refer.tsx`, `Notifications.tsx`, `Kyc.tsx`, `Security.tsx` (+`TwoFactorPanel`), `Alerts.tsx`, `Tickets.tsx`, `Rewards.tsx` | |
| Info | `Fees.tsx`, `ProofOfReserves.tsx`, `PlatformPage.tsx` (learn/faq/blog/status) | |
| Shared UI | `RushXHeader.tsx` (desktop header, guest header, centered mobile menu, chat icon → `window.rushxChat()`), `MobileNav.tsx` (bottom nav; Trade → Futures), `navigationConfig.ts` (menus), `VerifiedTick.tsx`, `LiveChart.tsx`, `QuickActions.tsx` | |

### KYC rules (current)
Full name (as on document) · country + mobile (auto from account, read-only; older accounts without them can type) · document type: National ID / Driving licence → **front + back required**, Passport → front page only · selfie holding the document · JPG/PNG ≤ 5 MB, stored privately in `storage/app/kyc/{userId}`. Admin reviews → user gets bell+email and a **verified tick** next to the name (header menu, profile page).

## 5. CSS map (`resources/css/`)
`app.css` (base + admin legacy) · `navigation.css`, `header-states.css` (header, guest/mobile menu — later file wins) · `mobile-home.css` (phone header/home/bottom nav) · `mobile-assets.css`, `mobile-markets.css`, `mobile-futures.css` · `spot.css`, `futures.css` · `deposit.css` (deposit/withdraw/transfer/convert, phone-fit rules at the bottom) · `profile.css` (profile, KYC form, verified tick) · `p2p.css`, `rewards.css`, `earn-bots.css`, `copy-trading.css`, `treasury.css`, `account-pages.css` · `landing*.css`, `light-theme.css` · `admin-ui.css` (admin kit).
**Rule for phone layouts:** grid children need `min-width:0`, otherwise content is wider than the screen and gets clipped.

## 6. Data model cheat-sheet (tables)
users (+status, kyc_status, referral_code, referred_by, phone, country, 2FA cols, admin_role) · wallet_balances · ledger_entries · spot_orders · spot_limit_orders · futures_positions · deposits (auto) · manual_deposits · manual_deposit_addresses · withdrawals · conversions · earn_products · earn_positions · bots · bot_follows · bot_claims · daily_checkins · referral_rewards · kyc_submissions · user_notifications · settings · admin_audit_logs · login_events · price_alerts · tickets · ticket_messages · por_reserves · p2p_ads · p2p_trades · p2p_messages · p2p_disputes · user_market_favorites. (See `database/migrations`, newest = `2026_10_18` users phone/country.)

## 7. Environment variables worth knowing
`APP_URL`, `DB_*`, `MAIL_*` (or Admin → Settings → Email), `PKR_RATE`, `FEATURE_PNL_SHARE`, `TRADING_*`, `NOWPAYMENTS_API_KEY`, `NOWPAYMENTS_IPN_SECRET`, `MARKET_DATA_*`, `SUPPORT_EMAIL`. Defaults live in `config/*.php`; `.env.example` lists them.

## 8. Testing & verification
* `php vendor/bin/phpunit` (sqlite in-memory; ~93 tests). Test files per area: Treasury, Referral, AdminOps, Security, LimitOrder (incl. TP/SL), P2p, SupportAlertsPor, KycForm, AdminSetup, AdminStructure, plus the original suites.
* Frontend: `npx tsc --noEmit` and `npx vite build` (output committed in `public/build`, so Hostinger needs no Node).
* Visual checks: run `php artisan serve` with a sqlite DB + seeded users and drive it with Playwright (Chromium at `/opt/pw-browsers/chromium`). External CDNs/Bybit are blocked in the sandbox, so charts show mock data; real MySQL, SMTP, NOWPayments and Bybit WS are **not** verifiable there.

## 9. Known gaps / ideas (not built)
User API keys (no public trading API), futures limit orders ("Soon"), real-device 2FA test, real SMTP test, real two-user P2P browser test, MySQL migration run on the production DB.

## 10. HTTP routes (user side, generated)
```
GET        //                                         Closure
GET        /alerts                                    AlertController@page
GET        /analysis                                  PlatformPageController@show
GET        /api/account/summary                       AccountController@summary
GET        /api/alerts                                AlertController@index
POST       /api/alerts                                AlertController@store
POST       /api/alerts/{id}/delete                    AlertController@destroy
GET        /api/bots                                  BotController@index
POST       /api/bots/{bot}/auto                       BotController@auto
POST       /api/bots/{bot}/claim                      BotController@claim
POST       /api/bots/{bot}/follow                     BotController@follow
POST       /api/bots/{bot}/unfollow                   BotController@unfollow
GET        /api/convert                               ConvertController@index
POST       /api/convert                               ConvertController@store
GET        /api/deposits                              DepositController@index
POST       /api/deposits                              DepositController@store
GET        /api/deposits/{orderId}                    DepositController@show
GET        /api/earn                                  EarnController@index
POST       /api/earn/stake                            EarnController@stake
POST       /api/earn/unstake                          EarnController@unstake
POST       /api/futures/close                         FuturesController@close
POST       /api/futures/open                          FuturesController@open
GET        /api/futures/state                         FuturesController@state
POST       /api/futures/tpsl                          FuturesController@tpsl
GET        /api/klines                                KlineController
GET        /api/manual-deposits                       ManualDepositController@index
POST       /api/manual-deposits                       ManualDepositController@store
GET        /api/market-favorites                      MarketFavoriteController@index
POST       /api/market-favorites                      MarketFavoriteController@store
DELETE     /api/market-favorites/{marketType}/{symbol} MarketFavoriteController@destroy
GET        /api/markets                               MarketDataController
GET        /api/notifications                         NotificationController@index
POST       /api/notifications/read                    NotificationController@read
POST       /api/p2p/ads                               P2pController@createAd
GET        /api/p2p/ads                               P2pController@ads
POST       /api/p2p/ads/{id}/status                   P2pController@adStatus
GET        /api/p2p/config                            P2pController@config
GET        /api/p2p/my-ads                            P2pController@mine
POST       /api/p2p/trades                            P2pController@start
GET        /api/p2p/trades                            P2pController@trades
GET        /api/p2p/trades/{ref}                      P2pController@show
POST       /api/p2p/trades/{ref}/cancel               P2pController@cancel
POST       /api/p2p/trades/{ref}/dispute              P2pController@dispute
POST       /api/p2p/trades/{ref}/message              P2pController@message
POST       /api/p2p/trades/{ref}/paid                 P2pController@paid
POST       /api/p2p/trades/{ref}/release              P2pController@release
GET        /api/rewards                               RewardController@show
POST       /api/rewards/claim                         RewardController@claim
GET        /api/spot/limit                            LimitOrderController@index
POST       /api/spot/limit                            LimitOrderController@store
POST       /api/spot/limit/{id}/cancel                LimitOrderController@cancel
GET        /api/spot/orders                           SpotOrderController@index
POST       /api/spot/orders                           SpotOrderController@store
GET        /api/tickets                               TicketController@index
POST       /api/tickets                               TicketController@store
GET        /api/tickets/{id}                          TicketController@show
POST       /api/tickets/{id}/close                    TicketController@close
POST       /api/tickets/{id}/reply                    TicketController@reply
GET        /api/wallet                                WalletController@index
POST       /api/wallet/transfer                       WalletController@transfer
POST       /api/webhooks/nowpayments                  DepositController@webhook
GET        /api/withdrawals                           WithdrawalController@index
POST       /api/withdrawals                           WithdrawalController@store
POST       /api/withdrawals/{id}/cancel               WithdrawalController@cancel
GET        /assets                                    PlatformPageController@show
GET        /blog                                      PlatformPageController@show
GET        /bots                                      PlatformPageController@show
GET        /convert                                   PlatformPageController@show
GET        /copy                                      PlatformPageController@show
GET        /dashboard                                 Closure
GET        /deposit                                   PlatformPageController@show
GET        /earn                                      PlatformPageController@show
GET        /faq                                       PlatformPageController@show
GET        /fees                                      PlatformPageController@show
POST       /forgot-password                           AuthController@sendResetLink
GET        /funding                                   PlatformPageController@show
GET        /futures                                   PlatformPageController@show
GET        /getting-started                           PlatformPageController@show
GET        /install                                   InstallController@show
POST       /install                                   InstallController@install
GET        /kyc                                       KycController@show
POST       /kyc                                       KycController@submit
GET        /learn                                     PlatformPageController@show
GET        /login                                     AuthController@login
POST       /login                                     AuthController@authenticate
POST       /login/2fa                                 AuthController@twoFactor
POST       /login/2fa/cancel                          Closure
POST       /logout                                    AuthController@logout
GET        /market/{symbol}                           MarketDetailController
GET        /markets                                   PlatformPageController@show
GET        /notifications                             NotificationController@page
GET        /orders                                    PlatformPageController@show
GET        /p2p                                       P2pController@market
GET        /p2p/ads                                   P2pController@myAds
GET        /p2p/orders                                P2pController@orders
GET        /p2p/orders/{ref}                          P2pController@order
GET        /profile                                   Closure
GET        /proof-of-reserves                         ProofOfReservesController@show
GET        /refer                                     ReferralController@show
POST       /register                                  AuthController@register
POST       /reset-password                            AuthController@resetPassword
GET        /reset-password/{token}                    AuthController@resetPage
GET        /rewards                                   PlatformPageController@show
GET        /security                                  SecurityController@show
POST       /security/2fa/confirm                      TwoFactorController@confirm
POST       /security/2fa/disable                      TwoFactorController@disable
POST       /security/2fa/start                        TwoFactorController@start
POST       /security/password                         SecurityController@password
GET        /spot                                      PlatformPageController@show
GET        /status                                    PlatformPageController@show
GET        /support                                   TicketController@support
GET        /tickets                                   TicketController@page
GET        /trading                                   PlatformPageController@show
GET        /transfer                                  PlatformPageController@show
GET        /withdraw                                  PlatformPageController@show
```

## 11. Maintenance rules for this file
After **every** change: update the relevant section (page table, rules, settings, tables, routes) and add a line to `HANDOFF.md`. When a feature is removed, delete its row here. When the owner gives a new standing rule, add it to §1. Keep it factual — this file is the memory of the project.

## 12. How to ask an AI to work on this
"Read BRAIN_USER.md and BRAIN_ADMIN.md, then <task>." The AI should: (1) find the page/service in §4/§3, (2) change code, (3) run tsc + build + phpunit, (4) update both BRAIN files + HANDOFF.md, (5) zip only if asked (recipe in HANDOFF.md: exclude `node_modules vendor .env storage/logs storage/framework storage/app/installed.lock composer.lock database/*.sqlite *.log`).


---

# Setup, install & update (moved from SETUP.md / README.md / UPDATE-INSTRUCTIONS.txt)

# Quick setup

1. On shared hosting, extract the project into `public_html`. Keep the included root `.htaccess` file; it routes public traffic through the Laravel `public/` directory and blocks direct web access to application files. If the host lets you set a document root, `public/` is the preferred target.
2. Create an empty MySQL database and database user in your hosting control panel.
3. From the project directory, run `sh prepare-hosting.sh` in the hosting terminal. It installs PHP dependencies and sets folder permissions. This ZIP already includes the production frontend files, so Node/npm are not needed on Hostinger.
4. Turn on HTTPS, then open `https://your-domain.example/install` and enter the MySQL details and first administrator account.
5. Sign in at `/login`. The install page locks itself after setup.

The host needs PHP 8.5, Composer, and MySQL/MariaDB. The setup script can build the frontend as a fallback if `public/build/` has been removed; for this release the assets are included. See `README.md` for security/deployment details.

## Updating an existing Hostinger install

1. Extract `Update.zip` into `/home/u597262569/domains/riseway.io/public_html`, allow files to overwrite, and keep the existing `.env` and `vendor/` directory.
2. In `public_html`, run: `composer dump-autoload --no-dev --no-scripts && php artisan migrate --force && php artisan optimize:clear`

## Email setup

New signups receive a welcome email that includes the account email and sign-in address; it never includes a password. Password recovery uses Laravel's secure reset link. Both require Hostinger SMTP settings in the existing `.env`: `MAIL_MAILER=smtp`, `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_ENCRYPTION` or `MAIL_SCHEME`, `MAIL_FROM_ADDRESS`, and `MAIL_FROM_NAME`. Then run `php artisan optimize:clear` once. Email delivery was not testable here because the local PHP/SMTP environment is unavailable.

## Fresh install on a NEW host / domain

1. Extract the ZIP, make sure `storage/app/installed.lock` does NOT exist (delete it if present) and there is no `.env`.
2. Create an empty MySQL database + user, run `sh prepare-hosting.sh` (installs `vendor/`), turn on HTTPS.
3. Open `https://your-domain/install` — it writes `.env`, creates every table (all migrations) and your first admin.
4. Add the cron in the hosting panel (every minute): `cd ~/public_html && php artisan schedule:run` — needed for earn interest, bots, futures liquidation/TP/SL, limit & TP/SL orders, price alerts and P2P expiry.
5. In `.env` set `APP_URL` to the new domain, `PKR_RATE`, SMTP (or Admin → Settings → Email), then `php artisan optimize:clear`.
6. In Admin → Deposits add your manual deposit addresses; Admin → Gateways/Settings for fees, KYC, P2P, maintenance etc. Keep `storage/` writable (KYC photos).
7. Server must reach `api.bybit.com` (prices) — outbound HTTPS must not be blocked.

## What the platform does today

Wallet ledger, deposits (manual + NOWPayments), withdrawals with admin review, spot (market, limit, TP/SL), futures, convert, earn, bots/copy, P2P, referrals, KYC, notifications/e-mails, 2FA, support tickets and a full admin console. See `HANDOFF.md` for every pack and its notes.


## Pack: mobile layout fix, no-zoom viewport, minimal KYC, data reset command
* Reverted a too-broad global CSS rule (`*{max-width:100%}`) from the previous pack — it was squishing icons/circles and causing overlapping elements on phones (Assets, Earn). Kept only `html,body{overflow-x:hidden}`.
* Fixed the real cause of the Earn/Bots page overflowing sideways on phones: CSS Grid items default to `min-width:auto`, so a wide table blew past the screen edge. Added `min-width:0` on the grid children (`earn-bots.css`) and made the staking table scroll horizontally inside its own box instead of blowing out the page.
* Viewport meta (`app.blade.php`, `auth.blade.php`, `install.blade.php`, `maintenance.blade.php`) now sets `maximum-scale=1, user-scalable=no` — the site no longer pinch/double-tap zooms on phones.
* Withdraw asset dropdown: "USDT — Tether USDT" → just "Tether USDT".
* KYC simplified to: full name, mobile number (from account), document front photo, document back photo. Removed: document type, document number, selfie. (`doc_type`/`doc_number`/`selfie_path` columns are still in the DB for compatibility but are no longer shown or required.)
* New command `php artisan rushx:reset-data` (asks to confirm, or `--yes` to skip): deletes every non-admin user and all balances/transactions/orders/KYC/tickets/etc. Keeps admin accounts and settings. Irreversible, no backup is made.

## Pack: profit-calc audit, zero fees, security pass
* Audited spot and futures profit/ROE math end to end (backend `FuturesPosition::pnlAt`, `FuturesService::settle/triggerFor/bufferLeftPct`, `SpotTradingService::marketOrder`, and the matching frontend formulas in `FuturesPage.tsx`/`lib/wallet.ts`): the math is correct (notional = margin × leverage; PnL = notional × (price−entry)/entry × direction; ROE = PnL/margin). The fee is charged on the full notional (standard), so at high leverage it is a bigger bite out of margin than it looks — that's very likely what read as "wrong profit".
* New command `php artisan rushx:zero-fees` sets spot, futures, convert and P2P fees to 0% (same effect as Admin → Settings, just from the command line). Reversible any time from Admin → Settings.
* Quick security pass: CSRF on, session cookie secure/http-only/same-site=lax, NOWPayments webhook verifies HMAC signature before trusting it, every cancel/close endpoint checks `user_id` ownership (withdrawals, limit/TP-SL orders, tickets, futures), no raw SQL/`dangerouslySetInnerHTML`/`eval` found, ledger writes are row-locked + idempotency-keyed. No new issues found in this pass.

## Pack: KYC — removed the Country field
* KYC form no longer shows a Country selector. Mobile number (with its country-code select, which still implies a country) is the only location field; `country` is still saved server-side (from the account, or derived from the chosen dial code for older accounts) for internal records, just not shown as its own field.
