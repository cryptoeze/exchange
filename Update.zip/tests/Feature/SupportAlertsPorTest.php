<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\LedgerService;
use App\Services\MarketDataService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class SupportAlertsPorTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(string $role = 'user'): User
    {
        return User::create(['name' => 'U', 'email' => 'u'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => $role]);
    }

    public function test_price_alert_fires_once_when_the_price_is_reached(): void
    {
        $this->app->instance(MarketDataService::class, new class extends MarketDataService {
            public function __construct() {}
            public function snapshot(string $type = 'both'): array { return ['markets' => [['symbol' => 'BTCUSDT', 'baseAsset' => 'BTC', 'marketType' => 'spot', 'isTradable' => true, 'lastPrice' => 91000.0]], 'meta' => ['updatedAt' => gmdate('c'), 'stale' => false]]; }
        });
        $u = $this->user();
        $this->actingAs($u)->postJson('/api/alerts', ['symbol' => 'BTCUSDT', 'direction' => 'above', 'price' => '90000'])->assertOk();
        $this->actingAs($u)->postJson('/api/alerts', ['symbol' => 'BTCUSDT', 'direction' => 'below', 'price' => '50000'])->assertOk();
        $this->artisan('alerts:check')->assertSuccessful();
        $this->artisan('alerts:check')->assertSuccessful();
        $this->assertSame(1, DB::table('user_notifications')->where('user_id', $u->id)->where('title', 'like', 'Price alert%')->count());
        $this->assertSame(1, DB::table('price_alerts')->whereNotNull('triggered_at')->count());
    }

    public function test_ticket_round_trip_user_and_admin(): void
    {
        $u = $this->user(); $admin = $this->user('admin'); $other = $this->user();
        $id = $this->actingAs($u)->postJson('/api/tickets', ['subject' => 'Help', 'category' => 'deposit', 'message' => 'My deposit is missing'])->assertCreated()->json('id');
        $this->assertDatabaseHas('user_notifications', ['user_id' => $admin->id, 'title' => 'New support ticket']);
        $this->actingAs($admin, 'admin')->get("/admin/tickets?id=$id")->assertOk();
        $this->actingAs($admin, 'admin')->post("/admin/tickets/$id/reply", ['message' => 'We are checking'])->assertRedirect();
        $this->assertSame('answered', DB::table('tickets')->find($id)->status);
        $this->assertDatabaseHas('user_notifications', ['user_id' => $u->id, 'title' => 'New reply on your ticket: Help']);
        $this->actingAs($u)->getJson("/api/tickets/$id")->assertOk()->assertJsonCount(2, 'messages');
        $this->actingAs($other)->getJson("/api/tickets/$id")->assertNotFound();
        $this->actingAs($u)->postJson("/api/tickets/$id/close")->assertOk()->assertJsonPath('ticket.status', 'closed');
    }

    public function test_proof_of_reserves_shows_live_liabilities_and_admin_reported_reserves(): void
    {
        $u = $this->user();
        app(LedgerService::class)->apply($u->id, 'funding', 'USDT', 100 * 100000000, 'admin_credit');
        $admin = $this->user('admin');
        $this->actingAs($admin, 'admin')->post('/admin/por', ['asset' => 'USDT', 'amount' => '120', 'wallet' => 'TXyz'])->assertRedirect();
        $this->get('/proof-of-reserves')->assertOk()->assertInertia(fn ($p) => $p->component('ProofOfReserves')->where('rows.0.asset', 'USDT')->where('rows.0.ratio', 120));
        $this->actingAs($admin, 'admin')->get('/admin/por')->assertOk();
    }

    public function test_admin_pages_for_p2p_and_new_sections_open(): void
    {
        $admin = $this->user('admin');
        foreach (['/admin/p2p', '/admin/p2p?tab=orders', '/admin/p2p?tab=ads', '/admin/tickets', '/admin/security', '/admin/team', '/admin/por'] as $url) {
            $this->actingAs($admin, 'admin')->get($url)->assertOk();
        }
        $this->get('/p2p')->assertOk();
        $this->actingAs($this->user())->get('/p2p/orders')->assertOk();
    }
}
