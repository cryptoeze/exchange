<?php

namespace Tests\Feature;

use App\Models\FuturesPosition;
use App\Models\User;
use App\Services\FuturesService;
use App\Services\LedgerService;
use App\Services\MarketDataService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class FuturesTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;
    public static float $price = 50000.0;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        config(['trading.futures_fee_rate' => 0.001, 'trading.futures_maintenance_rate' => 0.005]);
        self::$price = 50000.0;
        $this->app->instance(MarketDataService::class, new class extends MarketDataService {
            public function __construct() {}
            public function snapshot(string $type = 'both'): array {
                return ['markets' => [['symbol' => 'BTCUSDT', 'baseAsset' => 'BTC', 'marketType' => 'futures', 'isTradable' => true, 'lastPrice' => FuturesTest::$price]],
                    'meta' => ['updatedAt' => gmdate('c'), 'stale' => false]];
            }
        });
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function trader(string $trading = '1000'): User
    {
        $u = User::query()->create(['name' => 'T', 'email' => 't'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
        DB::transaction(fn () => app(LedgerService::class)->apply($u->id, 'trading', 'USDT', Money::toUnits($trading), 'admin_credit'));

        return $u;
    }

    private function bal(User $u, string $account = 'trading'): int
    {
        return app(LedgerService::class)->balance($u->id, $account, 'USDT');
    }

    private function open(User $u, array $extra = []): \Illuminate\Testing\TestResponse
    {
        return $this->actingAs($u)->postJson('/api/futures/open', $extra + ['symbol' => 'BTCUSDT', 'side' => 'long', 'margin' => '100', 'leverage' => 10]);
    }

    public function test_open_locks_margin_charges_fee_and_uses_server_price(): void
    {
        $u = $this->trader();
        $res = $this->open($u, ['idempotency_key' => 'k1', 'entry_price' => 1])->assertCreated()->json();
        // margin 100 locked, fee = 100*10*0.001 = 1
        $this->assertSame(Money::toUnits('899'), $this->bal($u));
        $this->assertSame(Money::toUnits('100'), $this->bal($u, 'futures'));
        $this->assertEquals(50000.0, $res['positions'][0]['entry']); // client price is ignored
        $this->open($u, ['idempotency_key' => 'k1'])->assertCreated(); // replay: no second position
        $this->assertSame(1, FuturesPosition::query()->count());
        $this->assertSame(Money::toUnits('899'), $this->bal($u));
    }

    public function test_profit_close_pays_pnl_minus_fees_and_losses_are_capped_at_margin(): void
    {
        $u = $this->trader();
        $id = $this->open($u)->json('positions.0.id');
        self::$price = 51000.0; // +2% x 10 = +20% of margin = +20
        $this->actingAs($u)->postJson('/api/futures/close', ['position_id' => $id])->assertOk();
        // notional 1000; close notional 1020, fee 1.02; payout = 100 + 20 - 1.02 = 118.98
        $this->assertSame(Money::toUnits('899') + Money::toUnits('118.98'), $this->bal($u));
        $this->assertSame(0, $this->bal($u, 'futures'));
        // Short that moves against the user is liquidated: loses margin only.
        self::$price = 50000.0;
        $u2 = $this->trader();
        $this->open($u2, ['side' => 'short', 'leverage' => 20, 'margin' => '50']);
        self::$price = 53000.0; // +3.9% against a 20x short -> beyond liquidation
        $this->actingAs($u2)->getJson('/api/futures/state')->assertOk();
        $this->assertSame(0, $this->bal($u2, 'futures'));
        $this->assertSame(Money::toUnits('1000') - Money::toUnits('50') - Money::toUnits('1'), $this->bal($u2)); // margin and open fee gone, nothing returned
        $this->assertSame('liquidation', FuturesPosition::query()->where('user_id', $u2->id)->value('close_reason'));
    }

    public function test_take_profit_and_stop_loss_are_enforced_by_the_server(): void
    {
        $u = $this->trader();
        $this->open($u, ['tp' => 51000, 'sl' => 49500])->assertCreated();
        self::$price = 50500.0;
        $this->actingAs($u)->getJson('/api/futures/state')->assertOk();
        $this->assertSame(1, FuturesPosition::query()->where('status', 'open')->count());
        self::$price = 52000.0; // through the TP: fills at the TP price 51000
        app(FuturesService::class)->sweep();
        $p = FuturesPosition::query()->first();
        $this->assertSame('tp', $p->close_reason);
        $this->assertEquals(51000.0, $p->close_micro / Money::SCALE);
        $this->assertSame(0, $this->bal($u, 'futures'));
    }

    public function test_validation_and_guards(): void
    {
        $u = $this->trader('10');
        $this->open($u, ['margin' => '50'])->assertStatus(422); // not enough balance
        $this->open($u, ['margin' => '5', 'leverage' => 101])->assertStatus(422);
        $this->open($u, ['margin' => '0.5'])->assertStatus(422);
        $this->open($u, ['margin' => '5', 'tp' => 49000])->assertStatus(422); // TP below entry on a long
        $this->open($u, ['symbol' => 'FAKEUSDT', 'margin' => '5'])->assertStatus(422);
        $this->assertSame(Money::toUnits('10'), $this->bal($u));
        $this->assertSame(0, FuturesPosition::query()->count());
        $other = $this->trader();
        $id = $this->open($this->trader())->json('positions.0.id');
        $this->actingAs($other)->postJson('/api/futures/close', ['position_id' => $id])->assertStatus(422); // someone else's position
        auth()->logout();
        $this->getJson('/api/futures/state')->assertStatus(401);
        $this->get('/futures')->assertRedirect();
    }
}
