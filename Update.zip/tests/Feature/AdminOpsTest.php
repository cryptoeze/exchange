<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminOpsTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function admin(): User
    {
        return User::create(['name' => 'Boss', 'email' => 'boss@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'admin']);
    }

    public function test_admin_pages_render_with_real_data(): void
    {
        $a = $this->admin();
        $u = User::create(['name' => 'Alice', 'email' => 'alice@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        foreach (['/admin', '/admin/users', '/admin/users?q=alice', '/admin/gateways', '/admin/settings', '/admin/kyc', '/admin/notifications', '/admin/audit', '/admin/referrals', '/admin/users/'.$u->id] as $url) {
            $this->actingAs($a, 'admin')->get($url)->assertOk();
        }
    }

    public function test_gateway_save_changes_switches_and_withdraw_networks_and_is_audited(): void
    {
        $a = $this->admin();
        $this->actingAs($a, 'admin')->post('/admin/gateways', [
            'switches' => ['auto_deposit' => true, 'manual_deposit' => false, 'withdraw_enabled' => true, 'kyc_required' => true],
            'networks' => [['ticker' => 'USDT', 'code' => 'TRC20', 'min' => 10, 'fee' => 2, 'off' => false], ['ticker' => 'USDT', 'code' => 'ERC20', 'min' => 10, 'fee' => 5, 'off' => true]],
        ])->assertRedirect();
        app(\App\Services\SettingsService::class)->apply();
        $this->assertFalse(config('gateways.manual_deposit'));
        $this->assertTrue(config('kyc.required_for_withdrawal'));
        $usdt = collect(config('withdraw.assets'))->firstWhere('ticker', 'USDT');
        $this->assertSame(10.0, $usdt['min']);
        $codes = array_column($usdt['networks'], 'code');
        $this->assertContains('TRC20', $codes);
        $this->assertNotContains('ERC20', $codes);
        $this->assertSame(2.0, collect($usdt['networks'])->firstWhere('code', 'TRC20')['fee']);
        $this->assertDatabaseHas('admin_audit_logs', ['action' => 'gateways.save']);
    }

    public function test_freeze_toggle_works(): void
    {
        $a = $this->admin();
        $u = User::create(['name' => 'Bob', 'email' => 'bob@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        $this->actingAs($a, 'admin')->post("/admin/users/{$u->id}/status", ['status' => 'frozen'])->assertRedirect();
        $this->assertSame('frozen', $u->fresh()->status);
    }

    public function test_pnl_share_flag_is_off_by_default_and_follows_config(): void
    {
        $u = User::create(['name' => 'T', 'email' => 't@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        $this->actingAs($u)->get('/futures')->assertOk()->assertInertia(fn ($p) => $p->where('pnlShare', false)->where('referralCode', null));
        config(['features.pnl_share' => true]);
        $this->actingAs($u)->get('/futures')->assertOk()->assertInertia(fn ($p) => $p->where('pnlShare', true)->where('referralCode', $u->referral_code));
    }

    public function test_fee_settings_are_percent_in_the_form_and_a_fraction_in_config(): void
    {
        $svc = app(\App\Services\SettingsService::class);
        $svc->save(['spot_fee' => '0.15', 'futures_fee' => '0.08', 'futures_max_lev' => '50']);
        $svc->apply();
        $this->assertEqualsWithDelta(0.0015, config('trading.spot_fee_rate'), 1e-9);
        $this->assertEqualsWithDelta(0.0008, config('trading.futures_fee_rate'), 1e-9);
        $this->assertSame(50, config('trading.futures_max_leverage'));
        $this->assertSame('0.15', $svc->current()['spot_fee']);
    }

    public function test_margin_buffer_math_and_one_time_warning_with_notification(): void
    {
        $u = User::create(['name' => 'Trader', 'email' => 'tr@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        $p = \App\Models\FuturesPosition::create(['user_id' => $u->id, 'symbol' => 'BTCUSDT', 'side' => 'long', 'leverage' => 10, 'margin' => 100 * 100000000, 'entry_micro' => 100 * 100000000, 'status' => 'open']);
        $svc = app(\App\Services\FuturesService::class);
        $this->assertEqualsWithDelta(100.0, $svc->bufferLeftPct($p, 100.0), 0.01);
        $this->assertEqualsWithDelta(47.4, $svc->bufferLeftPct($p, 95.0), 0.5);
        $warn = new \ReflectionMethod($svc, 'warnIfLow'); $warn->setAccessible(true);
        config(['trading.margin_alert_pct' => 50]);
        $warn->invoke($svc, $p, 95.0); $warn->invoke($svc, $p->fresh(), 94.0);
        $this->assertSame(1, \Illuminate\Support\Facades\DB::table('user_notifications')->where('user_id', $u->id)->count());
        $this->assertNotNull($p->fresh()->warned_at);
        $warn->invoke($svc, $p->fresh(), 100.0);
        $this->assertNull($p->fresh()->warned_at);
    }

    public function test_email_templates_render_override_and_admin_pages_open(): void
    {
        $a = $this->admin();
        $mail = app(\App\Services\MailService::class);
        $this->assertStringContainsString('125.00 USDT', $mail->render('deposit_credited', ['name' => 'A', 'amount' => '125.00', 'asset' => 'USDT'])['subject']);
        $this->actingAs($a, 'admin')->post('/admin/emails/deposit_credited', ['subject' => 'Custom {amount}', 'heading' => 'H', 'body' => 'B {name}', 'enabled' => false])->assertRedirect();
        $this->assertFalse($mail->template('deposit_credited')['enabled']);
        $this->assertSame('Custom 5', $mail->render('deposit_credited', ['name' => 'A', 'amount' => '5', 'asset' => 'USDT'])['subject']);
        $this->actingAs($a, 'admin')->get('/admin/emails')->assertOk();
    }

    public function test_bot_and_earn_limits_are_enforced(): void
    {
        $u = User::create(['name' => 'U', 'email' => 'u2@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        app(\App\Services\LedgerService::class)->apply($u->id, 'funding', 'USDT', 1000 * 100000000, 'admin_adjust', ['note' => 't']);
        $bot = \App\Models\Bot::create(['name' => 'B', 'pair' => 'BTCUSDT', 'strategy' => 'x', 'daily_yield_pct' => 1, 'profit_share_pct' => 0, 'min_units' => 10 * 100000000, 'max_per_user' => 100 * 100000000, 'enabled' => true, 'kind' => 'bot', 'sort' => 1]);
        $this->expectException(\DomainException::class);
        app(\App\Services\BotService::class)->follow($u, $bot, 200 * 100000000, false);
    }
}
