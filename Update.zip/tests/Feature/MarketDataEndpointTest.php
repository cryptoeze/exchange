<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class MarketDataEndpointTest extends TestCase
{
    private string $installLock;
    private bool $createdInstallLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        config(['cache.default' => 'array', 'market-data.base_url' => 'https://api.bybit.com']);
        Cache::flush();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) {
            file_put_contents($this->installLock, 'test');
            $this->createdInstallLock = true;
        }
    }

    protected function tearDown(): void
    {
        if ($this->createdInstallLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    public function test_market_api_returns_normalized_spot_and_futures_prices_from_provider_payloads(): void
    {
        Http::fake(function ($request) {
            parse_str((string) parse_url($request->url(), PHP_URL_QUERY), $query);
            $linear = ($query['category'] ?? '') === 'linear';
            $symbol = $linear ? 'ETHUSDT' : 'BTCUSDT';
            if (str_contains($request->url(), 'instruments-info')) {
                return Http::response(['retCode' => 0, 'result' => ['list' => [[
                    'symbol' => $symbol, 'baseCoin' => $linear ? 'ETH' : 'BTC', 'quoteCoin' => 'USDT', 'status' => 'Trading', 'launchTime' => '1500000000000',
                ]], 'nextPageCursor' => '']]);
            }
            return Http::response(['retCode' => 0, 'result' => ['list' => [[
                'symbol' => $symbol, 'lastPrice' => $linear ? '3500.123456' : '68000.12', 'price24hPcnt' => $linear ? '0.025' : '-0.01',
                'highPrice24h' => $linear ? '3600' : '69000', 'lowPrice24h' => $linear ? '3400' : '67000', 'volume24h' => '100', 'turnover24h' => $linear ? '900000' : '2000000',
            ]]]]);
        });

        $response = $this->getJson('/api/markets?type=both')->assertOk();
        $response->assertJsonPath('meta.provider', 'Bybit');
        $response->assertJsonPath('meta.stale', false);
        $response->assertJsonPath('meta.spotCount', 1);
        $response->assertJsonPath('meta.futuresCount', 1);
        $response->assertJsonPath('markets.0.marketType', 'spot');
        $response->assertJsonPath('markets.0.symbol', 'BTCUSDT');
        $response->assertJsonPath('markets.1.marketType', 'futures');
        $response->assertJsonPath('markets.1.change24h', 2.5);
        $response->assertJsonPath('highlights.topGainers.0.symbol', 'ETHUSDT');
    }

    public function test_market_api_returns_safe_retry_response_when_provider_is_unavailable(): void
    {
        Http::fake(fn () => Http::response(['retCode' => 10001, 'result' => []], 503));

        $this->getJson('/api/markets')
            ->assertStatus(503)
            ->assertJsonPath('message', 'Market data temporarily unavailable. Please try again.')
            ->assertHeader('Retry-After', '15');
    }
}
