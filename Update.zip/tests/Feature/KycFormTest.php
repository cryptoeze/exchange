<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class KycFormTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        Storage::fake('local');
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function payload(bool $back = true): array
    {
        $p = ['full_name' => 'Ali Khan', 'country' => 'Pakistan', 'dial' => '+92', 'phone' => '3001234567', 'front' => UploadedFile::fake()->image('f.jpg')];
        if ($back) $p['back'] = UploadedFile::fake()->image('b.jpg');

        return $p;
    }

    public function test_kyc_needs_full_name_front_back_and_phone_is_saved(): void
    {
        $u = User::create(['name' => 'T', 'email' => 'k@x.com', 'password' => 'password-12345', 'role' => 'user']);
        $this->actingAs($u)->post('/kyc', $this->payload(false))->assertSessionHasErrors('back');
        $this->assertSame(0, DB::table('kyc_submissions')->count());
        $this->actingAs($u)->post('/kyc', $this->payload(true))->assertSessionHasNoErrors();
        $row = DB::table('kyc_submissions')->first();
        $this->assertSame('Pakistan', DB::table('users')->where('id', $u->id)->value('country'));
        $this->assertSame('+923001234567', $row->phone);
        $this->assertSame('Ali Khan', $row->full_name);
        $this->assertNotNull($row->back_path);
        $this->assertSame('', $row->selfie_path);
    }

    public function test_account_country_and_mobile_override_the_form(): void
    {
        $u = User::create(['name' => 'C', 'email' => 'c@x.com', 'password' => 'password-12345', 'role' => 'user', 'phone' => '+971501234567', 'country' => 'United Arab Emirates']);
        $payload = $this->payload(true);
        unset($payload['country'], $payload['dial'], $payload['phone']);
        $this->actingAs($u)->post('/kyc', $payload)->assertSessionHasNoErrors();
        $row = DB::table('kyc_submissions')->where('user_id', $u->id)->first();
        $this->assertSame('+971501234567', $row->phone);
        $this->assertSame('United Arab Emirates', $row->country);
    }

    public function test_signup_requires_and_stores_country_and_mobile(): void
    {
        $base = ['name' => 'Zed', 'email' => 'zed@x.com', 'password' => 'Str0ngPassw0rd!', 'password_confirmation' => 'Str0ngPassw0rd!'];
        $this->post('/register', $base)->assertSessionHasErrors(['country', 'dial', 'phone']);
        $this->post('/register', $base + ['country' => 'India', 'dial' => '+91', 'phone' => '98765'])->assertSessionHasNoErrors();
        $u = User::where('email', 'zed@x.com')->first();
        $this->assertSame('+9198765', $u->phone);
        $this->assertSame('India', $u->country);
    }
}
