<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class KycFormTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        Storage::fake('local');
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function payload(string $type, bool $back): array
    {
        $p = ['full_name' => 'Ali Khan', 'country' => 'Pakistan', 'dial' => '+92', 'phone' => '3001234567', 'doc_type' => $type, 'doc_number' => '12345-6789012-3',
            'front' => UploadedFile::fake()->image('f.jpg'), 'selfie' => UploadedFile::fake()->image('s.jpg')];
        if ($back) $p['back'] = UploadedFile::fake()->image('b.jpg');

        return $p;
    }

    public function test_id_card_needs_both_sides_passport_does_not_and_phone_is_saved(): void
    {
        $u = User::create(['name' => 'T', 'email' => 'k@x.com', 'password' => 'password-12345', 'role' => 'user']);
        $this->actingAs($u)->post('/kyc', $this->payload('national_id', false))->assertSessionHasErrors('back');
        $this->assertSame(0, DB::table('kyc_submissions')->count());
        $this->actingAs($u)->post('/kyc', $this->payload('national_id', true))->assertSessionHasNoErrors();
        $row = DB::table('kyc_submissions')->first();
        $this->assertSame('+923001234567', $row->phone);
        $this->assertNotNull($row->back_path);

        $v = User::create(['name' => 'P', 'email' => 'p@x.com', 'password' => 'password-12345', 'role' => 'user']);
        $this->actingAs($v)->post('/kyc', $this->payload('passport', false))->assertSessionHasNoErrors();
        $this->assertNull(DB::table('kyc_submissions')->where('user_id', $v->id)->value('back_path'));
    }
}
