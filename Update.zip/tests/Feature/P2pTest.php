<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\LedgerService;
use App\Services\P2pService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class P2pTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        config(['p2p.fee_pct' => 0]);
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(string $usdt = '0'): User
    {
        $u = User::create(['name' => 'P'.uniqid(), 'email' => 'p'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
        if (Money::toUnits($usdt) > 0) app(LedgerService::class)->apply($u->id, 'funding', 'USDT', Money::toUnits($usdt), 'admin_credit');

        return $u;
    }

    private function bal(User $u, string $acc = 'funding'): int
    {
        return app(LedgerService::class)->balance($u->id, $acc, 'USDT');
    }

    private function sellAd(User $seller, string $amount = '100'): int
    {
        return app(P2pService::class)->createAd($seller, ['side' => 'sell', 'coin' => 'USDT', 'fiat' => 'PKR', 'price' => '280', 'amount' => $amount, 'min_fiat' => 1000, 'max_fiat' => 100000, 'methods' => ['JazzCash'], 'details' => ['JazzCash' => '0300-1234567 Ali']]);
    }

    public function test_sell_ad_escrows_and_a_full_order_releases_to_the_buyer(): void
    {
        $p2p = app(P2pService::class);
        $seller = $this->user('500'); $buyer = $this->user();
        $ad = $this->sellAd($seller, '100');
        $this->assertSame(Money::toUnits('400'), $this->bal($seller));
        $this->assertSame(Money::toUnits('100'), $this->bal($seller, 'p2p'));

        $ref = $p2p->start($buyer, $ad, '28000', 'JazzCash');
        $trade = DB::table('p2p_trades')->where('ref', $ref)->first();
        $this->assertSame(Money::toUnits('100'), (int) $trade->qty);
        $this->assertSame('0300-1234567 Ali', $trade->pay_details);
        $this->assertSame(0, (int) DB::table('p2p_ads')->find($ad)->available);

        $p2p->markPaid($buyer, $ref);
        $p2p->release($seller, $ref);
        $this->assertSame(Money::toUnits('100'), $this->bal($buyer));
        $this->assertSame(0, $this->bal($seller, 'p2p'));
        $this->assertSame('completed', DB::table('p2p_trades')->where('ref', $ref)->value('status'));
    }

    public function test_seller_cannot_release_before_payment_and_buyer_cannot_release(): void
    {
        $p2p = app(P2pService::class);
        $seller = $this->user('50'); $buyer = $this->user();
        $ref = $p2p->start($buyer, $this->sellAd($seller, '50'), '14000', 'JazzCash');
        try { $p2p->release($seller, $ref); $this->fail('released early'); } catch (\DomainException) {}
        $p2p->markPaid($buyer, $ref);
        try { $p2p->release($buyer, $ref); $this->fail('buyer released'); } catch (\DomainException) {}
        $this->assertSame(0, $this->bal($buyer));
    }

    public function test_cancel_and_expiry_return_coins_to_the_ad_and_closing_the_ad_refunds_the_rest(): void
    {
        $p2p = app(P2pService::class);
        $seller = $this->user('100'); $buyer = $this->user();
        $ad = $this->sellAd($seller, '100');
        $ref = $p2p->start($buyer, $ad, '14000', 'JazzCash'); // 50 USDT
        $this->assertSame(Money::toUnits('50'), (int) DB::table('p2p_ads')->find($ad)->available);
        $p2p->cancel($buyer, $ref);
        $this->assertSame(Money::toUnits('100'), (int) DB::table('p2p_ads')->find($ad)->available);

        $ref2 = $p2p->start($buyer, $ad, '14000', 'JazzCash');
        DB::table('p2p_trades')->where('ref', $ref2)->update(['expires_at' => now()->subMinute()]);
        $this->assertSame(1, $p2p->expireDue());
        $this->assertSame('expired', DB::table('p2p_trades')->where('ref', $ref2)->value('status'));

        $p2p->setAdStatus($seller, $ad, 'closed');
        $this->assertSame(Money::toUnits('100'), $this->bal($seller));
        $this->assertSame(0, $this->bal($seller, 'p2p'));
    }

    public function test_buy_ad_locks_the_responding_sellers_coins_and_release_pays_the_advertiser(): void
    {
        $p2p = app(P2pService::class);
        $advertiser = $this->user(); $responder = $this->user('80');
        $ad = $p2p->createAd($advertiser, ['side' => 'buy', 'coin' => 'USDT', 'fiat' => 'PKR', 'price' => '275', 'amount' => '100', 'min_fiat' => 1000, 'max_fiat' => 50000, 'methods' => ['Easypaisa']]);
        $this->assertSame(0, $this->bal($advertiser, 'p2p'));
        try { $p2p->start($responder, $ad, '11000', 'Easypaisa'); $this->fail('needs details'); } catch (\DomainException) {}
        $ref = $p2p->start($responder, $ad, '11000', 'Easypaisa', 'Easypaisa 0345 Sara');
        $this->assertSame(Money::toUnits('40'), (int) DB::table('p2p_trades')->where('ref', $ref)->value('qty'));
        $this->assertSame(Money::toUnits('40'), $this->bal($responder, 'p2p'));
        $p2p->markPaid($advertiser, $ref); $p2p->release($responder, $ref);
        $this->assertSame(Money::toUnits('40'), $this->bal($advertiser));
        $this->assertSame(Money::toUnits('40'), $this->bal($responder));
    }

    public function test_dispute_admin_resolution_both_ways_and_fee(): void
    {
        config(['p2p.fee_pct' => 1]);
        $p2p = app(P2pService::class);
        $seller = $this->user('100'); $buyer = $this->user();
        $ad = $this->sellAd($seller, '100');
        $ref = $p2p->start($buyer, $ad, '14000', 'JazzCash'); $p2p->markPaid($buyer, $ref);
        $p2p->dispute($buyer, $ref, 'Seller is not answering');
        $p2p->resolve(1, $ref, 'release', 'screenshot ok');
        $this->assertSame(Money::toUnits('49.5'), $this->bal($buyer)); // 1% fee kept
        $ref2 = $p2p->start($buyer, $ad, '14000', 'JazzCash'); $p2p->markPaid($buyer, $ref2);
        $p2p->dispute($seller, $ref2, 'Payment never arrived');
        $p2p->resolve(1, $ref2, 'refund', null);
        $this->assertSame(Money::toUnits('50'), (int) DB::table('p2p_ads')->find($ad)->available);
        $this->assertSame('cancelled', DB::table('p2p_trades')->where('ref', $ref2)->value('status'));
    }

    public function test_api_lists_ads_publicly_and_hides_account_details(): void
    {
        $seller = $this->user('100'); $this->sellAd($seller, '100');
        $res = $this->getJson('/api/p2p/ads?want=buy&fiat=PKR')->assertOk()->json();
        $this->assertCount(1, $res['ads']);
        $this->assertArrayNotHasKey('details', $res['ads'][0]);
        $buyer = $this->user();
        $this->actingAs($buyer)->postJson('/api/p2p/trades', ['ad_id' => $res['ads'][0]['id'], 'fiat_amount' => '5000', 'method' => 'JazzCash'])->assertCreated();
        $ref = DB::table('p2p_trades')->value('ref');
        $this->actingAs($buyer)->getJson("/api/p2p/trades/$ref")->assertOk()->assertJsonPath('trade.role', 'buyer')->assertJsonPath('trade.payDetails', '0300-1234567 Ali');
        $stranger = $this->user();
        $this->actingAs($stranger)->getJson("/api/p2p/trades/$ref")->assertNotFound();
    }
}
