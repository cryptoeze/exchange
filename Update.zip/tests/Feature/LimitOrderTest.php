<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\LedgerService;
use App\Services\LimitOrderService;
use App\Services\MarketDataService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class LimitOrderTest extends TestCase
{
    use RefreshDatabase;

    public static float $price = 50000.0;
    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        config(['trading.spot_fee_rate' => 0.001]);
        self::$price = 50000.0;
        $this->app->instance(MarketDataService::class, new class extends MarketDataService {
            public function __construct() {}
            public function snapshot(string $type = 'both'): array {
                return ['markets' => [['symbol' => 'BTCUSDT', 'baseAsset' => 'BTC', 'marketType' => 'spot', 'isTradable' => true, 'lastPrice' => LimitOrderTest::$price]], 'meta' => ['updatedAt' => gmdate('c'), 'stale' => false]];
            }
        });
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(string $usdt = '0', string $btc = '0'): User
    {
        $u = User::create(['name' => 'T', 'email' => 't'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
        $l = app(LedgerService::class);
        if (Money::toUnits($usdt) > 0) $l->apply($u->id, 'funding', 'USDT', Money::toUnits($usdt), 'admin_credit');
        if (Money::toUnits($btc) > 0) $l->apply($u->id, 'funding', 'BTC', Money::toUnits($btc), 'admin_credit');

        return $u;
    }

    private function bal(User $u, string $acc, string $asset): int
    {
        return app(LedgerService::class)->balance($u->id, $acc, $asset);
    }

    public function test_resting_buy_limit_reserves_then_fills_at_the_better_price(): void
    {
        $u = $this->user('10000');
        $svc = app(LimitOrderService::class);
        $o = $svc->place($u, 'BTCUSDT', 'buy', '49000', '0.1');
        $this->assertSame('open', $o->status);
        $reserved = (int) $o->reserved;
        $this->assertSame(Money::toUnits('10000') - $reserved, $this->bal($u, 'funding', 'USDT'));
        $this->assertSame($reserved, $this->bal($u, 'hold', 'USDT'));

        $this->assertSame(0, $svc->sweep());
        self::$price = 48500.0;
        $this->assertSame(1, $svc->sweep());
        $this->assertSame(Money::toUnits('0.1'), $this->bal($u, 'funding', 'BTC'));
        $this->assertSame(0, $this->bal($u, 'hold', 'USDT'));
        $cost = (int) floor(Money::toUnits('0.1') * 48500.0);
        $this->assertSame(Money::toUnits('10000') - $cost - (int) floor($cost * 0.001), $this->bal($u, 'funding', 'USDT'));
    }

    public function test_cancel_returns_everything(): void
    {
        $u = $this->user('5000', '1');
        $svc = app(LimitOrderService::class);
        $a = $svc->place($u, 'BTCUSDT', 'buy', '45000', '0.05');
        $b = $svc->place($u, 'BTCUSDT', 'sell', '60000', '0.5');
        $svc->cancel($u, $a->id); $svc->cancel($u, $b->id);
        $this->assertSame(Money::toUnits('5000'), $this->bal($u, 'funding', 'USDT'));
        $this->assertSame(Money::toUnits('1'), $this->bal($u, 'funding', 'BTC'));
        $this->assertSame(0, $this->bal($u, 'hold', 'USDT') + $this->bal($u, 'hold', 'BTC'));
        $this->expectException(\DomainException::class);
        $svc->cancel($u, $a->id);
    }

    public function test_resting_sell_limit_fills_when_price_rises_and_marketable_limit_fills_now(): void
    {
        $u = $this->user('0', '1');
        $svc = app(LimitOrderService::class);
        $svc->place($u, 'BTCUSDT', 'sell', '52000', '0.2');
        $this->assertSame(Money::toUnits('0.8'), $this->bal($u, 'funding', 'BTC'));
        self::$price = 53000.0; $svc->sweep();
        $gross = (int) floor(Money::toUnits('0.2') * 53000.0);
        $this->assertSame($gross - (int) floor($gross * 0.001), $this->bal($u, 'funding', 'USDT'));

        self::$price = 50000.0;
        $buyer = $this->user('10000');
        $o = $svc->place($buyer, 'BTCUSDT', 'buy', '51000', '0.1');
        $this->assertSame('filled', $o->status);
        $this->assertSame(Money::toUnits('0.1'), $this->bal($buyer, 'funding', 'BTC'));
        $this->assertSame(0, $this->bal($buyer, 'hold', 'USDT'));
        $this->assertSame(2, DB::table('spot_orders')->count());
    }

    public function test_take_profit_and_stop_loss_orders_trigger_and_validate(): void
    {
        $svc = app(LimitOrderService::class);
        $u = $this->user('0', '2');
        $tp = $svc->place($u, 'BTCUSDT', 'sell', '55000', '0.5', null, 'tp');
        $sl = $svc->place($u, 'BTCUSDT', 'sell', '45000', '0.5', null, 'sl');
        $this->assertSame('open', $tp->status);
        $this->assertSame(Money::toUnits('1'), $this->bal($u, 'hold', 'BTC'));
        self::$price = 51000.0; $this->assertSame(0, $svc->sweep());
        self::$price = 44000.0; $this->assertSame(1, $svc->sweep());
        $this->assertSame('filled', DB::table('spot_limit_orders')->find($sl->id)->status);
        $this->assertSame('open', DB::table('spot_limit_orders')->find($tp->id)->status);
        $gross = (int) floor(Money::toUnits('0.5') * 44000.0);
        $this->assertSame($gross - (int) floor($gross * 0.001), $this->bal($u, 'funding', 'USDT'));
        self::$price = 56000.0; $this->assertSame(1, $svc->sweep());
        $this->assertSame(0, $this->bal($u, 'hold', 'BTC'));
        self::$price = 50000.0;
        $this->expectException(\DomainException::class);
        $svc->place($this->user('0', '1'), 'BTCUSDT', 'sell', '49000', '0.1', null, 'tp');
    }

    public function test_api_validates_and_lists(): void
    {
        $u = $this->user('1000');
        $this->actingAs($u)->postJson('/api/spot/limit', ['symbol' => 'BTCUSDT', 'side' => 'buy', 'price' => '40000', 'amount' => '0.01'])->assertCreated()->assertJsonPath('open.0.side', 'buy');
        $this->actingAs($u)->postJson('/api/spot/limit', ['symbol' => 'BTCUSDT', 'side' => 'buy', 'price' => '100', 'amount' => '1'])->assertStatus(422);
        $this->actingAs($u)->getJson('/api/spot/limit')->assertOk()->assertJsonCount(1, 'open');
    }
}
