<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\LedgerService;
use App\Services\SettingsService;
use App\Services\SpotTradingService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class AdminSetupTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function admin(): User
    {
        return User::create(['name' => 'Boss', 'email' => 'boss@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'admin']);
    }

    private function user(): User
    {
        return User::create(['name' => 'Alice', 'email' => 'alice@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
    }

    public function test_new_admin_pages_render(): void
    {
        $a = $this->admin();
        foreach (['/admin/markets', '/admin/orders', '/admin/orders?status=filled', '/admin/settings'] as $url) {
            $this->actingAs($a, 'admin')->get($url)->assertOk();
        }
    }

    public function test_site_setup_smtp_secret_is_encrypted_and_applies(): void
    {
        $a = $this->admin();
        $values = app(SettingsService::class)->current();
        $values['site_name'] = 'RushX Pro';
        $values['smtp_host'] = 'smtp.example.com';
        $values['smtp_port'] = '465';
        $values['smtp_pass'] = 'S3cret-pass';
        $this->actingAs($a, 'admin')->post('/admin/settings', $values)->assertRedirect();
        $raw = DB::table('settings')->where('key', 'smtp_pass')->value('value');
        $this->assertNotSame('S3cret-pass', $raw);
        app(SettingsService::class)->apply();
        $this->assertSame('S3cret-pass', config('mail.mailers.smtp.password'));
        $this->assertSame('RushX Pro', config('app.name'));
        $this->assertSame('********', app(SettingsService::class)->current()['smtp_pass']);
        // Saving the masked value again keeps the stored password.
        $values['smtp_pass'] = '********';
        $this->actingAs($a, 'admin')->post('/admin/settings', $values)->assertRedirect();
        $this->assertSame($raw, DB::table('settings')->where('key', 'smtp_pass')->value('value'));
        $this->assertDatabaseMissing('admin_audit_logs', ['details' => '%S3cret%']);
    }

    public function test_maintenance_blocks_users_but_not_admin(): void
    {
        $a = $this->admin();
        config(['app.maintenance_mode' => true, 'app.maintenance_message' => 'Back soon']);
        $this->get('/markets')->assertStatus(503)->assertSee('Back soon');
        $this->getJson('/api/markets')->assertStatus(503);
        $this->actingAs($a, 'admin')->get('/admin')->assertOk();
    }

    public function test_paused_pair_blocks_trading_and_pairs_save_persists(): void
    {
        $a = $this->admin();
        $this->actingAs($a, 'admin')->post('/admin/markets', ['paused' => ['BTCUSDT', 'ETHUSDT']])->assertRedirect();
        app(SettingsService::class)->apply();
        $this->assertSame(['BTCUSDT', 'ETHUSDT'], config('trading.disabled_pairs'));
        $this->expectExceptionMessage('paused');
        app(SpotTradingService::class)->quote('BTCUSDT');
    }

    public function test_admin_edits_user_and_resets_password(): void
    {
        $a = $this->admin();
        $u = $this->user();
        $this->actingAs($a, 'admin')->post('/admin/users/'.$u->id.'/profile', ['name' => 'Alice B', 'email' => 'alice2@x.com', 'password' => 'N3w-long-password'])->assertRedirect();
        $u->refresh();
        $this->assertSame('Alice B', $u->name);
        $this->assertSame('alice2@x.com', $u->email);
        $this->assertTrue(\Illuminate\Support\Facades\Hash::check('N3w-long-password', $u->password));
        $this->actingAs($a, 'admin')->post('/admin/users/'.$u->id.'/profile', ['name' => 'X', 'email' => 'boss@x.com'])->assertSessionHasErrors('email');
        $this->assertDatabaseHas('admin_audit_logs', ['action' => 'user.edit']);
    }

    public function test_admin_can_cancel_a_resting_order_and_funds_return(): void
    {
        $a = $this->admin();
        $u = $this->user();
        $l = app(LedgerService::class);
        $l->apply($u->id, 'hold', 'BTC', Money::toUnits('0.5'), 'limit_hold');
        $id = DB::table('spot_limit_orders')->insertGetId(['user_id' => $u->id, 'symbol' => 'BTCUSDT', 'base_asset' => 'BTC', 'side' => 'sell', 'kind' => 'tp', 'limit_price' => 60000, 'qty' => Money::toUnits('0.5'), 'reserve_asset' => 'BTC', 'reserved' => Money::toUnits('0.5'), 'status' => 'open', 'created_at' => now()]);
        $this->actingAs($a, 'admin')->post("/admin/orders/$id/cancel")->assertRedirect();
        $this->assertSame('cancelled', DB::table('spot_limit_orders')->find($id)->status);
        $this->assertSame(Money::toUnits('0.5'), $l->balance($u->id, 'funding', 'BTC'));
        $this->assertSame(0, $l->balance($u->id, 'hold', 'BTC'));
    }
}
