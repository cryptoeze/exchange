<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\LedgerService;
use App\Services\SettingsService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Inertia\Testing\AssertableInertia as Assert;
use Tests\TestCase;

/** The admin sitemap: user 360, transactions, trades, deposits, withdrawals and gateways. */
class AdminStructureTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;
    private User $admin;
    private User $alice;
    private User $bob;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        $this->admin = User::create(['name' => 'Boss', 'email' => 'boss@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'admin']);
        $this->alice = User::create(['name' => 'Alice', 'email' => 'alice@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        $this->bob = User::create(['name' => 'Bob', 'email' => 'bob@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        DB::table('users')->where('id', $this->bob->id)->update(['status' => 'frozen']);
        $l = app(LedgerService::class);
        $l->apply($this->alice->id, 'funding', 'USDT', Money::toUnits('500'), 'deposit');
        $l->apply($this->alice->id, 'funding', 'USDT', -Money::toUnits('50'), 'withdrawal_hold');
        $l->apply($this->alice->id, 'funding', 'BTC', Money::toUnits('0.1'), 'admin_credit', ['note' => 'bonus']);
        $l->apply($this->bob->id, 'funding', 'USDT', Money::toUnits('20'), 'deposit');
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function adm(string $url)
    {
        return $this->actingAs($this->admin, 'admin')->get($url);
    }

    public function test_users_directory_filters_stats_and_csv(): void
    {
        $this->adm('/admin/users')->assertInertia(fn (Assert $p) => $p->component('Admin/Users')->where('stats.total', 2)->where('stats.frozen', 1)->has('rows', 2));
        $this->adm('/admin/users?status=frozen')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.email', 'bob@x.com'));
        $this->adm('/admin/users?q=alice')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.total', '450.00')->where('rows.0.uid', 100000 + $this->alice->id));
        $this->adm('/admin/users?q='.(100000 + $this->alice->id))->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $res = $this->adm('/admin/users?export=1');
        $res->assertOk();
        $this->assertStringContainsString('alice@x.com', $res->streamedContent());
    }

    public function test_every_user_tab_renders_with_its_own_data(): void
    {
        DB::table('withdrawals')->insert(['user_id' => $this->alice->id, 'asset' => 'USDT', 'network' => 'TRC20', 'address' => 'TXYZ', 'amount' => Money::toUnits('50'), 'fee' => Money::toUnits('1'), 'net' => Money::toUnits('49'), 'status' => 'pending', 'created_at' => now(), 'updated_at' => now()]);
        $id = $this->alice->id;
        foreach (\App\Http\Controllers\Admin\UsersController::TABS as $tab) {
            $this->adm("/admin/users/$id?tab=$tab")->assertOk()->assertInertia(fn (Assert $p) => $p->component('Admin/UserShow')->where('tab', $tab)->where('user.email', 'alice@x.com')->has('data'));
        }
        foreach (['spot', 'futures', 'limit', 'earn', 'bots'] as $sub) {
            $this->adm("/admin/users/$id?tab=trading&sub=$sub")->assertOk()->assertInertia(fn (Assert $p) => $p->where('data.sub', $sub));
        }
        $this->adm("/admin/users/$id?tab=deposits&sub=auto")->assertInertia(fn (Assert $p) => $p->where('data.sub', 'auto'));
        $this->adm("/admin/users/$id")->assertInertia(fn (Assert $p) => $p->where('counts.withdrawals', 1)->where('summary.totalUsdt', '450.00')->where('summary.deposited', '500.00'));
        $this->adm("/admin/users/$id?tab=wallet&cat=withdrawal")->assertInertia(fn (Assert $p) => $p->has('data.ledger', 1)->where('data.ledger.0.type', 'withdrawal_hold'));
        $this->adm("/admin/users/$id?tab=wallet&asset=BTC")->assertInertia(fn (Assert $p) => $p->has('data.ledger', 1));
        $this->adm('/admin/users/'.$id.'?tab=nonsense')->assertInertia(fn (Assert $p) => $p->where('tab', 'overview'));
    }

    public function test_user_actions_message_signout_2fa_and_audit(): void
    {
        $id = $this->alice->id;
        $this->alice->forceFill(['two_factor_enabled' => true, 'two_factor_secret' => 'x'])->save();
        $this->actingAs($this->admin, 'admin')->post("/admin/users/$id/notify", ['title' => 'Hello', 'body' => 'Welcome'])->assertRedirect();
        $this->assertDatabaseHas('user_notifications', ['user_id' => $id, 'title' => 'Hello']);
        $this->actingAs($this->admin, 'admin')->post("/admin/users/$id/2fa-reset")->assertRedirect();
        $this->assertFalse((bool) $this->alice->fresh()->two_factor_enabled);
        $this->actingAs($this->admin, 'admin')->post("/admin/users/$id/signout")->assertRedirect();
        foreach (['user.notify', 'user.2fa_reset', 'user.signout_all'] as $a) $this->assertDatabaseHas('admin_audit_logs', ['action' => $a]);
    }

    public function test_transactions_filters_summary_and_export(): void
    {
        $this->adm('/admin/transactions')->assertInertia(fn (Assert $p) => $p->component('Admin/Transactions')->has('rows', 4)->where('summary.asset', 'USDT')->where('summary.in', '520.00')->where('summary.out', '-50.00'));
        $this->adm('/admin/transactions?cat=deposit')->assertInertia(fn (Assert $p) => $p->has('rows', 2));
        $this->adm('/admin/transactions?cat=withdrawal&q=alice')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.category', 'withdrawal'));
        $this->adm('/admin/transactions?asset=BTC')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.by', null));
        $this->adm('/admin/transactions?dir=out')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/transactions?min=100')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/transactions?from=2999-01-01')->assertInertia(fn (Assert $p) => $p->has('rows', 0));
        $csv = $this->adm('/admin/transactions?export=1&cat=deposit');
        $csv->assertOk();
        $this->assertStringContainsString('bob@x.com', $csv->streamedContent());
    }

    public function test_spot_trades_page_lists_orders_with_totals(): void
    {
        DB::table('spot_orders')->insert(['user_id' => $this->alice->id, 'symbol' => 'BTCUSDT', 'base_asset' => 'BTC', 'side' => 'buy', 'price_micro' => 50000 * 100000000, 'base_qty' => Money::toUnits('0.01'), 'quote_total' => Money::toUnits('500.5'), 'fee' => Money::toUnits('0.1'), 'status' => 'filled', 'created_at' => now(), 'updated_at' => now()]);
        $this->adm('/admin/trades')->assertInertia(fn (Assert $p) => $p->component('Admin/Trades')->has('rows', 1)->where('stats.dayOrders', 1)->where('stats.matchVolume', '500.50')->where('rows.0.price', '50000'));
        $this->adm('/admin/trades?side=sell')->assertInertia(fn (Assert $p) => $p->has('rows', 0));
        $this->adm('/admin/trades?symbol=btc&q=alice')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
    }

    public function test_deposits_tabs_filters_and_review_actions(): void
    {
        $addr = DB::table('manual_deposit_addresses')->insertGetId(['asset' => 'USDT', 'network' => 'TRC20', 'label' => 'USDT TRC20', 'address' => 'TADDR', 'min_units' => 0, 'enabled' => 1, 'sort' => 1, 'created_at' => now(), 'updated_at' => now()]);
        $mk = fn ($uid, $tx, $st = 'pending') => DB::table('manual_deposits')->insertGetId(['user_id' => $uid, 'address_id' => $addr, 'asset' => 'USDT', 'network' => 'TRC20', 'claimed' => Money::toUnits('40'), 'txid' => $tx, 'status' => $st, 'created_at' => now(), 'updated_at' => now()]);
        config(['bonus.enabled' => false]);
        $one = $mk($this->alice->id, 'tx-aaa');
        $mk($this->bob->id, 'tx-bbb', 'rejected');
        $this->adm('/admin/deposits')->assertInertia(fn (Assert $p) => $p->component('Admin/Deposits')->where('tab', 'pending')->has('rows', 1)->where('counts.pending', 1)->where('stats.pendingValue', '40.00'));
        $this->adm('/admin/deposits?tab=all')->assertInertia(fn (Assert $p) => $p->has('rows', 2));
        $this->adm('/admin/deposits?tab=rejected&q=bob')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/deposits?tab=all&q=tx-aaa')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/deposits?tab=auto')->assertInertia(fn (Assert $p) => $p->where('tab', 'auto')->has('rows', 0));
        $this->actingAs($this->admin, 'admin')->post("/admin/deposits/$one", ['decision' => 'approve', 'amount' => '39.5'])->assertRedirect();
        $this->assertSame(Money::toUnits('39.5'), app(LedgerService::class)->balance($this->alice->id, 'funding', 'USDT') - Money::toUnits('450'));
        $this->adm('/admin/deposits?tab=approved')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.credited', '39.5')->where('rows.0.by', 'boss@x.com'));
    }

    public function test_withdrawals_tabs_filters_and_review(): void
    {
        $mk = fn ($uid, $st, $addr) => DB::table('withdrawals')->insertGetId(['user_id' => $uid, 'asset' => 'USDT', 'network' => 'TRC20', 'address' => $addr, 'amount' => Money::toUnits('30'), 'fee' => Money::toUnits('1'), 'net' => Money::toUnits('29'), 'status' => $st, 'created_at' => now(), 'updated_at' => now()]);
        $p1 = $mk($this->alice->id, 'pending', 'TADDRESS1');
        $mk($this->bob->id, 'completed', 'TADDRESS2');
        $this->adm('/admin/withdrawals')->assertInertia(fn (Assert $p) => $p->component('Admin/Withdrawals')->has('rows', 1)->where('counts.pending', 1)->where('stats.pendingValue', '29.00')->where('rows.0.kyc', 'none'));
        $this->adm('/admin/withdrawals?status=all')->assertInertia(fn (Assert $p) => $p->has('rows', 2));
        $this->adm('/admin/withdrawals?status=all&q=TADDRESS2')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.email', 'bob@x.com'));
        $this->adm('/admin/withdrawals?status=all&id='.$p1)->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->actingAs($this->admin, 'admin')->post("/admin/withdrawals/$p1", ['decision' => 'reject', 'reason' => 'bad address'])->assertRedirect();
        $this->adm('/admin/withdrawals?status=rejected')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.reason', 'bad address'));
        $this->assertSame(Money::toUnits('480'), app(LedgerService::class)->balance($this->alice->id, 'funding', 'USDT'));
    }

    public function test_gateways_tabs_deposit_switches_and_manual_methods(): void
    {
        foreach (['overview', 'deposit-auto', 'deposit-manual', 'withdraw'] as $tab) {
            $this->adm('/admin/gateways?tab='.$tab)->assertOk()->assertInertia(fn (Assert $p) => $p->component('Admin/Gateways')->where('tab', $tab)->has('depositCoins')->has('addresses'));
        }
        $code = config('deposit-coins.coins.0.networks.0.code');
        $this->actingAs($this->admin, 'admin')->post('/admin/gateways', ['switches' => ['auto_deposit' => true, 'manual_deposit' => true, 'withdraw_enabled' => true, 'kyc_required' => false], 'depositOff' => [$code]])->assertRedirect();
        app(SettingsService::class)->apply();
        $codes = collect(config('deposit-coins.coins'))->flatMap(fn ($c) => collect($c['networks'])->pluck('code'));
        $this->assertNotContains($code, $codes->all());
        $this->assertContains($code, collect(config('deposit-coins.coins_all'))->flatMap(fn ($c) => collect($c['networks'])->pluck('code'))->all());
        // switching everything back on
        $this->actingAs($this->admin, 'admin')->post('/admin/gateways', ['switches' => ['auto_deposit' => true], 'depositOff' => []])->assertRedirect();
        $this->assertSame('', DB::table('settings')->where('key', 'dep_off')->value('value'));
        // add a manual method
        $this->actingAs($this->admin, 'admin')->post('/admin/deposits/address', ['asset' => 'BTC', 'network' => 'BTC', 'label' => 'Bitcoin', 'address' => 'bc1qxyz', 'min' => '0.001', 'enabled' => true])->assertRedirect();
        $this->adm('/admin/gateways?tab=deposit-manual')->assertInertia(fn (Assert $p) => $p->where('addresses', fn ($a) => collect($a)->contains('label', 'Bitcoin')));
    }

    public function test_role_limits_and_legacy_links(): void
    {
        $support = User::create(['name' => 'Sam', 'email' => 'sam@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'admin']);
        DB::table('users')->where('id', $support->id)->update(['admin_role' => 'support']);
        $support->refresh();
        $this->actingAs($support, 'admin')->get('/admin/users')->assertOk();
        $this->actingAs($support, 'admin')->get('/admin/withdrawals')->assertForbidden();
        $this->actingAs($support, 'admin')->get('/admin/transactions')->assertForbidden();
        $this->actingAs($support, 'admin')->get('/admin/trades')->assertOk();
        $this->adm('/admin/p2pdesk')->assertRedirect('/admin/p2p');
        $this->adm('/admin')->assertInertia(fn (Assert $p) => $p->has('adminBadges'));
    }

    public function test_kyc_futures_orders_audit_referrals_lists_filter_and_paginate(): void
    {
        DB::table('kyc_submissions')->insert(['user_id' => $this->alice->id, 'full_name' => 'Alice A', 'country' => 'Pakistan', 'phone' => '+923001112233', 'doc_type' => 'national_id', 'doc_number' => '111-22', 'front_path' => 'a', 'back_path' => 'b', 'selfie_path' => 'c', 'status' => 'pending', 'created_at' => now(), 'updated_at' => now()]);
        $this->adm('/admin/kyc')->assertInertia(fn (Assert $p) => $p->component('Admin/Kyc')->has('rows', 1)->where('counts.pending', 1)->where('rows.0.phone', '+923001112233')->where('rows.0.hasBack', true));
        $this->adm('/admin/kyc?status=all&q=111-22')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/kyc?status=approved')->assertInertia(fn (Assert $p) => $p->has('rows', 0));

        DB::table('futures_positions')->insert(['user_id' => $this->alice->id, 'symbol' => 'BTCUSDT', 'side' => 'long', 'leverage' => 10, 'margin' => Money::toUnits('100'), 'entry_micro' => 50000 * 100000000, 'status' => 'open', 'created_at' => now(), 'updated_at' => now()]);
        DB::table('futures_positions')->insert(['user_id' => $this->bob->id, 'symbol' => 'ETHUSDT', 'side' => 'short', 'leverage' => 5, 'margin' => Money::toUnits('50'), 'entry_micro' => 3000 * 100000000, 'close_micro' => 2900 * 100000000, 'status' => 'closed', 'close_reason' => 'tp', 'pnl' => Money::toUnits('10'), 'closed_at' => now(), 'created_at' => now(), 'updated_at' => now()]);
        $this->adm('/admin/futures')->assertInertia(fn (Assert $p) => $p->component('Admin/Futures')->where('tab', 'open')->has('rows', 1)->where('counts.open', 1)->where('rows.0.symbol', 'BTCUSDT'));
        $this->adm('/admin/futures?tab=closed')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('rows.0.reason', 'tp')->where('rows.0.pnl', '10.00'));
        $this->adm('/admin/futures?tab=all&side=short')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/futures?tab=all&q=alice&symbol=btc')->assertInertia(fn (Assert $p) => $p->has('rows', 1));

        DB::table('spot_limit_orders')->insert(['user_id' => $this->alice->id, 'symbol' => 'BTCUSDT', 'base_asset' => 'BTC', 'side' => 'sell', 'kind' => 'tp', 'limit_price' => 90000, 'qty' => Money::toUnits('0.1'), 'reserve_asset' => 'BTC', 'reserved' => Money::toUnits('0.1'), 'status' => 'open', 'created_at' => now()]);
        $this->adm('/admin/orders')->assertInertia(fn (Assert $p) => $p->has('rows', 1)->where('counts.open', 1)->where('rows.0.qty', '0.1 BTC'));
        $this->adm('/admin/orders?kind=sl')->assertInertia(fn (Assert $p) => $p->has('rows', 0));

        $this->alice->forceFill(['referral_code' => 'ALICE1'])->save();
        DB::table('users')->where('id', $this->bob->id)->update(['referred_by' => $this->alice->id]);
        $this->adm('/admin/referrals')->assertInertia(fn (Assert $p) => $p->component('Admin/Referrals')->has('rows', 1)->where('rows.0.invited', 1)->where('stats.referred', 1));
        $this->adm('/admin/referrals?q=zzz')->assertInertia(fn (Assert $p) => $p->has('rows', 0));

        $this->actingAs($this->admin, 'admin')->post('/admin/users/'.$this->alice->id.'/notify', ['title' => 'Hi'])->assertRedirect();
        $this->adm('/admin/audit')->assertInertia(fn (Assert $p) => $p->component('Admin/Audit')->has('rows', 1)->where('rows.0.action', 'user.notify')->where('rows.0.target', 'alice@x.com'));
        $this->adm('/admin/audit?action=user')->assertInertia(fn (Assert $p) => $p->has('rows', 1));
        $this->adm('/admin/audit?q=nothing-matches')->assertInertia(fn (Assert $p) => $p->has('rows', 0));
    }
}
