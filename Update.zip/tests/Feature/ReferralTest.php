<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReferralTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function signup(array $extra = [])
    {
        return $this->post('/register', array_merge(['name' => 'Friend', 'email' => 'f'.uniqid().'@x.com', 'password' => 'Str0ngPassw0rd!', 'country' => 'Pakistan', 'dial' => '+92', 'phone' => '3001234567', 'password_confirmation' => 'Str0ngPassw0rd!'], $extra));
    }

    public function test_every_user_gets_a_code_and_signup_without_a_code_still_works(): void
    {
        $this->signup()->assertRedirect(route('dashboard'));
        $this->assertNotEmpty(User::first()->referral_code);
        $this->assertNull(User::first()->referred_by);
    }

    public function test_signup_with_a_valid_code_links_the_referrer_and_invalid_code_is_rejected(): void
    {
        $owner = User::create(['name' => 'Owner', 'email' => 'o@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        $this->signup(['referral_code' => strtolower($owner->referral_code)])->assertRedirect(route('dashboard'));
        $this->assertSame($owner->id, User::where('email', '!=', 'o@x.com')->first()->referred_by);
        auth()->logout();
        $this->post('/register', ['name' => 'X', 'email' => 'z@x.com', 'password' => 'Str0ngPassw0rd!', 'country' => 'Pakistan', 'dial' => '+92', 'phone' => '3001234567', 'password_confirmation' => 'Str0ngPassw0rd!', 'referral_code' => 'NOPE1234'])->assertSessionHasErrors('referral_code');
    }

    public function test_refer_page_shows_code_link_and_count(): void
    {
        $owner = User::create(['name' => 'Owner', 'email' => 'o@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        User::create(['name' => 'Kid', 'email' => 'k@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user', 'referred_by' => $owner->id]);
        $this->actingAs($owner)->get('/refer')->assertOk()->assertInertia(fn ($p) => $p->component('Refer')->where('code', $owner->referral_code)->where('total', 1));
        $this->actingAs($owner)->get('/profile')->assertOk();
    }

    public function test_referral_commission_pays_referrer_once_and_notifies(): void
    {
        config(['referral.percent' => 10]);
        $owner = User::create(['name' => 'Owner', 'email' => 'o@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        $kid = User::create(['name' => 'Kid', 'email' => 'k@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user', 'referred_by' => $owner->id]);
        $svc = app(\App\Services\ReferralService::class);
        $this->assertSame(10 * 100000000, $svc->payForDeposit($kid->id, 'USDT', 100 * 100000000, 'deposit', 1));
        $this->assertSame(0, $svc->payForDeposit($kid->id, 'USDT', 100 * 100000000, 'deposit', 1));
        $this->assertSame(1, \Illuminate\Support\Facades\DB::table('user_notifications')->where('user_id', $owner->id)->count());
    }

    public function test_frozen_user_is_blocked_and_kyc_gate_applies(): void
    {
        $u = User::create(['name' => 'U', 'email' => 'u@x.com', 'password' => 'Str0ngPassw0rd!', 'role' => 'user']);
        \Illuminate\Support\Facades\DB::table('users')->where('id', $u->id)->update(['status' => 'frozen']);
        $this->actingAs($u->fresh())->get('/dashboard')->assertRedirect('/login');
    }

    public function test_settings_service_overrides_config(): void
    {
        app(\App\Services\SettingsService::class)->save(['referral_percent' => '7', 'bonus_enabled' => true, 'rewards_amounts' => '1,2,3,4,5,6,7']);
        app(\App\Services\SettingsService::class)->apply();
        $this->assertSame(7.0, config('referral.percent'));
        $this->assertSame([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0], config('rewards.amounts'));
    }
}
