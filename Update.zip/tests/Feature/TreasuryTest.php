<?php

namespace Tests\Feature;

use App\Models\ManualDepositAddress;
use App\Models\User;
use App\Services\LedgerService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Tests\TestCase;

class TreasuryTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        config(['bonus.enabled' => false]);
        Carbon::setTestNow('2026-10-01 00:00:00');
        $this->app->instance(\App\Services\MarketDataService::class, new class extends \App\Services\MarketDataService {
            public function __construct() {}
            public function snapshot(string $type = 'both'): array {
                return ['markets' => [['symbol' => 'BTCUSDT', 'baseAsset' => 'BTC', 'marketType' => 'spot', 'isTradable' => true, 'lastPrice' => 50000.0]], 'meta' => ['updatedAt' => gmdate('c'), 'stale' => false]];
            }
        });
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(string $funds = '1000'): User
    {
        $u = User::query()->create(['name' => 'T', 'email' => 't'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
        if (Money::toUnits($funds) > 0) DB::transaction(fn () => app(LedgerService::class)->apply($u->id, 'funding', 'USDT', Money::toUnits($funds), 'admin_credit'));

        return $u;
    }

    private function bal(User $u): int
    {
        return app(LedgerService::class)->balance($u->id, 'funding', 'USDT');
    }

    private function admin(): User
    {
        return User::query()->create(['name' => 'A', 'email' => 'adm'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'admin']);
    }

    private const TRON = 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE';

    public function test_withdrawal_holds_funds_and_can_be_cancelled(): void
    {
        $u = $this->user('100');
        $r = $this->actingAs($u)->postJson('/api/withdrawals', ['asset' => 'USDT', 'network' => 'TRC20', 'address' => self::TRON, 'amount' => '40', 'idempotency_key' => 'k1'])->assertCreated();
        $this->assertSame('39.0000', $r->json('rows.0.net'));
        $this->assertSame(Money::toUnits('60'), $this->bal($u));
        $this->actingAs($u)->postJson('/api/withdrawals', ['asset' => 'USDT', 'network' => 'TRC20', 'address' => self::TRON, 'amount' => '40', 'idempotency_key' => 'k1'])->assertCreated();
        $this->assertSame(Money::toUnits('60'), $this->bal($u)); // replay does not charge twice
        $id = $r->json('rows.0.id');
        $this->actingAs($u)->postJson("/api/withdrawals/{$id}/cancel")->assertOk();
        $this->assertSame(Money::toUnits('100'), $this->bal($u));
        $this->actingAs($u)->postJson("/api/withdrawals/{$id}/cancel")->assertStatus(422);
    }

    public function test_withdrawal_validation(): void
    {
        $u = $this->user('100');
        $base = ['asset' => 'USDT', 'network' => 'TRC20', 'address' => self::TRON, 'amount' => '10'];
        $this->actingAs($u)->postJson('/api/withdrawals', ['address' => '0x1234'] + $base)->assertStatus(422);
        $this->actingAs($u)->postJson('/api/withdrawals', ['amount' => '4'] + $base)->assertStatus(422); // below minimum
        $this->actingAs($u)->postJson('/api/withdrawals', ['amount' => '500'] + $base)->assertStatus(422); // insufficient
        $this->actingAs($u)->postJson('/api/withdrawals', ['network' => 'BEP20'] + $base)->assertStatus(422); // tron address on evm
        $this->assertSame(Money::toUnits('100'), $this->bal($u));
    }

    public function test_admin_completes_or_rejects_withdrawal(): void
    {
        $u = $this->user('100');
        $a = $this->actingAs($u)->postJson('/api/withdrawals', ['asset' => 'USDT', 'network' => 'BEP20', 'address' => '0x'.str_repeat('a', 40), 'amount' => '10'])->json('rows.0.id');
        $b = $this->actingAs($u)->postJson('/api/withdrawals', ['asset' => 'USDT', 'network' => 'BEP20', 'address' => '0x'.str_repeat('b', 40), 'amount' => '20'])->json('rows.0.id');
        auth()->logout();
        $adm = $this->admin();
        $this->actingAs($adm, 'admin')->post("/admin/withdrawals/{$a}", ['decision' => 'complete', 'tx_hash' => '0xabc'])->assertRedirect();
        $this->actingAs($adm, 'admin')->post("/admin/withdrawals/{$b}", ['decision' => 'reject', 'reason' => 'nope'])->assertRedirect();
        $this->actingAs($adm, 'admin')->post("/admin/withdrawals/{$b}", ['decision' => 'reject'])->assertSessionHasErrors('withdrawal'); // already handled
        $this->assertSame(Money::toUnits('90'), $this->bal($u)); // 100 - 10 sent, 20 refunded
        $this->assertDatabaseHas('withdrawals', ['id' => $a, 'status' => 'completed', 'tx_hash' => '0xabc']);
        $this->assertDatabaseHas('withdrawals', ['id' => $b, 'status' => 'rejected']);
        $this->assertDatabaseHas('admin_audit_logs', ['action' => 'withdrawal.complete']);
    }

    public function test_manual_deposit_flow(): void
    {
        $u = $this->user('0');
        $this->actingAs($u)->getJson('/api/manual-deposits')->assertOk()->assertJsonCount(0, 'addresses'); // addresses are off until admin sets them
        $adm = $this->admin();
        $addr = ManualDepositAddress::query()->where('network', 'TRC20')->firstOrFail();
        $save = ['id' => $addr->id, 'asset' => 'USDT', 'network' => 'TRC20', 'label' => 'Tron (TRC20)', 'address' => '', 'min' => '10', 'enabled' => true];
        $this->actingAs($adm, 'admin')->post('/admin/deposits/address', $save)->assertSessionHasErrors('address'); // cannot enable without address
        $this->actingAs($adm, 'admin')->post('/admin/deposits/address', ['address' => self::TRON] + $save)->assertRedirect();
        auth()->logout();
        $this->actingAs($u)->getJson('/api/manual-deposits')->assertJsonPath('addresses.0.address', self::TRON);
        $tx = str_repeat('c', 64);
        $this->actingAs($u)->postJson('/api/manual-deposits', ['address_id' => $addr->id, 'amount' => '5', 'txid' => $tx])->assertStatus(422); // under min
        $id = $this->actingAs($u)->postJson('/api/manual-deposits', ['address_id' => $addr->id, 'amount' => '50', 'txid' => $tx])->assertCreated()->json('rows.0.id');
        $this->actingAs($u)->postJson('/api/manual-deposits', ['address_id' => $addr->id, 'amount' => '50', 'txid' => strtoupper($tx)])->assertStatus(422); // same TXID
        $this->assertSame(0, $this->bal($u));
        auth()->logout();
        $this->actingAs($adm, 'admin')->post("/admin/deposits/{$id}", ['decision' => 'approve', 'amount' => '49.5'])->assertRedirect();
        $this->actingAs($adm, 'admin')->post("/admin/deposits/{$id}", ['decision' => 'approve', 'amount' => '49.5'])->assertSessionHasErrors('deposit');
        $this->assertSame(Money::toUnits('49.5'), $this->bal($u)); // credited once, with the amount the admin actually received
    }

    public function test_pages_render(): void
    {
        $u = $this->user('1');
        $this->actingAs($u)->get('/withdraw')->assertOk();
        $this->actingAs($u)->get('/transfer')->assertOk();
        $this->actingAs($u)->get('/deposit')->assertOk();
    }

    public function test_convert_uses_server_price_with_no_fee(): void
    {
        $u = $this->user('1000');
        $this->actingAs($u)->postJson('/api/convert', ['from' => 'USDT', 'to' => 'BTC', 'amount' => '500', 'idempotency_key' => 'c1'])->assertCreated();
        $this->actingAs($u)->postJson('/api/convert', ['from' => 'USDT', 'to' => 'BTC', 'amount' => '500', 'idempotency_key' => 'c1'])->assertCreated(); // replay
        $this->assertSame(Money::toUnits('500'), $this->bal($u));
        $this->assertSame(Money::toUnits('0.01'), app(LedgerService::class)->balance($u->id, 'funding', 'BTC'));
        $this->actingAs($u)->postJson('/api/convert', ['from' => 'BTC', 'to' => 'USDT', 'amount' => '0.01'])->assertCreated();
        $this->assertSame(Money::toUnits('1000'), $this->bal($u));
        $this->actingAs($u)->postJson('/api/convert', ['from' => 'USDT', 'to' => 'BTC', 'amount' => '99999'])->assertStatus(422);
        $this->actingAs($u)->postJson('/api/convert', ['from' => 'USDT', 'to' => 'NOPE', 'amount' => '10'])->assertStatus(422);
        $this->actingAs($u)->get('/convert')->assertOk();
    }

    public function test_manual_deposit_adds_twelve_percent_real_bonus_once(): void
    {
        config(['bonus.enabled' => true]);
        $u = $this->user('0');
        $adm = $this->admin();
        $addr = ManualDepositAddress::query()->where('network', 'TRC20')->firstOrFail();
        $addr->fill(['address' => self::TRON, 'enabled' => true, 'min_units' => 0])->save();
        $id = $this->actingAs($u)->postJson('/api/manual-deposits', ['address_id' => $addr->id, 'amount' => '100', 'txid' => str_repeat('d', 64)])->json('rows.0.id');
        auth()->logout();
        $this->actingAs($adm, 'admin')->post("/admin/deposits/{$id}", ['decision' => 'approve', 'amount' => '100'])->assertRedirect();
        $this->actingAs($adm, 'admin')->post("/admin/deposits/{$id}", ['decision' => 'approve', 'amount' => '100']);
        $this->assertSame(Money::toUnits('112'), $this->bal($u)); // 100 + 12%
        $this->assertDatabaseHas('ledger_entries', ['user_id' => $u->id, 'type' => 'deposit_bonus']);
        auth()->logout();
        // bonus is ordinary balance: it can be withdrawn
        $this->actingAs($u)->postJson('/api/withdrawals', ['asset' => 'USDT', 'network' => 'TRC20', 'address' => self::TRON, 'amount' => '112'])->assertCreated();
        $this->assertSame(0, $this->bal($u));
    }
}
