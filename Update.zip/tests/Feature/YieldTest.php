<?php

namespace Tests\Feature;

use App\Models\Bot;
use App\Models\EarnProduct;
use App\Models\User;
use App\Services\LedgerService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Tests\TestCase;

class YieldTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        Carbon::setTestNow('2026-10-01 00:00:00');
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(string $funds = '1000'): User
    {
        $u = User::query()->create(['name' => 'T', 'email' => 't'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
        DB::transaction(fn () => app(LedgerService::class)->apply($u->id, 'funding', 'USDT', Money::toUnits($funds), 'admin_credit'));

        return $u;
    }

    private function bal(User $u, string $account = 'funding'): int
    {
        return app(LedgerService::class)->balance($u->id, $account, 'USDT');
    }

    private function product(bool $enabled = true): EarnProduct
    {
        EarnProduct::query()->update(['enabled' => $enabled]);

        return EarnProduct::query()->firstOrFail(); // seeded: USDT, 3.5% APR, min 1
    }

    public function test_earn_interest_is_exact_simple_interest_and_principal_is_safe(): void
    {
        $u = $this->user('1000'); $p = $this->product();
        $this->actingAs($u)->postJson('/api/earn/stake', ['product_id' => $p->id, 'amount' => '365', 'from' => 'funding', 'idempotency_key' => 's1'])->assertOk();
        $this->assertSame(Money::toUnits('635'), $this->bal($u));
        $this->assertSame(Money::toUnits('365'), $this->bal($u, 'earn'));
        // replay changes nothing
        $this->actingAs($u)->postJson('/api/earn/stake', ['product_id' => $p->id, 'amount' => '365', 'from' => 'funding', 'idempotency_key' => 's1'])->assertOk();
        $this->assertSame(Money::toUnits('365'), $this->bal($u, 'earn'));
        // 10 days at 3.5% APR on 365 = 365 * 0.035 * 10/365 = 0.35
        Carbon::setTestNow('2026-10-11 00:00:00');
        $res = $this->actingAs($u)->getJson('/api/earn')->assertOk()->json();
        $this->assertSame(Money::toUnits('635') + Money::toUnits('0.35'), $this->bal($u));
        $this->assertSame('0.3500', $res['totalEarned']);
        // settling again immediately pays nothing more (no double pay)
        $this->actingAs($u)->getJson('/api/earn')->assertOk();
        $this->assertSame(Money::toUnits('635.35'), $this->bal($u));
        // cannot unstake more than staked; can unstake part
        $this->actingAs($u)->postJson('/api/earn/unstake', ['product_id' => $p->id, 'amount' => '366'])->assertStatus(422);
        $this->actingAs($u)->postJson('/api/earn/unstake', ['product_id' => $p->id, 'amount' => '65'])->assertOk();
        $this->assertSame(Money::toUnits('700.35'), $this->bal($u));
        $this->assertSame(Money::toUnits('300'), $this->bal($u, 'earn'));
    }

    public function test_earn_rejects_disabled_product_small_amount_and_overdraft(): void
    {
        $u = $this->user('10');
        $p = $this->product(false);
        $this->actingAs($u)->postJson('/api/earn/stake', ['product_id' => $p->id, 'amount' => '5', 'from' => 'funding'])->assertStatus(422);
        $p = $this->product(true);
        $this->actingAs($u)->postJson('/api/earn/stake', ['product_id' => $p->id, 'amount' => '0.5', 'from' => 'funding'])->assertStatus(422);
        $this->actingAs($u)->postJson('/api/earn/stake', ['product_id' => $p->id, 'amount' => '50', 'from' => 'funding'])->assertStatus(422);
        $this->assertSame(Money::toUnits('10'), $this->bal($u));
    }

    public function test_admin_rate_change_pays_at_old_rate_first(): void
    {
        $admin = User::query()->create(['name' => 'A', 'email' => 'a@x.com', 'password' => 'password-12345', 'role' => 'admin']);
        $u = $this->user('1000'); $p = $this->product();
        $this->actingAs($u)->postJson('/api/earn/stake', ['product_id' => $p->id, 'amount' => '365', 'from' => 'funding'])->assertOk();
        Carbon::setTestNow('2026-10-11 00:00:00');
        $this->actingAs($admin, 'admin')->post('/admin/earn', ['id' => $p->id, 'name' => 'USDT Flexible', 'asset' => 'USDT', 'apr' => '10', 'min' => '1', 'enabled' => true])->assertRedirect();
        $this->assertSame(Money::toUnits('635.35'), $this->bal($u)); // 10 days at the OLD 3.5%
        Carbon::setTestNow('2026-10-21 00:00:00');
        $this->actingAs($u)->getJson('/api/earn')->assertOk();
        $this->assertSame(Money::toUnits('635.35') + Money::toUnits('1'), $this->bal($u)); // 10 days at the new 10%
        $this->assertDatabaseHas('admin_audit_logs', ['action' => 'earn_product_save']);
    }

    public function test_bot_cycles_share_and_stop_return_capital(): void
    {
        $u = $this->user('1000');
        $bot = Bot::query()->create(['name' => 'Grid', 'pair' => 'BTCUSDT', 'strategy' => 'Futures grid', 'daily_yield_pct' => 2, 'profit_share_pct' => 25, 'min_units' => Money::toUnits('10'), 'enabled' => true]);
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/follow", ['capital' => '500', 'idempotency_key' => 'f1'])->assertOk();
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/follow", ['capital' => '500', 'idempotency_key' => 'f1'])->assertOk(); // replay
        $this->assertSame(Money::toUnits('500'), $this->bal($u));
        $this->assertSame(Money::toUnits('500'), $this->bal($u, 'bots'));
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/follow", ['capital' => '100'])->assertStatus(422); // already following
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/claim")->assertStatus(422); // no full cycle yet
        Carbon::setTestNow('2026-10-01 23:59:59');
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/claim")->assertStatus(422);
        Carbon::setTestNow('2026-10-03 00:00:00'); // 2 full cycles: 500*2%*2 = 20 gross, 5 share, 15 net
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/claim")->assertOk();
        $this->assertSame(Money::toUnits('515'), $this->bal($u));
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/claim")->assertStatus(422); // cannot claim twice
        $this->assertSame(1, DB::table('bot_claims')->where('user_id', $u->id)->count());
        // half a cycle later: nothing due; stopping returns the capital only
        Carbon::setTestNow('2026-10-03 12:00:00');
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/unfollow")->assertOk();
        $this->assertSame(Money::toUnits('1015'), $this->bal($u));
        $this->assertSame(0, $this->bal($u, 'bots'));
        // can follow again after stopping
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/follow", ['capital' => '100'])->assertOk();
        $this->assertSame(Money::toUnits('100'), $this->bal($u, 'bots'));
    }

    public function test_bot_auto_claim_and_disabled_bot(): void
    {
        $u = $this->user('1000');
        $bot = Bot::query()->create(['name' => 'Grid', 'pair' => 'ETHUSDT', 'strategy' => 'Grid', 'daily_yield_pct' => 1, 'profit_share_pct' => 0, 'min_units' => 0, 'enabled' => true]);
        $this->actingAs($u)->postJson("/api/bots/{$bot->id}/follow", ['capital' => '100', 'auto_claim' => true])->assertOk();
        Carbon::setTestNow('2026-10-02 00:00:01');
        $this->actingAs($u)->getJson('/api/bots')->assertOk(); // opening the page settles auto-claim
        $this->assertSame(Money::toUnits('901'), $this->bal($u));
        $bot->update(['enabled' => false]);
        $other = $this->user('100');
        $this->actingAs($other)->postJson("/api/bots/{$bot->id}/follow", ['capital' => '10'])->assertStatus(422);
        $this->assertNotContains($bot->id, array_column($this->actingAs($other)->getJson('/api/bots')->json('bots'), 'id')); // closed and not followed: hidden
    }

    public function test_guests_and_non_admins_are_blocked(): void
    {
        $this->getJson('/api/earn')->assertStatus(401);
        $this->getJson('/api/bots')->assertStatus(401);
        $this->get('/earn')->assertRedirect();
        $u = $this->user();
        $this->actingAs($u)->get('/admin/earn')->assertRedirect();
        $this->actingAs($u)->post('/admin/bots', ['name' => 'x'])->assertRedirect();
    }

    public function test_seeded_catalogue_and_copy_traders_are_separate_from_bots(): void
    {
        $u = $this->user('100');
        $bots = $this->actingAs($u)->getJson('/api/bots')->json('bots');
        $traders = $this->actingAs($u)->getJson('/api/bots?kind=trader')->json('bots');
        $this->assertCount(4, $bots);
        $this->assertCount(8, $traders);
        $this->assertSame([], array_intersect(array_column($bots, 'id'), array_column($traders, 'id')));
        $t = $traders[0];
        $after = $this->actingAs($u)->postJson("/api/bots/{$t['id']}/follow", ['capital' => '50', 'kind' => 'trader'])->assertOk()->json();
        $this->assertSame(1, $after['kpis']['active']);
        $this->assertSame(0, $this->actingAs($u)->getJson('/api/bots')->json('kpis.active')); // not counted under Bots
        $this->assertTrue(EarnProduct::query()->where('name', 'USDT Flexible')->value('enabled') == true);
        $this->actingAs($u)->get('/copy')->assertOk();
    }
}
