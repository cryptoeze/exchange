<?php

namespace Tests\Feature;

use App\Models\LedgerEntry;
use App\Models\User;
use App\Services\LedgerService;
use App\Services\MarketDataService;
use App\Support\Money;
use DomainException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class WalletTradingTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        config(['trading.spot_fee_rate' => 0.001]);
        // Fixed server-side price feed: BTC = 50,000 USDT
        $this->app->instance(MarketDataService::class, new class extends MarketDataService {
            public function __construct() {}
            public function snapshot(string $type = 'both'): array {
                return ['markets' => [['symbol' => 'BTCUSDT', 'baseAsset' => 'BTC', 'marketType' => 'spot', 'isTradable' => true, 'lastPrice' => 50000.0]],
                    'meta' => ['updatedAt' => gmdate('c'), 'stale' => false]];
            }
        });
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(): User
    {
        return User::query()->create(['name' => 'T', 'email' => 't'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
    }

    private function fund(User $u, string $asset, string $amount, string $account = 'funding'): void
    {
        DB::transaction(fn () => app(LedgerService::class)->apply($u->id, $account, $asset, Money::toUnits($amount), 'admin_credit'));
    }

    public function test_money_parsing_is_exact(): void
    {
        $this->assertSame(150_000_000, Money::toUnits('1.5'));
        $this->assertSame(1, Money::toUnits('0.00000001'));
        $this->assertSame('12.50', Money::format(1_250_000_000));
        $this->expectException(\InvalidArgumentException::class);
        Money::toUnits('1.123456789');
    }

    public function test_debit_cannot_overdraw_and_every_change_is_journaled(): void
    {
        $u = $this->user();
        $this->fund($u, 'USDT', '100');
        $ledger = app(LedgerService::class);
        try {
            DB::transaction(fn () => $ledger->apply($u->id, 'funding', 'USDT', -Money::toUnits('100.00000001'), 'admin_debit'));
            $this->fail('overdraw allowed');
        } catch (DomainException) {}
        $this->assertSame(Money::toUnits('100'), $ledger->balance($u->id, 'funding', 'USDT'));
        $this->assertSame(1, LedgerEntry::query()->where('user_id', $u->id)->count());
    }

    public function test_idempotent_credit_applies_once(): void
    {
        $u = $this->user(); $ledger = app(LedgerService::class);
        foreach ([1, 2] as $_) DB::transaction(fn () => $ledger->apply($u->id, 'funding', 'USDT', Money::toUnits('10'), 'admin_credit', ['idempotency_key' => 'k1']));
        $this->assertSame(Money::toUnits('10'), $ledger->balance($u->id, 'funding', 'USDT'));
    }

    public function test_spot_buy_and_sell_use_server_price_and_fee(): void
    {
        $u = $this->user(); $this->fund($u, 'USDT', '1000');
        $res = $this->actingAs($u)->postJson('/api/spot/orders', ['symbol' => 'BTCUSDT', 'side' => 'buy', 'amount' => '500', 'idempotency_key' => 'b1']);
        $res->assertCreated();
        $ledger = app(LedgerService::class);
        // spend 500, fee 0.5, net 499.5 / 50000 = 0.00999 BTC
        $this->assertSame(Money::toUnits('500'), Money::toUnits('1000') - $ledger->balance($u->id, 'funding', 'USDT'));
        $this->assertSame(Money::toUnits('0.00999'), $ledger->balance($u->id, 'funding', 'BTC'));
        // replay is a no-op
        $this->actingAs($u)->postJson('/api/spot/orders', ['symbol' => 'BTCUSDT', 'side' => 'buy', 'amount' => '500', 'idempotency_key' => 'b1'])->assertCreated();
        $this->assertSame(Money::toUnits('0.00999'), $ledger->balance($u->id, 'funding', 'BTC'));
        // sell all: 0.00999 * 50000 = 499.5, fee 0.4995 -> +499.0005
        $this->actingAs($u)->postJson('/api/spot/orders', ['symbol' => 'BTCUSDT', 'side' => 'sell', 'amount' => '0.00999'])->assertCreated();
        $this->assertSame(0, $ledger->balance($u->id, 'funding', 'BTC'));
        $this->assertSame(Money::toUnits('500') + Money::toUnits('499.0005'), $ledger->balance($u->id, 'funding', 'USDT'));
    }

    public function test_orders_are_rejected_without_funds_or_for_unknown_markets(): void
    {
        $u = $this->user(); $this->fund($u, 'USDT', '10');
        $this->actingAs($u)->postJson('/api/spot/orders', ['symbol' => 'BTCUSDT', 'side' => 'buy', 'amount' => '500'])->assertStatus(422);
        $this->actingAs($u)->postJson('/api/spot/orders', ['symbol' => 'FAKEUSDT', 'side' => 'buy', 'amount' => '5'])->assertStatus(422);
        $this->actingAs($u)->postJson('/api/spot/orders', ['symbol' => 'BTCUSDT', 'side' => 'sell', 'amount' => '1'])->assertStatus(422);
        $this->assertSame(Money::toUnits('10'), app(LedgerService::class)->balance($u->id, 'funding', 'USDT'));
    }

    public function test_guests_cannot_reach_wallet_or_orders(): void
    {
        $this->getJson('/api/wallet')->assertStatus(401);
        $this->postJson('/api/spot/orders', [])->assertStatus(401);
    }

    public function test_transfer_moves_usdt_between_accounts(): void
    {
        $u = $this->user(); $this->fund($u, 'USDT', '100');
        $this->actingAs($u)->postJson('/api/wallet/transfer', ['from' => 'funding', 'to' => 'trading', 'amount' => '40.5'])->assertOk();
        $l = app(LedgerService::class);
        $this->assertSame(Money::toUnits('59.5'), $l->balance($u->id, 'funding', 'USDT'));
        $this->assertSame(Money::toUnits('40.5'), $l->balance($u->id, 'trading', 'USDT'));
        $this->actingAs($u)->postJson('/api/wallet/transfer', ['from' => 'trading', 'to' => 'funding', 'amount' => '41'])->assertStatus(422);
    }

    public function test_admin_credit_updates_balance_and_writes_audit_and_ledger(): void
    {
        $admin = User::query()->create(['name' => 'A', 'email' => 'a@x.com', 'password' => 'password-12345', 'role' => 'admin']);
        $u = $this->user();
        $payload = ['action' => 'credit', 'account' => 'funding', 'asset' => 'USDT', 'amount' => '250.5', 'note' => 'Deposit received', 'idempotency_key' => 'abc'];
        $this->actingAs($admin, 'admin')->post("/admin/users/{$u->id}/wallet", $payload)->assertRedirect();
        $this->actingAs($admin, 'admin')->post("/admin/users/{$u->id}/wallet", $payload)->assertRedirect(); // double submit
        $this->assertSame(Money::toUnits('250.5'), app(LedgerService::class)->balance($u->id, 'funding', 'USDT'));
        $this->assertSame(1, DB::table('admin_audit_logs')->where('target_user_id', $u->id)->count() >= 1 ? 1 : 0);
        $this->actingAs($admin, 'admin')->post("/admin/users/{$u->id}/wallet", ['action' => 'debit', 'amount' => '9999', 'idempotency_key' => 'def'] + $payload)->assertSessionHasErrors('amount');
        $this->assertSame(Money::toUnits('250.5'), app(LedgerService::class)->balance($u->id, 'funding', 'USDT'));
    }

    public function test_normal_users_cannot_use_admin_wallet_endpoint(): void
    {
        $u = $this->user(); $other = $this->user();
        $this->actingAs($u)->post("/admin/users/{$other->id}/wallet", ['action' => 'credit', 'account' => 'funding', 'asset' => 'USDT', 'amount' => '5', 'note' => 'x', 'idempotency_key' => 'z'])->assertRedirect(route('admin.login'));
        $this->assertSame(0, app(LedgerService::class)->balance($other->id, 'funding', 'USDT'));
    }
}
