<?php

namespace Tests\Feature;

use App\Models\Deposit;
use App\Models\User;
use App\Services\LedgerService;
use App\Support\Money;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class DepositTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        config(['bonus.enabled' => false]);
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
        config(['services.nowpayments.api_key' => 'key', 'services.nowpayments.ipn_secret' => 'secret', 'app.url' => 'https://riseway.io']);
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(): User
    {
        return User::query()->create(['name' => 'T', 'email' => 't'.uniqid().'@x.com', 'password' => 'password-12345', 'role' => 'user']);
    }

    private function sign(array $payload): string
    {
        $sort = function (array $d) use (&$sort) { ksort($d); foreach ($d as $k => $v) if (is_array($v)) $d[$k] = $sort($v); return $d; };

        return hash_hmac('sha512', json_encode($sort($payload), JSON_UNESCAPED_SLASHES), 'secret');
    }

    private function create(User $u): Deposit
    {
        Http::fake(['api.nowpayments.io/v1/payment' => Http::response(['payment_id' => 5001, 'payment_status' => 'waiting', 'pay_address' => 'TXYZaddress', 'pay_amount' => 20.5, 'order_id' => 'x'], 201)]);
        $res = $this->actingAs($u)->postJson('/api/deposits', ['currency' => 'usdttrc20'])->assertCreated();

        return Deposit::query()->where('order_id', $res->json('deposit.orderId'))->firstOrFail();
    }

    public function test_creating_a_deposit_stores_address_and_maps_the_asset(): void
    {
        $u = $this->user(); $d = $this->create($u);
        $this->assertSame('USDT', $d->asset);
        $this->assertSame('TXYZaddress', $d->pay_address);
        Http::assertSent(fn ($r) => $r['pay_currency'] === 'usdttrc20' && $r->hasHeader('x-api-key', 'key') && str_ends_with($r['ipn_callback_url'], '/api/webhooks/nowpayments'));
    }

    public function test_unsupported_currency_and_guests_are_rejected(): void
    {
        $u = $this->user();
        $this->actingAs($u)->postJson('/api/deposits', ['currency' => 'notacoin'])->assertStatus(422);
        $this->app['auth']->forgetGuards();
        $this->postJson('/api/deposits', ['currency' => 'usdttrc20'])->assertStatus(401);
    }

    public function test_missing_api_key_reports_unavailable_without_calling_provider(): void
    {
        config(['services.nowpayments.api_key' => '']);
        Http::fake();
        $this->actingAs($this->user())->postJson('/api/deposits', ['currency' => 'usdttrc20'])->assertStatus(503);
        Http::assertNothingSent();
    }

    public function test_webhook_requires_a_valid_signature(): void
    {
        $u = $this->user(); $d = $this->create($u);
        $payload = ['payment_id' => 5001, 'payment_status' => 'finished', 'order_id' => $d->order_id, 'actually_paid' => 20.5];
        $this->postJson('/api/webhooks/nowpayments', $payload, ['x-nowpayments-sig' => 'bad'])->assertStatus(401);
        $this->postJson('/api/webhooks/nowpayments', $payload)->assertStatus(401);
        $this->assertSame(0, app(LedgerService::class)->balance($u->id, 'funding', 'USDT'));
    }

    public function test_finished_payment_is_credited_exactly_once_after_provider_verification(): void
    {
        $u = $this->user(); $d = $this->create($u);
        $payload = ['payment_id' => 5001, 'payment_status' => 'finished', 'order_id' => $d->order_id, 'actually_paid' => 20.5];
        Http::fake(['api.nowpayments.io/v1/payment/5001' => Http::response(['payment_id' => 5001, 'payment_status' => 'finished', 'order_id' => $d->order_id, 'actually_paid' => 20.5, 'payin_hash' => '0xabc'])]);
        foreach ([1, 2, 3] as $_) {
            $this->postJson('/api/webhooks/nowpayments', $payload, ['x-nowpayments-sig' => $this->sign($payload)])->assertOk();
        }
        $this->assertSame(Money::toUnits('20.5'), app(LedgerService::class)->balance($u->id, 'funding', 'USDT'));
        $this->assertSame('0xabc', $d->fresh()->tx_hash);
        $this->assertNotNull($d->fresh()->credited_at);
    }

    public function test_webhook_claiming_finished_is_ignored_when_provider_says_waiting(): void
    {
        $u = $this->user(); $d = $this->create($u);
        $payload = ['payment_id' => 5001, 'payment_status' => 'finished', 'order_id' => $d->order_id, 'actually_paid' => 999];
        Http::fake(['api.nowpayments.io/v1/payment/5001' => Http::response(['payment_id' => 5001, 'payment_status' => 'waiting', 'order_id' => $d->order_id, 'actually_paid' => 0])]);
        $this->postJson('/api/webhooks/nowpayments', $payload, ['x-nowpayments-sig' => $this->sign($payload)])->assertOk();
        $this->assertSame(0, app(LedgerService::class)->balance($u->id, 'funding', 'USDT'));
    }

    public function test_polling_credits_when_the_provider_reports_finished_and_users_only_see_their_own(): void
    {
        config(['bonus.enabled' => true]);
        $u = $this->user(); $d = $this->create($u);
        Http::fake(['api.nowpayments.io/v1/payment/5001' => Http::response(['payment_id' => 5001, 'payment_status' => 'finished', 'order_id' => $d->order_id, 'actually_paid' => 7])]);
        $this->actingAs($u)->getJson('/api/deposits/'.$d->order_id)->assertOk()->assertJsonPath('deposit.status', 'finished');
        $this->assertSame(Money::toUnits('7.84'), app(LedgerService::class)->balance($u->id, 'funding', 'USDT')); // 7 + 12% bonus
        $this->actingAs($this->user())->getJson('/api/deposits/'.$d->order_id)->assertNotFound();
    }

    public function test_an_open_address_is_reused_instead_of_creating_a_new_payment(): void
    {
        $u = $this->user(); $first = $this->create($u);
        Http::fake();
        $again = $this->actingAs($u)->postJson('/api/deposits', ['currency' => 'usdttrc20'])->assertCreated();
        $this->assertSame($first->order_id, $again->json('deposit.orderId'));
        Http::assertNothingSent();
    }
}
