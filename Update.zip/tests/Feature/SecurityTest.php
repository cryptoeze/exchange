<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\TotpService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class SecurityTest extends TestCase
{
    use RefreshDatabase;

    private string $installLock;
    private bool $createdLock = false;

    protected function setUp(): void
    {
        parent::setUp();
        $this->installLock = storage_path('app/installed.lock');
        if (! is_dir(dirname($this->installLock))) mkdir(dirname($this->installLock), 0775, true);
        if (! file_exists($this->installLock)) { file_put_contents($this->installLock, 'test'); $this->createdLock = true; }
    }

    protected function tearDown(): void
    {
        if ($this->createdLock && file_exists($this->installLock)) unlink($this->installLock);
        parent::tearDown();
    }

    private function user(string $email = 'u@x.com', string $role = 'user', string $adminRole = 'super'): User
    {
        $u = User::create(['name' => 'U', 'email' => $email, 'password' => 'Str0ngPassw0rd!', 'role' => $role]);
        DB::table('users')->where('id', $u->id)->update(['admin_role' => $adminRole]);

        return $u->fresh();
    }

    public function test_totp_matches_the_rfc_6238_vector(): void
    {
        $this->assertSame('287082', app(TotpService::class)->code('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', 59));
    }

    public function test_login_with_2fa_needs_a_valid_code_and_recovery_codes_work_once(): void
    {
        $totp = app(TotpService::class);
        $u = $this->user();
        $secret = $totp->newSecret();
        $recovery = $totp->enable($u, $secret);

        $this->post('/login', ['email' => 'u@x.com', 'password' => 'Str0ngPassw0rd!'])->assertRedirect(route('login'));
        $this->assertGuest();
        $this->get('/login')->assertInertia(fn ($p) => $p->where('authMode', 'twofactor'));
        $this->post('/login/2fa', ['code' => '000000'])->assertSessionHasErrors('code');
        $this->assertGuest();
        $this->post('/login/2fa', ['code' => $totp->code($secret)])->assertRedirect(route('dashboard'));
        $this->assertAuthenticatedAs($u);

        auth()->logout();
        $this->post('/login', ['email' => 'u@x.com', 'password' => 'Str0ngPassw0rd!']);
        $this->post('/login/2fa', ['code' => $recovery[0]])->assertRedirect(route('dashboard'));
        auth()->logout();
        $this->post('/login', ['email' => 'u@x.com', 'password' => 'Str0ngPassw0rd!']);
        $this->post('/login/2fa', ['code' => $recovery[0]])->assertSessionHasErrors('code');
        $this->assertDatabaseHas('login_events', ['user_id' => $u->id, 'success' => 1]);
    }

    public function test_user_can_set_up_and_disable_2fa_through_the_api(): void
    {
        $u = $this->user();
        $start = $this->actingAs($u)->postJson('/security/2fa/start')->assertOk()->json();
        $code = app(TotpService::class)->code($start['secret']);
        $res = $this->actingAs($u)->postJson('/security/2fa/confirm', ['code' => $code])->assertOk()->json();
        $this->assertCount(8, $res['recovery']);
        $this->assertTrue((bool) $u->fresh()->two_factor_enabled);
        $this->actingAs($u->fresh())->postJson('/security/2fa/disable', ['password' => 'Str0ngPassw0rd!', 'code' => $res['recovery'][0]])->assertOk();
        $this->assertFalse((bool) $u->fresh()->two_factor_enabled);
        $this->actingAs($u)->get('/security')->assertOk();
    }

    public function test_admin_roles_limit_what_each_admin_can_open(): void
    {
        $super = $this->user('s@x.com', 'admin', 'super');
        $support = $this->user('sup@x.com', 'admin', 'support');
        $finance = $this->user('fin@x.com', 'admin', 'finance');
        $target = $this->user('t@x.com');
        $this->actingAs($super, 'admin')->get('/admin/gateways')->assertOk();
        $this->actingAs($super, 'admin')->get('/admin/team')->assertOk();
        $this->actingAs($support, 'admin')->get('/admin/users')->assertOk();
        $this->actingAs($support, 'admin')->get('/admin/gateways')->assertForbidden();
        $this->actingAs($support, 'admin')->get('/admin/team')->assertForbidden();
        $this->actingAs($support, 'admin')->post("/admin/users/{$target->id}/wallet", [])->assertForbidden();
        $this->actingAs($finance, 'admin')->get('/admin/gateways')->assertOk();
        $this->actingAs($finance, 'admin')->get('/admin/kyc')->assertForbidden();
    }

    public function test_new_registration_notifies_admins(): void
    {
        $admin = $this->user('boss@x.com', 'admin');
        $this->post('/register', ['name' => 'New', 'email' => 'new@x.com', 'password' => 'Str0ngPassw0rd!', 'password_confirmation' => 'Str0ngPassw0rd!'])->assertRedirect();
        $this->assertDatabaseHas('user_notifications', ['user_id' => $admin->id, 'type' => 'admin', 'title' => 'New user registered']);
        $this->actingAs($admin, 'admin')->getJson('/admin/api/bell')->assertOk()->assertJsonPath('unread', 1);
    }
}
