# RushX exchange dashboard (starter)

Laravel 13 + Inertia 3 + React/TypeScript + Tailwind CSS 4 RushX exchange frontend for PHP 8.5 and Hostinger shared hosting. It includes the responsive reference landing page, local Inter/JetBrains Mono fonts and coin marks, persistent light/dark mode, signup/sign-in/password reset, authenticated user and separate admin dashboards, and the first-run `/install` wizard. The landing market table reads public spot tickers from Bybit through a Laravel service; the terminal chart/order book and dashboard account balances remain clearly labeled illustrative previews. Trading is not enabled.

## Requirements

- PHP 8.5 (Laravel 13 supports PHP 8.3+), Composer 2, `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `tokenizer`, `xml`, `ctype`, `json`, `bcmath` and `curl` PHP extensions.
- MySQL 8.0+ or a compatible MariaDB database created in advance.
- The release includes built frontend assets, so Hostinger does not need Node/npm. If `public/build/` is missing, the setup script can use PHP PharData, zlib, SHA-256, and `curl` to download and verify Node 24 LTS temporarily and rebuild them. Node is not used by the live application.
- HTTPS enabled for production.

## Build and publish

The archive contains application source and compiled Vite assets, but not Composer's `vendor/` folder. On shared hosting where the document root cannot be changed from `public_html`, extract the project into `public_html`; the included root `.htaccess` serves files from `public/`, forwards application requests to Laravel, and denies web access to source and runtime folders. Confirm that the host honors `.htaccess` and `mod_rewrite`. On the server terminal, run from the extracted project directory:

```sh
sh prepare-hosting.sh
```

When the host allows it, pointing the domain document root at `public/` remains the stronger layout. Otherwise, retain the root `.htaccess` protection and do not remove it. Make `storage/` and `bootstrap/cache/` writable by PHP; `.env` must be writable for the initial `/install` request. Open `https://your-domain.example/install`, enter the pre-created database credentials, and create the administrator account. After success, the wizard writes production settings with a fresh application key and permanently locks itself. Sign in at `/login`; public registration is available on the same page. Admins use the separate `/admin/login` page.

If the host has no Composer, build `vendor/` on a compatible machine using the same PHP version and upload it with the project. The root `.htaccess` is required when the whole Laravel tree resides in `public_html`.

## Security notes

- Installer setup is CSRF-protected and rate-limited, validates input, tests the MySQL connection, runs migrations, creates one admin, and sets a private installation lock. The setup token is stored under `storage/app` and is removed after success.
- Production errors are not rendered, the installer returns 404 after setup, registration/login are rate-limited, passwords require 12+ characters with letters and numbers, and session cookies are HTTP-only, SameSite Lax, encrypted, and secure over HTTPS.
- Remove any temporary server-side upload copies and ensure directory indexes are disabled. Back up the database and `.env` securely.
- Markets: `GET /markets` uses the Laravel `GET /api/markets?type=spot|futures|both` API and `MarketDataService`. Bybit public V5 tickers and instrument metadata are fetched server-side, normalized to active USDT pairs, cached briefly, and served from a last-good snapshot on temporary provider failure. The Bybit public endpoints do not require API credentials. Signed-in favorites use `user_market_favorites`; guests use browser storage. Market filters, search, details, and admin health status are included. Spot and futures order execution/chart history are not connected.
- No wallet, trading, deposit, withdrawal, bot, order-book, or payment API is connected. Dashboard balances and the terminal preview are illustrative and are not account or trading data.

## Admin dashboard and data boundary

- `/admin` and every `/admin/*` workspace require the separate admin session and server-side `role=admin` authorization. Logout invalidates the server session; protected responses are marked no-store.
- The Operations Dashboard reads the real registered-user total, users created today, and latest five accounts from the existing `users` table. `/admin/users` gives an admin-only, read-only paginated account directory; signup emails link to admin-only user details.
- KYC, funding, wallet allocation, deposits, withdrawals, trades, staking, and bots do not exist in the current database schema. Their dashboard values say “not configured” and are never filled with screenshot examples or guessed zeroes. Other navigation destinations open clear next-phase placeholders.
- One additive migration indexes `users.created_at` for recent-user dashboard and directory queries. After uploading `Update.zip`, run `php artisan migrate --force && php artisan optimize:clear` from `public_html`.
- The admin console follows the Rushpay reference palette, supports shared persistent light/dark preference, and uses a keyboard-operable mobile navigation drawer. It has no financial mutation actions.

## Layout boundaries

- `resources/js/pages/Dashboard.tsx`: dashboard composition and mock view data.
- `resources/css/app.css`: responsive desktop/mobile theme styles and light/dark tokens.
- `app/Http/Controllers`: installer, auth, dashboard entry points.
- `resources/js/components/`: intended home for future reusable interface components.
- `app/Services/`: intended boundary for future market/trading integrations; no engine exists in this phase.
- `resources/js/components/TradingChart.tsx`: future chart boundary stub.

TypeScript type-checking and production Vite asset compilation passed. The admin layout was visually checked at 1920, 1440, 1366, 1280, 1024, 912, 834, 768, 430, 414, 390, 375, 360, and the browser's minimum supported 360 CSS px when asked for 320; no horizontal page overflow was measured. Mobile drawer open/Escape-close/focus restore/scroll lock and theme switching were inspected. PHP and Composer are unavailable in the local build environment, so PHP syntax, the additive migration, live database reads, admin authentication, and the Hostinger login/logout flow still need verification on the PHP host.
