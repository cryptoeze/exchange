<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\{InstallController,AuthController,DashboardController,PlatformPageController};
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MarketDataController;
use App\Http\Controllers\MarketFavoriteController;
use App\Http\Controllers\MarketDetailController;
Route::get('/install',[InstallController::class,'show'])->name('install.show');
Route::post('/install',[InstallController::class,'install'])->middleware('throttle:5,1')->name('install.run');
Route::get('/',function(Request $request){ if($request->user()) return redirect()->route('dashboard'); return inertia('Landing',['authOpen'=>false,'authMode'=>'signin']); })->name('home');
Route::get('/login',[AuthController::class,'login'])->name('login');
Route::post('/login',[AuthController::class,'authenticate'])->middleware('throttle:5,1')->name('login.submit');
Route::post('/register',[AuthController::class,'register'])->middleware('throttle:5,1')->name('register');
Route::post('/forgot-password',[AuthController::class,'sendResetLink'])->middleware('throttle:3,1')->name('password.email');
Route::get('/reset-password/{token}',[AuthController::class,'resetPage'])->name('password.reset');
Route::post('/reset-password',[AuthController::class,'resetPassword'])->middleware('throttle:5,1')->name('password.update');
Route::get('/api/markets',MarketDataController::class)->middleware('throttle:60,1')->name('api.markets');
Route::middleware('auth')->prefix('api/market-favorites')->name('api.market-favorites.')->group(function(){
 Route::get('/',[MarketFavoriteController::class,'index'])->name('index');
 Route::post('/',[MarketFavoriteController::class,'store'])->middleware('throttle:30,1')->name('store');
 Route::delete('/{marketType}/{symbol}',[MarketFavoriteController::class,'destroy'])->name('destroy');
});
Route::get('/market/{symbol}',MarketDetailController::class)->where('symbol','[A-Za-z0-9]{2,32}')->name('market.detail');
foreach (['p2p','spot','futures','convert','bots','earn','learn','getting-started','faq','blog','fees','security','proof-of-reserves','status','support','markets'] as $page) {
 Route::get('/'.$page,[PlatformPageController::class,'show'])->defaults('page',$page)->name('platform.'.$page);
}
Route::middleware('auth')->group(function () {
 foreach (['assets','deposit','withdraw','transfer','analysis','orders'] as $page) {
  Route::get('/'.$page,[PlatformPageController::class,'show'])->defaults('page',$page)->name('platform.'.$page);
 }
});
Route::prefix('admin')->name('admin.')->group(function(){
 Route::get('/',[AdminController::class,'dashboard'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('dashboard');
 Route::get('/users/{user}',[AdminController::class,'user'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereNumber('user')->name('users.show');
 Route::get('/{section}',[AdminController::class,'section'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereIn('section',['users','kyc','deposits','withdrawals','transactions','trades','bots','p2pdesk','notifications','audit','settings'])->name('section');
 Route::get('/login',[AdminController::class,'loginForm'])->name('login');
 Route::post('/login',[AdminController::class,'login'])->middleware('throttle:5,1')->name('login.submit');
 Route::post('/logout',[AdminController::class,'logout'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('logout');
});
Route::middleware('auth')->group(function(){Route::get('/dashboard',DashboardController::class)->name('dashboard');Route::post('/logout',[AuthController::class,'logout'])->name('logout');});
