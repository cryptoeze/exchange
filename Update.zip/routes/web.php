<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\{InstallController,AuthController,DashboardController,PlatformPageController};
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MarketDataController;
use App\Http\Controllers\MarketFavoriteController;
use App\Http\Controllers\MarketDetailController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\DepositController;
use App\Http\Controllers\SpotOrderController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\EarnController;
use App\Http\Controllers\BotController;
use App\Http\Controllers\AdminYieldController;
use App\Http\Controllers\AdminTreasuryController;
use App\Http\Controllers\WithdrawalController;
use App\Http\Controllers\ConvertController;
use App\Http\Controllers\RewardController;
use App\Http\Controllers\ManualDepositController;
use App\Http\Controllers\FuturesController;
use App\Http\Controllers\AdminWalletController;
Route::get('/install',[InstallController::class,'show'])->name('install.show');
Route::post('/install',[InstallController::class,'install'])->middleware('throttle:5,1,install.run')->name('install.run');
Route::get('/',function(Request $request){ if($request->user()) return redirect()->route('dashboard'); return inertia('Landing',['authOpen'=>false,'authMode'=>'signin']); })->name('home');
Route::get('/login',[AuthController::class,'login'])->name('login');
Route::post('/login',[AuthController::class,'authenticate'])->middleware('throttle:5,1,login.submit')->name('login.submit');
Route::post('/register',[AuthController::class,'register'])->middleware('throttle:5,1,register')->name('register');
Route::post('/forgot-password',[AuthController::class,'sendResetLink'])->middleware('throttle:3,1,password.email')->name('password.email');
Route::get('/reset-password/{token}',[AuthController::class,'resetPage'])->name('password.reset');
Route::post('/reset-password',[AuthController::class,'resetPassword'])->middleware('throttle:5,1,password.update')->name('password.update');
Route::get('/api/markets',MarketDataController::class)->middleware('throttle:300,1,api.markets')->name('api.markets');
Route::middleware('auth')->prefix('api/market-favorites')->name('api.market-favorites.')->group(function(){
 Route::get('/',[MarketFavoriteController::class,'index'])->name('index');
 Route::post('/',[MarketFavoriteController::class,'store'])->middleware('throttle:30,1,store')->name('store');
 Route::delete('/{marketType}/{symbol}',[MarketFavoriteController::class,'destroy'])->name('destroy');
});
Route::middleware('auth')->prefix('api')->group(function(){
 Route::get('/wallet',[WalletController::class,'index'])->middleware('throttle:120,1,api.wallet')->name('api.wallet');
 Route::post('/wallet/transfer',[WalletController::class,'transfer'])->middleware('throttle:20,1,api.wallet.transfer')->name('api.wallet.transfer');
 Route::get('/earn',[EarnController::class,'index'])->middleware('throttle:60,1,api.earn')->name('api.earn');
 Route::post('/earn/stake',[EarnController::class,'stake'])->middleware('throttle:20,1,api.earn.stake')->name('api.earn.stake');
 Route::post('/earn/unstake',[EarnController::class,'unstake'])->middleware('throttle:20,1,api.earn.unstake')->name('api.earn.unstake');
 Route::get('/bots',[BotController::class,'index'])->middleware('throttle:60,1,api.bots')->name('api.bots');
 Route::post('/bots/{bot}/follow',[BotController::class,'follow'])->whereNumber('bot')->middleware('throttle:20,1,api.bots.follow')->name('api.bots.follow');
 Route::post('/bots/{bot}/claim',[BotController::class,'claim'])->whereNumber('bot')->middleware('throttle:20,1,api.bots.claim')->name('api.bots.claim');
 Route::post('/bots/{bot}/unfollow',[BotController::class,'unfollow'])->whereNumber('bot')->middleware('throttle:20,1,api.bots.unfollow')->name('api.bots.unfollow');
 Route::post('/bots/{bot}/auto',[BotController::class,'auto'])->whereNumber('bot')->middleware('throttle:30,1,api.bots.auto')->name('api.bots.auto');
 Route::get('/futures/state',[FuturesController::class,'state'])->middleware('throttle:120,1,api.futures.state')->name('api.futures.state');
 Route::post('/futures/open',[FuturesController::class,'open'])->middleware('throttle:30,1,api.futures.open')->name('api.futures.open');
 Route::post('/futures/close',[FuturesController::class,'close'])->middleware('throttle:30,1,api.futures.close')->name('api.futures.close');
 Route::post('/futures/tpsl',[FuturesController::class,'tpsl'])->middleware('throttle:30,1,api.futures.tpsl')->name('api.futures.tpsl');
 Route::get('/account/summary',[AccountController::class,'summary'])->middleware('throttle:60,1,api.account.summary')->name('api.account.summary');
 Route::get('/spot/orders',[SpotOrderController::class,'index'])->middleware('throttle:60,1,api.spot.orders')->name('api.spot.orders');
 Route::post('/spot/orders',[SpotOrderController::class,'store'])->middleware('throttle:30,1,api.spot.orders.store')->name('api.spot.orders.store');
});
Route::post('/api/webhooks/nowpayments',[DepositController::class,'webhook'])->middleware('throttle:120,1,api.webhooks.nowpayments')->name('api.webhooks.nowpayments');
Route::middleware('auth')->prefix('api')->group(function(){
 Route::get('/withdrawals',[WithdrawalController::class,'index'])->middleware('throttle:60,1,api.withdrawals')->name('api.withdrawals');
 Route::post('/withdrawals',[WithdrawalController::class,'store'])->middleware('throttle:10,1,api.withdrawals.store')->name('api.withdrawals.store');
 Route::post('/withdrawals/{id}/cancel',[WithdrawalController::class,'cancel'])->middleware('throttle:20,1,api.withdrawals.cancel')->whereNumber('id')->name('api.withdrawals.cancel');
 Route::get('/manual-deposits',[ManualDepositController::class,'index'])->middleware('throttle:60,1,api.manual')->name('api.manual');
 Route::post('/manual-deposits',[ManualDepositController::class,'store'])->middleware('throttle:10,1,api.manual.store')->name('api.manual.store');
 Route::get('/rewards',[RewardController::class,'show'])->middleware('throttle:60,1,api.rewards')->name('api.rewards');
 Route::post('/rewards/claim',[RewardController::class,'claim'])->middleware('throttle:10,1,api.rewards.claim')->name('api.rewards.claim');
 Route::get('/convert',[ConvertController::class,'index'])->middleware('throttle:60,1,api.convert')->name('api.convert');
 Route::post('/convert',[ConvertController::class,'store'])->middleware('throttle:20,1,api.convert.store')->name('api.convert.store');
 Route::get('/deposits',[DepositController::class,'index'])->middleware('throttle:60,1,api.deposits')->name('api.deposits');
 Route::post('/deposits',[DepositController::class,'store'])->middleware('throttle:10,1,api.deposits.store')->name('api.deposits.store');
 Route::get('/deposits/{orderId}',[DepositController::class,'show'])->middleware('throttle:60,1,api.deposits.show')->name('api.deposits.show');
});
Route::get('/market/{symbol}',MarketDetailController::class)->where('symbol','[A-Za-z0-9]{2,32}')->name('market.detail');
foreach (['p2p','spot','learn','getting-started','faq','blog','fees','security','proof-of-reserves','status','support','markets'] as $page) {
 Route::get('/'.$page,[PlatformPageController::class,'show'])->defaults('page',$page)->name('platform.'.$page);
}
Route::middleware('auth')->group(function () {
 foreach (['assets','funding','trading','futures','earn','bots','deposit','withdraw','transfer','convert','copy','rewards','analysis','orders'] as $page) {
  Route::get('/'.$page,[PlatformPageController::class,'show'])->defaults('page',$page)->name('platform.'.$page);
 }
});
Route::prefix('admin')->name('admin.')->group(function(){
 Route::get('/',[AdminController::class,'dashboard'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('dashboard');
 Route::post('/users/{user}/wallet',[AdminWalletController::class,'adjust'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereNumber('user')->middleware('throttle:30,1,admin.users.wallet')->name('users.wallet');
 Route::get('/users/{user}',[AdminController::class,'user'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereNumber('user')->name('users.show');
 Route::get('/futures',[AdminYieldController::class,'futures'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('futures');
 Route::get('/earn',[AdminYieldController::class,'earn'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('earn');
 Route::post('/earn',[AdminYieldController::class,'saveEarn'])->middleware([\App\Http\Middleware\EnsureAdmin::class,'throttle:60,1,admin.earn.save'])->name('earn.save');
 Route::get('/withdrawals',[AdminTreasuryController::class,'withdrawals'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('withdrawals');
 Route::post('/withdrawals/{id}',[AdminTreasuryController::class,'reviewWithdrawal'])->middleware([\App\Http\Middleware\EnsureAdmin::class,'throttle:60,1,admin.withdrawals.review'])->whereNumber('id')->name('withdrawals.review');
 Route::get('/deposits',[AdminTreasuryController::class,'deposits'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('deposits');
 Route::post('/deposits/address',[AdminTreasuryController::class,'saveAddress'])->middleware([\App\Http\Middleware\EnsureAdmin::class,'throttle:60,1,admin.deposits.address'])->name('deposits.address');
 Route::post('/deposits/{id}',[AdminTreasuryController::class,'reviewDeposit'])->middleware([\App\Http\Middleware\EnsureAdmin::class,'throttle:60,1,admin.deposits.review'])->whereNumber('id')->name('deposits.review');
 Route::get('/traders',fn (\Illuminate\Http\Request $r) => app(AdminYieldController::class)->bots($r, 'trader'))->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('traders');
 Route::get('/bots',[AdminYieldController::class,'bots'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('bots');
 Route::post('/bots',[AdminYieldController::class,'saveBot'])->middleware([\App\Http\Middleware\EnsureAdmin::class,'throttle:60,1,admin.bots.save'])->name('bots.save');
 Route::get('/{section}',[AdminController::class,'section'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereIn('section',['users','kyc','deposits','withdrawals','transactions','trades','bots','p2pdesk','notifications','audit','settings'])->name('section');
 Route::get('/login',[AdminController::class,'loginForm'])->name('login');
 Route::post('/login',[AdminController::class,'login'])->middleware('throttle:5,1,admin.login.submit')->name('login.submit');
 Route::post('/logout',[AdminController::class,'logout'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('logout');
});
Route::middleware('auth')->group(function(){Route::get('/dashboard',fn()=>inertia('Home'))->name('dashboard');Route::post('/logout',[AuthController::class,'logout'])->name('logout');});
