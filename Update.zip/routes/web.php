<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\{InstallController,AuthController,DashboardController,PlatformPageController};
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MarketDataController;
use App\Http\Controllers\MarketFavoriteController;
use App\Http\Controllers\MarketDetailController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\DepositController;
use App\Http\Controllers\SpotOrderController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\AdminWalletController;
Route::get('/install',[InstallController::class,'show'])->name('install.show');
Route::post('/install',[InstallController::class,'install'])->middleware('throttle:5,1')->name('install.run');
Route::get('/',function(Request $request){ if($request->user()) return redirect()->route('dashboard'); return inertia('Landing',['authOpen'=>false,'authMode'=>'signin']); })->name('home');
Route::get('/login',[AuthController::class,'login'])->name('login');
Route::post('/login',[AuthController::class,'authenticate'])->middleware('throttle:5,1')->name('login.submit');
Route::post('/register',[AuthController::class,'register'])->middleware('throttle:5,1')->name('register');
Route::post('/forgot-password',[AuthController::class,'sendResetLink'])->middleware('throttle:3,1')->name('password.email');
Route::get('/reset-password/{token}',[AuthController::class,'resetPage'])->name('password.reset');
Route::post('/reset-password',[AuthController::class,'resetPassword'])->middleware('throttle:5,1')->name('password.update');
Route::get('/api/markets',MarketDataController::class)->middleware('throttle:60,1')->name('api.markets');
Route::middleware('auth')->prefix('api/market-favorites')->name('api.market-favorites.')->group(function(){
 Route::get('/',[MarketFavoriteController::class,'index'])->name('index');
 Route::post('/',[MarketFavoriteController::class,'store'])->middleware('throttle:30,1')->name('store');
 Route::delete('/{marketType}/{symbol}',[MarketFavoriteController::class,'destroy'])->name('destroy');
});
Route::middleware('auth')->prefix('api')->group(function(){
 Route::get('/wallet',[WalletController::class,'index'])->middleware('throttle:120,1')->name('api.wallet');
 Route::post('/wallet/transfer',[WalletController::class,'transfer'])->middleware('throttle:20,1')->name('api.wallet.transfer');
 Route::get('/account/summary',[AccountController::class,'summary'])->middleware('throttle:60,1')->name('api.account.summary');
 Route::get('/spot/orders',[SpotOrderController::class,'index'])->middleware('throttle:60,1')->name('api.spot.orders');
 Route::post('/spot/orders',[SpotOrderController::class,'store'])->middleware('throttle:30,1')->name('api.spot.orders.store');
});
Route::post('/api/webhooks/nowpayments',[DepositController::class,'webhook'])->middleware('throttle:120,1')->name('api.webhooks.nowpayments');
Route::middleware('auth')->prefix('api')->group(function(){
 Route::get('/deposits',[DepositController::class,'index'])->middleware('throttle:60,1')->name('api.deposits');
 Route::post('/deposits',[DepositController::class,'store'])->middleware('throttle:10,1')->name('api.deposits.store');
 Route::get('/deposits/{orderId}',[DepositController::class,'show'])->middleware('throttle:60,1')->name('api.deposits.show');
});
Route::get('/market/{symbol}',MarketDetailController::class)->where('symbol','[A-Za-z0-9]{2,32}')->name('market.detail');
foreach (['p2p','spot','futures','convert','bots','earn','learn','getting-started','faq','blog','fees','security','proof-of-reserves','status','support','markets'] as $page) {
 Route::get('/'.$page,[PlatformPageController::class,'show'])->defaults('page',$page)->name('platform.'.$page);
}
Route::middleware('auth')->group(function () {
 foreach (['assets','funding','trading','deposit','withdraw','transfer','analysis','orders'] as $page) {
  Route::get('/'.$page,[PlatformPageController::class,'show'])->defaults('page',$page)->name('platform.'.$page);
 }
});
Route::prefix('admin')->name('admin.')->group(function(){
 Route::get('/',[AdminController::class,'dashboard'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('dashboard');
 Route::post('/users/{user}/wallet',[AdminWalletController::class,'adjust'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereNumber('user')->middleware('throttle:30,1')->name('users.wallet');
 Route::get('/users/{user}',[AdminController::class,'user'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereNumber('user')->name('users.show');
 Route::get('/{section}',[AdminController::class,'section'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->whereIn('section',['users','kyc','deposits','withdrawals','transactions','trades','bots','p2pdesk','notifications','audit','settings'])->name('section');
 Route::get('/login',[AdminController::class,'loginForm'])->name('login');
 Route::post('/login',[AdminController::class,'login'])->middleware('throttle:5,1')->name('login.submit');
 Route::post('/logout',[AdminController::class,'logout'])->middleware(\App\Http\Middleware\EnsureAdmin::class)->name('logout');
});
Route::middleware('auth')->group(function(){Route::get('/dashboard',fn()=>redirect()->route('platform.assets'))->name('dashboard');Route::post('/logout',[AuthController::class,'logout'])->name('logout');});
