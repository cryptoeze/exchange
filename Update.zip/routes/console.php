<?php

use Illuminate\Support\Facades\Schedule;

// Optional: only runs if the hosting cron calls `php artisan schedule:run` every minute.
// Earn interest and bot profit are also settled whenever a user opens those pages.
Schedule::command('earn:accrue')->hourly();
Schedule::command('bots:settle')->hourly();
Schedule::command('futures:sweep')->everyMinute();
Schedule::command('alerts:check')->everyMinute();
Schedule::command('p2p:expire')->everyMinute();
Schedule::command('orders:fill')->everyMinute();
// Sold-copy license check-in; a no-op on the vendor's own install (config('license.authority') === true).
Schedule::command('license:check')->everyTenMinutes();
