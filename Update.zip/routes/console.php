<?php

use Illuminate\Support\Facades\Schedule;

// Optional: only runs if the hosting cron calls `php artisan schedule:run` every minute.
// Earn interest and bot profit are also settled whenever a user opens those pages.
Schedule::command('earn:accrue')->hourly();
Schedule::command('bots:settle')->hourly();
