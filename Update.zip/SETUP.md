# Quick setup

1. On shared hosting, extract the project into `public_html`. Keep the included root `.htaccess` file; it routes public traffic through the Laravel `public/` directory and blocks direct web access to application files. If the host lets you set a document root, `public/` is the preferred target.
2. Create an empty MySQL database and database user in your hosting control panel.
3. From the project directory, run `sh prepare-hosting.sh` in the hosting terminal. It installs PHP dependencies and sets folder permissions. This ZIP already includes the production frontend files, so Node/npm are not needed on Hostinger.
4. Turn on HTTPS, then open `https://your-domain.example/install` and enter the MySQL details and first administrator account.
5. Sign in at `/login`. The install page locks itself after setup.

The host needs PHP 8.5, Composer, and MySQL/MariaDB. The setup script can build the frontend as a fallback if `public/build/` has been removed; for this release the assets are included. See `README.md` for security/deployment details.

## Updating an existing Hostinger install

1. Extract `Update.zip` into `/home/u597262569/domains/riseway.io/public_html`, allow files to overwrite, and keep the existing `.env` and `vendor/` directory.
2. In `public_html`, run: `composer dump-autoload --no-dev --no-scripts && php artisan migrate --force && php artisan optimize:clear`

## Email setup

New signups receive a welcome email that includes the account email and sign-in address; it never includes a password. Password recovery uses Laravel's secure reset link. Both require Hostinger SMTP settings in the existing `.env`: `MAIL_MAILER=smtp`, `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_ENCRYPTION` or `MAIL_SCHEME`, `MAIL_FROM_ADDRESS`, and `MAIL_FROM_NAME`. Then run `php artisan optimize:clear` once. Email delivery was not testable here because the local PHP/SMTP environment is unavailable.

## Current feature limits

The app's current database does not contain wallet balances, a financial ledger, deposits, withdrawals, trades, or KYC records. Those routes are clear placeholders and do not change funds. Admin user list/detail pages are read-only. Do not use sample balance data as production account information. Confirm wallet posting rules and a full database backup/retention plan before enabling financial operations or bulk account deletion.
