# Admin panel — structure & how to extend it

## Sitemap (sidebar groups; each group also shows as pill tabs at the top of its pages)
| Group | Pages |
|---|---|
| Overview | Dashboard (live, every card is a link) |
| Users & compliance | **Users** → **User 360** · KYC review · Referrals · Support tickets |
| Money | **Transactions** · Deposits · Withdrawals · **Gateways** · Proof of Reserves |
| Trading | Spot trades · Futures · Limit & TP/SL · Markets on/off · P2P desk |
| Products | Earn · Bots · Copy traders |
| Communication | Notifications · Email templates |
| System | Settings · Admin team · Audit log · My security |

* **User 360** (`/admin/users/{id}?tab=…`): Overview, Wallet (balances, credit/debit, ledger with filters), Deposits, Withdrawals (approve/reject inline), Trading (spot/futures/limit/earn/bots), P2P, KYC (photos + approve/reject), Security (2FA reset, sign-out, sign-in history), Referrals, Support, Manage (edit profile/password, freeze, message).
* **Transactions** = the whole ledger (every balance movement) with category / type / asset / account / direction / amount / date / user filters, totals and CSV export.
* **Gateways** = one place for: master switches, automatic deposits (NOWPayments status + per-network on/off), manual deposit addresses (add/edit/on-off) and withdrawal networks (min, fee, on/off).
* Deposits / Withdrawals: tabs by status with counts, filters, pagination, CSV, and the review actions (credit / reject / mark sent / reject & refund) as modals with reasons.

## Where things live
| Piece | File |
|---|---|
| Sitemap, roles, badges (single source of truth for sidebar + section tabs) | `resources/js/admin/nav.ts` |
| UI kit (Page, Panel, Stats, Tabs, FilterBar, DataTable, Pager, Badge, ActionButton/Modal, Switch, UserLink…) | `resources/js/admin/kit.tsx` + `resources/css/admin-ui.css` (prefix `au-`) |
| Layout (sidebar, topbar, user finder, bell, section tabs) | `resources/js/pages/Admin/Layout.tsx` |
| Server helpers (pagination shape, date filters, audit, CSV, money format) | `app/Http/Controllers/Admin/Concerns/AdminHelpers.php` |
| Ledger categories (what shows under "Deposits", "Spot"…) | `app/Support/LedgerCategory.php` |
| Role limits (server-side gatekeeper) | `app/Http/Middleware/EnsureAdmin.php` (`ROLE_PATHS`) |
| Sidebar counters | `HandleInertiaRequests` → `adminBadges` |

## Add a new admin page (checklist)
1. Controller `use AdminHelpers;` → build filters from `$request`, use `$this->paged($query, $request, 25)`, return `inertia('Admin/Thing', [... 'pager' => $pager, 'filters' => [...]])`.
2. Route in `routes/web.php` inside the `admin` prefix with `EnsureAdmin` middleware.
3. Page component `resources/js/pages/Admin/Thing.tsx` (copy `Trades.tsx` — the smallest example: Page → Stats → Panel → FilterBar → DataTable → Pager) and register it in `resources/js/app.tsx` (`'Admin/Thing': AdminThing`).
4. Add one entry to `ADMIN_NAV` in `nav.ts` (label, href, icon, roles, optional badge) and, for non-super roles, the first path segment to `EnsureAdmin::ROLE_PATHS`.
5. Add a test in `tests/Feature/AdminStructureTest.php` style (`assertInertia`).

## Add a new tab to User 360
Add the key to `UsersController::TABS`, a `tabXxx()` method returning that tab's data, a component in `UserShow.tsx` and a line in its `<Tabs>`.
