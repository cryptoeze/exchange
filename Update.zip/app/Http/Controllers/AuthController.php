<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password as PasswordRule;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        if ($request->user()) {
            return redirect()->route('dashboard');
        }

        $mode = $request->query('mode');
        $mode = in_array($mode, ['signup', 'forgot'], true) ? $mode : 'signin';
        if ($request->filled('ref') && $mode === 'signin') {
            $mode = 'signup';
        }

        return inertia('Landing', ['authOpen' => true, 'authMode' => $mode]);
    }

    public function resetPage(Request $request, string $token)
    {
        if ($request->user()) {
            return redirect()->route('dashboard');
        }

        return inertia('Landing', [
            'authOpen' => true,
            'authMode' => 'reset',
            'resetToken' => $token,
            'resetEmail' => is_string($request->query('email')) ? $request->query('email') : '',
        ]);
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->validate(['email' => 'required|email', 'password' => 'required|string']);
        if (! Auth::attempt($credentials, $request->boolean('remember'))) {
            return back()->withErrors(['email' => 'These credentials do not match our records.'])->onlyInput('email');
        }

        $request->session()->regenerate();

        return redirect()->intended(route('dashboard'));
    }

    public function register(Request $request)
    {
        if (is_string($request->input('referral_code'))) {
            $request->merge(['referral_code' => strtoupper(trim($request->input('referral_code'))) ?: null]);
        }
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email:rfc|max:190|unique:users,email',
            'password' => ['required', 'confirmed', PasswordRule::min(12)->letters()->numbers()],
            'referral_code' => 'nullable|string|max:12|exists:users,referral_code',
        ], ['referral_code.exists' => 'That referral code was not found. Leave it empty if you do not have one.']);
        $referrer = ! empty($data['referral_code']) ? User::where('referral_code', strtoupper($data['referral_code']))->value('id') : null;

        $user = User::create([
            'referred_by' => $referrer,
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'role' => 'user',
        ]);
        try {
            Mail::raw(
                "Welcome to RushX, {$user->name}. Your account is ready. Sign in at ".url('/login')." using {$user->email}. If you need to change your password, use the Forgot password link on the sign-in page. RushX will never email you your password.",
                static function ($message) use ($user): void {
                    $message->to($user->email, $user->name)->subject('Your RushX account is ready');
                }
            );
        } catch (\Throwable $exception) {
            Log::warning('RushX account welcome email could not be delivered.', ['user_id' => $user->id, 'exception' => $exception::class]);
        }
        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->route('dashboard');
    }

    public function sendResetLink(Request $request)
    {
        $request->validate(['email' => 'required|email']);
        try {
            $status = Password::sendResetLink($request->only('email'));
        } catch (\Throwable $exception) {
            Log::warning('Password reset email could not be delivered.', ['exception' => $exception::class]);

            return back()->withErrors(['email' => 'Password reset email could not be sent. Please try again later.']);
        }

        return $status === Password::RESET_LINK_SENT
            ? back()->with('status', __($status))
            : back()->withErrors(['email' => __($status)]);
    }

    public function resetPassword(Request $request)
    {
        $data = $request->validate([
            'token' => 'required',
            'email' => 'required|email',
            'password' => ['required', 'confirmed', PasswordRule::min(12)->letters()->numbers()],
        ]);

        $status = Password::reset($data, function (User $user, string $password): void {
            $user->forceFill(['password' => Hash::make($password), 'remember_token' => Str::random(60)])->save();
            event(new PasswordReset($user));
        });

        return $status === Password::PASSWORD_RESET
            ? redirect()->route('login')->with('status', __($status))
            : back()->withErrors(['email' => __($status)]);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
