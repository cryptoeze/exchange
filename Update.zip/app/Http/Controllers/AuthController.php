<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password as PasswordRule;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        if ($request->user()) {
            return redirect()->route('dashboard');
        }

        $mode = $request->query('mode');
        $mode = in_array($mode, ['signup', 'forgot'], true) ? $mode : 'signin';
        if ($request->session()->has('2fa.id') && $request->session()->get('2fa.exp', 0) > time()) {
            $mode = 'twofactor';
        }
        if ($request->filled('ref') && $mode === 'signin') {
            $mode = 'signup';
        }

        return inertia('Landing', ['authOpen' => true, 'authMode' => $mode]);
    }

    public function twoFactor(Request $request)
    {
        $d = $request->validate(['code' => 'required|string|max:20']);
        $id = $request->session()->get('2fa.id');
        if (! $id || $request->session()->get('2fa.exp', 0) < time()) {
            $request->session()->forget(['2fa.id', '2fa.remember', '2fa.exp', '2fa.tries']);

            return redirect()->route('login')->withErrors(['code' => 'Your sign-in session expired. Please sign in again.']);
        }
        $user = User::query()->findOrFail($id);
        $totp = app(\App\Services\TotpService::class);
        if (! $totp->check($user, $d['code'])) {
            $tries = (int) $request->session()->increment('2fa.tries');
            $totp->logLogin($user->id, $user->email, 'web', false, 'bad 2fa code');
            if ($tries >= 5) {
                $request->session()->forget(['2fa.id', '2fa.remember', '2fa.exp', '2fa.tries']);

                return redirect()->route('login')->withErrors(['code' => 'Too many wrong codes. Please sign in again.']);
            }

            return back()->withErrors(['code' => 'That code is not correct.']);
        }
        $remember = (bool) $request->session()->get('2fa.remember');
        $request->session()->forget(['2fa.id', '2fa.remember', '2fa.exp', '2fa.tries']);
        if (($user->status ?? 'active') === 'frozen') {
            return redirect()->route('login')->withErrors(['email' => 'This account is frozen. Contact support.']);
        }
        Auth::login($user, $remember);
        $request->session()->regenerate();
        $totp->logLogin($user->id, $user->email, 'web', true, '2fa');

        return redirect()->intended(route('dashboard'));
    }

    public function resetPage(Request $request, string $token)
    {
        if ($request->user()) {
            return redirect()->route('dashboard');
        }

        return inertia('Landing', [
            'authOpen' => true,
            'authMode' => 'reset',
            'resetToken' => $token,
            'resetEmail' => is_string($request->query('email')) ? $request->query('email') : '',
        ]);
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->validate(['email' => 'required|email', 'password' => 'required|string']);
        if (! Auth::attempt($credentials, $request->boolean('remember'))) {
            app(\App\Services\TotpService::class)->logLogin(User::where('email', $credentials['email'])->value('id'), $credentials['email'], 'web', false, 'bad password');
            return back()->withErrors(['email' => 'These credentials do not match our records.'])->onlyInput('email');
        }

        $totp = app(\App\Services\TotpService::class);
        if (Auth::user()->two_factor_enabled) {
            $request->session()->put(['2fa.id' => Auth::id(), '2fa.remember' => $request->boolean('remember'), '2fa.exp' => time() + 300, '2fa.tries' => 0]);
            Auth::logout();

            return redirect()->route('login');
        }
        $totp->logLogin(Auth::id(), Auth::user()->email, 'web', true);
        if ((Auth::user()->status ?? 'active') === 'frozen') {
            Auth::logout();

            return back()->withErrors(['email' => 'This account is frozen. Contact support.'])->onlyInput('email');
        }
        $request->session()->regenerate();

        return redirect()->intended(route('dashboard'));
    }

    public function register(Request $request)
    {
        if (is_string($request->input('referral_code'))) {
            $request->merge(['referral_code' => strtoupper(trim($request->input('referral_code'))) ?: null]);
        }
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email:rfc|max:190|unique:users,email',
            'country' => 'required|string|max:80',
            'dial' => ['required', 'regex:/^\+\d{1,5}$/'],
            'phone' => ['required', 'regex:/^\d{5,14}$/'],
            'password' => ['required', 'confirmed', PasswordRule::min(12)->letters()->numbers()],
            'referral_code' => 'nullable|string|max:12|exists:users,referral_code',
        ], ['referral_code.exists' => 'That referral code was not found. Leave it empty if you do not have one.']);
        $referrer = ! empty($data['referral_code']) ? User::where('referral_code', strtoupper($data['referral_code']))->value('id') : null;

        $user = User::create([
            'referred_by' => $referrer,
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['dial'].$data['phone'],
            'country' => $data['country'],
            'password' => Hash::make($data['password']),
            'role' => 'user',
        ]);
        try {
            Mail::raw(
                "Welcome to RushX, {$user->name}. Your account is ready. Sign in at ".url('/login')." using {$user->email}. If you need to change your password, use the Forgot password link on the sign-in page. RushX will never email you your password.",
                static function ($message) use ($user): void {
                    $message->to($user->email, $user->name)->subject('Your RushX account is ready');
                }
            );
        } catch (\Throwable $exception) {
            Log::warning('RushX account welcome email could not be delivered.', ['user_id' => $user->id, 'exception' => $exception::class]);
        }
        \App\Services\NotificationService::admins('New user registered', $user->name.' · '.$user->email, '/admin/users/'.$user->id);
        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->route('dashboard');
    }

    public function sendResetLink(Request $request)
    {
        $request->validate(['email' => 'required|email']);
        try {
            $status = Password::sendResetLink($request->only('email'));
        } catch (\Throwable $exception) {
            Log::warning('Password reset email could not be delivered.', ['exception' => $exception::class]);

            return back()->withErrors(['email' => 'Password reset email could not be sent. Please try again later.']);
        }

        return $status === Password::RESET_LINK_SENT
            ? back()->with('status', __($status))
            : back()->withErrors(['email' => __($status)]);
    }

    public function resetPassword(Request $request)
    {
        $data = $request->validate([
            'token' => 'required',
            'email' => 'required|email',
            'password' => ['required', 'confirmed', PasswordRule::min(12)->letters()->numbers()],
        ]);

        $status = Password::reset($data, function (User $user, string $password): void {
            $user->forceFill(['password' => Hash::make($password), 'remember_token' => Str::random(60)])->save();
            event(new PasswordReset($user));
        });

        return $status === Password::PASSWORD_RESET
            ? redirect()->route('login')->with('status', __($status))
            : back()->withErrors(['email' => __($status)]);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
