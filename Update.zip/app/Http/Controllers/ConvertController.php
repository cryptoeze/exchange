<?php

namespace App\Http\Controllers;

use App\Models\Conversion;
use App\Services\LedgerService;
use App\Services\SpotTradingService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Instant zero-fee conversion inside the Funding account at the server-side market price. */
final class ConvertController extends Controller
{
    private const STABLE = ['USDT', 'USDC'];

    public function __construct(private readonly LedgerService $ledger, private readonly SpotTradingService $spot)
    {
    }

    public function index(Request $request): JsonResponse
    {
        return response()->json($this->history($request->user()->id))->header('Cache-Control', 'no-store');
    }

    public function store(Request $request): JsonResponse
    {
        $d = $request->validate([
            'from' => ['required', 'regex:/^[A-Z0-9]{2,10}$/'], 'to' => ['required', 'regex:/^[A-Z0-9]{2,10}$/', 'different:from'],
            'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'idempotency_key' => 'nullable|string|max:64',
        ]);
        $user = $request->user();
        try {
            $units = Money::toUnits($d['amount']);
            if ($units <= 0) {
                throw new DomainException('Enter an amount.');
            }
            $fromUsd = $this->usdPrice($d['from']);
            $toUsd = $this->usdPrice($d['to']);
            $usdValue = $units / 1e8 * $fromUsd;
            if ($usdValue < (float) config('trading.spot_min_quote_usdt') || $usdValue > (float) config('trading.spot_max_quote_usdt')) {
                throw new DomainException('Conversion size is outside the allowed range.');
            }
            $rate = $fromUsd / $toUsd;
            $received = (int) floor($units * $rate);
            if ($received <= 0) {
                throw new DomainException('The amount is too small to convert.');
            }
            $key = isset($d['idempotency_key']) ? "{$user->id}:cv:{$d['idempotency_key']}" : null;
            DB::transaction(function () use ($user, $d, $units, $received, $rate, $key): void {
                if ($key !== null && Conversion::query()->where('idempotency_key', $key)->exists()) {
                    return;
                }
                $c = Conversion::query()->create(['user_id' => $user->id, 'from_asset' => $d['from'], 'to_asset' => $d['to'], 'from_amount' => $units, 'to_amount' => $received, 'rate' => $rate, 'idempotency_key' => $key]);
                $this->ledger->apply($user->id, 'funding', $d['from'], -$units, 'convert_out', ['ref_type' => 'conversion', 'ref_id' => $c->id, 'note' => "to {$d['to']}"]);
                $this->ledger->apply($user->id, 'funding', $d['to'], $received, 'convert_in', ['ref_type' => 'conversion', 'ref_id' => $c->id, 'note' => "from {$d['from']}"]);
            }, 3);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->history($user->id), 201);
    }

    private function usdPrice(string $asset): float
    {
        if (in_array($asset, self::STABLE, true)) {
            return 1.0;
        }

        return $this->spot->quote($asset.'USDT')['price'];
    }

    /** @return array<string, mixed> */
    private function history(int $userId): array
    {
        return ['rows' => Conversion::query()->where('user_id', $userId)->orderByDesc('id')->limit(30)->get()->map(fn ($c) => [
            'id' => $c->id, 'from' => $c->from_asset, 'to' => $c->to_asset, 'spent' => Money::format((int) $c->from_amount, 4), 'received' => Money::format((int) $c->to_amount, 6), 'at' => $c->created_at?->toIso8601String(),
        ])->values()];
    }
}
