<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/** Public candle history for the in-app chart (Bybit public market data, cached for 2s). */
class KlineController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $d = $request->validate([
            'symbol' => ['required', 'regex:/^[A-Z0-9]{2,32}$/'],
            'interval' => 'required|in:1,3,5,15,30,60,120,240,D,W',
            'market' => 'nullable|in:spot,linear',
            'limit' => 'nullable|integer|min:10|max:1000',
        ]);
        $market = $d['market'] ?? 'spot';
        $limit = (int) ($d['limit'] ?? 500);
        $key = "kline:{$market}:{$d['symbol']}:{$d['interval']}:{$limit}";
        $rows = Cache::remember($key, 2, function () use ($d, $market, $limit) {
            $res = Http::acceptJson()->timeout(8)->get(rtrim((string) config('market-data.base_url'), '/').'/v5/market/kline', ['category' => $market, 'symbol' => $d['symbol'], 'interval' => $d['interval'], 'limit' => $limit]);
            $list = $res->json('result.list');
            if (! $res->ok() || ! is_array($list)) {
                return null;
            }

            return array_reverse(array_map(fn ($r) => ['t' => (int) ((int) $r[0] / 1000), 'o' => (float) $r[1], 'h' => (float) $r[2], 'l' => (float) $r[3], 'c' => (float) $r[4], 'v' => (float) $r[5]], $list));
        });
        if ($rows === null) {
            Cache::forget($key);

            return response()->json(['message' => 'Chart data is temporarily unavailable.'], 503);
        }

        return response()->json(['candles' => $rows]);
    }
}
