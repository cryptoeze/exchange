<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use App\Models\User;

/**
 * Step-gated installer: requirements -> site URL -> database (must test OK) -> admin account -> email/SMTP
 * (optional, can skip) -> license key (must activate OK) -> install. Nothing is written to disk or the database
 * until every required step has already passed, and the license key is checked (a real activation call to the
 * vendor's license server) before anything else is written — an invalid or missing key stops the install cold,
 * same as a real commercial script installer.
 */
class InstallController extends Controller {
 private const REQUIRED_EXT = ['pdo_mysql', 'mbstring', 'openssl', 'curl', 'bcmath', 'ctype', 'json', 'tokenizer', 'xml', 'fileinfo'];

 private function token(): string { $path=storage_path('app/install.token'); if(!file_exists($path)) file_put_contents($path,bin2hex(random_bytes(32)),LOCK_EX); return trim(file_get_contents($path)); }
 private function checkToken(Request $request): void { $path=storage_path('app/install.token'); abort_unless(is_file($path)&&hash_equals(trim(file_get_contents($path)),(string)$request->input('install_token')),403); }

 public function show(){
  abort_if(file_exists(storage_path('app/installed.lock')),404);
  $checks=[];
  $checks[]=['label'=>'PHP 8.3 or newer','ok'=>version_compare(PHP_VERSION,'8.3','>=')];
  foreach(self::REQUIRED_EXT as $ext) $checks[]=['label'=>"PHP extension: {$ext}",'ok'=>extension_loaded($ext)];
  $checks[]=['label'=>'storage/ and bootstrap/cache/ are writable','ok'=>is_writable(storage_path()) && is_writable(base_path('bootstrap/cache'))];
  $checks[]=['label'=>'.env file can be written','ok'=>!file_exists(base_path('.env')) || is_writable(base_path('.env'))];
  return response()->view('install',['installToken'=>$this->token(),'checks'=>$checks,'requirementsOk'=>collect($checks)->every(fn($c)=>$c['ok']),'authorityUrl'=>config('license.authority_url')]);
 }

 public function testDb(Request $request){
  abort_if(file_exists(storage_path('app/installed.lock')),404); $this->checkToken($request);
  $d=$request->validate(['db_host'=>'required|string|max:255','db_port'=>'required|integer|between:1,65535','db_name'=>'required|string|max:64','db_user'=>'required|string|max:128','db_password'=>'nullable|string|max:255']);
  try{
   config(['database.connections.mysql.host'=>$d['db_host'],'database.connections.mysql.port'=>$d['db_port'],'database.connections.mysql.database'=>$d['db_name'],'database.connections.mysql.username'=>$d['db_user'],'database.connections.mysql.password'=>$d['db_password']??'']);
   DB::purge('mysql'); DB::connection('mysql')->getPdo();
  }catch(\Throwable $e){ return response()->json(['ok'=>false,'message'=>'Could not connect: confirm the host, port, database name, username and password, and that the database already exists.'],422); }
  return response()->json(['ok'=>true]);
 }

 public function testSmtp(Request $request){
  abort_if(file_exists(storage_path('app/installed.lock')),404); $this->checkToken($request);
  $d=$request->validate(['smtp_host'=>'required|string|max:255','smtp_port'=>'required|integer|between:1,65535','smtp_user'=>'required|string|max:255','smtp_pass'=>'required|string|max:255','smtp_scheme'=>'nullable|string|in:smtp,smtps','mail_from'=>'required|email:rfc','mail_from_name'=>'nullable|string|max:120','test_to'=>'required|email:rfc']);
  config(['mail.default'=>'smtp','mail.mailers.smtp.host'=>$d['smtp_host'],'mail.mailers.smtp.port'=>$d['smtp_port'],'mail.mailers.smtp.username'=>$d['smtp_user'],'mail.mailers.smtp.password'=>$d['smtp_pass'],'mail.mailers.smtp.scheme'=>$d['smtp_scheme']??null,'mail.from.address'=>$d['mail_from'],'mail.from.name'=>$d['mail_from_name']??config('app.name')]);
  try{ Mail::raw('This is a test message from the RushX installer — your SMTP settings work.',function($m)use($d){ $m->to($d['test_to'])->subject('RushX installer: SMTP test'); }); }
  catch(\Throwable $e){ return response()->json(['ok'=>false,'message'=>'Could not send: confirm the SMTP host, port, username, password and security mode.'],422); }
  return response()->json(['ok'=>true]);
 }

 /** Calls the vendor's license server directly — a real activation, not a dry run, so the final install step re-uses the same result. */
 public function testLicense(Request $request){
  abort_if(file_exists(storage_path('app/installed.lock')),404); $this->checkToken($request);
  $d=$request->validate(['app_url'=>'required|url|max:255','license_key'=>'required|string|max:64']);
  $domain=parse_url($d['app_url'],PHP_URL_HOST)?:$d['app_url'];
  try{ $r=Http::timeout(10)->post(rtrim((string)config('license.authority_url'),'/').'/api/webhooks/license/activate',['key'=>strtoupper(trim($d['license_key'])),'domain'=>$domain]); }
  catch(\Throwable $e){ return response()->json(['ok'=>false,'message'=>'Could not reach the license server. Check this server can make outbound HTTPS requests, then retry.'],422); }
  if(!$r->successful() || $r->json('status')!=='active') return response()->json(['ok'=>false,'message'=>'That license key was not accepted (wrong, already used on another domain, or revoked). Contact the vendor.'],422);
  return response()->json(['ok'=>true]);
 }

 public function install(Request $request){
  abort_if(file_exists(storage_path('app/installed.lock')),404);
  $data=$request->validate(['app_url'=>'required|url|max:255','db_host'=>'required|string|max:255','db_port'=>'required|integer|between:1,65535','db_name'=>'required|string|max:64','db_user'=>'required|string|max:128','db_password'=>'nullable|string|max:255','admin_name'=>'required|string|max:100','admin_email'=>'required|email:rfc,dns|max:190','admin_password'=>'required|string|min:12|max:128','install_token'=>'required|string','license_key'=>'required|string|max:64','smtp_enabled'=>'nullable|boolean','smtp_host'=>'nullable|string|max:255','smtp_port'=>'nullable|integer|between:1,65535','smtp_user'=>'nullable|string|max:255','smtp_pass'=>'nullable|string|max:255','smtp_scheme'=>'nullable|string|in:smtp,smtps','mail_from'=>'nullable|email:rfc','mail_from_name'=>'nullable|string|max:120']);
  $tokenPath=storage_path('app/install.token'); abort_unless(is_file($tokenPath)&&hash_equals(trim(file_get_contents($tokenPath)),$data['install_token']),403);

  // License first — a real activation call, before anything is written to disk or database. An invalid key stops here.
  $licenseKey=strtoupper(trim($data['license_key'])); $domain=parse_url($data['app_url'],PHP_URL_HOST)?:$data['app_url'];
  try{ $lic=Http::timeout(10)->post(rtrim((string)config('license.authority_url'),'/').'/api/webhooks/license/activate',['key'=>$licenseKey,'domain'=>$domain]); }
  catch(\Throwable $e){ return back()->withErrors(['setup'=>'Could not reach the license server. Check outbound HTTPS access on this server, then retry.'])->withInput($request->except('admin_password','db_password','smtp_pass')); }
  if(!$lic->successful() || $lic->json('status')!=='active') return back()->withErrors(['setup'=>'License key was not accepted. Contact the vendor you purchased this from.'])->withInput($request->except('admin_password','db_password','smtp_pass'));

  $appKey='base64:'.base64_encode(random_bytes(32));
  $envQuote=static fn(string $value): string=>'"'.str_replace(['\\','"',"\n","\r"],['\\\\','\\"','\\n','\\r'],$value).'"';
  $appUrlEnv=$envQuote($data['app_url']); $dbHostEnv=$envQuote($data['db_host']); $dbNameEnv=$envQuote($data['db_name']); $dbUserEnv=$envQuote($data['db_user']); $dbPasswordEnv=$envQuote($data['db_password']??'');
  $env="APP_NAME=RushX\nAPP_ENV=production\nAPP_KEY={$appKey}\nAPP_DEBUG=false\nAPP_URL={$appUrlEnv}\nAPP_LOCALE=en\nAPP_FALLBACK_LOCALE=en\nLOG_CHANNEL=stack\nLOG_LEVEL=warning\nDB_CONNECTION=mysql\nDB_HOST={$dbHostEnv}\nDB_PORT={$data['db_port']}\nDB_DATABASE={$dbNameEnv}\nDB_USERNAME={$dbUserEnv}\nDB_PASSWORD={$dbPasswordEnv}\nSESSION_DRIVER=file\nSESSION_LIFETIME=120\nSESSION_ENCRYPT=true\nSESSION_SECURE_COOKIE=true\nCACHE_STORE=file\nQUEUE_CONNECTION=sync\n";
  $envPath=base_path('.env'); if(!is_writable(dirname($envPath)) || file_exists($envPath)&&!is_writable($envPath)) return back()->withErrors(['setup'=>'Application directory is not writable.'])->withInput($request->except('admin_password','db_password','smtp_pass'));
  try {
   config(['database.connections.mysql.host'=>$data['db_host'],'database.connections.mysql.port'=>$data['db_port'],'database.connections.mysql.database'=>$data['db_name'],'database.connections.mysql.username'=>$data['db_user'],'database.connections.mysql.password'=>$data['db_password']??'']); DB::purge('mysql'); DB::connection('mysql')->getPdo();
   $status=Artisan::call('migrate',['--force'=>true]); if($status!==0) throw new \RuntimeException('Database migrations did not complete.');
   if(file_put_contents($envPath,$env,LOCK_EX)===false) throw new \RuntimeException('Could not save configuration.');
   User::create(['name'=>$data['admin_name'],'email'=>$data['admin_email'],'password'=>Hash::make($data['admin_password']),'role'=>'admin']);
   $now=now();
   DB::table('settings')->updateOrInsert(['key'=>'license_key'],['value'=>$licenseKey,'updated_at'=>$now]);
   DB::table('settings')->updateOrInsert(['key'=>'license_locked'],['value'=>'0','updated_at'=>$now]);
   if($request->boolean('smtp_enabled') && $data['smtp_host']){
    app(\App\Services\SettingsService::class)->save(['smtp_host'=>$data['smtp_host'],'smtp_port'=>(string)($data['smtp_port']??587),'smtp_user'=>$data['smtp_user']??'','smtp_pass'=>$data['smtp_pass']??'','smtp_scheme'=>$data['smtp_scheme']??'','mail_from'=>$data['mail_from']??'','mail_from_name'=>$data['mail_from_name']??'']);
   }
   if(file_put_contents(storage_path('app/installed.lock'),now()->toIso8601String(),LOCK_EX)===false) throw new \RuntimeException('Could not lock installer.'); @unlink($tokenPath);
  } catch(\Throwable $e){ report($e); return back()->withErrors(['setup'=>'Setup failed. Confirm database credentials and that the database exists, then retry.'])->withInput($request->except('admin_password','db_password','smtp_pass')); }
  return redirect()->route('login')->with('status','Installation complete. Sign in with your administrator account.');
 }
}
