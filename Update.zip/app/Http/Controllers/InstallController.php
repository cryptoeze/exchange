<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
class InstallController extends Controller {
 public function show(){ $path=storage_path('app/install.token'); if(!file_exists($path)) file_put_contents($path,bin2hex(random_bytes(32)),LOCK_EX); return response()->view('install',['installToken'=>trim(file_get_contents($path))]); }
 public function install(Request $request){
  abort_if(file_exists(storage_path('app/installed.lock')),404);
  $data=$request->validate(['app_url'=>'required|url|max:255','db_host'=>'required|string|max:255','db_port'=>'required|integer|between:1,65535','db_name'=>'required|string|max:64','db_user'=>'required|string|max:128','db_password'=>'nullable|string|max:255','admin_name'=>'required|string|max:100','admin_email'=>'required|email:rfc,dns|max:190','admin_password'=>'required|string|min:12|max:128','install_token'=>'required|string']);
  $tokenPath=storage_path('app/install.token'); abort_unless(is_file($tokenPath)&&hash_equals(trim(file_get_contents($tokenPath)),$data['install_token']),403);
  $appKey='base64:'.base64_encode(random_bytes(32));
  $envQuote=static fn(string $value): string=>'"'.str_replace(['\\','"',"\n","\r"],['\\\\','\\"','\\n','\\r'],$value).'"';
  $appUrlEnv=$envQuote($data['app_url']); $dbHostEnv=$envQuote($data['db_host']); $dbNameEnv=$envQuote($data['db_name']); $dbUserEnv=$envQuote($data['db_user']); $dbPasswordEnv=$envQuote($data['db_password']??'');
  $env="APP_NAME=RushX\nAPP_ENV=production\nAPP_KEY={$appKey}\nAPP_DEBUG=false\nAPP_URL={$appUrlEnv}\nAPP_LOCALE=en\nAPP_FALLBACK_LOCALE=en\nLOG_CHANNEL=stack\nLOG_LEVEL=warning\nDB_CONNECTION=mysql\nDB_HOST={$dbHostEnv}\nDB_PORT={$data['db_port']}\nDB_DATABASE={$dbNameEnv}\nDB_USERNAME={$dbUserEnv}\nDB_PASSWORD={$dbPasswordEnv}\nSESSION_DRIVER=file\nSESSION_LIFETIME=120\nSESSION_ENCRYPT=true\nSESSION_SECURE_COOKIE=true\nCACHE_STORE=file\nQUEUE_CONNECTION=sync\n";
  $envPath=base_path('.env'); if(!is_writable(dirname($envPath)) || file_exists($envPath)&&!is_writable($envPath)) return back()->withErrors(['setup'=>'Application directory is not writable.'])->withInput($request->except('admin_password','db_password'));
  try {
   config(['database.connections.mysql.host'=>$data['db_host'],'database.connections.mysql.port'=>$data['db_port'],'database.connections.mysql.database'=>$data['db_name'],'database.connections.mysql.username'=>$data['db_user'],'database.connections.mysql.password'=>$data['db_password']??'']); DB::purge('mysql'); DB::connection()->getPdo();
   $status=Artisan::call('migrate',['--force'=>true]); if($status!==0) throw new \RuntimeException('Database migrations did not complete.');
   if(file_put_contents($envPath,$env,LOCK_EX)===false) throw new \RuntimeException('Could not save configuration.');
   User::create(['name'=>$data['admin_name'],'email'=>$data['admin_email'],'password'=>Hash::make($data['admin_password']),'role'=>'admin']);
   if(file_put_contents(storage_path('app/installed.lock'),now()->toIso8601String(),LOCK_EX)===false) throw new \RuntimeException('Could not lock installer.'); @unlink($tokenPath);
  } catch(\Throwable $e){ report($e); return back()->withErrors(['setup'=>'Setup failed. Confirm database credentials and that the database exists, then retry.'])->withInput($request->except('admin_password','db_password')); }
  return redirect()->route('login')->with('status','Installation complete. Sign in with your administrator account.');
 }
}
