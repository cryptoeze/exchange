<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    public function page()
    {
        return inertia('Notifications');
    }

    public function index(Request $request): JsonResponse
    {
        $uid = $request->user()->id;
        $rows = DB::table('user_notifications')->where('user_id', $uid)->orderByDesc('id')->limit(60)->get();

        return response()->json([
            'unread' => DB::table('user_notifications')->where('user_id', $uid)->whereNull('read_at')->count(),
            'items' => $rows->map(fn ($n) => ['id' => $n->id, 'type' => $n->type, 'title' => $n->title, 'body' => $n->body, 'url' => $n->url, 'read' => $n->read_at !== null, 'at' => \Illuminate\Support\Carbon::parse($n->created_at)->toIso8601String()])->values(),
        ]);
    }

    public function read(Request $request): JsonResponse
    {
        $uid = $request->user()->id;
        $q = DB::table('user_notifications')->where('user_id', $uid)->whereNull('read_at');
        if ($request->filled('id')) {
            $q->where('id', (int) $request->input('id'));
        }
        $q->update(['read_at' => now()]);

        return response()->json(['ok' => true]);
    }
}
