<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Services\DepositService;
use App\Services\NowPaymentsClient;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

final class DepositController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $rows = Deposit::query()->where('user_id', $request->user()->id)->orderByDesc('id')->limit(100)->get()->map(fn ($d) => $this->present($d))->values();

        return response()->json(['deposits' => $rows])->header('Cache-Control', 'no-store');
    }

    public function store(Request $request, DepositService $deposits): JsonResponse
    {
        $data = $request->validate(['currency' => ['required', 'string', 'regex:/^[a-z0-9]{2,24}$/']]);
        try {
            $deposit = $deposits->create($request->user(), $data['currency']);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], $e->getMessage() === 'Deposits are not available right now.' ? 503 : 422);
        } catch (Throwable $e) {
            report($e);

            return response()->json(['message' => 'Could not create a deposit address. Please try again.'], 502);
        }

        return response()->json(['deposit' => $this->present($deposit)], 201);
    }

    /** Poll a deposit; re-checks the provider so the status updates even if the webhook is delayed. */
    public function show(Request $request, string $orderId, DepositService $deposits): JsonResponse
    {
        $deposit = Deposit::query()->where('user_id', $request->user()->id)->where('order_id', $orderId)->firstOrFail();
        try {
            $deposit = $deposits->sync($deposit);
        } catch (Throwable $e) {
            Log::warning('Deposit status refresh failed.', ['deposit' => $deposit->id]);
        }

        return response()->json(['deposit' => $this->present($deposit)])->header('Cache-Control', 'no-store');
    }

    /** Provider webhook. Signature is verified, then the payment is re-read from the provider before crediting. */
    public function webhook(Request $request, NowPaymentsClient $client, DepositService $deposits): JsonResponse
    {
        $payload = $request->json()->all();
        if (! $client->validSignature($payload, $request->header('x-nowpayments-sig'))) {
            return response()->json(['ok' => false], 401);
        }
        $deposit = Deposit::query()->where('provider_payment_id', (string) ($payload['payment_id'] ?? ''))->first();
        if ($deposit) {
            try {
                $deposits->sync($deposit);
            } catch (Throwable $e) {
                report($e);

                return response()->json(['ok' => false], 500); // provider will retry
            }
        }

        return response()->json(['ok' => true]);
    }

    /** @return array<string,mixed> */
    private function present(Deposit $d): array
    {
        return ['id' => $d->id, 'orderId' => $d->order_id, 'asset' => $d->asset, 'network' => $d->network, 'address' => $d->pay_address, 'memo' => $d->pay_extra_id,
            'status' => $d->status, 'expected' => $d->expected_amount, 'paid' => $d->paid_amount, 'txHash' => $d->tx_hash,
            'credited' => $d->credited_at !== null ? Money::format((int) $d->credited_units, 2) : null, 'at' => $d->created_at?->toIso8601String()];
    }
}
