<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\NotificationService;
use App\Services\SettingsService;
use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** Admin: settings, KYC review, broadcasts, audit log, referrals, freeze/unfreeze. */
class AdminOpsController extends Controller
{
    private function admin(Request $r): array
    {
        return ['name' => $r->user('admin')->name, 'email' => $r->user('admin')->email];
    }

    private function audit(Request $r, string $action, ?int $userId = null, array $details = []): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $r->user('admin')->id, 'action' => $action, 'target_user_id' => $userId, 'details' => json_encode($details), 'ip' => $r->ip(), 'created_at' => now()]);
    }

    public function settings(Request $r, SettingsService $s)
    {
        $fields = collect(SettingsService::FIELDS)->map(fn ($f, $k) => ['key' => $k, 'type' => $f[1], 'label' => $f[2], 'hint' => $f[3]])->values();

        return inertia('Admin/Settings', ['admin' => $this->admin($r), 'fields' => $fields, 'values' => $s->current()]);
    }

    public function saveSettings(Request $r, SettingsService $s)
    {
        $rules = [];
        foreach (SettingsService::FIELDS as $k => [, $type]) {
            $rules[$k] = match ($type) {
                'bool' => 'nullable|boolean',
                'float' => 'nullable|numeric|min:0|max:1000000',
                'amounts' => ['nullable', 'regex:/^\s*\d+(\.\d+)?(\s*,\s*\d+(\.\d+)?){6}\s*$/'],
            };
        }
        $d = $r->validate($rules, ['rewards_amounts.regex' => 'Enter exactly 7 comma-separated amounts.']);
        foreach (SettingsService::FIELDS as $k => [, $type]) {
            if ($type === 'bool') {
                $d[$k] = (bool) ($d[$k] ?? false);
            }
        }
        if (($d['bonus_percent'] ?? 0) > 100 || ($d['referral_percent'] ?? 0) > 100) {
            return back()->withErrors(['settings' => 'Percentages cannot exceed 100.']);
        }
        $s->save(array_filter($d, fn ($v) => $v !== null));
        $this->audit($r, 'settings.save', null, $d);

        return back()->with('status', 'Settings saved.');
    }

    public function kyc(Request $r)
    {
        $status = in_array($r->query('status'), ['pending', 'approved', 'rejected'], true) ? $r->query('status') : 'pending';
        $rows = DB::table('kyc_submissions')->where('status', $status)->orderByDesc('id')->limit(100)->get();
        $emails = User::query()->whereIn('id', $rows->pluck('user_id'))->pluck('email', 'id');

        return inertia('Admin/Kyc', ['admin' => $this->admin($r), 'status' => $status, 'pending' => DB::table('kyc_submissions')->where('status', 'pending')->count(),
            'rows' => $rows->map(fn ($k) => ['id' => $k->id, 'userId' => $k->user_id, 'user' => $emails[$k->user_id] ?? '#'.$k->user_id, 'name' => $k->full_name, 'country' => $k->country, 'docType' => $k->doc_type, 'docNumber' => $k->doc_number, 'status' => $k->status, 'reason' => $k->reason, 'at' => $k->created_at])->values()]);
    }

    public function kycFile(int $id, string $which)
    {
        abort_unless(in_array($which, ['front', 'selfie'], true), 404);
        $row = DB::table('kyc_submissions')->find($id);
        abort_unless($row && Storage::disk('local')->exists($row->{$which.'_path'}), 404);

        return Storage::disk('local')->response($row->{$which.'_path'});
    }

    public function kycReview(Request $r, int $id)
    {
        $d = $r->validate(['decision' => 'required|in:approve,reject', 'reason' => 'nullable|string|max:255']);
        $row = DB::table('kyc_submissions')->where('id', $id)->where('status', 'pending')->first();
        if (! $row) {
            return back()->withErrors(['kyc' => 'This submission was already reviewed.']);
        }
        $ok = $d['decision'] === 'approve';
        DB::transaction(function () use ($r, $row, $ok, $d): void {
            DB::table('kyc_submissions')->where('id', $row->id)->update(['status' => $ok ? 'approved' : 'rejected', 'reason' => $ok ? null : ($d['reason'] ?? 'Documents were not clear'), 'reviewed_by' => $r->user('admin')->id, 'reviewed_at' => now(), 'updated_at' => now()]);
            DB::table('users')->where('id', $row->user_id)->update(['kyc_status' => $ok ? 'approved' : 'rejected']);
        });
        NotificationService::send($row->user_id, $ok ? 'Identity verified' : 'Verification rejected', $ok ? 'Your identity verification was approved.' : 'Reason: '.($d['reason'] ?? 'Documents were not clear').'. You can submit again.', $ok ? 'success' : 'warn', '/kyc');
        $this->audit($r, 'kyc.'.$d['decision'], $row->user_id, ['submission' => $id, 'reason' => $d['reason'] ?? null]);

        return back()->with('status', 'KYC #'.$id.($ok ? ' approved.' : ' rejected.'));
    }

    public function notifications(Request $r)
    {
        $recent = DB::table('user_notifications')->where('type', 'broadcast')->selectRaw('title, body, created_at, count(*) as total')->groupBy('title', 'body', 'created_at')->orderByDesc('created_at')->limit(20)->get();

        return inertia('Admin/Notifications', ['admin' => $this->admin($r), 'recent' => $recent, 'users' => User::count()]);
    }

    public function broadcast(Request $r)
    {
        $d = $r->validate(['title' => 'required|string|max:140', 'body' => 'nullable|string|max:1000', 'email' => 'nullable|email']);
        $now = now();
        if (! empty($d['email'])) {
            $uid = User::where('email', $d['email'])->value('id');
            if (! $uid) {
                return back()->withErrors(['email' => 'No user with that email.']);
            }
            DB::table('user_notifications')->insert(['user_id' => $uid, 'type' => 'broadcast', 'title' => $d['title'], 'body' => $d['body'] ?? null, 'created_at' => $now]);
            $count = 1;
        } else {
            $count = 0;
            User::query()->select('id')->chunkById(500, function ($users) use ($d, $now, &$count): void {
                DB::table('user_notifications')->insert($users->map(fn ($u) => ['user_id' => $u->id, 'type' => 'broadcast', 'title' => $d['title'], 'body' => $d['body'] ?? null, 'created_at' => $now])->all());
                $count += $users->count();
            });
        }
        $this->audit($r, 'notification.broadcast', null, ['title' => $d['title'], 'recipients' => $count]);

        return back()->with('status', "Sent to {$count} user(s).");
    }

    public function audit_log(Request $r)
    {
        $rows = DB::table('admin_audit_logs')->orderByDesc('id')->limit(200)->get();
        $admins = DB::table('users')->whereIn('id', $rows->pluck('admin_id'))->pluck('email', 'id');

        return inertia('Admin/Audit', ['admin' => $this->admin($r), 'rows' => $rows->map(fn ($l) => ['id' => $l->id, 'admin' => $admins[$l->admin_id] ?? '#'.$l->admin_id, 'action' => $l->action, 'userId' => $l->target_user_id, 'details' => $l->details, 'ip' => $l->ip, 'at' => (string) $l->created_at])->values()]);
    }

    public function referrals(Request $r)
    {
        $rows = User::query()->whereIn('id', User::query()->whereNotNull('referred_by')->select('referred_by'))->get(['id', 'email', 'referral_code'])->map(function ($u) {
            return ['id' => $u->id, 'email' => $u->email, 'code' => $u->referral_code, 'invited' => User::where('referred_by', $u->id)->count(), 'earned' => Money::format((int) DB::table('referral_rewards')->where('referrer_id', $u->id)->sum('amount'), 4)];
        })->sortByDesc('invited')->values();

        return inertia('Admin/Referrals', ['admin' => $this->admin($r), 'rows' => $rows, 'percent' => (float) config('referral.percent')]);
    }

    public function userStatus(Request $r, int $user)
    {
        $d = $r->validate(['status' => 'required|in:active,frozen']);
        $u = User::findOrFail($user);
        DB::table('users')->where('id', $u->id)->update(['status' => $d['status']]);
        $this->audit($r, 'user.'.$d['status'], $u->id, []);

        return back()->with('status', 'Account '.($d['status'] === 'frozen' ? 'frozen.' : 'unfrozen.'));
    }
}
