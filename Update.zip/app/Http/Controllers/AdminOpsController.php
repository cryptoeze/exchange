<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\NotificationService;
use App\Services\MarketDataService;
use App\Services\SettingsService;
use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** Admin: settings, KYC review, broadcasts, audit log, referrals, freeze/unfreeze. */
class AdminOpsController extends Controller
{
    use \App\Http\Controllers\Admin\Concerns\AdminHelpers;

    public function settings(Request $r, SettingsService $s)
    {
        $fields = collect(SettingsService::FIELDS)->reject(fn ($f) => $f[4] === '_hidden')->map(fn ($f, $k) => ['key' => $k, 'type' => $f[1], 'label' => $f[2], 'hint' => $f[3], 'group' => $f[4]])->values();

        return inertia('Admin/Settings', ['admin' => $this->adminProps($r), 'fields' => $fields, 'values' => $s->current(), 'logoUrl' => config('app.logo_url')]);
    }

    /** Admin → Settings: replace the site logo shown in the header/brand mark everywhere. */
    public function uploadLogo(Request $r, SettingsService $s)
    {
        $r->validate(['logo' => 'required|image|mimes:png,jpg,jpeg,webp,svg|max:1024']);
        $old = trim((string) ($s->stored()['site_logo'] ?? ''));
        $path = $r->file('logo')->store('branding', 'public');
        DB::table('settings')->updateOrInsert(['key' => 'site_logo'], ['value' => $path, 'updated_at' => now()]);
        if ($old !== '' && Storage::disk('public')->exists($old)) {
            Storage::disk('public')->delete($old);
        }
        $s->apply();
        $this->audit($r, 'settings.logo', null, ['path' => $path]);

        return back()->with('status', 'Logo updated.');
    }

    /** Admin → Settings: remove the custom logo and fall back to the built-in RushX mark. */
    public function removeLogo(Request $r, SettingsService $s)
    {
        $old = trim((string) ($s->stored()['site_logo'] ?? ''));
        if ($old !== '' && Storage::disk('public')->exists($old)) {
            Storage::disk('public')->delete($old);
        }
        DB::table('settings')->where('key', 'site_logo')->delete();
        $s->apply();
        $this->audit($r, 'settings.logo_remove', null, []);

        return back()->with('status', 'Logo reset to default.');
    }

    public function saveSettings(Request $r, SettingsService $s)
    {
        $rules = [];
        foreach (SettingsService::FIELDS as $k => [, $type]) {
            $rules[$k] = match ($type) {
                'bool' => 'nullable|boolean',
                'float' => 'nullable|numeric|min:0|max:1000000',
                'int' => 'nullable|integer|min:1|max:1000',
                'rate' => 'nullable|numeric|min:0|max:20',
                'amounts' => ['nullable', 'regex:/^\s*\d+(\.\d+)?(\s*,\s*\d+(\.\d+)?){6}\s*$/'],
                'text', 'secret' => 'nullable|string|max:190',
                'list' => 'nullable|string',
            };
        }
        $d = $r->validate($rules, ['rewards_amounts.regex' => 'Enter exactly 7 comma-separated amounts.']);
        foreach (SettingsService::FIELDS as $k => [, $type]) {
            if ($type === 'bool') {
                $d[$k] = (bool) ($d[$k] ?? false);
            }
        }
        if (($d['bonus_percent'] ?? 0) > 100 || ($d['referral_percent'] ?? 0) > 100) {
            return back()->withErrors(['settings' => 'Percentages cannot exceed 100.']);
        }
        $s->save(array_filter($d, fn ($v) => $v !== null));
        $this->audit($r, 'settings.save', null, array_diff_key($d, ['smtp_pass' => 1]));

        return back()->with('status', 'Settings saved.');
    }

    /** Admin → Markets: pause or resume trading per pair. */
    public function pairs(Request $r, MarketDataService $m)
    {
        $off = (array) config('trading.disabled_pairs', []);
        try {
            $snap = $m->snapshot('both');
        } catch (\Throwable) {
            $snap = ['markets' => []];
        }
        $rows = collect($snap['markets'] ?? [])->groupBy('symbol')->map(function ($g, $sym) use ($off) {
            $f = $g->first();

            return ['symbol' => (string) $sym, 'base' => (string) ($f['baseAsset'] ?? ''), 'spot' => $g->contains('marketType', 'spot'), 'futures' => $g->contains('marketType', 'futures'), 'price' => (float) ($f['lastPrice'] ?? 0), 'paused' => in_array($sym, $off, true)];
        })->sortBy('symbol')->values();

        return inertia('Admin/Pairs', ['admin' => $this->adminProps($r), 'rows' => $rows, 'paused' => $off]);
    }

    public function savePairs(Request $r, SettingsService $s)
    {
        $d = $r->validate(['paused' => 'array|max:2000', 'paused.*' => ['string', 'regex:/^[A-Z0-9]{2,24}$/']]);
        $s->savePairs($d['paused'] ?? []);
        $this->audit($r, 'pairs.save', null, ['paused' => $d['paused'] ?? []]);

        return back()->with('status', 'Markets updated.');
    }

    /** Admin → Orders: every resting limit / take-profit / stop-loss order. */
    public function orders(Request $r)
    {
        $status = $this->pick($r, 'status', ['open', 'filled', 'cancelled']) ?: 'open';
        $kind = $this->pick($r, 'kind', ['limit', 'tp', 'sl']);
        $side = $this->pick($r, 'side', ['buy', 'sell']);
        $q = trim((string) $r->query('q', ''));
        $symbol = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $r->query('symbol', '')));
        $query = DB::table('spot_limit_orders as o')->join('users as u', 'u.id', '=', 'o.user_id')->select(['o.*', 'u.email', 'u.name'])->where('o.status', $status)->orderByDesc('o.id');
        $kind && $query->where('o.kind', $kind);
        $side && $query->where('o.side', $side);
        $symbol && $query->where('o.symbol', 'like', $symbol.'%');
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($w) => $w->where('u.email', 'like', $this->like($q))->orWhere('u.name', 'like', $this->like($q))->orWhere('u.id', $digits));
        }
        $this->dateRange($query, $r, 'o.created_at');
        [$items, $pager] = $this->paged($query, $r, 25);
        $c = fn (string $st) => DB::table('spot_limit_orders')->where('status', $st)->count();

        return inertia('Admin/Orders', ['admin' => $this->adminProps($r), 'status' => $status, 'pager' => $pager,
            'filters' => ['q' => $q, 'symbol' => $symbol, 'kind' => $kind, 'side' => $side, 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))],
            'counts' => ['open' => $c('open'), 'filled' => $c('filled'), 'cancelled' => $c('cancelled')],
            'rows' => $items->map(fn ($o) => ['id' => $o->id, 'userId' => $o->user_id, 'email' => $o->email, 'name' => $o->name, 'symbol' => $o->symbol, 'side' => $o->side, 'kind' => $o->kind ?? 'limit', 'price' => rtrim(rtrim(number_format((float) $o->limit_price, 10, '.', ''), '0'), '.'), 'qty' => rtrim(rtrim(number_format($o->qty / 1e8, 8, '.', ''), '0'), '.').' '.$o->base_asset, 'at' => substr((string) $o->created_at, 0, 16)])->values()]);
    }

    public function cancelOrder(Request $r, int $id, \App\Services\LimitOrderService $limits)
    {
        try {
            $limits->cancel($r->user('admin'), $id, true);
        } catch (\DomainException $e) {
            return back()->withErrors(['order' => $e->getMessage()]);
        }
        $this->audit($r, 'order.cancel', null, ['order' => $id]);

        return back()->with('status', 'Order #'.$id.' cancelled and funds released.');
    }

    /** Admin edits a user's name / email, or sets a new password. */
    public function updateUser(Request $r, int $user)
    {
        $u = User::query()->findOrFail($user);
        abort_if($u->role === 'admin', 403, 'Admin accounts are managed from Admin team.');
        $d = $r->validate(['name' => 'required|string|max:120', 'email' => ['required', 'email:rfc', 'max:190', \Illuminate\Validation\Rule::unique('users', 'email')->ignore($u->id)], 'password' => 'nullable|string|min:10|max:100']);
        $changes = ['name' => $d['name'], 'email' => strtolower($d['email'])];
        if (! empty($d['password'])) {
            $changes['password'] = $d['password'];
        }
        $before = ['name' => $u->name, 'email' => $u->email];
        $u->forceFill($changes)->save();
        if (! empty($d['password']) && \Illuminate\Support\Facades\Schema::hasTable('sessions')) {
            DB::table('sessions')->where('user_id', $u->id)->delete();
        }
        $this->audit($r, 'user.edit', $u->id, ['before' => $before, 'after' => ['name' => $d['name'], 'email' => $changes['email']], 'password_reset' => ! empty($d['password'])]);

        return back()->with('status', 'User updated.'.(! empty($d['password']) ? ' They were signed out everywhere.' : ''));
    }

    public function kyc(Request $r)
    {
        $status = $this->pick($r, 'status', ['pending', 'approved', 'rejected', 'all']) ?: 'pending';
        $q = trim((string) $r->query('q', ''));
        $query = DB::table('kyc_submissions as k')->join('users as u', 'u.id', '=', 'k.user_id')->select(['k.*', 'u.email', 'u.name as account_name'])->orderByDesc('k.id');
        $status !== 'all' && $query->where('k.status', $status);
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($w) => $w->where('u.email', 'like', $this->like($q))->orWhere('k.full_name', 'like', $this->like($q))->orWhere('k.doc_number', 'like', $this->like($q))->orWhere('k.phone', 'like', $this->like($q))->orWhere('u.id', $digits));
        }
        $this->dateRange($query, $r, 'k.created_at');
        [$items, $pager] = $this->paged($query, $r, 15);
        $count = fn (string $st) => DB::table('kyc_submissions')->where('status', $st)->count();

        return inertia('Admin/Kyc', ['admin' => $this->adminProps($r), 'status' => $status, 'pager' => $pager, 'filters' => ['q' => $q, 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))],
            'counts' => ['pending' => $count('pending'), 'approved' => $count('approved'), 'rejected' => $count('rejected')],
            'rows' => $items->map(fn ($k) => ['id' => $k->id, 'userId' => $k->user_id, 'email' => $k->email, 'account' => $k->account_name, 'name' => $k->full_name, 'country' => $k->country, 'phone' => $k->phone, 'hasBack' => (bool) $k->back_path, 'docType' => $k->doc_type, 'docNumber' => $k->doc_number, 'status' => $k->status, 'reason' => $k->reason, 'at' => substr((string) $k->created_at, 0, 16)])->values()]);
    }

    public function kycFile(int $id, string $which)
    {
        abort_unless(in_array($which, ['front', 'back', 'selfie'], true), 404);
        $row = DB::table('kyc_submissions')->find($id);
        abort_unless($row && $row->{$which.'_path'} && Storage::disk('local')->exists($row->{$which.'_path'}), 404);

        return Storage::disk('local')->response($row->{$which.'_path'});
    }

    public function kycReview(Request $r, int $id)
    {
        $d = $r->validate(['decision' => 'required|in:approve,reject', 'reason' => 'nullable|string|max:255']);
        $row = DB::table('kyc_submissions')->where('id', $id)->where('status', 'pending')->first();
        if (! $row) {
            return back()->withErrors(['kyc' => 'This submission was already reviewed.']);
        }
        $ok = $d['decision'] === 'approve';
        DB::transaction(function () use ($r, $row, $ok, $d): void {
            DB::table('kyc_submissions')->where('id', $row->id)->update(['status' => $ok ? 'approved' : 'rejected', 'reason' => $ok ? null : ($d['reason'] ?? 'Documents were not clear'), 'reviewed_by' => $r->user('admin')->id, 'reviewed_at' => now(), 'updated_at' => now()]);
            DB::table('users')->where('id', $row->user_id)->update(['kyc_status' => $ok ? 'approved' : 'rejected']);
        });
        NotificationService::event($row->user_id, $ok ? 'kyc_approved' : 'kyc_rejected', ['reason' => $d['reason'] ?? 'Documents were not clear']);
        $this->audit($r, 'kyc.'.$d['decision'], $row->user_id, ['submission' => $id, 'reason' => $d['reason'] ?? null]);

        return back()->with('status', 'KYC #'.$id.($ok ? ' approved.' : ' rejected.'));
    }

    public function notifications(Request $r)
    {
        $recent = DB::table('user_notifications')->where('type', 'broadcast')->selectRaw('title, body, created_at, count(*) as total')->groupBy('title', 'body', 'created_at')->orderByDesc('created_at')->limit(20)->get();

        return inertia('Admin/Notifications', ['admin' => $this->adminProps($r), 'recent' => $recent, 'users' => User::count()]);
    }

    public function broadcast(Request $r)
    {
        $d = $r->validate(['title' => 'required|string|max:140', 'body' => 'nullable|string|max:1000', 'email' => 'nullable|email']);
        $now = now();
        if (! empty($d['email'])) {
            $uid = User::where('email', $d['email'])->value('id');
            if (! $uid) {
                return back()->withErrors(['email' => 'No user with that email.']);
            }
            DB::table('user_notifications')->insert(['user_id' => $uid, 'type' => 'broadcast', 'title' => $d['title'], 'body' => $d['body'] ?? null, 'created_at' => $now]);
            $count = 1;
        } else {
            $count = 0;
            User::query()->select('id')->chunkById(500, function ($users) use ($d, $now, &$count): void {
                DB::table('user_notifications')->insert($users->map(fn ($u) => ['user_id' => $u->id, 'type' => 'broadcast', 'title' => $d['title'], 'body' => $d['body'] ?? null, 'created_at' => $now])->all());
                $count += $users->count();
            });
        }
        $this->audit($r, 'notification.broadcast', null, ['title' => $d['title'], 'recipients' => $count]);

        return back()->with('status', "Sent to {$count} user(s).");
    }

    public function audit_log(Request $r)
    {
        $q = trim((string) $r->query('q', ''));
        $action = preg_replace('/[^a-z0-9_.]/', '', strtolower((string) $r->query('action', '')));
        $query = DB::table('admin_audit_logs as l')->leftJoin('users as a', 'a.id', '=', 'l.admin_id')->leftJoin('users as t', 't.id', '=', 'l.target_user_id')->select(['l.*', 'a.email as admin_email', 't.email as target_email'])->orderByDesc('l.id');
        if ($q !== '') {
            $query->where(fn ($w) => $w->where('a.email', 'like', $this->like($q))->orWhere('t.email', 'like', $this->like($q))->orWhere('l.details', 'like', $this->like($q))->orWhere('l.ip', $q));
        }
        $action && $query->where('l.action', 'like', $action.'%');
        $this->dateRange($query, $r, 'l.created_at');
        [$items, $pager] = $this->paged($query, $r, 40);

        return inertia('Admin/Audit', ['admin' => $this->adminProps($r), 'pager' => $pager, 'filters' => ['q' => $q, 'action' => $action, 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))],
            'actions' => DB::table('admin_audit_logs')->distinct()->orderBy('action')->pluck('action')->map(fn ($x) => explode('.', explode('_', $x)[0])[0])->unique()->values(),
            'rows' => $items->map(fn ($l) => ['id' => $l->id, 'admin' => $l->admin_email ?? '#'.$l->admin_id, 'action' => $l->action, 'userId' => $l->target_user_id, 'target' => $l->target_email, 'details' => $l->details, 'ip' => $l->ip, 'at' => substr((string) $l->created_at, 0, 19)])->values()]);
    }

    public function referrals(Request $r)
    {
        $q = trim((string) $r->query('q', ''));
        $query = User::query()->whereIn('id', User::query()->whereNotNull('referred_by')->select('referred_by'))->select(['id', 'name', 'email', 'referral_code'])
            ->selectSub(DB::table('users as f')->selectRaw('COUNT(*)')->whereColumn('f.referred_by', 'users.id'), 'invited')
            ->selectSub(DB::table('referral_rewards')->selectRaw('COALESCE(SUM(amount),0)')->whereColumn('referrer_id', 'users.id'), 'earned_units')
            ->orderByDesc('invited')->orderBy('id');
        if ($q !== '') {
            $query->where(fn ($w) => $w->where('email', 'like', $this->like($q))->orWhere('name', 'like', $this->like($q))->orWhere('referral_code', strtoupper($q)));
        }
        [$items, $pager] = $this->paged($query, $r, 25);

        return inertia('Admin/Referrals', ['admin' => $this->adminProps($r), 'percent' => (float) config('referral.percent'), 'pager' => $pager, 'filters' => ['q' => $q],
            'stats' => ['referrers' => User::query()->whereIn('id', User::query()->whereNotNull('referred_by')->select('referred_by'))->count(), 'referred' => User::query()->whereNotNull('referred_by')->count(), 'paid' => Money::format((int) DB::table('referral_rewards')->sum('amount'), 2)],
            'rows' => $items->map(fn ($u) => ['id' => $u->id, 'name' => $u->name, 'email' => $u->email, 'code' => $u->referral_code, 'invited' => (int) $u->invited, 'earned' => Money::format((int) $u->earned_units, 4)])->values()]);
    }

    public function userStatus(Request $r, int $user)
    {
        $d = $r->validate(['status' => 'required|in:active,frozen']);
        $u = User::findOrFail($user);
        DB::table('users')->where('id', $u->id)->update(['status' => $d['status']]);
        $this->audit($r, 'user.'.$d['status'], $u->id, []);

        return back()->with('status', 'Account '.($d['status'] === 'frozen' ? 'frozen.' : 'unfrozen.'));
    }

    public function gateways(Request $r)
    {
        $np = (array) config('services.nowpayments');
        $d30 = now()->subDays(30);

        return inertia('Admin/Gateways', ['admin' => $this->adminProps($r),
            'switches' => ['auto_deposit' => (bool) config('gateways.auto_deposit'), 'manual_deposit' => (bool) config('gateways.manual_deposit'), 'withdraw_enabled' => (bool) config('withdraw.enabled'), 'kyc_required' => (bool) config('kyc.required_for_withdrawal')],
            'nowpayments' => ['apiKey' => (string) ($np['api_key'] ?? '') !== '', 'ipnSecret' => (string) ($np['ipn_secret'] ?? '') !== '', 'sandbox' => str_contains((string) ($np['base_url'] ?? ''), 'sandbox'), 'ipnUrl' => url('/api/webhooks/nowpayments')],
            'stats' => ['autoDeposits30d' => DB::table('deposits')->where('created_at', '>=', $d30)->count(), 'autoCredited30d' => DB::table('deposits')->where('credited_at', '>=', $d30)->where('credited_units', '>', 0)->count(),
                'manualPending' => DB::table('manual_deposits')->where('status', 'pending')->count(), 'manualAddresses' => DB::table('manual_deposit_addresses')->where('enabled', 1)->where('address', '!=', '')->count(),
                'withdrawPending' => DB::table('withdrawals')->where('status', 'pending')->count(), 'withdrawDone30d' => DB::table('withdrawals')->where('status', 'completed')->where('created_at', '>=', $d30)->count()],
            'tab' => $this->pick($r, 'tab', ['overview', 'deposit-auto', 'deposit-manual', 'withdraw']) ?: 'overview',
            'depositCoins' => collect((array) config('deposit-coins.coins_all', config('deposit-coins.coins')))->flatMap(fn ($c) => collect($c['networks'])->map(fn ($n) => ['ticker' => $c['ticker'], 'coin' => $c['name'], 'code' => $n['code'], 'network' => $n['name'], 'off' => in_array($n['code'], (array) config('deposit-coins.off', []), true)]))->values(),
            'addresses' => \App\Models\ManualDepositAddress::query()->orderBy('sort')->orderBy('id')->get()->map(fn ($a) => ['id' => $a->id, 'asset' => $a->asset, 'network' => $a->network, 'label' => $a->label, 'address' => $a->address, 'min' => rtrim(rtrim(Money::format((int) $a->min_units, 8), '0'), '.'), 'note' => $a->note, 'enabled' => (bool) $a->enabled])->values(),
            'networks' => collect((array) config('withdraw.assets_all', config('withdraw.assets')))->flatMap(fn ($a) => collect($a['networks'])->map(fn ($n) => ['ticker' => $a['ticker'], 'code' => $n['code'], 'label' => $n['label'], 'min' => $a['min'], 'fee' => $n['fee'], 'off' => ! empty($n['off'])]))->values()]);
    }

    public function saveGateways(Request $r, SettingsService $s)
    {
        $d = $r->validate(['switches' => 'required|array', 'switches.*' => 'boolean', 'depositOff' => 'nullable|array', 'depositOff.*' => ['string', 'regex:/^[a-z0-9]{2,24}$/'], 'networks' => 'nullable|array', 'networks.*.ticker' => 'required|string|max:12', 'networks.*.code' => 'required|string|max:12', 'networks.*.min' => 'required|numeric|min:0', 'networks.*.fee' => 'required|numeric|min:0', 'networks.*.off' => 'nullable|boolean']);
        $map = ['auto_deposit' => 'auto_deposit', 'manual_deposit' => 'manual_deposit', 'withdraw_enabled' => 'withdraw_enabled', 'kyc_required' => 'kyc_required'];
        $s->save(collect($map)->mapWithKeys(fn ($k, $f) => [$k => (bool) ($d['switches'][$f] ?? false)])->all());
        $s->saveWithdrawNetworks($d['networks'] ?? []);
        if (array_key_exists('depositOff', $d) || $r->has('depositOff')) {
            $s->saveDepositOff($d['depositOff'] ?? []);
        }
        $this->audit($r, 'gateways.save', null, ['switches' => $d['switches'], 'networks' => count($d['networks'] ?? []), 'deposit_off' => $d['depositOff'] ?? null]);

        return back()->with('status', 'Gateway settings saved.');
    }

    public function emailTemplates(Request $r, \App\Services\MailService $mail)
    {
        $events = collect(array_keys(config('mail-templates.events')))->map(function ($k) use ($mail) {
            $t = $mail->template($k);

            return ['key' => $k, 'label' => $t['label'], 'vars' => $t['vars'], 'subject' => $t['subject'], 'heading' => $t['heading'], 'body' => $t['body'], 'enabled' => $t['enabled']];
        })->values();

        return inertia('Admin/EmailTemplates', ['admin' => $this->adminProps($r), 'events' => $events, 'master' => (bool) config('mail-templates.enabled'), 'mailer' => (string) config('mail.default'), 'from' => (string) config('mail.from.address')]);
    }

    public function saveEmailTemplate(Request $r, string $event)
    {
        abort_unless(config("mail-templates.events.$event"), 404);
        $d = $r->validate(['subject' => 'required|string|max:160', 'heading' => 'required|string|max:160', 'body' => 'required|string|max:3000', 'enabled' => 'required|boolean']);
        DB::table('settings')->updateOrInsert(['key' => "mailtpl.$event"], ['value' => json_encode($d), 'updated_at' => now()]);
        $this->audit($r, 'email_template.save', null, ['event' => $event, 'enabled' => $d['enabled']]);

        return back()->with('status', 'Template saved.');
    }

    public function testEmail(Request $r, string $event, \App\Services\MailService $mail)
    {
        abort_unless(config("mail-templates.events.$event"), 404);
        $t = $mail->template($event);
        $sample = ['name' => 'Alex', 'amount' => '125.00', 'asset' => 'USDT', 'network' => 'TRC20', 'address' => 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE', 'txid' => '0xabc123…', 'reason' => 'Example reason', 'symbol' => 'BTCUSDT', 'side' => 'LONG', 'leverage' => 10, 'price' => '83,100.0', 'liq_price' => '75,500.0', 'left_pct' => '22', 'margin' => '100.00', 'pnl' => '+12.40'];
        $ok = $mail->send($r->user('admin')->email, $event, $sample);

        return $ok ? back()->with('status', 'Test email sent to '.$r->user('admin')->email.'.') : back()->withErrors(['mail' => 'Could not send. Check MAIL_* settings in .env (and that this template is switched on).']);
    }

    /** Admin bell: unread admin events (new users, KYC, withdrawals, deposits, disputes…). */
    public function bell(Request $r)
    {
        $uid = $r->user('admin')->id;
        $q = DB::table('user_notifications')->where('user_id', $uid)->where('type', 'admin');

        return response()->json([
            'unread' => (clone $q)->whereNull('read_at')->count(),
            'items' => (clone $q)->orderByDesc('id')->limit(25)->get()->map(fn ($n) => ['id' => $n->id, 'title' => $n->title, 'body' => $n->body, 'url' => $n->url, 'read' => $n->read_at !== null, 'at' => \Illuminate\Support\Carbon::parse($n->created_at)->toIso8601String()])->values(),
            'queues' => ['withdrawals' => DB::table('withdrawals')->where('status', 'pending')->count(), 'deposits' => DB::table('manual_deposits')->where('status', 'pending')->count(), 'kyc' => DB::table('kyc_submissions')->where('status', 'pending')->count()],
        ]);
    }

    public function bellRead(Request $r)
    {
        $q = DB::table('user_notifications')->where('user_id', $r->user('admin')->id)->where('type', 'admin')->whereNull('read_at');
        if ($r->filled('id')) {
            $q->where('id', (int) $r->input('id'));
        }
        $q->update(['read_at' => now()]);

        return response()->json(['ok' => true]);
    }
}
