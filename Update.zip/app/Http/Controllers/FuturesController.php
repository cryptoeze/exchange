<?php

namespace App\Http\Controllers;

use App\Models\FuturesPosition;
use App\Services\FuturesService;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class FuturesController extends Controller
{
    public function __construct(private readonly FuturesService $futures, private readonly LedgerService $ledger)
    {
    }

    public function state(Request $request): JsonResponse
    {
        $this->futures->sweep($request->user()->id);

        return response()->json($this->payload($request->user()->id))->header('Cache-Control', 'no-store');
    }

    public function open(Request $request): JsonResponse
    {
        $d = $request->validate([
            'symbol' => ['required', 'string', 'regex:/^[A-Z0-9]{2,20}USDT$/'], 'side' => 'required|in:long,short',
            'margin' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'leverage' => 'required|integer|min:1|max:1000',
            'tp' => 'nullable|numeric|gt:0', 'sl' => 'nullable|numeric|gt:0', 'idempotency_key' => 'nullable|string|max:64',
        ]);

        return $this->run($request, fn () => $this->futures->open($request->user(), $d['symbol'], $d['side'], Money::toUnits($d['margin']), (int) $d['leverage'], isset($d['tp']) ? (float) $d['tp'] : null, isset($d['sl']) ? (float) $d['sl'] : null, $d['idempotency_key'] ?? null), 201);
    }

    public function close(Request $request): JsonResponse
    {
        $d = $request->validate(['position_id' => 'required|integer']);

        return $this->run($request, fn () => $this->futures->close($request->user(), (int) $d['position_id']));
    }

    public function tpsl(Request $request): JsonResponse
    {
        $d = $request->validate(['position_id' => 'required|integer', 'tp' => 'nullable|numeric|gt:0', 'sl' => 'nullable|numeric|gt:0']);

        return $this->run($request, fn () => $this->futures->setTpSl($request->user(), (int) $d['position_id'], isset($d['tp']) ? (float) $d['tp'] : null, isset($d['sl']) ? (float) $d['sl'] : null));
    }

    private function run(Request $request, callable $action, int $status = 200): JsonResponse
    {
        try {
            $action();
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }
        $this->futures->sweep($request->user()->id);

        return response()->json($this->payload($request->user()->id), $status);
    }

    /** @return array<string, mixed> */
    private function payload(int $userId): array
    {
        $prices = [];
        try {
            $prices = $this->futures->priceMap();
        } catch (DomainException) {
        }
        $present = function (FuturesPosition $p) use ($prices) {
            $mark = $prices[$p->symbol] ?? null;
            $pnl = $mark !== null && $p->status === 'open' ? $p->pnlAt($mark) : ($p->pnl ?? 0);

            return [
                'id' => $p->id, 'symbol' => $p->symbol, 'side' => $p->side, 'leverage' => $p->leverage, 'margin' => Money::format((int) $p->margin, 2), 'marginUnits' => (int) $p->margin,
                'entry' => $p->entry(), 'mark' => $mark, 'liq' => $p->liqPrice(), 'tp' => $p->take_profit_micro ? $p->take_profit_micro / Money::SCALE : null,
                'sl' => $p->stop_loss_micro ? $p->stop_loss_micro / Money::SCALE : null, 'pnl' => Money::format((int) $pnl, 2), 'pnlUnits' => (int) $pnl,
                'roe' => $p->margin > 0 ? round($pnl / $p->margin * 100, 2) : 0, 'status' => $p->status, 'close' => $p->close_micro ? $p->close_micro / Money::SCALE : null,
                'reason' => $p->close_reason, 'net' => Money::format($p->status === 'closed' ? ($p->close_reason === 'liquidation' ? -(int) $p->margin : max(-(int) $p->margin, (int) $p->pnl - (int) $p->fee_close)) - (int) $p->fee_open : 0, 2), 'feeOpen' => Money::format((int) $p->fee_open, 4), 'feeClose' => Money::format((int) $p->fee_close, 4),
                'at' => $p->created_at?->toIso8601String(), 'closedAt' => $p->closed_at?->toIso8601String(),
            ];
        };

        return [
            'trading' => Money::format($this->ledger->balance($userId, 'trading', 'USDT'), 2), 'tradingUnits' => $this->ledger->balance($userId, 'trading', 'USDT'),
            'funding' => Money::format($this->ledger->balance($userId, 'funding', 'USDT'), 2),
            'positions' => FuturesPosition::query()->where(['user_id' => $userId, 'status' => 'open'])->orderByDesc('id')->get()->map($present)->values(),
            'history' => FuturesPosition::query()->where(['user_id' => $userId, 'status' => 'closed'])->orderByDesc('id')->limit(50)->get()->map($present)->values(),
            'config' => ['maxLeverage' => (int) config('trading.futures_max_leverage'), 'feeRate' => (float) config('trading.futures_fee_rate'), 'minMargin' => (float) config('trading.futures_min_margin_usdt'), 'enabled' => (bool) config('trading.futures_enabled')],
        ];
    }
}
