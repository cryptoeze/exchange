<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminTicketController extends Controller
{
    private function audit(Request $r, string $action, int $ticket, int $user): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $r->user('admin')->id, 'action' => $action, 'target_user_id' => $user, 'details' => json_encode(['ticket' => $ticket]), 'ip' => $r->ip(), 'created_at' => now()]);
    }

    public function index(Request $r)
    {
        $status = in_array($r->query('status'), ['open', 'answered', 'closed'], true) ? $r->query('status') : 'open';
        $rows = DB::table('tickets')->where('status', $status)->orderByDesc('updated_at')->limit(100)->get();
        $emails = User::query()->whereIn('id', $rows->pluck('user_id'))->pluck('email', 'id');
        $selected = null;
        $messages = [];
        if ($id = (int) $r->query('id')) {
            $selected = DB::table('tickets')->find($id);
            if ($selected) {
                $messages = DB::table('ticket_messages')->where('ticket_id', $id)->orderBy('id')->get()->map(fn ($m) => ['id' => $m->id, 'staff' => (bool) $m->is_staff, 'body' => $m->body, 'at' => (string) $m->created_at])->all();
                $selected = ['id' => $selected->id, 'subject' => $selected->subject, 'status' => $selected->status, 'category' => $selected->category, 'userId' => $selected->user_id, 'user' => User::query()->whereKey($selected->user_id)->value('email')];
            }
        }

        return inertia('Admin/Tickets', ['admin' => ['name' => $r->user('admin')->name, 'email' => $r->user('admin')->email], 'status' => $status,
            'counts' => ['open' => DB::table('tickets')->where('status', 'open')->count(), 'answered' => DB::table('tickets')->where('status', 'answered')->count(), 'closed' => DB::table('tickets')->where('status', 'closed')->count()],
            'rows' => $rows->map(fn ($t) => ['id' => $t->id, 'subject' => $t->subject, 'category' => $t->category, 'user' => $emails[$t->user_id] ?? '#'.$t->user_id, 'at' => (string) $t->updated_at])->values(), 'selected' => $selected, 'messages' => $messages]);
    }

    public function reply(Request $r, int $id)
    {
        $d = $r->validate(['message' => 'required|string|max:4000']);
        $t = DB::table('tickets')->find($id);
        abort_unless($t, 404);
        DB::table('ticket_messages')->insert(['ticket_id' => $id, 'user_id' => $r->user('admin')->id, 'is_staff' => true, 'body' => $d['message'], 'created_at' => now()]);
        DB::table('tickets')->where('id', $id)->update(['status' => 'answered', 'last_reply_at' => now(), 'updated_at' => now()]);
        NotificationService::event($t->user_id, 'ticket_reply', ['subject' => $t->subject]);
        $this->audit($r, 'ticket.reply', $id, $t->user_id);

        return back()->with('status', 'Reply sent.');
    }

    public function status(Request $r, int $id)
    {
        $d = $r->validate(['status' => 'required|in:open,closed']);
        $t = DB::table('tickets')->find($id);
        abort_unless($t, 404);
        DB::table('tickets')->where('id', $id)->update(['status' => $d['status'], 'updated_at' => now()]);
        $this->audit($r, 'ticket.'.$d['status'], $id, $t->user_id);

        return back()->with('status', 'Ticket '.$d['status'].'.');
    }
}
