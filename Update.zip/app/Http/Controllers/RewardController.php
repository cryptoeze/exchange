<?php

namespace App\Http\Controllers;

use App\Models\DailyCheckin;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/** Daily check-in rewards. */
final class RewardController extends Controller
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function show(Request $request): JsonResponse
    {
        return response()->json($this->state($request->user()->id))->header('Cache-Control', 'no-store');
    }

    public function claim(Request $request): JsonResponse
    {
        $userId = $request->user()->id;
        try {
            if (! config('rewards.enabled')) {
                throw new DomainException('Daily rewards are paused.');
            }
            DB::transaction(function () use ($userId): void {
                $today = Carbon::now('UTC')->toDateString();
                $last = DailyCheckin::query()->where('user_id', $userId)->orderByDesc('day')->lockForUpdate()->first();
                if ($last && $last->day->toDateString() === $today) {
                    throw new DomainException('You have already claimed today.');
                }
                $continues = $last && $last->day->toDateString() === Carbon::now('UTC')->subDay()->toDateString();
                $cycleDay = $continues ? ($last->cycle_day % 7) + 1 : 1;
                $streak = $continues ? $last->streak + 1 : 1;
                $units = Money::toUnits(config('rewards.amounts')[$cycleDay - 1]);
                $row = DailyCheckin::query()->create(['user_id' => $userId, 'day' => $today, 'cycle_day' => $cycleDay, 'streak' => $streak, 'asset' => config('rewards.asset'), 'amount' => $units]);
                $this->ledger->apply($userId, 'funding', config('rewards.asset'), $units, 'daily_reward', ['ref_type' => 'daily_checkin', 'ref_id' => $row->id, 'idempotency_key' => "daily-reward:{$userId}:{$today}", 'note' => "day {$cycleDay}"]);
            }, 3);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        } catch (\Illuminate\Database\UniqueConstraintViolationException) {
            return response()->json(['message' => 'You have already claimed today.'], 422);
        }

        return response()->json($this->state($userId), 201);
    }

    /** @return array<string, mixed> */
    private function state(int $userId): array
    {
        $today = Carbon::now('UTC');
        $last = DailyCheckin::query()->where('user_id', $userId)->orderByDesc('day')->first();
        $claimedToday = $last && $last->day->toDateString() === $today->toDateString();
        $continues = $last && ($claimedToday || $last->day->toDateString() === $today->copy()->subDay()->toDateString());
        $cycleDay = $continues ? $last->cycle_day : 0;                      // last claimed position still "live"
        $nextDay = $claimedToday ? ($cycleDay % 7) + 1 : ($continues ? ($cycleDay % 7) + 1 : 1);
        $claimedUpTo = $continues ? $cycleDay : 0;
        if (! $claimedToday && $continues && $cycleDay === 7) {
            $claimedUpTo = 0; // a finished cycle starts again
        }
        $amounts = config('rewards.amounts');

        return [
            'enabled' => (bool) config('rewards.enabled'), 'asset' => config('rewards.asset'), 'claimedToday' => $claimedToday,
            'nextDay' => $nextDay, 'streak' => $continues ? (int) $last->streak : 0,
            'lifetime' => Money::format((int) DailyCheckin::query()->where('user_id', $userId)->sum('amount'), 2),
            'lastAmount' => $last ? Money::format((int) $last->amount, 2) : null,
            'days' => collect($amounts)->map(fn ($a, $i) => ['day' => $i + 1, 'amount' => number_format($a, 2), 'claimed' => $i + 1 <= $claimedUpTo, 'today' => ! $claimedToday && $i + 1 === $nextDay])->values(),
            'nextReset' => $today->copy()->addDay()->startOfDay()->toIso8601String(),
        ];
    }
}
