<?php

namespace App\Http\Controllers;

use App\Services\NotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TicketController extends Controller
{
    public function page(Request $r)
    {
        return inertia('Tickets');
    }

    /** Guests see the public support page; signed-in users go to their tickets. */
    public function support(Request $r)
    {
        return $r->user() ? redirect('/tickets') : app(PlatformPageController::class)->show($r, 'support');
    }

    public function index(Request $r): JsonResponse
    {
        $rows = DB::table('tickets')->where('user_id', $r->user()->id)->orderByDesc('updated_at')->limit(50)->get();

        return response()->json(['tickets' => $rows->map(fn ($t) => ['id' => $t->id, 'subject' => $t->subject, 'category' => $t->category, 'status' => $t->status, 'at' => (string) $t->updated_at])->values()]);
    }

    public function show(Request $r, int $id): JsonResponse
    {
        $t = DB::table('tickets')->where(['id' => $id, 'user_id' => $r->user()->id])->first();
        abort_unless($t, 404);

        return response()->json(['ticket' => ['id' => $t->id, 'subject' => $t->subject, 'status' => $t->status], 'messages' => DB::table('ticket_messages')->where('ticket_id', $id)->orderBy('id')->get()->map(fn ($m) => ['id' => $m->id, 'staff' => (bool) $m->is_staff, 'body' => $m->body, 'at' => (string) $m->created_at])->values()]);
    }

    public function store(Request $r): JsonResponse
    {
        $d = $r->validate(['subject' => 'required|string|max:140', 'category' => 'required|in:deposit,withdrawal,trading,account,other', 'message' => 'required|string|max:4000']);
        if (DB::table('tickets')->where('user_id', $r->user()->id)->where('status', '!=', 'closed')->count() >= 10) {
            return response()->json(['message' => 'You already have 10 open tickets. Please wait for replies or close one.'], 422);
        }
        $id = DB::transaction(function () use ($r, $d) {
            $id = DB::table('tickets')->insertGetId(['user_id' => $r->user()->id, 'subject' => $d['subject'], 'category' => $d['category'], 'status' => 'open', 'last_reply_at' => now(), 'created_at' => now(), 'updated_at' => now()]);
            DB::table('ticket_messages')->insert(['ticket_id' => $id, 'user_id' => $r->user()->id, 'is_staff' => false, 'body' => $d['message'], 'created_at' => now()]);

            return $id;
        });
        NotificationService::admins('New support ticket', $r->user()->email.' · '.$d['subject'], '/admin/tickets?id='.$id);

        return response()->json(['id' => $id], 201);
    }

    public function reply(Request $r, int $id): JsonResponse
    {
        $d = $r->validate(['message' => 'required|string|max:4000']);
        $t = DB::table('tickets')->where(['id' => $id, 'user_id' => $r->user()->id])->first();
        abort_unless($t, 404);
        if ($t->status === 'closed') {
            return response()->json(['message' => 'This ticket is closed. Open a new one.'], 422);
        }
        DB::table('ticket_messages')->insert(['ticket_id' => $id, 'user_id' => $r->user()->id, 'is_staff' => false, 'body' => $d['message'], 'created_at' => now()]);
        DB::table('tickets')->where('id', $id)->update(['status' => 'open', 'last_reply_at' => now(), 'updated_at' => now()]);
        NotificationService::admins('Ticket reply', $r->user()->email.' · '.$t->subject, '/admin/tickets?id='.$id);

        return $this->show($r, $id);
    }

    public function close(Request $r, int $id): JsonResponse
    {
        DB::table('tickets')->where(['id' => $id, 'user_id' => $r->user()->id])->update(['status' => 'closed', 'updated_at' => now()]);

        return $this->show($r, $id);
    }
}
