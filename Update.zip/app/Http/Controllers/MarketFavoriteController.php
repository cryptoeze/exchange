<?php

namespace App\Http\Controllers;

use App\Services\MarketDataService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class MarketFavoriteController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $favorites = DB::table('user_market_favorites')
            ->where('user_id', $request->user()->id)
            ->orderBy('market_type')->orderBy('symbol')
            ->get(['symbol', 'market_type'])
            ->map(static fn (object $row): array => ['symbol' => $row->symbol, 'marketType' => $row->market_type]);

        return response()->json(['favorites' => $favorites])->header('Cache-Control', 'private, no-store');
    }

    public function store(Request $request, MarketDataService $markets): JsonResponse
    {
        $data = $request->validate([
            'symbol' => ['required', 'string', 'max:32', 'regex:/^[A-Z0-9]{2,32}$/'],
            'marketType' => 'required|in:spot,futures',
        ]);
        $marketType = $data['marketType'];
        $valid = collect($markets->snapshot($marketType)['markets'])
            ->contains(static fn (array $market): bool => $market['symbol'] === $data['symbol']);

        abort_unless($valid, 404, 'This market is not available.');

        DB::table('user_market_favorites')->insertOrIgnore([
            'user_id' => $request->user()->id,
            'symbol' => $data['symbol'],
            'market_type' => $marketType,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['saved' => true], 201)->header('Cache-Control', 'private, no-store');
    }

    public function destroy(Request $request, string $marketType, string $symbol): JsonResponse
    {
        abort_unless(in_array($marketType, ['spot', 'futures'], true)
            && preg_match('/^[A-Z0-9]{2,32}$/', $symbol) === 1, 404);

        DB::table('user_market_favorites')
            ->where('user_id', $request->user()->id)
            ->where('market_type', $marketType)
            ->where('symbol', $symbol)
            ->delete();

        return response()->json(['saved' => false])->header('Cache-Control', 'private, no-store');
    }
}
