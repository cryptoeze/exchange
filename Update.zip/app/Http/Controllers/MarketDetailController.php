<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

final class MarketDetailController extends Controller
{
    public function __invoke(Request $request, string $symbol)
    {
        $symbol = strtoupper($symbol);
        abort_unless(preg_match('/^[A-Z0-9]{2,32}$/', $symbol) === 1, 404);
        $type = $request->query('type', 'spot');
        abort_unless(in_array($type, ['spot', 'futures'], true), 404);

        return inertia('MarketDetail', ['symbol' => $symbol, 'marketType' => $type]);
    }
}
