<?php

namespace App\Http\Controllers;

use App\Models\Withdrawal;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class WithdrawalController extends Controller
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function index(Request $request): JsonResponse
    {
        return response()->json($this->payload($request->user()->id))->header('Cache-Control', 'no-store');
    }

    public function store(Request $request): JsonResponse
    {
        $d = $request->validate([
            'asset' => ['required', 'string', 'regex:/^[A-Z0-9]{2,10}$/'], 'network' => ['required', 'string', 'regex:/^[A-Z0-9]{2,10}$/'],
            'address' => ['required', 'string', 'min:16', 'max:128'], 'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'idempotency_key' => 'nullable|string|max:64',
        ]);
        $user = $request->user();
        try {
            if (! config('withdraw.enabled')) {
                throw new DomainException('Withdrawals are temporarily paused.');
            }
            if (config('kyc.required_for_withdrawal') && ($user->kyc_status ?? 'none') !== 'approved') {
                throw new DomainException('Identity verification is required before withdrawing. Open Profile → Identity verification.');
            }
            if (config('withdraw.require_verified_email') && ! $user->email_verified_at) {
                throw new DomainException('Verify your email address before withdrawing.');
            }
            $asset = collect(config('withdraw.assets'))->firstWhere('ticker', $d['asset']) ?? throw new DomainException('This asset cannot be withdrawn.');
            $net = collect($asset['networks'])->firstWhere('code', $d['network']) ?? throw new DomainException('This network is not supported for the asset.');
            $address = trim($d['address']);
            if (! preg_match((string) config('withdraw.patterns.'.$net['pattern']), $address)) {
                throw new DomainException("That is not a valid {$net['label']} address.");
            }
            $amount = Money::toUnits($d['amount']);
            $fee = Money::toUnits($net['fee']);
            if ($amount < Money::toUnits($asset['min'])) {
                throw new DomainException("Minimum withdrawal is {$asset['min']} {$asset['ticker']}.");
            }
            if ($amount <= $fee) {
                throw new DomainException('The amount must be higher than the network fee.');
            }
            $key = isset($d['idempotency_key']) ? "{$user->id}:wd:{$d['idempotency_key']}" : null;
            DB::transaction(function () use ($user, $asset, $net, $address, $amount, $fee, $key): void {
                if ($key !== null && Withdrawal::query()->where('idempotency_key', $key)->exists()) {
                    return;
                }
                if (Withdrawal::query()->where(['user_id' => $user->id, 'status' => 'pending'])->lockForUpdate()->count() >= (int) config('withdraw.max_pending')) {
                    throw new DomainException('You have too many pending withdrawals. Wait for them to be reviewed.');
                }
                $w = Withdrawal::query()->create(['user_id' => $user->id, 'asset' => $asset['ticker'], 'network' => $net['code'], 'address' => $address, 'amount' => $amount, 'fee' => $fee, 'net' => $amount - $fee, 'status' => 'pending', 'idempotency_key' => $key]);
                $this->ledger->apply($user->id, 'funding', $asset['ticker'], -$amount, 'withdrawal_hold', ['ref_type' => 'withdrawal', 'ref_id' => $w->id]);
                DB::afterCommit(fn () => \App\Services\NotificationService::admins('Withdrawal request', $user->email.' · '.\App\Support\Money::format((int) $amount, 4).' '.$asset['ticker'].' ('.$net['code'].')', '/admin/withdrawals'));
                DB::afterCommit(fn () => \App\Services\NotificationService::event($user->id, 'withdrawal_requested', ['amount' => \App\Support\Money::format((int) $amount, 4), 'asset' => $asset['ticker'], 'network' => $net['code'], 'address' => $address]));
            }, 3);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($user->id), 201);
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        try {
            DB::transaction(function () use ($request, $id): void {
                $w = Withdrawal::query()->where(['id' => $id, 'user_id' => $request->user()->id])->lockForUpdate()->first() ?? throw new DomainException('Withdrawal not found.');
                if ($w->status !== 'pending') {
                    throw new DomainException('Only pending withdrawals can be cancelled.');
                }
                $this->ledger->apply($w->user_id, 'funding', $w->asset, $w->amount, 'withdrawal_refund', ['ref_type' => 'withdrawal', 'ref_id' => $w->id, 'note' => 'cancelled by user']);
                $w->fill(['status' => 'cancelled'])->save();
            }, 3);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($request->user()->id));
    }

    /** @return array<string, mixed> */
    private function payload(int $userId): array
    {
        $balances = [];
        foreach (config('withdraw.assets') as $a) {
            $balances[$a['ticker']] = Money::format($this->ledger->balance($userId, 'funding', $a['ticker']), 8);
        }

        return [
            'enabled' => (bool) config('withdraw.enabled'), 'balances' => $balances,
            'assets' => collect(config('withdraw.assets'))->map(fn ($a) => ['ticker' => $a['ticker'], 'name' => $a['name'], 'logo' => $a['logo'], 'min' => $a['min'], 'networks' => collect($a['networks'])->map(fn ($n) => ['code' => $n['code'], 'label' => $n['label'], 'fee' => $n['fee'], 'arrival' => $n['arrival']])->values()])->values(),
            'rows' => Withdrawal::query()->where('user_id', $userId)->orderByDesc('id')->limit(50)->get()->map(fn ($w) => [
                'id' => $w->id, 'asset' => $w->asset, 'network' => $w->network, 'address' => $w->address, 'amount' => Money::format((int) $w->amount, 4), 'net' => Money::format((int) $w->net, 4),
                'fee' => Money::format((int) $w->fee, 4), 'status' => $w->status, 'txHash' => $w->tx_hash, 'reason' => $w->reason, 'at' => $w->created_at?->toIso8601String(),
            ])->values(),
        ];
    }
}
