<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\P2pService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminP2pController extends Controller
{
    private function audit(Request $r, string $action, array $d): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $r->user('admin')->id, 'action' => $action, 'target_user_id' => null, 'details' => json_encode($d), 'ip' => $r->ip(), 'created_at' => now()]);
    }

    public function index(Request $r)
    {
        $tab = in_array($r->query('tab'), ['disputes', 'orders', 'ads'], true) ? $r->query('tab') : 'disputes';
        $names = fn ($ids) => User::query()->whereIn('id', $ids)->pluck('email', 'id');
        $data = [];
        if ($tab === 'disputes') {
            $rows = DB::table('p2p_disputes as d')->join('p2p_trades as t', 't.id', '=', 'd.trade_id')->orderByRaw("CASE WHEN d.status='open' THEN 0 ELSE 1 END")->orderByDesc('d.id')->limit(100)->get(['d.*', 't.ref', 't.coin', 't.fiat', 't.qty', 't.fiat_amount', 't.method', 't.buyer_id', 't.seller_id', 't.status as trade_status']);
            $emails = $names($rows->pluck('buyer_id')->merge($rows->pluck('seller_id'))->unique());
            $data = $rows->map(fn ($d) => ['ref' => $d->ref, 'status' => $d->status, 'outcome' => $d->outcome, 'reason' => $d->reason, 'coin' => $d->coin, 'qty' => Money::format((int) $d->qty, 6), 'fiat' => $d->fiat, 'fiatAmount' => (float) $d->fiat_amount, 'method' => $d->method, 'buyer' => $emails[$d->buyer_id] ?? '', 'seller' => $emails[$d->seller_id] ?? '', 'openedBy' => (int) $d->opened_by === (int) $d->buyer_id ? 'buyer' : 'seller', 'at' => (string) $d->created_at, 'note' => $d->note])->values();
        } elseif ($tab === 'orders') {
            $rows = DB::table('p2p_trades')->orderByDesc('id')->limit(100)->get();
            $emails = $names($rows->pluck('buyer_id')->merge($rows->pluck('seller_id'))->unique());
            $data = $rows->map(fn ($t) => ['ref' => $t->ref, 'status' => $t->status, 'coin' => $t->coin, 'qty' => Money::format((int) $t->qty, 6), 'fiat' => $t->fiat, 'fiatAmount' => (float) $t->fiat_amount, 'method' => $t->method, 'buyer' => $emails[$t->buyer_id] ?? '', 'seller' => $emails[$t->seller_id] ?? '', 'at' => (string) $t->created_at])->values();
        } else {
            $rows = DB::table('p2p_ads')->where('status', '!=', 'closed')->orderByDesc('id')->limit(100)->get();
            $emails = $names($rows->pluck('user_id')->unique());
            $data = $rows->map(fn ($a) => ['id' => $a->id, 'user' => $emails[$a->user_id] ?? '', 'userId' => $a->user_id, 'side' => $a->side, 'coin' => $a->coin, 'fiat' => $a->fiat, 'price' => (float) $a->price, 'available' => Money::format((int) $a->available, 6), 'status' => $a->status])->values();
        }

        return inertia('Admin/P2p', ['admin' => ['name' => $r->user('admin')->name, 'email' => $r->user('admin')->email], 'tab' => $tab, 'rows' => $data, 'counts' => ['disputes' => DB::table('p2p_disputes')->where('status', 'open')->count(), 'active' => DB::table('p2p_trades')->whereIn('status', ['pending', 'paid', 'disputed'])->count()]]);
    }

    public function resolve(Request $r, string $ref, P2pService $p2p)
    {
        $d = $r->validate(['outcome' => 'required|in:release,refund', 'note' => 'nullable|string|max:250']);
        try {
            $p2p->resolve($r->user('admin')->id, strtoupper($ref), $d['outcome'], $d['note'] ?? null);
        } catch (DomainException $e) {
            return back()->withErrors(['p2p' => $e->getMessage()]);
        }
        $this->audit($r, 'p2p.resolve', ['ref' => $ref] + $d);

        return back()->with('status', "Order {$ref}: ".($d['outcome'] === 'release' ? 'released to buyer.' : 'refunded to seller.'));
    }

    public function closeAd(Request $r, int $id, P2pService $p2p)
    {
        $ad = DB::table('p2p_ads')->find($id);
        abort_unless($ad, 404);
        try {
            $p2p->setAdStatus(User::findOrFail($ad->user_id), $id, 'closed');
        } catch (DomainException $e) {
            return back()->withErrors(['p2p' => $e->getMessage()]);
        }
        $this->audit($r, 'p2p.close_ad', ['ad' => $id]);

        return back()->with('status', 'Ad closed and coins returned.');
    }
}
