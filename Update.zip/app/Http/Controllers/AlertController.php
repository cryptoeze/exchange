<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AlertController extends Controller
{
    public function page()
    {
        return inertia('Alerts');
    }

    public function index(Request $r): JsonResponse
    {
        $rows = DB::table('price_alerts')->where('user_id', $r->user()->id)->orderByDesc('id')->limit(60)->get();

        return response()->json(['alerts' => $rows->map(fn ($a) => ['id' => $a->id, 'symbol' => $a->symbol, 'direction' => $a->direction, 'price' => rtrim(rtrim(number_format((float) $a->price, 8, '.', ''), '0'), '.'), 'triggered' => $a->triggered_at !== null, 'at' => (string) $a->created_at])->values()]);
    }

    public function store(Request $r): JsonResponse
    {
        $d = $r->validate(['symbol' => ['required', 'regex:/^[A-Z0-9]{2,24}USDT$/'], 'direction' => 'required|in:above,below', 'price' => 'required|numeric|gt:0|lt:100000000']);
        if (DB::table('price_alerts')->where('user_id', $r->user()->id)->whereNull('triggered_at')->count() >= 20) {
            return response()->json(['message' => 'You can have up to 20 active alerts. Delete one first.'], 422);
        }
        DB::table('price_alerts')->insert(['user_id' => $r->user()->id, 'symbol' => $d['symbol'], 'direction' => $d['direction'], 'price' => $d['price'], 'created_at' => now()]);

        return $this->index($r);
    }

    public function destroy(Request $r, int $id): JsonResponse
    {
        DB::table('price_alerts')->where(['id' => $id, 'user_id' => $r->user()->id])->delete();

        return $this->index($r);
    }
}
