<?php

namespace App\Http\Controllers;

use App\Models\EarnPosition;
use App\Models\EarnProduct;
use App\Models\LedgerEntry;
use App\Services\EarnService;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class EarnController extends Controller
{
    public function __construct(private readonly EarnService $earn, private readonly LedgerService $ledger)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $this->earn->settleUser($request->user()->id);

        return response()->json($this->payload($request->user()->id))->header('Cache-Control', 'no-store');
    }

    public function stake(Request $request): JsonResponse
    {
        $d = $request->validate(['product_id' => 'required|integer', 'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'from' => 'required|in:funding,trading', 'idempotency_key' => 'nullable|string|max:64']);
        $product = EarnProduct::query()->findOrFail($d['product_id']);
        try {
            $this->earn->stake($request->user(), $product, Money::toUnits($d['amount']), $d['from'], $d['idempotency_key'] ?? null);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($request->user()->id));
    }

    public function unstake(Request $request): JsonResponse
    {
        $d = $request->validate(['product_id' => 'required|integer', 'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'idempotency_key' => 'nullable|string|max:64']);
        $product = EarnProduct::query()->findOrFail($d['product_id']);
        try {
            $this->earn->unstake($request->user(), $product, Money::toUnits($d['amount']), $d['idempotency_key'] ?? null);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($request->user()->id));
    }

    /** @return array<string, mixed> */
    private function payload(int $userId): array
    {
        $positions = EarnPosition::query()->where('user_id', $userId)->get()->keyBy('earn_product_id');
        // Show enabled products, plus disabled ones the user still has money in.
        $products = EarnProduct::query()->orderBy('sort')->orderBy('id')->get()->filter(fn ($p) => $p->enabled || ($positions[$p->id]->principal ?? 0) > 0)->values();
        $earned = fn ($since) => LedgerEntry::query()->where('user_id', $userId)->where('type', 'earn_interest')->when($since, fn ($q) => $q->where('created_at', '>=', $since))->sum('amount');
        $bal = fn (string $account, string $asset) => Money::format($this->ledger->balance($userId, $account, $asset), 2);

        return [
            'products' => $products->map(fn ($p) => [
                'id' => $p->id, 'asset' => $p->asset, 'name' => $p->name, 'apr' => (float) $p->apr_pct, 'minAmount' => Money::format((int) $p->min_units, 2), 'enabled' => $p->enabled,
                'staked' => Money::format((int) ($positions[$p->id]->principal ?? 0), 8), 'stakedUnits' => (int) ($positions[$p->id]->principal ?? 0),
                'funding' => $bal('funding', $p->asset), 'trading' => $bal('trading', $p->asset),
            ])->values(),
            'totalStaked' => Money::format((int) $positions->sum('principal'), 2),
            'yesterday' => Money::format((int) $earned(now()->subDay()), 4),
            'totalEarned' => Money::format((int) $earned(null), 4),
        ];
    }
}
