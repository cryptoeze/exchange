<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\SettingsService;
use App\Services\TelegramNotifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Owner-only Telegram control for riseway.io: /status, /on, /off (site maintenance mode), /login (a one-time,
 * 10-minute admin login link), and — only when config('license.authority') is true, i.e. this IS the owner's
 * own riseway.io install — /newkey, /keys, /revoke for issuing and managing license keys handed out to buyers
 * of the script (see LicenseController). Every update is checked against TELEGRAM_OWNER_CHAT_ID; anything else
 * is silently ignored. The webhook path includes a random secret (TELEGRAM_WEBHOOK_SECRET) so it can't be found
 * or spammed by guessing the URL.
 */
class TelegramBotController extends Controller
{
    public function webhook(Request $request, string $secret, SettingsService $settings, TelegramNotifier $tg)
    {
        $expected = (string) config('telegram.webhook_secret');
        if ($expected === '' || ! hash_equals($expected, $secret)) {
            abort(404);
        }

        $chatId = (string) $request->input('message.chat.id', '');
        $text = trim((string) $request->input('message.text', ''));
        $owner = (string) config('telegram.owner_chat_id');
        if ($owner === '' || $chatId === '' || ! hash_equals($owner, $chatId)) {
            return response()->json(['ok' => true]); // not the owner: ignore silently, no reply, no error.
        }

        $parts = explode(' ', $text, 2);
        $cmd = strtolower($parts[0] ?? '');
        $arg = trim($parts[1] ?? '');
        $reply = match (true) {
            in_array($cmd, ['/start', '/help'], true) => $this->help(),
            $cmd === '/status' => (bool) config('app.maintenance_mode') ? '🔴 Maintenance mode is ON — visitors see the maintenance page.' : '🟢 Site is live.',
            $cmd === '/on' => $this->setMaintenance($settings, false),
            $cmd === '/off' => $this->setMaintenance($settings, true),
            $cmd === '/login' => $this->issueLoginLink(),
            $cmd === '/newkey' && config('license.authority') => $this->newKey($arg),
            $cmd === '/keys' && config('license.authority') => $this->listKeys(),
            $cmd === '/revoke' && config('license.authority') => $this->revokeKey($arg),
            default => "Unknown command. Send /help to see what I can do.",
        };
        $tg->toChat($chatId, $reply);

        return response()->json(['ok' => true]);
    }

    private function help(): string
    {
        $base = "Commands:\n/status — site status\n/on — take the site live\n/off — maintenance mode\n/login — one-time admin login link (valid 10 min)";
        if (! config('license.authority')) {
            return $base;
        }

        return $base."\n\nLicensing (sold copies):\n/newkey [note] — issue a new license key\n/keys — list recent keys\n/revoke <key> — deactivate a key (locks that install within 10 min)";
    }

    private function setMaintenance(SettingsService $settings, bool $on): string
    {
        $settings->save(['maintenance' => $on]);

        return $on ? '🔴 Maintenance mode is ON. Visitors see the maintenance page; admin panel keeps working.' : '🟢 Site is live again.';
    }

    private function issueLoginLink(): string
    {
        $email = (string) config('telegram.login_admin_email');
        $admin = $email !== '' ? User::query()->where('email', $email)->where('role', 'admin')->first() : null;
        if (! $admin) {
            return 'No TELEGRAM_LOGIN_ADMIN_EMAIL configured (or no matching admin account) — set it in .env first.';
        }
        $token = Str::random(48);
        DB::table('telegram_logins')->insert([
            'token' => $token, 'admin_id' => $admin->id,
            'expires_at' => now()->addMinutes((int) config('telegram.login_ttl_minutes', 10)),
            'created_at' => now(), 'updated_at' => now(),
        ]);

        return 'One-time admin login (valid '.config('telegram.login_ttl_minutes', 10)." min, single use):\n".url('/admin/telegram-login/'.$token);
    }

    public function consumeLogin(string $token)
    {
        $row = DB::table('telegram_logins')->where('token', $token)->whereNull('used_at')->where('expires_at', '>=', now())->first();
        abort_unless($row, 404);
        DB::table('telegram_logins')->where('id', $row->id)->update(['used_at' => now()]);
        $admin = User::query()->where('id', $row->admin_id)->where('role', 'admin')->first();
        abort_unless($admin, 404);
        Auth::guard('admin')->login($admin);
        request()->session()->regenerate();

        return redirect()->route('admin.dashboard');
    }

    /** Issue a new, unassigned license key. Hand it to the buyer along with the Update.zip. */
    private function newKey(string $note): string
    {
        $key = strtoupper(Str::random(4).'-'.Str::random(4).'-'.Str::random(4).'-'.Str::random(4));
        DB::table('licenses')->insert(['key' => $key, 'status' => 'pending', 'note' => $note ?: null, 'created_at' => now(), 'updated_at' => now()]);

        return "New license key (give this to the buyer):\n{$key}\n\nIt activates itself the first time their install runs `php artisan license:activate {$key}`.";
    }

    private function listKeys(): string
    {
        $rows = DB::table('licenses')->orderByDesc('id')->limit(15)->get();
        if ($rows->isEmpty()) {
            return 'No license keys issued yet. Send /newkey to create one.';
        }

        return $rows->map(fn ($l) => "{$l->key} — {$l->status}".($l->domain ? " — {$l->domain}" : '').($l->note ? " — {$l->note}" : ''))->implode("\n");
    }

    private function revokeKey(string $key): string
    {
        $key = strtoupper(trim($key));
        if ($key === '') {
            return 'Usage: /revoke <key>';
        }
        $n = DB::table('licenses')->where('key', $key)->update(['status' => 'revoked', 'updated_at' => now()]);
        if ($n === 0) {
            return "No license found for {$key}.";
        }

        return "Revoked {$key}. That install locks itself within ~10 minutes of its next check-in.";
    }
}
