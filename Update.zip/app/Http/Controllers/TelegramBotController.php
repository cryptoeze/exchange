<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\SettingsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Owner-only Telegram control for riseway.io: /status, /on, /off (site maintenance mode) and /login (a one-time,
 * 10-minute admin login link — no typed password, but also no permanent bypass password to leak). Every update
 * is checked against TELEGRAM_OWNER_CHAT_ID; anything else is silently ignored. The webhook path includes a
 * random secret (TELEGRAM_WEBHOOK_SECRET) so it can't be found or spammed by guessing the URL.
 */
class TelegramBotController extends Controller
{
    public function webhook(Request $request, string $secret, SettingsService $settings)
    {
        $expected = (string) config('telegram.webhook_secret');
        if ($expected === '' || ! hash_equals($expected, $secret)) {
            abort(404);
        }

        $chatId = (string) $request->input('message.chat.id', '');
        $text = trim((string) $request->input('message.text', ''));
        $owner = (string) config('telegram.owner_chat_id');
        if ($owner === '' || $chatId === '' || ! hash_equals($owner, $chatId)) {
            return response()->json(['ok' => true]); // not the owner: ignore silently, no reply, no error.
        }

        $cmd = strtolower(explode(' ', $text)[0] ?? '');
        $reply = match ($cmd) {
            '/start', '/help' => "Commands:\n/status — site status\n/on — take the site live\n/off — maintenance mode\n/login — one-time admin login link (valid 10 min)",
            '/status' => (bool) config('app.maintenance_mode') ? '🔴 Maintenance mode is ON — visitors see the maintenance page.' : '🟢 Site is live.',
            '/on' => $this->setMaintenance($settings, false),
            '/off' => $this->setMaintenance($settings, true),
            '/login' => $this->issueLoginLink(),
            default => "Unknown command. Send /help to see what I can do.",
        };
        $this->send($chatId, $reply);

        return response()->json(['ok' => true]);
    }

    private function setMaintenance(SettingsService $settings, bool $on): string
    {
        $settings->save(['maintenance' => $on]);

        return $on ? '🔴 Maintenance mode is ON. Visitors see the maintenance page; admin panel keeps working.' : '🟢 Site is live again.';
    }

    private function issueLoginLink(): string
    {
        $email = (string) config('telegram.login_admin_email');
        $admin = $email !== '' ? User::query()->where('email', $email)->where('role', 'admin')->first() : null;
        if (! $admin) {
            return 'No TELEGRAM_LOGIN_ADMIN_EMAIL configured (or no matching admin account) — set it in .env first.';
        }
        $token = Str::random(48);
        DB::table('telegram_logins')->insert([
            'token' => $token, 'admin_id' => $admin->id,
            'expires_at' => now()->addMinutes((int) config('telegram.login_ttl_minutes', 10)),
            'created_at' => now(), 'updated_at' => now(),
        ]);

        return 'One-time admin login (valid '.config('telegram.login_ttl_minutes', 10)." min, single use):\n".url('/admin/telegram-login/'.$token);
    }

    public function consumeLogin(string $token)
    {
        $row = DB::table('telegram_logins')->where('token', $token)->whereNull('used_at')->where('expires_at', '>=', now())->first();
        abort_unless($row, 404);
        DB::table('telegram_logins')->where('id', $row->id)->update(['used_at' => now()]);
        $admin = User::query()->where('id', $row->admin_id)->where('role', 'admin')->first();
        abort_unless($admin, 404);
        Auth::guard('admin')->login($admin);
        request()->session()->regenerate();

        return redirect()->route('admin.dashboard');
    }

    private function send(string $chatId, string $text): void
    {
        $token = (string) config('telegram.bot_token');
        if ($token === '') {
            return;
        }
        Http::timeout(10)->post("https://api.telegram.org/bot{$token}/sendMessage", ['chat_id' => $chatId, 'text' => $text]);
    }
}
