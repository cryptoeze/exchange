<?php

namespace App\Http\Controllers;

use App\Services\TotpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/** Authenticator-app 2FA setup for the signed-in account. Works for both the user area and the admin area (route default `guard`). */
class TwoFactorController extends Controller
{
    private function who(Request $r)
    {
        return $r->user($r->route()->defaults['guard'] ?? 'web');
    }

    public function start(Request $r, TotpService $totp): JsonResponse
    {
        $u = $this->who($r);
        if ($u->two_factor_enabled) {
            return response()->json(['message' => 'Two-factor authentication is already on.'], 422);
        }
        $secret = $totp->newSecret();
        $r->session()->put('2fa.setup', $secret);

        return response()->json(['secret' => $secret, 'uri' => $totp->uri($secret, $u->email)]);
    }

    public function confirm(Request $r, TotpService $totp): JsonResponse
    {
        $u = $this->who($r);
        $d = $r->validate(['code' => 'required|string|max:12']);
        $secret = $r->session()->get('2fa.setup');
        if (! $secret || ! $totp->verify($secret, $d['code'])) {
            return response()->json(['message' => 'That code is not correct. Check the time on your phone and try again.'], 422);
        }
        $codes = $totp->enable($u, $secret);
        $r->session()->forget('2fa.setup');
        $totp->logLogin($u->id, $u->email, ($r->route()->defaults['guard'] ?? 'web') === 'admin' ? 'admin' : 'web', true, '2fa enabled');

        return response()->json(['recovery' => $codes]);
    }

    public function disable(Request $r, TotpService $totp): JsonResponse
    {
        $u = $this->who($r);
        $d = $r->validate(['password' => 'required|string', 'code' => 'required|string|max:20']);
        if (! Hash::check($d['password'], $u->password)) {
            return response()->json(['message' => 'Wrong password.'], 422);
        }
        if (! $totp->check($u->fresh(), $d['code'])) {
            return response()->json(['message' => 'Wrong authentication code.'], 422);
        }
        $totp->disable($u);

        return response()->json(['ok' => true]);
    }

    public static function history(int $userId, string $area): array
    {
        return DB::table('login_events')->where('user_id', $userId)->where('area', $area)->orderByDesc('id')->limit(15)->get(['success', 'note', 'ip', 'agent', 'created_at'])->map(fn ($e) => ['ok' => (bool) $e->success, 'note' => $e->note, 'ip' => $e->ip, 'agent' => $e->agent, 'at' => (string) $e->created_at])->all();
    }
}
