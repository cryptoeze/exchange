<?php

namespace App\Http\Controllers;

use App\Models\Bot;
use App\Models\BotClaim;
use App\Models\BotFollow;
use App\Models\EarnPosition;
use App\Models\EarnProduct;
use App\Models\LedgerEntry;
use App\Services\BotService;
use App\Services\EarnService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Administrator controls for Earn products and yield strategies (bots). Every change is audit-logged. */
final class AdminYieldController extends Controller
{
    use \App\Http\Controllers\Admin\Concerns\AdminHelpers;

    private function admin(Request $request): array
    {
        return ['name' => $request->user('admin')->name, 'email' => $request->user('admin')->email];
    }

    private function audit(Request $request, string $action, array $details): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $request->user('admin')->id, 'action' => $action, 'target_user_id' => null, 'details' => json_encode($details), 'ip' => $request->ip(), 'created_at' => now()]);
    }

    public function futures(Request $request, \App\Services\FuturesService $futures)
    {
        $tab = $this->pick($request, 'tab', ['open', 'closed', 'all']) ?: 'open';
        $q = trim((string) $request->query('q', ''));
        $symbol = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $request->query('symbol', '')));
        $side = $this->pick($request, 'side', ['long', 'short']);
        $reason = $this->pick($request, 'reason', ['manual', 'tp', 'sl', 'liquidation']);
        try {
            $prices = $futures->priceMap();
        } catch (\Throwable) {
            $prices = []; // price feed down: the page still loads, marks show as unavailable
        }
        // Exposure is always computed over every open position, regardless of the list filters.
        $allOpen = \App\Models\FuturesPosition::query()->where('status', 'open')->get();
        $long = 0;
        $short = 0;
        $unrealized = 0;
        foreach ($allOpen as $p) {
            $mark = $prices[$p->symbol] ?? null;
            $unrealized += $mark !== null ? $p->pnlAt($mark) : 0;
            $p->side === 'long' ? $long += $p->notional() : $short += $p->notional();
        }
        $closed = \App\Models\FuturesPosition::query()->where('status', 'closed');

        $query = \App\Models\FuturesPosition::query()->join('users as u', 'u.id', '=', 'futures_positions.user_id')->select(['futures_positions.*', 'u.email as u_email', 'u.name as u_name'])->orderByDesc('futures_positions.id');
        $tab !== 'all' && $query->where('futures_positions.status', $tab);
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($w) => $w->where('u.email', 'like', $this->like($q))->orWhere('u.name', 'like', $this->like($q))->orWhere('u.id', $digits));
        }
        $symbol && $query->where('futures_positions.symbol', 'like', $symbol.'%');
        $side && $query->where('futures_positions.side', $side);
        $reason && $query->where('futures_positions.close_reason', $reason);
        $this->dateRange($query, $request, 'futures_positions.created_at');
        [$items, $pager] = $this->paged($query, $request, 25);

        $rows = $items->map(function ($p) use ($prices) {
            $isOpen = $p->status === 'open';
            $mark = $isOpen ? ($prices[$p->symbol] ?? null) : null;
            $pnl = $isOpen ? ($mark !== null ? $p->pnlAt($mark) : 0) : (int) $p->pnl;

            return ['id' => $p->id, 'userId' => $p->user_id, 'email' => $p->u_email, 'name' => $p->u_name, 'symbol' => $p->symbol, 'side' => $p->side, 'leverage' => $p->leverage, 'margin' => Money::format((int) $p->margin, 2),
                'entry' => $p->entry(), 'mark' => $mark, 'close' => $p->close_micro ? $p->close_micro / Money::SCALE : null, 'liq' => $p->liqPrice(), 'pnl' => Money::format($pnl, 2), 'status' => $p->status, 'reason' => $p->close_reason,
                'at' => $p->created_at?->format('Y-m-d H:i'), 'closedAt' => $p->closed_at ? substr((string) $p->closed_at, 0, 16) : null];
        })->values();

        return inertia('Admin/Futures', ['admin' => $this->adminProps($request), 'tab' => $tab, 'pager' => $pager, 'rows' => $rows,
            'filters' => ['q' => $q, 'symbol' => $symbol, 'side' => $side, 'reason' => $reason, 'from' => (string) $this->day($request->query('from')), 'to' => (string) $this->day($request->query('to'))],
            'counts' => ['open' => $allOpen->count(), 'closed' => (clone $closed)->count()],
            'totals' => [
                'open' => $allOpen->count(), 'margin' => Money::format((int) $allOpen->sum('margin'), 2), 'long' => Money::format($long, 2), 'short' => Money::format($short, 2),
                'unrealized' => Money::format($unrealized, 2), 'feesEarned' => Money::format((int) (clone $closed)->sum('fee_close') + (int) \App\Models\FuturesPosition::query()->sum('fee_open'), 2),
                'closedCount' => (clone $closed)->count(), 'liquidations' => (clone $closed)->where('close_reason', 'liquidation')->count(),
            ], 'config' => ['enabled' => (bool) config('trading.futures_enabled'), 'feeRate' => (float) config('trading.futures_fee_rate'), 'maxLeverage' => (int) config('trading.futures_max_leverage'), 'maxMargin' => (float) config('trading.futures_max_margin_usdt')]]);
    }

    public function earn(Request $request)
    {
        $positions = EarnPosition::query()->selectRaw('earn_product_id, COUNT(*) as holders, SUM(principal) as staked')->where('principal', '>', 0)->groupBy('earn_product_id')->get()->keyBy('earn_product_id');
        $paid = LedgerEntry::query()->where('type', 'earn_interest')->selectRaw('ref_id, SUM(amount) as total')->groupBy('ref_id')->get();
        $paidTotal = (int) $paid->sum('total');

        return inertia('Admin/Earn', ['admin' => $this->admin($request), 'products' => EarnProduct::query()->orderBy('sort')->orderBy('id')->get()->map(fn ($p) => [
            'id' => $p->id, 'asset' => $p->asset, 'name' => $p->name, 'apr' => (float) $p->apr_pct, 'min' => Money::format((int) $p->min_units, 2), 'maxPerUser' => $p->max_per_user ? Money::format((int) $p->max_per_user, 2) : '', 'capacity' => $p->capacity ? Money::format((int) $p->capacity, 2) : '', 'enabled' => $p->enabled,
            'holders' => (int) ($positions[$p->id]->holders ?? 0), 'staked' => Money::format((int) ($positions[$p->id]->staked ?? 0), 2),
        ])->values(), 'totals' => ['staked' => Money::format((int) $positions->sum('staked'), 2), 'interestPaid' => Money::format($paidTotal, 4)]]);
    }

    public function saveEarn(Request $request, EarnService $earn): RedirectResponse
    {
        $d = $request->validate([
            'id' => 'nullable|integer', 'name' => 'required|string|max:60', 'asset' => 'required|in:USDT,USDC',
            'apr' => 'required|numeric|min:0|max:1000', 'max_per_user' => ['nullable', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'capacity' => ['nullable', 'string', 'regex:/^\d{1,12}(\.\d{1,8})?$/'],  'min' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'enabled' => 'required|boolean',
        ]);
        $product = ! empty($d['id']) ? EarnProduct::query()->findOrFail($d['id']) : new EarnProduct(['sort' => (int) EarnProduct::query()->max('sort') + 1]);
        if ($product->exists && ($product->asset !== $d['asset'])) {
            return back()->withErrors(['asset' => 'The asset of an existing product cannot be changed.']);
        }
        if ($product->exists && abs((float) $product->apr_pct - (float) $d['apr']) > 0.00001) {
            $earn->settleProduct($product); // pay everyone at the old rate up to now
        }
        $product->fill(['max_per_user' => ! empty($d['max_per_user']) ? Money::toUnits($d['max_per_user']) : null, 'capacity' => ! empty($d['capacity']) ? Money::toUnits($d['capacity']) : null, 'name' => $d['name'], 'asset' => $d['asset'], 'apr_pct' => $d['apr'], 'min_units' => Money::toUnits($d['min']), 'enabled' => $d['enabled']])->save();
        $this->audit($request, 'earn_product_save', ['id' => $product->id] + $d);

        return back()->with('status', "Saved {$product->name}.");
    }

    public function bots(Request $request, string $kind = 'bot')
    {
        $stats = BotFollow::query()->where('status', 'active')->selectRaw('bot_id, COUNT(*) as followers, SUM(capital) as aum')->groupBy('bot_id')->get()->keyBy('bot_id');
        $paid = BotClaim::query()->selectRaw('bot_id, SUM(net) as net, SUM(share) as share')->groupBy('bot_id')->get()->keyBy('bot_id');

        return inertia('Admin/Bots', ['kind' => $kind, 'admin' => $this->admin($request), 'bots' => Bot::query()->where('kind', $kind)->orderBy('sort')->orderBy('id')->get()->map(fn ($b) => [
            'id' => $b->id, 'name' => $b->name, 'bio' => $b->bio, 'direction' => $b->direction, 'leverage' => (int) $b->leverage, 'pair' => $b->pair, 'strategy' => $b->strategy, 'daily' => (float) $b->daily_yield_pct, 'share' => (float) $b->profit_share_pct,
            'min' => Money::format((int) $b->min_units, 2), 'maxPerUser' => $b->max_per_user ? Money::format((int) $b->max_per_user, 2) : '', 'capacity' => $b->capacity ? Money::format((int) $b->capacity, 2) : '', 'enabled' => $b->enabled,
            'followers' => (int) ($stats[$b->id]->followers ?? 0), 'aum' => Money::format((int) ($stats[$b->id]->aum ?? 0), 2),
            'paid' => Money::format((int) ($paid[$b->id]->net ?? 0), 2), 'kept' => Money::format((int) ($paid[$b->id]->share ?? 0), 2),
        ])->values(), 'totals' => ['aum' => Money::format((int) $stats->sum('aum'), 2), 'paid' => Money::format((int) $paid->sum('net'), 2)]]);
    }

    public function saveBot(Request $request, BotService $bots): RedirectResponse
    {
        $d = $request->validate([
            'id' => 'nullable|integer', 'kind' => 'required|in:bot,trader', 'bio' => 'nullable|string|max:255', 'direction' => 'nullable|in:LONG,SHORT', 'leverage' => 'nullable|integer|min:1|max:200', 'name' => 'required|string|max:60', 'pair' => ['required', 'string', 'max:24', 'regex:/^[A-Z0-9]+$/'], 'strategy' => 'required|string|max:40',
            'daily' => 'required|numeric|min:0|max:20', 'max_per_user' => ['nullable', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'capacity' => ['nullable', 'string', 'regex:/^\d{1,12}(\.\d{1,8})?$/'],  'share' => 'required|numeric|min:0|max:100', 'min' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'enabled' => 'required|boolean',
        ]);
        $bot = ! empty($d['id']) ? Bot::query()->findOrFail($d['id']) : new Bot(['kind' => $d['kind'], 'sort' => (int) Bot::query()->max('sort') + 1]);
        if ($bot->exists && (abs((float) $bot->daily_yield_pct - (float) $d['daily']) > 0.0001 || abs((float) $bot->profit_share_pct - (float) $d['share']) > 0.001)) {
            $bots->settleBot($bot); // pay completed cycles at the old terms first
        }
        $bot->fill(['max_per_user' => ! empty($d['max_per_user']) ? Money::toUnits($d['max_per_user']) : null, 'capacity' => ! empty($d['capacity']) ? Money::toUnits($d['capacity']) : null, 'bio' => $d['bio'] ?? null, 'direction' => $d['direction'] ?? 'LONG', 'leverage' => $d['leverage'] ?? 1, 'name' => $d['name'], 'pair' => $d['pair'], 'strategy' => $d['strategy'], 'daily_yield_pct' => $d['daily'], 'profit_share_pct' => $d['share'], 'min_units' => Money::toUnits($d['min']), 'enabled' => $d['enabled']])->save();
        $this->audit($request, 'bot_save', ['id' => $bot->id] + $d);

        return back()->with('status', "Saved {$bot->name}.");
    }

    /** Followers of one strategy (JSON for the admin modal). */
    public function followers(Request $request, int $bot)
    {
        $rows = BotFollow::query()->where(['bot_id' => $bot, 'status' => 'active'])->orderByDesc('capital')->limit(200)->get();
        $emails = \App\Models\User::query()->whereIn('id', $rows->pluck('user_id'))->pluck('email', 'id');

        return response()->json($rows->map(fn ($f) => ['userId' => $f->user_id, 'email' => $emails[$f->user_id] ?? '#'.$f->user_id, 'capital' => Money::format((int) $f->capital, 2), 'since' => $f->created_at?->format('Y-m-d'), 'auto' => (bool) $f->auto_claim])->values());
    }

    /** Admin stops one follower: completed cycles are paid, capital returns to the user's Funding account. */
    public function stopFollower(Request $request, int $bot, int $user, BotService $bots): RedirectResponse
    {
        $b = Bot::query()->findOrFail($bot);
        $u = \App\Models\User::query()->findOrFail($user);
        try {
            $bots->unfollow($u, $b);
        } catch (\DomainException $e) {
            return back()->withErrors(['bot' => $e->getMessage()]);
        }
        \App\Services\NotificationService::send($u->id, 'Strategy stopped', "Your allocation to {$b->name} was stopped by RushX and returned to your Funding account.", 'warn', '/bots');
        $this->audit($request, 'bot_stop_follower', ['bot' => $b->id, 'user' => $u->id]);

        return back()->with('status', "Stopped {$u->email} on {$b->name}.");
    }

    /** Pay every follower's completed cycles right now. */
    public function settleNow(Request $request, int $bot, BotService $bots): RedirectResponse
    {
        $b = Bot::query()->findOrFail($bot);
        $n = $bots->settleBot($b);
        $this->audit($request, 'bot_settle_now', ['bot' => $b->id, 'paid' => $n]);

        return back()->with('status', "Settled {$b->name}: {$n} payout(s).");
    }

    /** Delete a strategy only when nobody ever used it. */
    public function deleteBot(Request $request, int $bot): RedirectResponse
    {
        $b = Bot::query()->findOrFail($bot);
        if (BotFollow::query()->where('bot_id', $b->id)->exists()) {
            return back()->withErrors(['bot' => 'This strategy has follower history. Switch it off instead of deleting.']);
        }
        $b->delete();
        $this->audit($request, 'bot_delete', ['bot' => $bot, 'name' => $b->name]);

        return back()->with('status', 'Strategy deleted.');
    }
}
