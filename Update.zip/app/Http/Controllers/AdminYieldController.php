<?php

namespace App\Http\Controllers;

use App\Models\Bot;
use App\Models\BotClaim;
use App\Models\BotFollow;
use App\Models\EarnPosition;
use App\Models\EarnProduct;
use App\Models\LedgerEntry;
use App\Services\BotService;
use App\Services\EarnService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Administrator controls for Earn products and yield strategies (bots). Every change is audit-logged. */
final class AdminYieldController extends Controller
{
    private function admin(Request $request): array
    {
        return ['name' => $request->user('admin')->name, 'email' => $request->user('admin')->email];
    }

    private function audit(Request $request, string $action, array $details): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $request->user('admin')->id, 'action' => $action, 'target_user_id' => null, 'details' => json_encode($details), 'ip' => $request->ip(), 'created_at' => now()]);
    }

    public function futures(Request $request, \App\Services\FuturesService $futures)
    {
        $open = \App\Models\FuturesPosition::query()->where('status', 'open')->orderByDesc('id')->limit(200)->get();
        try {
            $prices = $futures->priceMap();
        } catch (\DomainException) {
            $prices = [];
        }
        $emails = \App\Models\User::query()->whereIn('id', $open->pluck('user_id'))->pluck('email', 'id');
        $long = 0;
        $short = 0;
        $unrealized = 0;
        $rows = $open->map(function ($p) use ($prices, $emails, &$long, &$short, &$unrealized) {
            $mark = $prices[$p->symbol] ?? null;
            $pnl = $mark !== null ? $p->pnlAt($mark) : 0;
            $p->side === 'long' ? $long += $p->notional() : $short += $p->notional();
            $unrealized += $pnl;

            return ['id' => $p->id, 'user' => $emails[$p->user_id] ?? '#'.$p->user_id, 'symbol' => $p->symbol, 'side' => $p->side, 'leverage' => $p->leverage, 'margin' => Money::format((int) $p->margin, 2),
                'entry' => $p->entry(), 'mark' => $mark, 'liq' => $p->liqPrice(), 'pnl' => Money::format($pnl, 2), 'at' => $p->created_at?->format('Y-m-d H:i')];
        })->values();
        $closed = \App\Models\FuturesPosition::query()->where('status', 'closed');

        return inertia('Admin/Futures', ['admin' => $this->admin($request), 'positions' => $rows, 'totals' => [
            'open' => $open->count(), 'margin' => Money::format((int) $open->sum('margin'), 2), 'long' => Money::format($long, 2), 'short' => Money::format($short, 2),
            'unrealized' => Money::format($unrealized, 2), 'feesEarned' => Money::format((int) (clone $closed)->sum('fee_close') + (int) \App\Models\FuturesPosition::query()->sum('fee_open'), 2),
            'closedCount' => (clone $closed)->count(), 'liquidations' => (clone $closed)->where('close_reason', 'liquidation')->count(),
        ], 'config' => ['enabled' => (bool) config('trading.futures_enabled'), 'feeRate' => (float) config('trading.futures_fee_rate'), 'maxLeverage' => (int) config('trading.futures_max_leverage'), 'maxMargin' => (float) config('trading.futures_max_margin_usdt')]]);
    }

    public function earn(Request $request)
    {
        $positions = EarnPosition::query()->selectRaw('earn_product_id, COUNT(*) as holders, SUM(principal) as staked')->where('principal', '>', 0)->groupBy('earn_product_id')->get()->keyBy('earn_product_id');
        $paid = LedgerEntry::query()->where('type', 'earn_interest')->selectRaw('ref_id, SUM(amount) as total')->groupBy('ref_id')->get();
        $paidTotal = (int) $paid->sum('total');

        return inertia('Admin/Earn', ['admin' => $this->admin($request), 'products' => EarnProduct::query()->orderBy('sort')->orderBy('id')->get()->map(fn ($p) => [
            'id' => $p->id, 'asset' => $p->asset, 'name' => $p->name, 'apr' => (float) $p->apr_pct, 'min' => Money::format((int) $p->min_units, 2), 'enabled' => $p->enabled,
            'holders' => (int) ($positions[$p->id]->holders ?? 0), 'staked' => Money::format((int) ($positions[$p->id]->staked ?? 0), 2),
        ])->values(), 'totals' => ['staked' => Money::format((int) $positions->sum('staked'), 2), 'interestPaid' => Money::format($paidTotal, 4)]]);
    }

    public function saveEarn(Request $request, EarnService $earn): RedirectResponse
    {
        $d = $request->validate([
            'id' => 'nullable|integer', 'name' => 'required|string|max:60', 'asset' => 'required|in:USDT,USDC',
            'apr' => 'required|numeric|min:0|max:1000', 'min' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'enabled' => 'required|boolean',
        ]);
        $product = ! empty($d['id']) ? EarnProduct::query()->findOrFail($d['id']) : new EarnProduct(['sort' => (int) EarnProduct::query()->max('sort') + 1]);
        if ($product->exists && ($product->asset !== $d['asset'])) {
            return back()->withErrors(['asset' => 'The asset of an existing product cannot be changed.']);
        }
        if ($product->exists && abs((float) $product->apr_pct - (float) $d['apr']) > 0.00001) {
            $earn->settleProduct($product); // pay everyone at the old rate up to now
        }
        $product->fill(['name' => $d['name'], 'asset' => $d['asset'], 'apr_pct' => $d['apr'], 'min_units' => Money::toUnits($d['min']), 'enabled' => $d['enabled']])->save();
        $this->audit($request, 'earn_product_save', ['id' => $product->id] + $d);

        return back()->with('status', "Saved {$product->name}.");
    }

    public function bots(Request $request, string $kind = 'bot')
    {
        $stats = BotFollow::query()->where('status', 'active')->selectRaw('bot_id, COUNT(*) as followers, SUM(capital) as aum')->groupBy('bot_id')->get()->keyBy('bot_id');
        $paid = BotClaim::query()->selectRaw('bot_id, SUM(net) as net, SUM(share) as share')->groupBy('bot_id')->get()->keyBy('bot_id');

        return inertia('Admin/Bots', ['kind' => $kind, 'admin' => $this->admin($request), 'bots' => Bot::query()->where('kind', $kind)->orderBy('sort')->orderBy('id')->get()->map(fn ($b) => [
            'id' => $b->id, 'name' => $b->name, 'bio' => $b->bio, 'direction' => $b->direction, 'leverage' => (int) $b->leverage, 'pair' => $b->pair, 'strategy' => $b->strategy, 'daily' => (float) $b->daily_yield_pct, 'share' => (float) $b->profit_share_pct,
            'min' => Money::format((int) $b->min_units, 2), 'enabled' => $b->enabled,
            'followers' => (int) ($stats[$b->id]->followers ?? 0), 'aum' => Money::format((int) ($stats[$b->id]->aum ?? 0), 2),
            'paid' => Money::format((int) ($paid[$b->id]->net ?? 0), 2), 'kept' => Money::format((int) ($paid[$b->id]->share ?? 0), 2),
        ])->values(), 'totals' => ['aum' => Money::format((int) $stats->sum('aum'), 2), 'paid' => Money::format((int) $paid->sum('net'), 2)]]);
    }

    public function saveBot(Request $request, BotService $bots): RedirectResponse
    {
        $d = $request->validate([
            'id' => 'nullable|integer', 'kind' => 'required|in:bot,trader', 'bio' => 'nullable|string|max:255', 'direction' => 'nullable|in:LONG,SHORT', 'leverage' => 'nullable|integer|min:1|max:200', 'name' => 'required|string|max:60', 'pair' => ['required', 'string', 'max:24', 'regex:/^[A-Z0-9]+$/'], 'strategy' => 'required|string|max:40',
            'daily' => 'required|numeric|min:0|max:20', 'share' => 'required|numeric|min:0|max:100', 'min' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'enabled' => 'required|boolean',
        ]);
        $bot = ! empty($d['id']) ? Bot::query()->findOrFail($d['id']) : new Bot(['kind' => $d['kind'], 'sort' => (int) Bot::query()->max('sort') + 1]);
        if ($bot->exists && (abs((float) $bot->daily_yield_pct - (float) $d['daily']) > 0.0001 || abs((float) $bot->profit_share_pct - (float) $d['share']) > 0.001)) {
            $bots->settleBot($bot); // pay completed cycles at the old terms first
        }
        $bot->fill(['bio' => $d['bio'] ?? null, 'direction' => $d['direction'] ?? 'LONG', 'leverage' => $d['leverage'] ?? 1, 'name' => $d['name'], 'pair' => $d['pair'], 'strategy' => $d['strategy'], 'daily_yield_pct' => $d['daily'], 'profit_share_pct' => $d['share'], 'min_units' => Money::toUnits($d['min']), 'enabled' => $d['enabled']])->save();
        $this->audit($request, 'bot_save', ['id' => $bot->id] + $d);

        return back()->with('status', "Saved {$bot->name}.");
    }
}
