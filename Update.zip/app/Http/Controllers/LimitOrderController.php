<?php

namespace App\Http\Controllers;

use App\Services\LimitOrderService;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LimitOrderController extends Controller
{
    private function payload(int $userId): array
    {
        $fmt = fn ($o) => ['id' => $o->id, 'symbol' => $o->symbol, 'base' => $o->base_asset, 'side' => $o->side, 'kind' => $o->kind ?? 'limit', 'price' => rtrim(rtrim(number_format((float) $o->limit_price, 10, '.', ''), '0'), '.'), 'qty' => rtrim(rtrim(number_format($o->qty / 1e8, 8, '.', ''), '0'), '.'), 'status' => $o->status, 'at' => (string) $o->created_at];

        return ['open' => DB::table('spot_limit_orders')->where(['user_id' => $userId, 'status' => 'open'])->orderByDesc('id')->limit(50)->get()->map($fmt)->values(), 'recent' => DB::table('spot_limit_orders')->where('user_id', $userId)->where('status', '!=', 'open')->orderByDesc('id')->limit(15)->get()->map($fmt)->values()];
    }

    public function index(Request $r, LimitOrderService $limits): JsonResponse
    {
        $limits->sweep($r->user()->id);

        return response()->json($this->payload($r->user()->id));
    }

    public function store(Request $r, LimitOrderService $limits): JsonResponse
    {
        $d = $r->validate(['symbol' => ['required', 'regex:/^[A-Z0-9]{2,24}USDT$/'], 'side' => 'required|in:buy,sell', 'price' => ['required', 'regex:/^\d{1,12}(\.\d{1,10})?$/'], 'amount' => ['required', 'regex:/^\d{1,12}(\.\d{1,8})?$/'], 'kind' => 'sometimes|in:limit,tp,sl']);
        try {
            $o = $limits->place($r->user(), $d['symbol'], $d['side'], $d['price'], $d['amount'], null, $d['kind'] ?? 'limit');
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($r->user()->id) + ['placed' => $o->status], 201);
    }

    public function cancel(Request $r, int $id, LimitOrderService $limits): JsonResponse
    {
        try {
            $limits->cancel($r->user(), $id);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($r->user()->id));
    }
}
