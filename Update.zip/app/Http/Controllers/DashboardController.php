<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
class DashboardController extends Controller
{
 public function __invoke()
 {
  $user = Auth::user();
  return inertia('Dashboard', ['user'=>[
   'id'=>(int) $user->id,
   'name'=>(string) $user->name,
   'email'=>(string) $user->email,
   'emailVerified'=>$user->email_verified_at !== null,
  ]]);
 }
}
