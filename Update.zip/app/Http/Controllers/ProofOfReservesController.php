<?php

namespace App\Http\Controllers;

use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Public Proof of Reserves: real user liabilities from the ledger next to the reserves the operator reports. */
class ProofOfReservesController extends Controller
{
    public static function rows(): array
    {
        $liab = DB::table('wallet_balances')->selectRaw('asset, SUM(balance) as total, COUNT(DISTINCT user_id) as users')->where('balance', '>', 0)->groupBy('asset')->get()->keyBy('asset');
        $res = DB::table('por_reserves')->get()->keyBy('asset');
        $assets = collect($liab->keys())->merge($res->keys())->unique()->sort()->values();

        return $assets->map(function ($a) use ($liab, $res) {
            $l = (int) ($liab[$a]->total ?? 0);
            $r = $res[$a] ?? null;
            $reserve = $r ? (float) $r->amount : null;
            $liabF = $l / 1e8;

            return ['asset' => $a, 'liabilities' => Money::format($l, 4), 'users' => (int) ($liab[$a]->users ?? 0), 'reserves' => $reserve === null ? null : rtrim(rtrim(number_format($reserve, 8, '.', ''), '0'), '.'), 'ratio' => $reserve !== null && $liabF > 0 ? round($reserve / $liabF * 100, 2) : null, 'wallet' => $r->wallet ?? null, 'verified' => $r?->verified_at ? \Illuminate\Support\Carbon::parse($r->verified_at)->toDateString() : null];
        })->all();
    }

    public function show()
    {
        return inertia('ProofOfReserves', ['rows' => self::rows(), 'updated' => now()->toIso8601String()]);
    }

    public function admin(Request $r)
    {
        return inertia('Admin/Por', ['admin' => ['name' => $r->user('admin')->name, 'email' => $r->user('admin')->email], 'rows' => self::rows()]);
    }

    public function save(Request $r)
    {
        $d = $r->validate(['asset' => ['required', 'regex:/^[A-Z0-9]{2,16}$/'], 'amount' => 'required|numeric|min:0|max:1000000000000', 'wallet' => 'nullable|string|max:190']);
        DB::table('por_reserves')->updateOrInsert(['asset' => $d['asset']], ['amount' => $d['amount'], 'wallet' => $d['wallet'] ?? null, 'verified_at' => now(), 'updated_at' => now(), 'created_at' => now()]);
        DB::table('admin_audit_logs')->insert(['admin_id' => $r->user('admin')->id, 'action' => 'por.save', 'target_user_id' => null, 'details' => json_encode($d), 'ip' => $r->ip(), 'created_at' => now()]);

        return back()->with('status', "Reserve for {$d['asset']} saved.");
    }
}
