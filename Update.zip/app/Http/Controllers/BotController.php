<?php

namespace App\Http\Controllers;

use App\Models\Bot;
use App\Models\BotClaim;
use App\Models\BotFollow;
use App\Services\BotService;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class BotController extends Controller
{
    public function __construct(private readonly BotService $bots, private readonly LedgerService $ledger)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $this->bots->settleAuto($request->user()->id);

        return response()->json($this->payload($request->user()->id, $this->kind($request)))->header('Cache-Control', 'no-store');
    }

    public function follow(Request $request, int $bot): JsonResponse
    {
        $d = $request->validate(['capital' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'auto_claim' => 'sometimes|boolean', 'idempotency_key' => 'nullable|string|max:64']);

        return $this->run($request, fn () => $this->bots->follow($request->user(), Bot::query()->findOrFail($bot), Money::toUnits($d['capital']), (bool) ($d['auto_claim'] ?? false), $d['idempotency_key'] ?? null));
    }

    public function claim(Request $request, int $bot): JsonResponse
    {
        return $this->run($request, fn () => $this->bots->claim($request->user(), Bot::query()->findOrFail($bot)));
    }

    public function unfollow(Request $request, int $bot): JsonResponse
    {
        return $this->run($request, fn () => $this->bots->unfollow($request->user(), Bot::query()->findOrFail($bot)));
    }

    public function auto(Request $request, int $bot): JsonResponse
    {
        $d = $request->validate(['auto_claim' => 'required|boolean']);

        return $this->run($request, fn () => $this->bots->setAuto($request->user(), Bot::query()->findOrFail($bot), (bool) $d['auto_claim']));
    }

    private function kind(Request $request): string
    {
        return $request->input('kind') === 'trader' ? 'trader' : 'bot';
    }

    private function run(Request $request, callable $action): JsonResponse
    {
        try {
            $action();
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($request->user()->id, $this->kind($request)));
    }

    /** @return array<string, mixed> */
    private function payload(int $userId, string $kind = 'bot'): array
    {
        $ids = Bot::query()->where('kind', $kind)->pluck('id');
        $follows = BotFollow::query()->where('user_id', $userId)->where('status', 'active')->whereIn('bot_id', $ids)->get()->keyBy('bot_id');
        $stats = BotFollow::query()->where('status', 'active')->selectRaw('bot_id, COUNT(*) as followers, SUM(capital) as aum')->groupBy('bot_id')->get()->keyBy('bot_id');
        $all = Bot::query()->where('kind', $kind)->orderBy('sort')->orderBy('id')->get()->filter(fn ($b) => $b->enabled || isset($follows[$b->id]))->values();
        $now = now()->getTimestamp();

        $present = fn (Bot $b) => [
            'id' => $b->id, 'name' => $b->name, 'pair' => $b->pair, 'strategy' => $b->strategy, 'enabled' => $b->enabled, 'bio' => $b->bio, 'direction' => $b->direction, 'leverage' => (int) $b->leverage,
            'dailyYield' => (float) $b->daily_yield_pct, 'profitShare' => (float) $b->profit_share_pct, 'minAmount' => Money::format((int) $b->min_units, 2),
            'followers' => (int) ($stats[$b->id]->followers ?? 0), 'aum' => Money::format((int) ($stats[$b->id]->aum ?? 0), 2),
            'runtimeDays' => max(0, (int) floor(($now - $b->created_at->getTimestamp()) / 86400)), 'following' => isset($follows[$b->id]),
        ];
        $mine = $follows->map(function (BotFollow $f) use ($all, $now) {
            $bot = $all->firstWhere('id', $f->bot_id);
            $cycles = $this->bots->cycles($f);
            $p = $this->bots->payout($f, $bot, max(1, $cycles));
            $remaining = max(0, BotService::CYCLE - (($now - $f->cycle_started_at->getTimestamp()) % BotService::CYCLE));

            return ['botId' => $f->bot_id, 'name' => $bot->name, 'pair' => $bot->pair, 'capital' => Money::format((int) $f->capital, 2), 'autoClaim' => $f->auto_claim,
                'claimableCycles' => $cycles, 'remaining' => $cycles >= 1 ? 0 : $remaining, 'pending' => Money::format($cycles >= 1 ? $p['net'] : 0, 4),
                'nextProfit' => Money::format($this->bots->payout($f, $bot, 1)['net'], 4), 'dailyYield' => (float) $bot->daily_yield_pct, 'profitShare' => (float) $bot->profit_share_pct,
                'since' => $f->created_at?->toIso8601String()];
        })->values();
        $history = BotClaim::query()->where('user_id', $userId)->whereIn('bot_id', $ids)->orderByDesc('id')->limit(100)->get()->map(function ($c) {
            $bot = Bot::query()->find($c->bot_id);

            return ['id' => $c->id, 'bot' => $bot?->name ?? 'Strategy', 'pair' => $bot?->pair ?? '', 'cycles' => $c->cycles, 'capital' => Money::format((int) $c->capital, 2), 'gross' => Money::format((int) $c->gross, 4),
                'share' => Money::format((int) $c->share, 4), 'net' => Money::format((int) $c->net, 4), 'at' => $c->created_at?->toIso8601String()];
        })->values();

        return [
            'bots' => $all->map($present)->values(), 'mine' => $mine, 'history' => $history,
            'kpis' => [
                'active' => $follows->count(), 'aum' => Money::format((int) $follows->sum('capital'), 2),
                'lifetime' => Money::format((int) BotClaim::query()->where('user_id', $userId)->whereIn('bot_id', $ids)->sum('net'), 2),
                'funding' => Money::format($this->ledger->balance($userId, 'funding', 'USDT'), 2),
                'running' => Bot::query()->where('kind', $kind)->where('enabled', true)->count(),
            ],
        ];
    }
}
