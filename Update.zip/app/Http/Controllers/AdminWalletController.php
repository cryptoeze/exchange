<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class AdminWalletController extends Controller
{
    /** Manual credit / debit of a user's wallet by an administrator. Always journaled and audit-logged. */
    public function adjust(Request $request, int $user, LedgerService $ledger): RedirectResponse
    {
        $data = $request->validate([
            'action' => 'required|in:credit,debit',
            'account' => 'required|in:funding,trading,copy',
            'asset' => ['required', 'string', 'regex:/^[A-Z0-9]{2,16}$/'],
            'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'],
            'note' => 'required|string|max:200',
            'idempotency_key' => 'required|string|max:64',
        ]);
        $target = User::query()->findOrFail($user);
        $admin = $request->user('admin');
        $units = Money::toUnits($data['amount']);
        if ($units <= 0) {
            return back()->withErrors(['amount' => 'Amount must be greater than zero.']);
        }
        try {
            DB::transaction(function () use ($ledger, $target, $admin, $data, $units, $request): void {
                $ledger->apply($target->id, $data['account'], $data['asset'], $data['action'] === 'credit' ? $units : -$units,
                    $data['action'] === 'credit' ? 'admin_credit' : 'admin_debit',
                    ['created_by' => $admin->id, 'note' => $data['note'], 'idempotency_key' => "admin:{$admin->id}:{$data['idempotency_key']}"]);
                DB::table('admin_audit_logs')->insert(['admin_id' => $admin->id, 'action' => 'wallet_'.$data['action'], 'target_user_id' => $target->id,
                    'details' => json_encode(['account' => $data['account'], 'asset' => $data['asset'], 'amount' => $data['amount'], 'note' => $data['note']]), 'ip' => $request->ip(), 'created_at' => now()]);
            }, 3);
        } catch (DomainException $e) {
            return back()->withErrors(['amount' => $e->getMessage()]);
        }

        return back()->with('status', ucfirst($data['action']).' of '.$data['amount'].' '.$data['asset'].' applied.');
    }
}
