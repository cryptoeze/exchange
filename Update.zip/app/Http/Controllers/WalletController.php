<?php

namespace App\Http\Controllers;

use App\Models\LedgerEntry;
use App\Models\WalletBalance;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class WalletController extends Controller
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function index(Request $request): JsonResponse
    {
        return response()->json($this->payload($request->user()->id, in_array($request->query('account'), ['funding', 'trading'], true) ? (string) $request->query('account') : 'funding'))->header('Cache-Control', 'no-store');
    }

    public function transfer(Request $request): JsonResponse
    {
        $data = $request->validate([
            'from' => 'required|in:funding,trading',
            'to' => 'required|in:funding,trading|different:from',
            'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'],
            'idempotency_key' => 'nullable|string|max:64',
        ]);
        $userId = $request->user()->id;
        $units = Money::toUnits($data['amount']);
        $asset = (string) config('trading.quote_asset');
        $key = $data['idempotency_key'] ?? null;
        try {
            DB::transaction(function () use ($userId, $data, $units, $asset, $key): void {
                $this->ledger->apply($userId, $data['from'], $asset, -$units, 'transfer_out', ['note' => 'to '.$data['to'], 'idempotency_key' => $key ? "{$userId}:{$key}:out" : null]);
                $this->ledger->apply($userId, $data['to'], $asset, $units, 'transfer_in', ['note' => 'from '.$data['from'], 'idempotency_key' => $key ? "{$userId}:{$key}:in" : null]);
            }, 3);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($userId));
    }

    /** @return array<string, mixed> */
    public function payload(int $userId, string $account = 'funding'): array
    {
        $balances = WalletBalance::query()->where('user_id', $userId)->orderBy('account')->orderBy('asset')->get()
            ->map(fn ($row) => ['account' => $row->account, 'asset' => $row->asset, 'balance' => Money::format((int) $row->balance, 2), 'units' => (int) $row->balance])->values();
        $labels = ['deposit' => 'Deposit', 'deposit_bonus' => 'Deposit bonus', 'admin_credit' => 'Received', 'admin_debit' => 'Adjustment', 'transfer_in' => 'Transfer in', 'transfer_out' => 'Transfer out', 'withdrawal' => 'Withdrawal', 'withdrawal_hold' => 'Withdrawal', 'withdrawal_refund' => 'Withdrawal refunded', 'convert_out' => 'Convert', 'convert_in' => 'Convert', 'earn_stake' => 'Stake', 'earn_unstake' => 'Unstake', 'earn_interest' => 'Earn interest', 'bot_allocate' => 'Bot allocation', 'bot_release' => 'Bot capital returned', 'bot_profit' => 'Bot profit', 'spot_buy' => 'Fulfill an order', 'spot_sell' => 'Fulfill an order'];
        $history = LedgerEntry::query()->where('user_id', $userId)->where('account', $account)->orderByDesc('id')->limit(12)->get()
            ->map(fn ($row) => ['id' => $row->id, 'title' => trim(($labels[$row->type] ?? $row->type).' '.$row->asset), 'type' => $row->type, 'asset' => $row->asset,
                'amount' => Money::format((int) $row->amount, 4), 'positive' => $row->amount > 0, 'at' => $row->created_at?->toIso8601String()])->values();

        return ['balances' => $balances, 'history' => $history, 'serverTime' => now()->toIso8601String()];
    }
}
