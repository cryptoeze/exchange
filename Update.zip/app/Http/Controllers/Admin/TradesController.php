<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Concerns\AdminHelpers;
use App\Http\Controllers\Controller;
use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/** Admin → Spot trades: every filled spot order (market, limit, take-profit, stop-loss) with volume and fee totals. */
final class TradesController extends Controller
{
    use AdminHelpers;

    public function index(Request $r)
    {
        $q = trim((string) $r->query('q', ''));
        $symbol = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $r->query('symbol', '')));
        $side = $this->pick($r, 'side', ['buy', 'sell']);
        $id = ctype_digit((string) $r->query('id', '')) ? (int) $r->query('id') : 0;

        $query = DB::table('spot_orders as o')->join('users as u', 'u.id', '=', 'o.user_id')
            ->select(['o.id', 'o.user_id', 'u.email', 'u.name', 'o.symbol', 'o.base_asset', 'o.side', 'o.price_micro', 'o.base_qty', 'o.quote_total', 'o.fee', 'o.status', 'o.created_at']);
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($w) => $w->where('u.email', 'like', $this->like($q))->orWhere('u.name', 'like', $this->like($q))->orWhere('u.id', $digits));
        }
        $symbol && $query->where('o.symbol', 'like', $symbol.'%');
        $side && $query->where('o.side', $side);
        $id && $query->where('o.id', $id);
        $this->dateRange($query, $r, 'o.created_at');

        if ($r->boolean('export')) {
            return $this->csv('spot-trades', ['ID', 'Time', 'User', 'Pair', 'Side', 'Price', 'Amount', 'Total USDT', 'Fee USDT', 'Status'],
                (clone $query)->orderByDesc('o.id')->limit(50000)->get()->map(fn ($o) => [$o->id, $o->created_at, $o->email, $o->symbol, $o->side, $this->units($o->price_micro, 8), $this->units($o->base_qty, 8), Money::format((int) $o->quote_total, 2), Money::format((int) $o->fee, 4), $o->status]));
        }

        $totals = (clone $query)->reorder()->selectRaw('COUNT(*) as n, COALESCE(SUM(o.quote_total),0) as vol, COALESCE(SUM(o.fee),0) as fees')->first();
        $day = DB::table('spot_orders')->where('created_at', '>=', Carbon::now()->subDay());
        [$items, $pager] = $this->paged($query->orderByDesc('o.id'), $r, 30);

        return inertia('Admin/Trades', ['admin' => $this->adminProps($r), 'pager' => $pager,
            'filters' => ['q' => $q, 'symbol' => $symbol, 'side' => $side, 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))],
            'stats' => ['dayOrders' => (clone $day)->count(), 'dayVolume' => Money::format((int) (clone $day)->sum('quote_total'), 2), 'dayFees' => Money::format((int) (clone $day)->sum('fee'), 4), 'dayTraders' => (clone $day)->distinct('user_id')->count('user_id'),
                'matchCount' => (int) $totals->n, 'matchVolume' => Money::format((int) $totals->vol, 2), 'matchFees' => Money::format((int) $totals->fees, 4)],
            'rows' => $items->map(fn ($o) => ['id' => $o->id, 'userId' => $o->user_id, 'email' => $o->email, 'name' => $o->name, 'symbol' => $o->symbol, 'side' => $o->side, 'price' => $this->units($o->price_micro, 8), 'qty' => $this->units($o->base_qty, 8).' '.$o->base_asset, 'total' => Money::format((int) $o->quote_total, 2), 'fee' => Money::format((int) $o->fee, 4), 'status' => $o->status, 'at' => substr((string) $o->created_at, 0, 19)])->values()]);
    }
}
