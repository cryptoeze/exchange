<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Concerns\AdminHelpers;
use App\Http\Controllers\Controller;
use App\Support\LedgerCategory;
use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Admin → Transactions: every balance movement on the platform (the append-only ledger) in one filterable list.
 * Deposits, withdrawals, transfers, trades, bonuses, admin adjustments … all land here with the same shape.
 */
final class TransactionsController extends Controller
{
    use AdminHelpers;

    private const COLUMNS = ['l.id', 'l.user_id', 'u.email', 'u.name', 'l.type', 'l.account', 'l.asset', 'l.amount', 'l.balance_after', 'l.ref_type', 'l.ref_id', 'l.note', 'l.created_by', 'l.created_at'];

    private function filtered(Request $r): array
    {
        $q = trim((string) $r->query('q', ''));
        $cat = $this->pick($r, 'cat', array_keys(LedgerCategory::MAP));
        $asset = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $r->query('asset', '')));
        $account = $this->pick($r, 'account', \App\Services\LedgerService::ACCOUNTS);
        $dir = $this->pick($r, 'dir', ['in', 'out']);
        $type = preg_replace('/[^a-z0-9_]/', '', strtolower((string) $r->query('type', '')));
        $min = preg_match('/^\d{1,10}(\.\d{1,8})?$/', (string) $r->query('min', '')) ? Money::toUnits((string) $r->query('min')) : 0;

        // No ->select() here: the summary totals below run selectRaw() on a clone of this query, and Laravel's
        // selectRaw() *appends* to an existing select instead of replacing it. With real columns already picked,
        // that mixes plain columns with COUNT()/SUM() and no GROUP BY — MySQL (strict mode) rejects it with
        // "Mixing of GROUP columns ... is illegal" (SQLite silently tolerates it, which hid this in testing).
        // Columns are applied explicitly at each call site instead (self::COLUMNS below).
        $query = DB::table('ledger_entries as l')->join('users as u', 'u.id', '=', 'l.user_id');
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($w) => $w->where('u.email', 'like', $this->like($q))->orWhere('u.name', 'like', $this->like($q))->orWhere('u.id', $digits)->orWhere('u.id', $digits >= 100000 ? $digits - 100000 : 0));
        }
        $cat && $query->where(fn ($w) => LedgerCategory::scope($w, $cat));
        $type && $query->where('l.type', $type);
        $asset && $query->where('l.asset', $asset);
        $account && $query->where('l.account', $account);
        $dir === 'in' && $query->where('l.amount', '>', 0);
        $dir === 'out' && $query->where('l.amount', '<', 0);
        $min > 0 && $query->whereRaw('ABS(l.amount) >= ?', [$min]);
        $this->dateRange($query, $r, 'l.created_at');

        return [$query, ['q' => $q, 'cat' => $cat, 'type' => $type, 'asset' => $asset, 'account' => $account, 'dir' => $dir, 'min' => $min > 0 ? (string) $r->query('min') : '', 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))]];
    }

    private function refLink(?string $type, ?int $id): ?string
    {
        if (! $type || ! $id) {
            return null;
        }

        return match ($type) {
            'withdrawal' => '/admin/withdrawals?status=all&id='.$id,
            'manual_deposit' => '/admin/deposits?tab=all&id='.$id,
            'spot_order' => '/admin/trades?id='.$id,
            'limit_order' => '/admin/orders?status=open',
            'futures_position' => '/admin/futures',
            'p2p_trade' => '/admin/p2p',
            default => null,
        };
    }

    public function index(Request $r)
    {
        [$query, $filters] = $this->filtered($r);
        $query->orderByDesc('l.id');
        $admins = fn ($rows) => DB::table('users')->whereIn('id', $rows->pluck('created_by')->filter()->unique())->pluck('email', 'id');

        if ($r->boolean('export')) {
            $rows = (clone $query)->select(self::COLUMNS)->limit(50000)->get();
            $by = $admins($rows);

            return $this->csv('transactions', ['ID', 'Time', 'User ID', 'Email', 'Category', 'Type', 'Account', 'Asset', 'Amount', 'Balance after', 'Note', 'By admin'],
                $rows->map(fn ($l) => [$l->id, $l->created_at, $l->user_id, $l->email, LedgerCategory::of($l->type), $l->type, $l->account, $l->asset, Money::format((int) $l->amount, 2), Money::format((int) $l->balance_after, 2), $l->note, $by[$l->created_by] ?? '']));
        }

        $sumAsset = $filters['asset'] ?: 'USDT';
        $sums = (clone $query)->reorder()->where('l.asset', $sumAsset)->selectRaw('COALESCE(SUM(CASE WHEN l.amount > 0 THEN l.amount ELSE 0 END),0) as cin, COALESCE(SUM(CASE WHEN l.amount < 0 THEN l.amount ELSE 0 END),0) as cout')->first();
        [$items, $pager] = $this->paged($query->select(self::COLUMNS), $r, 30);
        $by = $admins($items);
        $types = DB::table('ledger_entries')->distinct()->orderBy('type')->pluck('type')->values();
        $assets = DB::table('ledger_entries')->distinct()->orderBy('asset')->pluck('asset')->values();

        return inertia('Admin/Transactions', ['admin' => $this->adminProps($r), 'filters' => $filters, 'pager' => $pager, 'types' => $types, 'assets' => $assets, 'categories' => LedgerCategory::options(), 'accounts' => \App\Services\LedgerService::ACCOUNTS,
            'summary' => ['asset' => $sumAsset, 'in' => Money::format((int) $sums->cin, 2), 'out' => Money::format((int) $sums->cout, 2), 'net' => Money::format((int) $sums->cin + (int) $sums->cout, 2)],
            'rows' => $items->map(fn ($l) => ['id' => $l->id, 'userId' => $l->user_id, 'email' => $l->email, 'name' => $l->name, 'category' => LedgerCategory::of($l->type), 'type' => $l->type, 'account' => $l->account, 'asset' => $l->asset, 'amount' => $this->units($l->amount, 4), 'after' => $this->units($l->balance_after, 4),
                'note' => $l->note, 'by' => $by[$l->created_by] ?? null, 'ref' => $this->refLink($l->ref_type, $l->ref_id), 'at' => substr((string) $l->created_at, 0, 19)])->values()]);
    }
}
