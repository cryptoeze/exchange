<?php

namespace App\Http\Controllers\Admin\Concerns;

use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Shared plumbing for the admin controllers: the admin header props, audit logging, pagination with the
 * { page, last, total, per } shape the frontend Pager expects, date-range filters and money formatting.
 * New admin controllers should `use AdminHelpers;` instead of re-implementing these.
 */
trait AdminHelpers
{
    protected function adminProps(Request $r): array
    {
        return ['name' => $r->user('admin')->name, 'email' => $r->user('admin')->email];
    }

    protected function audit(Request $r, string $action, ?int $userId = null, array $details = []): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $r->user('admin')->id, 'action' => $action, 'target_user_id' => $userId, 'details' => json_encode($details), 'ip' => $r->ip(), 'created_at' => now()]);
    }

    /** Run a query builder through offset pagination. @return array{0: \Illuminate\Support\Collection, 1: array{page:int,last:int,total:int,per:int}} */
    protected function paged($query, Request $r, int $per = 25): array
    {
        $base = method_exists($query, 'toBase') ? $query->toBase() : $query;
        $total = (int) (clone $base)->reorder()->getCountForPagination();
        $last = max(1, (int) ceil($total / $per));
        $page = min(max(1, (int) $r->query('page', 1)), $last);
        $items = $query->forPage($page, $per)->get();

        return [$items, ['page' => $page, 'last' => $last, 'total' => $total, 'per' => $per]];
    }

    /** Apply ?from=YYYY-MM-DD&to=YYYY-MM-DD (inclusive) to a column. */
    protected function dateRange($query, Request $r, string $column)
    {
        $from = $this->day($r->query('from'));
        $to = $this->day($r->query('to'));
        if ($from) {
            $query->where($column, '>=', $from.' 00:00:00');
        }
        if ($to) {
            $query->where($column, '<=', $to.' 23:59:59');
        }

        return $query;
    }

    protected function day(mixed $v): ?string
    {
        return is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : null;
    }

    /** Units (1e-8) → "1,234.56" style trimmed string. */
    protected function units(int|string|null $u, int $dp = 4): string
    {
        $s = Money::format((int) $u, $dp);

        return str_contains($s, '.') ? rtrim(rtrim($s, '0'), '.') : $s;
    }

    protected function like(string $q): string
    {
        return '%'.str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q).'%';
    }

    /** Clean string filter from the query string, limited to an allow-list (returns '' when not allowed). */
    protected function pick(Request $r, string $key, array $allowed): string
    {
        $v = (string) $r->query($key, '');

        return in_array($v, $allowed, true) ? $v : '';
    }

    /** CSV download of already-mapped rows. */
    protected function csv(string $name, array $header, iterable $rows): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        return response()->streamDownload(function () use ($header, $rows): void {
            $out = fopen('php://output', 'w');
            fputcsv($out, $header);
            foreach ($rows as $row) {
                fputcsv($out, array_map(fn ($c) => is_string($c) && preg_match('/^[=+\-@]/', $c) ? "'".$c : $c, (array) $row));
            }
            fclose($out);
        }, $name.'-'.date('Ymd-His').'.csv', ['Content-Type' => 'text/csv']);
    }
}
