<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Concerns\AdminHelpers;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\LedgerService;
use App\Services\NotificationService;
use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Admin → Users. The list is the directory; show() is the "User 360" page where everything about one account lives:
 * wallet (credit/debit + ledger), deposits, withdrawals, trading, P2P, KYC, security, referrals, support and account controls.
 * Each tab loads only its own data (?tab=…), so the page stays fast and a new tab is one method + one entry in TABS.
 */
final class UsersController extends Controller
{
    use AdminHelpers;

    public const TABS = ['overview', 'wallet', 'deposits', 'withdrawals', 'trading', 'p2p', 'kyc', 'security', 'referrals', 'support', 'manage'];
    private const UID_BASE = 100000;

    /* ───────────────────────── Directory ───────────────────────── */

    private function directory(Request $r)
    {
        $q = trim((string) $r->query('q', ''));
        $status = $this->pick($r, 'status', ['active', 'frozen']);
        $kyc = $this->pick($r, 'kyc', ['none', 'pending', 'approved', 'rejected']);
        $verified = $this->pick($r, 'verified', ['yes', 'no']);
        $sort = $this->pick($r, 'sort', ['newest', 'oldest', 'balance', 'name']) ?: 'newest';

        $fund = fn (string $acct) => DB::table('wallet_balances')->selectRaw('COALESCE(SUM(balance),0)')->whereColumn('user_id', 'users.id')->where('asset', 'USDT')->where('account', $acct);
        $query = User::query()->where('role', '!=', 'admin')
            ->select(['id', 'name', 'email', 'status', 'kyc_status', 'referral_code', 'created_at', 'email_verified_at'])
            ->selectSub($fund('funding'), 'funding_units')
            ->selectSub(DB::table('wallet_balances')->selectRaw('COALESCE(SUM(balance),0)')->whereColumn('user_id', 'users.id')->where('asset', 'USDT')->whereNotIn('account', ['hold']), 'total_units')
            ->selectSub(DB::table('login_events')->selectRaw('MAX(created_at)')->whereColumn('user_id', 'users.id')->where('success', true)->where('area', 'web'), 'last_login');
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($w) => $w->where('email', 'like', $this->like($q))->orWhere('name', 'like', $this->like($q))->orWhere('referral_code', strtoupper($q))
                ->orWhere('id', $digits)->orWhere('id', $digits >= self::UID_BASE ? $digits - self::UID_BASE : 0));
        }
        $status && $query->where('status', $status);
        $kyc && $query->where('kyc_status', $kyc);
        $verified === 'yes' && $query->whereNotNull('email_verified_at');
        $verified === 'no' && $query->whereNull('email_verified_at');
        $this->dateRange($query, $r, 'created_at');
        match ($sort) {
            'oldest' => $query->orderBy('id'),
            'balance' => $query->orderByDesc('total_units'),
            'name' => $query->orderBy('name'),
            default => $query->orderByDesc('id'),
        };

        return [$query, ['q' => $q, 'status' => $status, 'kyc' => $kyc, 'verified' => $verified, 'sort' => $sort, 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))]];
    }

    private function row(object $u): array
    {
        return ['id' => $u->id, 'uid' => self::UID_BASE + $u->id, 'name' => $u->name, 'email' => $u->email, 'status' => $u->status ?: 'active', 'kyc' => $u->kyc_status ?: 'none', 'verified' => $u->email_verified_at !== null,
            'funding' => Money::format((int) $u->funding_units, 2), 'total' => Money::format((int) $u->total_units, 2), 'lastLogin' => $u->last_login ? substr((string) $u->last_login, 0, 16) : null, 'joined' => $u->created_at?->format('Y-m-d')];
    }

    public function index(Request $r)
    {
        [$query, $filters] = $this->directory($r);
        if ($r->boolean('export')) {
            return $this->csv('users', ['ID', 'UID', 'Name', 'Email', 'Status', 'KYC', 'Email verified', 'Funding USDT', 'Total USDT', 'Last login', 'Joined'],
                (clone $query)->limit(20000)->get()->map(function ($u) {
                    $x = $this->row($u);

                    return [$x['id'], $x['uid'], $x['name'], $x['email'], $x['status'], $x['kyc'], $x['verified'] ? 'yes' : 'no', $x['funding'], $x['total'], $x['lastLogin'], $x['joined']];
                }));
        }
        [$items, $pager] = $this->paged($query, $r, 25);
        $base = User::query()->where('role', '!=', 'admin');

        return inertia('Admin/Users', ['admin' => $this->adminProps($r), 'filters' => $filters, 'pager' => $pager,
            'stats' => ['total' => (clone $base)->count(), 'today' => (clone $base)->where('created_at', '>=', Carbon::today())->count(), 'week' => (clone $base)->where('created_at', '>=', Carbon::now()->subDays(7))->count(),
                'frozen' => (clone $base)->where('status', 'frozen')->count(), 'kycPending' => (clone $base)->where('kyc_status', 'pending')->count(), 'kycApproved' => (clone $base)->where('kyc_status', 'approved')->count(), 'unverified' => (clone $base)->whereNull('email_verified_at')->count()],
            'rows' => $items->map(fn ($u) => $this->row($u))->values()]);
    }

    /* ───────────────────────── User 360 ───────────────────────── */

    public function show(Request $r, int $user)
    {
        $u = User::query()->findOrFail($user);
        $tab = $this->pick($r, 'tab', self::TABS) ?: 'overview';
        $id = $u->id;
        $sumLedger = fn (string $type, string $assets = 'USDT') => (int) DB::table('ledger_entries')->where('user_id', $id)->where('type', $type)->whereIn('asset', explode(',', $assets))->sum('amount');
        $bal = fn (string $account) => (int) DB::table('wallet_balances')->where(['user_id' => $id, 'account' => $account, 'asset' => 'USDT'])->value('balance');
        $totalUsdt = (int) DB::table('wallet_balances')->where(['user_id' => $id, 'asset' => 'USDT'])->where('account', '!=', 'hold')->sum('balance');
        $last = DB::table('login_events')->where('user_id', $id)->where('success', true)->where('area', 'web')->orderByDesc('id')->first();
        $counts = [
            'deposits' => DB::table('manual_deposits')->where(['user_id' => $id, 'status' => 'pending'])->count(),
            'withdrawals' => DB::table('withdrawals')->where(['user_id' => $id, 'status' => 'pending'])->count(),
            'kyc' => DB::table('kyc_submissions')->where(['user_id' => $id, 'status' => 'pending'])->count(),
            'support' => DB::table('tickets')->where('user_id', $id)->where('status', 'open')->count(),
        ];
        $referredBy = $u->referred_by ? User::query()->whereKey($u->referred_by)->first(['id', 'email', 'name']) : null;

        return inertia('Admin/UserShow', [
            'admin' => $this->adminProps($r), 'tab' => $tab, 'counts' => $counts,
            'user' => ['id' => $u->id, 'uid' => self::UID_BASE + $u->id, 'name' => $u->name, 'email' => $u->email, 'role' => $u->role, 'status' => $u->status ?: 'active', 'kyc' => $u->kyc_status ?: 'none', 'verified' => $u->email_verified_at !== null,
                'phone' => $u->phone, 'country' => $u->country, 'twoFactor' => (bool) ($u->two_factor_enabled ?? false), 'joined' => $u->created_at?->format('Y-m-d H:i'), 'referralCode' => $u->referral_code, 'referredBy' => $referredBy ? ['id' => $referredBy->id, 'label' => $referredBy->email] : null],
            'summary' => ['totalUsdt' => Money::format($totalUsdt, 2), 'funding' => Money::format($bal('funding'), 2), 'trading' => Money::format($bal('trading'), 2), 'futures' => Money::format($bal('futures'), 2),
                'deposited' => Money::format($sumLedger('deposit', 'USDT,USDC'), 2), 'withdrawn' => Money::format((int) DB::table('withdrawals')->where(['user_id' => $id, 'status' => 'completed'])->whereIn('asset', ['USDT', 'USDC'])->sum('amount'), 2),
                'spotTrades' => DB::table('spot_orders')->where('user_id', $id)->count(), 'futuresTrades' => DB::table('futures_positions')->where('user_id', $id)->count(), 'openPositions' => DB::table('futures_positions')->where(['user_id' => $id, 'status' => 'open'])->count(),
                'invited' => User::query()->where('referred_by', $id)->count(), 'lastLogin' => $last ? substr((string) $last->created_at, 0, 16) : null, 'lastIp' => $last->ip ?? null],
            'data' => $this->{'tab'.ucfirst($tab)}($r, $u),
        ]);
    }

    private function tabOverview(Request $r, User $u): array
    {
        $ledger = DB::table('ledger_entries')->where('user_id', $u->id)->orderByDesc('id')->limit(8)->get();
        $logins = DB::table('login_events')->where('user_id', $u->id)->orderByDesc('id')->limit(5)->get();
        $kyc = DB::table('kyc_submissions')->where('user_id', $u->id)->orderByDesc('id')->first();

        return ['ledger' => $ledger->map(fn ($l) => $this->ledgerRow($l))->values(), 'logins' => $logins->map(fn ($e) => $this->loginRow($e))->values(),
            'kyc' => $kyc ? ['id' => $kyc->id, 'status' => $kyc->status, 'name' => $kyc->full_name, 'country' => $kyc->country, 'at' => (string) $kyc->created_at] : null];
    }

    private function ledgerRow(object $l): array
    {
        return ['id' => $l->id, 'type' => $l->type, 'account' => $l->account, 'asset' => $l->asset, 'amount' => $this->units($l->amount, 4), 'after' => $this->units($l->balance_after, 4), 'note' => $l->note, 'at' => substr((string) $l->created_at, 0, 16)];
    }

    private function loginRow(object $e): array
    {
        return ['id' => $e->id, 'ok' => (bool) $e->success, 'area' => $e->area, 'note' => $e->note, 'ip' => $e->ip, 'agent' => $e->agent, 'at' => substr((string) $e->created_at, 0, 16)];
    }

    private function tabWallet(Request $r, User $u): array
    {
        $balances = DB::table('wallet_balances')->where('user_id', $u->id)->orderBy('account')->orderBy('asset')->get()
            ->filter(fn ($b) => (int) $b->balance !== 0)->map(fn ($b) => ['account' => $b->account, 'asset' => $b->asset, 'balance' => $this->units($b->balance, 4)])->values();
        $query = DB::table('ledger_entries')->where('user_id', $u->id)->orderByDesc('id');
        $asset = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $r->query('asset', '')));
        $category = (string) $r->query('cat', '');
        $asset && $query->where('asset', $asset);
        if ($category !== '' && isset(\App\Support\LedgerCategory::MAP[$category])) {
            $query->where(fn ($w) => \App\Support\LedgerCategory::scope($w, $category));
        }
        $this->dateRange($query, $r, 'created_at');
        [$items, $pager] = $this->paged($query, $r, 20);

        return ['balances' => $balances, 'accounts' => ['funding', 'trading', 'copy'], 'assets' => DB::table('wallet_balances')->where('user_id', $u->id)->distinct()->pluck('asset')->values(),
            'categories' => \App\Support\LedgerCategory::options(), 'filters' => ['asset' => $asset, 'cat' => $category, 'from' => (string) $this->day($r->query('from')), 'to' => (string) $this->day($r->query('to'))],
            'ledger' => $items->map(fn ($l) => $this->ledgerRow($l))->values(), 'pager' => $pager];
    }

    private function tabDeposits(Request $r, User $u): array
    {
        $sub = $this->pick($r, 'sub', ['manual', 'auto']) ?: 'manual';
        if ($sub === 'auto') {
            [$items, $pager] = $this->paged(DB::table('deposits')->where('user_id', $u->id)->orderByDesc('id'), $r, 15);
            $rows = $items->map(fn ($d) => ['id' => $d->id, 'asset' => $d->asset, 'network' => $d->network, 'amount' => $d->paid_amount ?: ($d->expected_amount ?: '—'), 'credited' => $this->units($d->credited_units, 4), 'status' => $d->status, 'ref' => $d->tx_hash, 'at' => substr((string) $d->created_at, 0, 16)]);
        } else {
            [$items, $pager] = $this->paged(DB::table('manual_deposits')->where('user_id', $u->id)->orderByDesc('id'), $r, 15);
            $rows = $items->map(fn ($d) => ['id' => $d->id, 'asset' => $d->asset, 'network' => $d->network, 'amount' => $this->units($d->claimed, 8), 'credited' => $d->credited !== null ? $this->units($d->credited, 4) : null, 'status' => $d->status, 'ref' => $d->txid, 'at' => substr((string) $d->created_at, 0, 16), 'reason' => $d->reason]);
        }

        return ['sub' => $sub, 'rows' => $rows->values(), 'pager' => $pager];
    }

    private function tabWithdrawals(Request $r, User $u): array
    {
        [$items, $pager] = $this->paged(DB::table('withdrawals')->where('user_id', $u->id)->orderByDesc('id'), $r, 15);

        return ['rows' => $items->map(fn ($w) => ['id' => $w->id, 'asset' => $w->asset, 'network' => $w->network, 'address' => $w->address, 'amount' => $this->units($w->amount, 4), 'fee' => $this->units($w->fee, 4), 'net' => $this->units($w->net, 4), 'status' => $w->status, 'tx' => $w->tx_hash, 'reason' => $w->reason, 'at' => substr((string) $w->created_at, 0, 16)])->values(), 'pager' => $pager];
    }

    private function tabTrading(Request $r, User $u): array
    {
        $sub = $this->pick($r, 'sub', ['spot', 'futures', 'limit', 'earn', 'bots']) ?: 'spot';
        $id = $u->id;
        $at = fn ($v) => substr((string) $v, 0, 16);
        switch ($sub) {
            case 'futures':
                [$items, $pager] = $this->paged(DB::table('futures_positions')->where('user_id', $id)->orderByDesc('id'), $r, 15);
                $rows = $items->map(fn ($p) => ['id' => $p->id, 'a' => $p->symbol, 'b' => strtoupper($p->side).' '.$p->leverage.'x', 'c' => $this->units($p->margin, 2), 'd' => $p->status.($p->close_reason ? ' · '.$p->close_reason : ''), 'e' => $p->pnl !== null ? $this->units($p->pnl, 2) : '—', 'at' => $at($p->created_at)]);
                $head = ['Pair', 'Side', 'Margin', 'Status', 'PnL', 'Opened'];
                break;
            case 'limit':
                [$items, $pager] = $this->paged(DB::table('spot_limit_orders')->where('user_id', $id)->orderByDesc('id'), $r, 15);
                $rows = $items->map(fn ($o) => ['id' => $o->id, 'a' => $o->symbol, 'b' => ucfirst($o->side).' · '.strtoupper($o->kind ?? 'limit'), 'c' => rtrim(rtrim(number_format((float) $o->limit_price, 8, '.', ''), '0'), '.'), 'd' => $o->status, 'e' => $this->units($o->qty, 8), 'at' => $at($o->created_at)]);
                $head = ['Pair', 'Type', 'Price', 'Status', 'Amount', 'Placed'];
                break;
            case 'earn':
                [$items, $pager] = $this->paged(DB::table('earn_positions')->join('earn_products', 'earn_products.id', '=', 'earn_positions.earn_product_id')->where('earn_positions.user_id', $id)->orderByDesc('earn_positions.id')->select(['earn_positions.id', 'earn_products.name', 'earn_products.asset', 'earn_products.apr_pct', 'earn_positions.principal', 'earn_positions.created_at']), $r, 15);
                $rows = $items->map(fn ($e) => ['id' => $e->id, 'a' => $e->name, 'b' => $e->asset, 'c' => $this->units($e->principal, 4), 'd' => rtrim(rtrim((string) $e->apr_pct, '0'), '.').'% APR', 'e' => '—', 'at' => $at($e->created_at)]);
                $head = ['Product', 'Asset', 'Staked', 'Rate', '', 'Since'];
                break;
            case 'bots':
                [$items, $pager] = $this->paged(DB::table('bot_follows')->join('bots', 'bots.id', '=', 'bot_follows.bot_id')->where('bot_follows.user_id', $id)->orderByDesc('bot_follows.id')->select(['bot_follows.id', 'bots.name', 'bots.pair', 'bot_follows.capital', 'bot_follows.status', 'bot_follows.created_at']), $r, 15);
                $rows = $items->map(fn ($b) => ['id' => $b->id, 'a' => $b->name, 'b' => $b->pair, 'c' => $this->units($b->capital, 2), 'd' => $b->status, 'e' => '—', 'at' => $at($b->created_at)]);
                $head = ['Bot', 'Pair', 'Capital', 'Status', '', 'Since'];
                break;
            default:
                [$items, $pager] = $this->paged(DB::table('spot_orders')->where('user_id', $id)->orderByDesc('id'), $r, 15);
                $rows = $items->map(fn ($o) => ['id' => $o->id, 'a' => $o->symbol, 'b' => ucfirst($o->side), 'c' => $this->units($o->quote_total, 2), 'd' => $o->status, 'e' => $this->units($o->fee, 4), 'at' => $at($o->created_at)]);
                $head = ['Pair', 'Side', 'Total (USDT)', 'Status', 'Fee', 'Time'];
        }

        return ['sub' => $sub, 'head' => $head, 'rows' => $rows->values(), 'pager' => $pager];
    }

    private function tabP2p(Request $r, User $u): array
    {
        $trades = DB::table('p2p_trades')->where(fn ($w) => $w->where('buyer_id', $u->id)->orWhere('seller_id', $u->id))->orderByDesc('id');
        [$items, $pager] = $this->paged($trades, $r, 15);

        return ['rows' => $items->map(fn ($t) => ['ref' => $t->ref, 'role' => (int) $t->buyer_id === $u->id ? 'Buyer' : 'Seller', 'coin' => $t->coin, 'qty' => $this->units($t->qty, 4), 'fiat' => $t->fiat.' '.number_format((float) $t->fiat_amount, 2), 'method' => $t->method, 'status' => $t->status, 'at' => substr((string) $t->created_at, 0, 16)])->values(), 'pager' => $pager,
            'ads' => DB::table('p2p_ads')->where('user_id', $u->id)->orderByDesc('id')->limit(10)->get()->map(fn ($a) => ['id' => $a->id, 'side' => $a->side, 'coin' => $a->coin, 'fiat' => $a->fiat, 'price' => $a->price, 'available' => $this->units($a->available, 4), 'status' => $a->status])->values()];
    }

    private function tabKyc(Request $r, User $u): array
    {
        return ['rows' => DB::table('kyc_submissions')->where('user_id', $u->id)->orderByDesc('id')->get()->map(fn ($k) => ['id' => $k->id, 'status' => $k->status, 'name' => $k->full_name, 'country' => $k->country, 'phone' => $k->phone ?? null, 'docType' => $k->doc_type, 'docNumber' => $k->doc_number, 'hasBack' => (bool) ($k->back_path ?? null), 'reason' => $k->reason, 'at' => substr((string) $k->created_at, 0, 16)])->values()];
    }

    private function tabSecurity(Request $r, User $u): array
    {
        [$items, $pager] = $this->paged(DB::table('login_events')->where('user_id', $u->id)->orderByDesc('id'), $r, 15);

        return ['rows' => $items->map(fn ($e) => $this->loginRow($e))->values(), 'pager' => $pager, 'twoFactor' => (bool) ($u->two_factor_enabled ?? false),
            'sessions' => Schema::hasTable('sessions') ? DB::table('sessions')->where('user_id', $u->id)->count() : 0];
    }

    private function tabReferrals(Request $r, User $u): array
    {
        [$items, $pager] = $this->paged(User::query()->where('referred_by', $u->id)->orderByDesc('id'), $r, 15);
        $earned = DB::table('referral_rewards')->where('referrer_id', $u->id)->selectRaw('asset, SUM(amount) as total, COUNT(*) as n')->groupBy('asset')->get();

        return ['rows' => $items->map(fn ($f) => ['id' => $f->id, 'name' => $f->name, 'email' => $f->email, 'kyc' => $f->kyc_status ?: 'none', 'joined' => $f->created_at?->format('Y-m-d')])->values(), 'pager' => $pager,
            'earned' => $earned->map(fn ($e) => ['asset' => $e->asset, 'total' => $this->units($e->total, 4), 'n' => $e->n])->values(), 'code' => $u->referral_code];
    }

    private function tabSupport(Request $r, User $u): array
    {
        [$items, $pager] = $this->paged(DB::table('tickets')->where('user_id', $u->id)->orderByDesc('id'), $r, 15);

        return ['rows' => $items->map(fn ($t) => ['id' => $t->id, 'subject' => $t->subject, 'category' => $t->category, 'status' => $t->status, 'at' => substr((string) $t->created_at, 0, 16)])->values(), 'pager' => $pager,
            'notifications' => DB::table('user_notifications')->where('user_id', $u->id)->orderByDesc('id')->limit(8)->get()->map(fn ($n) => ['id' => $n->id, 'title' => $n->title, 'read' => $n->read_at !== null, 'at' => substr((string) $n->created_at, 0, 16)])->values()];
    }

    private function tabManage(Request $r, User $u): array
    {
        return ['isAdmin' => $u->role === 'admin'];
    }

    /* ───────────────────────── Actions ───────────────────────── */

    public function notify(Request $r, int $user)
    {
        $u = User::query()->findOrFail($user);
        $d = $r->validate(['title' => 'required|string|max:140', 'body' => 'nullable|string|max:1000']);
        NotificationService::send($u->id, $d['title'], $d['body'] ?? null, 'info', '/notifications');
        $this->audit($r, 'user.notify', $u->id, ['title' => $d['title']]);

        return back()->with('status', 'Message sent to '.$u->email.'.');
    }

    public function reset2fa(Request $r, int $user)
    {
        $u = User::query()->findOrFail($user);
        abort_if($u->role === 'admin', 403);
        $u->forceFill(['two_factor_enabled' => false, 'two_factor_secret' => null, 'two_factor_recovery' => null])->save();
        $this->audit($r, 'user.2fa_reset', $u->id);

        return back()->with('status', 'Two-factor authentication was switched off for this user.');
    }

    public function signOutEverywhere(Request $r, int $user)
    {
        $u = User::query()->findOrFail($user);
        abort_if($u->role === 'admin', 403);
        $u->forceFill(['remember_token' => \Illuminate\Support\Str::random(60)])->save();
        if (Schema::hasTable('sessions')) {
            DB::table('sessions')->where('user_id', $u->id)->delete();
        }
        $this->audit($r, 'user.signout_all', $u->id);

        return back()->with('status', 'User was signed out from every device.');
    }
}
