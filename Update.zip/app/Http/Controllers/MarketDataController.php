<?php

namespace App\Http\Controllers;

use App\Services\MarketDataService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

final class MarketDataController extends Controller
{
    public function __invoke(Request $request, MarketDataService $markets): JsonResponse
    {
        $validated = $request->validate([
            'type' => 'sometimes|in:spot,futures,both',
            'limit' => 'sometimes|integer|min:1|max:100',
        ]);

        try {
            $snapshot = $markets->snapshot($validated['type'] ?? 'both');
            if (isset($validated['limit'])) {
                $snapshot['markets'] = array_slice($snapshot['markets'], 0, (int) $validated['limit']);
            }

            $cacheSeconds = max(2, (int) config('market-data.cache_seconds', 3));

            return response()->json($snapshot)->header(
                'Cache-Control',
                "public, max-age={$cacheSeconds}, stale-while-revalidate=30",
            );
        } catch (Throwable $exception) {
            Log::warning('RushX market API request could not be served.', ['exception' => $exception::class]);

            return response()->json([
                'message' => 'Market data temporarily unavailable. Please try again.',
            ], 503, ['Cache-Control' => 'no-store', 'Retry-After' => '15']);
        }
    }
}
