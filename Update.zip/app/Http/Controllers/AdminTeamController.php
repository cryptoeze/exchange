<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password as PasswordRule;

/** Super admins manage who can sign in to the admin console and with which role. */
class AdminTeamController extends Controller
{
    private function me(Request $r)
    {
        return $r->user('admin');
    }

    private function audit(Request $r, string $action, int $target, array $d = []): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $this->me($r)->id, 'action' => $action, 'target_user_id' => $target, 'details' => json_encode($d), 'ip' => $r->ip(), 'created_at' => now()]);
    }

    public function index(Request $r)
    {
        abort_unless(($this->me($r)->admin_role ?: 'super') === 'super', 403, 'Only super admins manage the team.');
        $rows = User::query()->where('role', 'admin')->orderBy('id')->get(['id', 'name', 'email', 'admin_role', 'two_factor_enabled', 'created_at']);

        return inertia('Admin/Team', ['admin' => ['name' => $this->me($r)->name, 'email' => $this->me($r)->email], 'me' => $this->me($r)->id,
            'rows' => $rows->map(fn ($u) => ['id' => $u->id, 'name' => $u->name, 'email' => $u->email, 'role' => $u->admin_role ?: 'super', 'twoFactor' => (bool) $u->two_factor_enabled, 'since' => $u->created_at?->format('Y-m-d')])->values()]);
    }

    public function save(Request $r)
    {
        abort_unless(($this->me($r)->admin_role ?: 'super') === 'super', 403);
        $d = $r->validate(['email' => 'required|email', 'name' => 'nullable|string|max:100', 'role' => 'required|in:super,finance,support', 'password' => ['nullable', PasswordRule::min(12)->letters()->numbers()]]);
        $u = User::query()->where('email', $d['email'])->first();
        if (! $u) {
            if (empty($d['password']) || empty($d['name'])) {
                return back()->withErrors(['email' => 'No account with that email. Enter a name and a strong password to create the admin.']);
            }
            $u = User::create(['name' => $d['name'], 'email' => $d['email'], 'password' => Hash::make($d['password']), 'role' => 'admin']);
        }
        if ($u->id === $this->me($r)->id && $d['role'] !== 'super') {
            return back()->withErrors(['role' => 'You cannot lower your own role.']);
        }
        DB::table('users')->where('id', $u->id)->update(['role' => 'admin', 'admin_role' => $d['role']]);
        $this->audit($r, 'admin.save', $u->id, ['role' => $d['role']]);

        return back()->with('status', "{$u->email} is now {$d['role']}.");
    }

    public function remove(Request $r, int $user)
    {
        abort_unless(($this->me($r)->admin_role ?: 'super') === 'super', 403);
        if ($user === $this->me($r)->id) {
            return back()->withErrors(['role' => 'You cannot remove yourself.']);
        }
        DB::table('users')->where('id', $user)->update(['role' => 'user', 'admin_role' => 'super']);
        $this->audit($r, 'admin.remove', $user);

        return back()->with('status', 'Admin access removed.');
    }

    public function security(Request $r)
    {
        $u = $this->me($r);

        return inertia('Admin/Security', ['admin' => ['name' => $u->name, 'email' => $u->email], 'twoFactor' => (bool) $u->two_factor_enabled, 'history' => TwoFactorController::history($u->id, 'admin')]);
    }
}
