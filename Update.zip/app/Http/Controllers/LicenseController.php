<?php

namespace App\Http\Controllers;

use App\Services\TelegramNotifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * The license AUTHORITY side — only live when config('license.authority') is true (the owner's own riseway.io
 * install, LICENSE_AUTHORITY=true in that one .env). A sold copy never sets this, so these endpoints 404 there;
 * a sold copy only ever calls OUT to the authority's URL as a client (see LicenseClientController).
 */
class LicenseController extends Controller
{
    public function activate(Request $request, TelegramNotifier $tg)
    {
        abort_unless(config('license.authority'), 404);
        $d = $request->validate(['key' => 'required|string|max:64', 'domain' => 'required|string|max:191']);
        $license = DB::table('licenses')->where('key', $d['key'])->first();
        if (! $license || $license->status === 'revoked') {
            $this->alertInvalid($tg, $d['key'], $d['domain'], $license ? 'a revoked key' : 'an unknown key');

            return response()->json(['status' => 'invalid'], 403);
        }
        if ($license->status === 'active' && $license->domain !== null && $license->domain !== $d['domain']) {
            // Already activated on a different domain: refuse silently rather than letting one key run everywhere.
            $this->alertInvalid($tg, $d['key'], $d['domain'], "a key already active on {$license->domain}");

            return response()->json(['status' => 'invalid'], 403);
        }
        $first = $license->status !== 'active';
        DB::table('licenses')->where('id', $license->id)->update([
            'status' => 'active', 'domain' => $d['domain'], 'activated_at' => $license->activated_at ?? now(), 'last_seen_at' => now(), 'updated_at' => now(),
        ]);
        if ($first) {
            $tg->toOwner("License {$d['key']} activated on {$d['domain']}.");
        }

        return response()->json(['status' => 'active']);
    }

    public function check(Request $request, TelegramNotifier $tg)
    {
        abort_unless(config('license.authority'), 404);
        $d = $request->validate(['key' => 'required|string|max:64', 'domain' => 'required|string|max:191']);
        $license = DB::table('licenses')->where('key', $d['key'])->where('domain', $d['domain'])->first();
        if (! $license || $license->status !== 'active') {
            $this->alertInvalid($tg, $d['key'], $d['domain'], $license ? "a {$license->status} key" : 'an unknown key/domain pair');

            return response()->json(['status' => $license->status ?? 'invalid'], 403);
        }
        DB::table('licenses')->where('id', $license->id)->update(['last_seen_at' => now()]);

        return response()->json(['status' => 'active']);
    }

    /** At most one alert per key+domain pair every 15 minutes, so a repeatedly-retrying nulled copy doesn't spam Telegram. */
    private function alertInvalid(TelegramNotifier $tg, string $key, string $domain, string $reason): void
    {
        $cacheKey = 'license_alert:'.md5($key.'|'.$domain);
        if (Cache::has($cacheKey)) {
            return;
        }
        Cache::put($cacheKey, true, now()->addMinutes(15));
        $tg->toOwner("⚠️ Unlicensed attempt: {$domain} tried to run with {$reason} ({$key}).");
    }
}
