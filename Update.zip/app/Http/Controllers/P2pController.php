<?php

namespace App\Http\Controllers;

use App\Services\P2pService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class P2pController extends Controller
{
    public function market() { return inertia('P2p'); }
    public function orders() { return inertia('P2pOrders'); }
    public function order(string $ref) { return inertia('P2pOrder', ['ref' => strtoupper($ref)]); }
    public function myAds() { return inertia('P2pAds'); }

    private function guard(callable $fn): JsonResponse
    {
        try {
            return $fn();
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }
    }

    public function config(): JsonResponse
    {
        return response()->json(['enabled' => (bool) config('p2p.enabled'), 'fee' => (float) config('p2p.fee_pct'), 'coins' => config('p2p.coins'), 'fiats' => collect(config('p2p.fiats'))->map(fn ($f) => ['name' => $f[0], 'symbol' => $f[1]]), 'methods' => config('p2p.methods')]);
    }

    private function stats(array $ids): array
    {
        if (! $ids) {
            return [];
        }
        $out = [];
        foreach ($ids as $id) {
            $done = DB::table('p2p_trades')->where('status', 'completed')->where(fn ($q) => $q->where('buyer_id', $id)->orWhere('seller_id', $id))->count();
            $bad = DB::table('p2p_trades')->whereIn('status', ['cancelled', 'expired'])->where(fn ($q) => $q->where('buyer_id', $id)->orWhere('seller_id', $id))->count();
            $out[$id] = ['completed' => $done, 'rate' => $done + $bad > 0 ? (int) round($done / ($done + $bad) * 100) : null];
        }

        return $out;
    }

    private function fmtAd(object $a, array $names, array $stats): array
    {
        return ['id' => $a->id, 'side' => $a->side, 'coin' => $a->coin, 'fiat' => $a->fiat, 'price' => (float) $a->price, 'available' => Money::format((int) $a->available, 6), 'availableUnits' => (int) $a->available, 'min' => (float) $a->min_fiat, 'max' => (float) $a->max_fiat, 'methods' => json_decode($a->methods, true), 'terms' => $a->terms, 'window' => (int) $a->window_min,
            'name' => $names[$a->user_id] ?? 'Trader', 'userId' => $a->user_id, 'completed' => $stats[$a->user_id]['completed'] ?? 0, 'rate' => $stats[$a->user_id]['rate'] ?? null, 'seen' => \Illuminate\Support\Carbon::parse($a->updated_at)->toIso8601String()];
    }

    /** Public ad list. `want` is what the visitor wants to do: buy coins (shows sell ads) or sell coins (shows buy ads). */
    public function ads(Request $r): JsonResponse
    {
        $want = $r->query('want') === 'sell' ? 'sell' : 'buy';
        $q = DB::table('p2p_ads')->where('status', 'online')->where('available', '>', 0)->where('side', $want === 'buy' ? 'sell' : 'buy')
            ->when($r->query('coin'), fn ($b, $c) => $b->where('coin', strtoupper((string) $c)))->when($r->query('fiat'), fn ($b, $f) => $b->where('fiat', strtoupper((string) $f)))
            ->when($r->query('method'), fn ($b, $m) => $b->whereJsonContains('methods', (string) $m))
            ->when((float) $r->query('amount') > 0, fn ($b) => $b->where('min_fiat', '<=', (float) $r->query('amount'))->where('max_fiat', '>=', (float) $r->query('amount')))
            ->when($r->user(), fn ($b, $u) => $b->where('user_id', '!=', $u->id))
            ->orderBy('price', $want === 'buy' ? 'asc' : 'desc')->limit(60);
        $rows = $q->get();
        $ids = $rows->pluck('user_id')->unique()->values()->all();

        return response()->json(['ads' => $rows->map(fn ($a) => $this->fmtAd($a, \App\Models\User::query()->whereIn('id', $ids)->pluck('name', 'id')->all(), $this->stats($ids)))->values()]);
    }

    public function mine(Request $r): JsonResponse
    {
        $rows = DB::table('p2p_ads')->where('user_id', $r->user()->id)->where('status', '!=', 'closed')->orderByDesc('id')->get();
        $names = [$r->user()->id => $r->user()->name];

        return response()->json(['ads' => $rows->map(fn ($a) => $this->fmtAd($a, $names, []) + ['status' => $a->status, 'total' => Money::format((int) $a->total, 6)])->values()]);
    }

    public function createAd(Request $r, P2pService $p2p): JsonResponse
    {
        $d = $r->validate(['side' => 'required|in:buy,sell', 'coin' => 'required|string|max:12', 'fiat' => 'required|string|max:8', 'price' => 'required|numeric|gt:0|lt:1000000000', 'amount' => ['required', 'regex:/^\d{1,12}(\.\d{1,8})?$/'], 'min_fiat' => 'required|numeric|gt:0', 'max_fiat' => 'required|numeric|gt:0',
            'methods' => 'required|array|min:1|max:5', 'methods.*' => 'string|max:60', 'details' => 'nullable|array', 'details.*' => 'nullable|string|max:300', 'terms' => 'nullable|string|max:600', 'window_min' => 'nullable|integer|min:10|max:60']);

        return $this->guard(fn () => response()->json(['id' => $p2p->createAd($r->user(), $d)], 201));
    }

    public function adStatus(Request $r, int $id, P2pService $p2p): JsonResponse
    {
        $d = $r->validate(['status' => 'required|in:online,offline,closed']);

        return $this->guard(function () use ($r, $id, $d, $p2p) {
            $p2p->setAdStatus($r->user(), $id, $d['status']);

            return $this->mine($r);
        });
    }

    public function start(Request $r, P2pService $p2p): JsonResponse
    {
        $d = $r->validate(['ad_id' => 'required|integer', 'fiat_amount' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/'], 'method' => 'required|string|max:60', 'details' => 'nullable|string|max:300']);

        return $this->guard(fn () => response()->json(['ref' => $p2p->start($r->user(), $d['ad_id'], $d['fiat_amount'], $d['method'], $d['details'] ?? null)], 201));
    }

    public function trades(Request $r): JsonResponse
    {
        $u = $r->user()->id;
        $rows = DB::table('p2p_trades')->where(fn ($q) => $q->where('buyer_id', $u)->orWhere('seller_id', $u))->orderByRaw("CASE WHEN status IN ('pending','paid','disputed') THEN 0 ELSE 1 END")->orderByDesc('id')->limit(60)->get();
        $names = \App\Models\User::query()->whereIn('id', $rows->pluck('buyer_id')->merge($rows->pluck('seller_id'))->unique())->pluck('name', 'id');

        return response()->json(['trades' => $rows->map(fn ($t) => ['ref' => $t->ref, 'role' => (int) $t->buyer_id === $u ? 'buyer' : 'seller', 'coin' => $t->coin, 'fiat' => $t->fiat, 'qty' => Money::format((int) $t->qty, 6), 'fiatAmount' => (float) $t->fiat_amount, 'price' => (float) $t->price, 'status' => $t->status, 'other' => $names[(int) $t->buyer_id === $u ? $t->seller_id : $t->buyer_id] ?? 'Trader', 'at' => (string) $t->created_at])->values()]);
    }

    public function show(Request $r, string $ref): JsonResponse
    {
        $u = $r->user()->id;
        $t = DB::table('p2p_trades')->where('ref', strtoupper($ref))->first();
        abort_unless($t && in_array($u, [(int) $t->buyer_id, (int) $t->seller_id], true), 404);
        $role = (int) $t->buyer_id === $u ? 'buyer' : 'seller';
        $otherId = $role === 'buyer' ? $t->seller_id : $t->buyer_id;
        $ad = DB::table('p2p_ads')->find($t->ad_id);
        $stats = $this->stats([(int) $otherId]);

        return response()->json(['trade' => ['ref' => $t->ref, 'role' => $role, 'coin' => $t->coin, 'fiat' => $t->fiat, 'price' => (float) $t->price, 'qty' => Money::format((int) $t->qty, 6), 'fiatAmount' => (float) $t->fiat_amount, 'method' => $t->method, 'status' => $t->status, 'resolution' => $t->resolution,
            'payDetails' => $t->pay_details, 'expires' => \Illuminate\Support\Carbon::parse($t->expires_at)->toIso8601String(), 'secondsLeft' => max(0, strtotime($t->expires_at) - time()), 'terms' => $ad->terms ?? null,
            'other' => ['name' => \App\Models\User::query()->whereKey($otherId)->value('name') ?? 'Trader', 'completed' => $stats[(int) $otherId]['completed'] ?? 0, 'rate' => $stats[(int) $otherId]['rate'] ?? null], 'me' => $u],
            'messages' => DB::table('p2p_messages')->where('trade_id', $t->id)->orderBy('id')->get()->map(fn ($m) => ['id' => $m->id, 'mine' => (int) $m->user_id === $u, 'system' => (int) $m->user_id === 0, 'body' => $m->body, 'at' => (string) $m->created_at])->values()]);
    }

    private function act(Request $r, string $ref, callable $do): JsonResponse
    {
        return $this->guard(function () use ($r, $ref, $do) {
            $do();

            return $this->show($r, $ref);
        });
    }

    public function paid(Request $r, string $ref, P2pService $p2p): JsonResponse { return $this->act($r, $ref, fn () => $p2p->markPaid($r->user(), strtoupper($ref))); }
    public function release(Request $r, string $ref, P2pService $p2p): JsonResponse { return $this->act($r, $ref, fn () => $p2p->release($r->user(), strtoupper($ref))); }
    public function cancel(Request $r, string $ref, P2pService $p2p): JsonResponse { return $this->act($r, $ref, fn () => $p2p->cancel($r->user(), strtoupper($ref))); }

    public function dispute(Request $r, string $ref, P2pService $p2p): JsonResponse
    {
        $d = $r->validate(['reason' => 'required|string|min:5|max:300']);

        return $this->act($r, $ref, fn () => $p2p->dispute($r->user(), strtoupper($ref), $d['reason']));
    }

    public function message(Request $r, string $ref, P2pService $p2p): JsonResponse
    {
        $d = $r->validate(['body' => 'required|string|max:500']);

        return $this->act($r, $ref, fn () => $p2p->message($r->user(), strtoupper($ref), $d['body']));
    }
}
