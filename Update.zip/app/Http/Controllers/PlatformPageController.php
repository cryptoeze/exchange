<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PlatformPageController extends Controller
{
    private const PAGES = [
        'p2p' => ['P2P Trading', 'Direct crypto trading is not available in this release.'],
        'spot' => ['Spot Trading', 'RushX spot order placement is not connected yet. Public market prices remain informational.'],
        'futures' => ['Futures Trading', 'Futures trading is planned for a later release. No orders can be placed here.'],
        'convert' => ['Convert', 'Crypto conversion is not available until RushX wallet and pricing rules are configured.'],
        'bots' => ['Trading Bots', 'Automated strategies are planned for a future release.'],
        'earn' => ['Earn', 'Earn products are not available in this release.'],
        'learn' => ['Learn Crypto', 'Educational content is being prepared.'],
        'getting-started' => ['Getting Started', 'A RushX getting-started guide is being prepared.'],
        'faq' => ['FAQ / Help', 'Frequently asked questions are being prepared. For account help, use Support.'],
        'blog' => ['Blog', 'RushX updates will appear here.'],
        'fees' => ['Fees', 'Trading and funding fees are not configured for this release.'],
        'security' => ['Security', 'Account and platform security information.'],
        'proof-of-reserves' => ['Proof of Reserves', 'Reserve reporting is not configured. No reserve claims are made by this page.'],
        'status' => ['System Status', 'A live system status service is not connected yet.'],
        'support' => ['Support', 'Use the RushX live chat to contact support when it is available.'],
        'funding' => ['Funding', 'Funding account.'],
        'trading' => ['Trading', 'Trading account.'],
        'assets' => ['My Assets', 'Wallet balances and an asset ledger are not configured. No balance is displayed here.'],
        'deposit' => ['Deposit', 'Deposits are not available until a reviewed funding method and wallet ledger are configured.'],
        'withdraw' => ['Withdraw', 'Withdrawals are not available until identity, wallet, and approval controls are configured.'],
        'transfer' => ['Transfer', 'Internal transfers are not available until the wallet ledger is configured.'],
        'analysis' => ['Analysis', 'Portfolio analysis requires configured wallet balances.'],
        'orders' => ['Order Center', 'RushX order placement and order history are not connected yet.'],
        'markets' => ['Markets', 'Live public spot market data. Trading is not connected.'],
    ];

    public function show(Request $request, string $page)
    {
        abort_unless(isset(self::PAGES[$page]), 404);
        if ($page === 'markets') {
            return inertia('MarketsPage', ['search' => (string) $request->query('search', '')]);
        }
        $pair = strtoupper((string) $request->query('pair', ''));
        $validPair = preg_match('/^[A-Z0-9]{2,32}$/', $pair) === 1 ? $pair : '';
        if ($page === 'funding' || $page === 'trading') {
            return inertia('AccountPage', ['kind' => $page]);
        }
        if ($page === 'futures') {
            return inertia('FuturesPage', ['pair' => $validPair !== '' ? $validPair : 'BTCUSDT']);
        }
        if ($page === 'earn') {
            return inertia('Earn');
        }
        if ($page === 'bots') {
            return inertia('Bots');
        }
        if ($page === 'analysis') {
            return inertia('Analysis');
        }
        if ($page === 'orders') {
            return inertia('OrderCenter');
        }
        if ($page === 'fees') {
            return inertia('Fees', ['feeRate' => (float) config('trading.spot_fee_rate'), 'futuresFeeRate' => (float) config('trading.futures_fee_rate'), 'maxLeverage' => (int) config('trading.futures_max_leverage')]);
        }
        if ($page === 'assets') {
            return inertia('Overview');
        }
        if ($page === 'deposit') {
            return inertia('Deposit', ['coins' => config('deposit-coins.coins'), 'available' => (string) config('services.nowpayments.api_key') !== '']);
        }
        if ($page === 'spot') {
            return inertia('SpotPage', ['pair' => $validPair !== '' ? $validPair : 'BTCUSDT']);
        }
        return inertia('PlatformPage', [
            'page' => $page,
            'title' => self::PAGES[$page][0],
            'description' => $validPair && in_array($page, ['spot', 'futures'], true)
                ? "{$validPair} selected. ".self::PAGES[$page][1]
                : self::PAGES[$page][1],
            'pair' => in_array($page, ['spot', 'futures'], true) ? $validPair : '',
        ]);
    }
}
