<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/**
 * Serves the admin-uploaded site logo straight from the `public` disk, without relying on the
 * `public/storage` symlink (`php artisan storage:link` needs `exec()`/`symlink()`, which many shared-hosting
 * accounts — Hostinger included — disable). No logo set, or the file is missing: 404, and the frontend falls
 * back to the built-in RushX mark (see RushXBrand.tsx / Landing.tsx).
 */
class BrandingController extends Controller
{
    public function logo()
    {
        $path = trim((string) (DB::table('settings')->where('key', 'site_logo')->value('value') ?? ''));
        if ($path === '' || ! Storage::disk('public')->exists($path)) {
            abort(404);
        }

        return Storage::disk('public')->response($path, null, ['Cache-Control' => 'public, max-age=31536000, immutable']);
    }
}
