<?php

namespace App\Http\Controllers;

use App\Models\SpotOrder;
use App\Services\SpotTradingService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;
use Throwable;

final class SpotOrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $orders = SpotOrder::query()->where('user_id', $request->user()->id)->orderByDesc('id')->limit(50)->get()->map(fn ($o) => $this->present($o))->values();

        return response()->json(['orders' => $orders])->header('Cache-Control', 'no-store');
    }

    public function store(Request $request, SpotTradingService $trading, WalletController $wallet): JsonResponse
    {
        $data = $request->validate([
            'symbol' => ['required', 'string', 'regex:/^[A-Z0-9]{2,20}USDT$/'],
            'side' => 'required|in:buy,sell',
            'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'],
            'idempotency_key' => 'nullable|string|max:64',
        ]);
        $user = $request->user();
        try {
            $order = $trading->marketOrder($user, $data['symbol'], $data['side'], $data['amount'], isset($data['idempotency_key']) ? "{$user->id}:{$data['idempotency_key']}" : null);
        } catch (DomainException|InvalidArgumentException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        } catch (Throwable $e) {
            report($e);

            return response()->json(['message' => 'The order could not be placed. Please try again.'], 500);
        }

        return response()->json(['order' => $this->present($order)] + $wallet->payload($user->id), 201);
    }

    /** @return array<string, mixed> */
    private function present(SpotOrder $o): array
    {
        return ['id' => $o->id, 'symbol' => $o->symbol, 'base' => $o->base_asset, 'side' => $o->side, 'status' => $o->status,
            'price' => $o->price_micro / Money::SCALE, 'quantity' => Money::format((int) $o->base_qty, 4), 'total' => Money::format((int) $o->quote_total, 2),
            'fee' => Money::format((int) $o->fee, 4), 'at' => $o->created_at?->toIso8601String()];
    }
}
