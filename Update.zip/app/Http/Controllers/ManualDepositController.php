<?php

namespace App\Http\Controllers;

use App\Models\ManualDeposit;
use App\Models\ManualDepositAddress;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class ManualDepositController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        return response()->json($this->payload($request->user()->id))->header('Cache-Control', 'no-store');
    }

    public function store(Request $request): JsonResponse
    {
        $d = $request->validate([
            'address_id' => 'required|integer', 'amount' => ['required', 'string', 'regex:/^\d{1,10}(\.\d{1,8})?$/'],
            'txid' => ['required', 'string', 'regex:/^(0x)?[A-Za-z0-9]{16,128}$/'],
        ], ['txid.regex' => 'Enter the transaction hash (TXID) exactly as shown in your wallet.']);
        $user = $request->user();
        try {
            $addr = ManualDepositAddress::query()->where(['id' => $d['address_id'], 'enabled' => true])->where('address', '!=', '')->first() ?? throw new DomainException('This deposit method is not available.');
            $claimed = Money::toUnits($d['amount']);
            if ($claimed < (int) $addr->min_units) {
                throw new DomainException('Minimum deposit is '.Money::format((int) $addr->min_units, 2).' '.$addr->asset.'.');
            }
            $txid = strtolower(trim($d['txid']));
            DB::transaction(function () use ($user, $addr, $claimed, $txid): void {
                if (ManualDeposit::query()->where(['network' => $addr->network, 'txid' => $txid])->whereIn('status', ['pending', 'approved'])->lockForUpdate()->exists()) {
                    throw new DomainException('This transaction has already been submitted.');
                }
                if (ManualDeposit::query()->where(['user_id' => $user->id, 'status' => 'pending'])->count() >= 10) {
                    throw new DomainException('You have too many pending deposits. Wait for them to be reviewed.');
                }
                ManualDeposit::query()->create(['user_id' => $user->id, 'address_id' => $addr->id, 'asset' => $addr->asset, 'network' => $addr->network, 'claimed' => $claimed, 'txid' => $txid, 'status' => 'pending']);
            }, 3);
        } catch (DomainException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        }

        return response()->json($this->payload($user->id), 201);
    }

    /** @return array<string, mixed> */
    private function payload(int $userId): array
    {
        return [
            'addresses' => ManualDepositAddress::query()->where('enabled', true)->where('address', '!=', '')->orderBy('sort')->orderBy('id')->get()->map(fn ($a) => [
                'id' => $a->id, 'asset' => $a->asset, 'network' => $a->network, 'label' => $a->label, 'address' => $a->address, 'min' => Money::format((int) $a->min_units, 2), 'note' => $a->note,
            ])->values(),
            'rows' => ManualDeposit::query()->where('user_id', $userId)->orderByDesc('id')->limit(50)->get()->map(fn ($m) => [
                'id' => $m->id, 'asset' => $m->asset, 'network' => $m->network, 'claimed' => Money::format((int) $m->claimed, 2), 'credited' => $m->credited !== null ? Money::format((int) $m->credited, 2) : null,
                'txid' => $m->txid, 'status' => $m->status, 'reason' => $m->reason, 'at' => $m->created_at?->toIso8601String(),
            ])->values(),
        ];
    }
}
