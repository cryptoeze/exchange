<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\QueryException;
use App\Services\AdminDashboardService;
class AdminController extends Controller {
 public function loginForm(){ return Auth::guard('admin')->check()?redirect()->route('admin.dashboard'):response()->view('admin.auth'); }
 public function login(Request $request){
  $credentials=$request->validate(['email'=>'required|email','password'=>'required|string']);
  if(!Auth::guard('admin')->attempt($credentials,$request->boolean('remember'))) return back()->withErrors(['email'=>'These credentials do not match an administrator account.'])->onlyInput('email');
  if(Auth::guard('admin')->user()->role!=='admin'){ Auth::guard('admin')->logout(); return back()->withErrors(['email'=>'This account does not have administrator access.'])->onlyInput('email'); }
  $request->session()->regenerate(); return redirect()->intended(route('admin.dashboard'));
 }
 public function dashboard(Request $request, AdminDashboardService $dashboard){
  $admin=$request->user('admin');
  try { $data=$dashboard->snapshot(); $loadError=null; }
  catch (QueryException $exception) { report($exception); $data=null; $loadError='Dashboard information could not be loaded. Please retry in a moment.'; }
  return inertia('Admin/Dashboard',['admin'=>['name'=>$admin->name,'email'=>$admin->email],'data'=>$data,'loadError'=>$loadError]);
 }
 public function section(Request $request, string $section, \App\Services\MarketDataService $markets){
  $sections=['users'=>'Users','kyc'=>'KYC review','deposits'=>'Deposits','withdrawals'=>'Withdrawals','transactions'=>'Wallet log','trades'=>'Trades','bots'=>'Bots','p2pdesk'=>'P2P Desk','notifications'=>'Notifications','audit'=>'Audit log','settings'=>'Settings'];
  abort_unless(isset($sections[$section]),404);
  $accounts=null;
  if ($section==='users') {
   $paginator=\App\Models\User::query()->select(['id','name','email','role','email_verified_at','created_at'])->latest('created_at')->latest('id')->simplePaginate(25)->withQueryString();
   $accounts=['current_page'=>$paginator->currentPage(),'data'=>$paginator->items(),'links'=>[
    ['url'=>$paginator->previousPageUrl(),'label'=>'Previous','active'=>false],
    ['url'=>null,'label'=>(string)$paginator->currentPage(),'active'=>true],
    ['url'=>$paginator->nextPageUrl(),'label'=>'Next','active'=>false],
   ]];
  }
  return inertia('Admin/Section',['admin'=>['name'=>$request->user('admin')->name,'email'=>$request->user('admin')->email],'section'=>$sections[$section],'accounts'=>$accounts,'marketHealth'=>$section==='settings' ? $markets->health() : null]);
 }
 public function user(Request $request, int $user){
  $record=\App\Models\User::query()->select(['id','name','email','role','email_verified_at','created_at'])->findOrFail($user);
  return inertia('Admin/Section',['admin'=>['name'=>$request->user('admin')->name,'email'=>$request->user('admin')->email],'section'=>'User account','account'=>['id'=>$record->id,'name'=>$record->name,'email'=>$record->email,'role'=>$record->role,'verified'=>$record->email_verified_at!==null,'joined'=>$record->created_at?->format('Y-m-d H:i:s')],'wallet'=>[
  'balances'=>\App\Models\WalletBalance::query()->where('user_id',$record->id)->orderBy('account')->orderBy('asset')->get()->map(fn($b)=>['account'=>$b->account,'asset'=>$b->asset,'balance'=>\App\Support\Money::format((int)$b->balance,2)])->values(),
  'ledger'=>\App\Models\LedgerEntry::query()->where('user_id',$record->id)->orderByDesc('id')->limit(15)->get()->map(fn($l)=>['id'=>$l->id,'type'=>$l->type,'account'=>$l->account,'asset'=>$l->asset,'amount'=>\App\Support\Money::format((int)$l->amount,2),'note'=>$l->note,'at'=>$l->created_at?->format('Y-m-d H:i:s')])->values(),
 ]]);
 }
 public function logout(Request $request){ Auth::guard('admin')->logout(); $request->session()->invalidate(); $request->session()->regenerateToken(); return redirect()->route('admin.login'); }
}
