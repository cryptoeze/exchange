<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\QueryException;
use App\Services\AdminDashboardService;
class AdminController extends Controller {
 public function loginForm(){ return Auth::guard('admin')->check()?redirect()->route('admin.dashboard'):response()->view('admin.auth'); }
 public function login(Request $request){
  $credentials=$request->validate(['email'=>'required|email','password'=>'required|string','code'=>'nullable|string|max:20']);
  $code=$credentials['code']??''; unset($credentials['code']);
  if(!Auth::guard('admin')->attempt($credentials,$request->boolean('remember'))) return back()->withErrors(['email'=>'These credentials do not match an administrator account.'])->onlyInput('email');
  $totp=app(\App\Services\TotpService::class);
  if(Auth::guard('admin')->user()->role==='admin' && Auth::guard('admin')->user()->two_factor_enabled && !$totp->check(Auth::guard('admin')->user(),$code)){ $uid=Auth::guard('admin')->id(); Auth::guard('admin')->logout(); $totp->logLogin($uid,$credentials['email'],'admin',false,'bad 2fa code'); return back()->withErrors(['email'=>'Enter the 6-digit code from your authenticator app (or a recovery code).'])->onlyInput('email'); }
  if(Auth::guard('admin')->user()->role!=='admin'){ Auth::guard('admin')->logout(); return back()->withErrors(['email'=>'This account does not have administrator access.'])->onlyInput('email'); }
  $totp->logLogin(Auth::guard('admin')->id(),$credentials['email'],'admin',true); $request->session()->regenerate(); return redirect()->intended(route('admin.dashboard'));
 }
 public function dashboard(Request $request, AdminDashboardService $dashboard){
  $admin=$request->user('admin');
  try { $data=$dashboard->snapshot(); $loadError=null; }
  catch (QueryException $exception) { report($exception); $data=null; $loadError='Dashboard information could not be loaded. Please retry in a moment.'; }
  return inertia('Admin/Dashboard',['admin'=>['name'=>$admin->name,'email'=>$admin->email],'data'=>$data,'loadError'=>$loadError]);
 }
 /** Legacy bookmarks: the old placeholder sections now live in their own pages. */
 public function section(Request $request, string $section){ return redirect('/admin/p2p'); }
 public function logout(Request $request){ Auth::guard('admin')->logout(); $request->session()->invalidate(); $request->session()->regenerateToken(); return redirect()->route('admin.login'); }
}
