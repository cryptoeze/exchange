<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KycController extends Controller
{
    public function show(Request $request)
    {
        $last = DB::table('kyc_submissions')->where('user_id', $request->user()->id)->orderByDesc('id')->first();

        return inertia('Kyc', [
            'status' => $request->user()->kyc_status ?? 'none',
            'required' => (bool) config('kyc.required_for_withdrawal'),
            'last' => $last ? ['status' => $last->status, 'reason' => $last->reason, 'at' => $last->created_at] : null,
        ]);
    }

    public function submit(Request $request)
    {
        $user = $request->user();
        if (in_array($user->kyc_status ?? 'none', ['pending', 'approved'], true)) {
            return back()->withErrors(['kyc' => 'Your verification is already '.$user->kyc_status.'.']);
        }
        $d = $request->validate([
            'full_name' => 'required|string|max:120',
            'country' => 'required|string|max:80',
            'doc_type' => 'required|in:passport,national_id,driving_license',
            'doc_number' => 'required|string|max:64',
            'front' => 'required|image|mimes:jpg,jpeg,png|max:5120',
            'selfie' => 'required|image|mimes:jpg,jpeg,png|max:5120',
        ]);
        $dir = 'kyc/'.$user->id;
        $front = $request->file('front')->store($dir, 'local');
        $selfie = $request->file('selfie')->store($dir, 'local');
        DB::transaction(function () use ($user, $d, $front, $selfie): void {
            DB::table('kyc_submissions')->insert(['user_id' => $user->id, 'full_name' => $d['full_name'], 'country' => $d['country'], 'doc_type' => $d['doc_type'], 'doc_number' => $d['doc_number'], 'front_path' => $front, 'selfie_path' => $selfie, 'status' => 'pending', 'created_at' => now(), 'updated_at' => now()]);
            DB::table('users')->where('id', $user->id)->update(['kyc_status' => 'pending']);
        });

        return back()->with('status', 'Documents received. We will review them shortly.');
    }
}
