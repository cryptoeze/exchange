<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KycController extends Controller
{
    public function show(Request $request)
    {
        $last = DB::table('kyc_submissions')->where('user_id', $request->user()->id)->orderByDesc('id')->first();

        return inertia('Kyc', [
            'status' => $request->user()->kyc_status ?? 'none',
            'required' => (bool) config('kyc.required_for_withdrawal'),
            'profile' => ['country' => $request->user()->country, 'phone' => $request->user()->phone],
            'last' => $last ? ['status' => $last->status, 'reason' => $last->reason, 'at' => $last->created_at] : null,
        ]);
    }

    public function submit(Request $request)
    {
        $user = $request->user();
        if (in_array($user->kyc_status ?? 'none', ['pending', 'approved'], true)) {
            return back()->withErrors(['kyc' => 'Your verification is already '.$user->kyc_status.'.']);
        }
        $d = $request->validate([
            'full_name' => 'required|string|max:120',
            // Country and mobile come from the account (set at sign-up). Only older accounts without them type them here.
            'country' => [$user->country ? 'nullable' : 'required', 'string', 'max:80'],
            'doc_type' => 'required|in:passport,national_id,driving_license',
            'dial' => [$user->phone ? 'nullable' : 'required', 'regex:/^\+\d{1,5}$/'],
            'phone' => [$user->phone ? 'nullable' : 'required', 'regex:/^\d{5,14}$/'],
            'doc_number' => 'required|string|max:64',
            'back' => 'nullable|image|mimes:jpg,jpeg,png|max:5120',
            'front' => 'required|image|mimes:jpg,jpeg,png|max:5120',
            'selfie' => 'required|image|mimes:jpg,jpeg,png|max:5120',
        ]);
        if ($d['doc_type'] !== 'passport' && ! $request->hasFile('back')) {
            return back()->withErrors(['back' => 'Please upload the back side of your document.']);
        }
        $country = $user->country ?: $d['country'];
        $phone = $user->phone ?: ($d['dial'].$d['phone']);
        if (! $user->country || ! $user->phone) {
            DB::table('users')->where('id', $user->id)->update(['country' => $country, 'phone' => $phone]);
        }
        $dir = 'kyc/'.$user->id;
        $front = $request->file('front')->store($dir, 'local');
        $selfie = $request->file('selfie')->store($dir, 'local');
        $back = $request->hasFile('back') ? $request->file('back')->store($dir, 'local') : null;
        DB::transaction(function () use ($user, $d, $front, $back, $selfie, $country, $phone): void {
            DB::table('kyc_submissions')->insert(['user_id' => $user->id, 'full_name' => $d['full_name'], 'country' => $country, 'doc_type' => $d['doc_type'], 'doc_number' => $d['doc_number'], 'front_path' => $front, 'back_path' => $back, 'phone' => $phone, 'selfie_path' => $selfie, 'status' => 'pending', 'created_at' => now(), 'updated_at' => now()]);
            DB::table('users')->where('id', $user->id)->update(['kyc_status' => 'pending']);
        });

        \App\Services\NotificationService::admins('KYC submitted', $user->email.' sent documents for review', '/admin/kyc');

        return back()->with('status', 'Documents received. We will review them shortly.');
    }
}
