<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class ReferralController extends Controller
{
    public function show(Request $request)
    {
        $user = $request->user();
        $invited = User::query()->where('referred_by', $user->id)->latest('id')->limit(50)->get(['id', 'name', 'created_at']);

        return inertia('Refer', [
            'code' => $user->referral_code,
            'link' => url('/login').'?mode=signup&ref='.$user->referral_code,
            'total' => User::query()->where('referred_by', $user->id)->count(),
            'invited' => $invited->map(fn ($u) => [
                'name' => mb_substr($u->name, 0, 1).str_repeat('•', max(2, min(6, mb_strlen($u->name) - 1))),
                'at' => $u->created_at?->toIso8601String(),
            ])->values(),
        ]);
    }
}
