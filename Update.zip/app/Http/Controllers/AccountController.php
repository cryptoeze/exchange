<?php

namespace App\Http\Controllers;

use App\Models\LedgerEntry;
use App\Models\SpotOrder;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/** Read-only statistics for the account pages (Analysis, Fees). Everything is derived from the ledger and orders. */
final class AccountController extends Controller
{
    public function summary(Request $request): JsonResponse
    {
        $userId = $request->user()->id;
        $since = now()->subDays(30);

        $deposits = (int) LedgerEntry::query()->where('user_id', $userId)->where('type', 'deposit')->where('asset', config('trading.quote_asset'))->sum('amount');
        $withdrawals = (int) abs((int) LedgerEntry::query()->where('user_id', $userId)->where('type', 'withdrawal')->where('asset', config('trading.quote_asset'))->sum('amount'));
        $recent = SpotOrder::query()->where('user_id', $userId)->where('status', 'filled')->where('created_at', '>=', $since);

        return response()->json([
            'deposits' => Money::format($deposits, 2),
            'withdrawals' => Money::format($withdrawals, 2),
            'volume30d' => Money::format((int) (clone $recent)->sum('quote_total'), 2),
            'fees30d' => Money::format((int) (clone $recent)->sum('fee'), 4),
            'trades30d' => (clone $recent)->count(),
            'tradesTotal' => SpotOrder::query()->where('user_id', $userId)->count(),
            'winRate' => $this->winRate($userId),
            'feeRate' => (float) config('trading.spot_fee_rate'),
        ])->header('Cache-Control', 'no-store');
    }

    /**
     * Share of closed (sell) trades that were profitable, using the running average cost of each asset.
     * Returns null until the user has closed at least one position.
     */
    private function winRate(int $userId): ?float
    {
        $qty = [];
        $cost = [];
        $wins = 0;
        $closed = 0;
        foreach (SpotOrder::query()->where('user_id', $userId)->where('status', 'filled')->orderBy('id')->limit(5000)->get(['base_asset', 'side', 'base_qty', 'quote_total', 'fee']) as $o) {
            $a = $o->base_asset;
            if ($o->side === 'buy') {
                $qty[$a] = ($qty[$a] ?? 0) + $o->base_qty;
                $cost[$a] = ($cost[$a] ?? 0) + $o->quote_total;
                continue;
            }
            $held = $qty[$a] ?? 0;
            if ($held <= 0) {
                continue;
            }
            $sold = min($held, $o->base_qty);
            $basis = ($cost[$a] ?? 0) * ($sold / $held);
            $proceeds = ($o->quote_total - $o->fee) * ($sold / max(1, $o->base_qty));
            $closed++;
            $wins += $proceeds > $basis ? 1 : 0;
            $qty[$a] = $held - $sold;
            $cost[$a] = ($cost[$a] ?? 0) - $basis;
        }

        return $closed > 0 ? round($wins / $closed * 100, 1) : null;
    }
}
