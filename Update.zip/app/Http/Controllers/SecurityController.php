<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password as PasswordRule;

class SecurityController extends Controller
{
    public function show(Request $request)
    {
        $u = $request->user();
        if (! $u) {
            return app(PlatformPageController::class)->show($request, 'security');
        }

        return inertia('Security', ['twoFactor' => (bool) $u->two_factor_enabled, 'history' => TwoFactorController::history($u->id, 'web')]);
    }

    public function password(Request $request)
    {
        $d = $request->validate(['current' => 'required|string', 'password' => ['required', 'confirmed', PasswordRule::min(12)->letters()->numbers()]]);
        $u = $request->user();
        if (! Hash::check($d['current'], $u->password)) {
            return back()->withErrors(['current' => 'Your current password is not correct.']);
        }
        $u->forceFill(['password' => $d['password']])->save();

        return back()->with('status', 'Password updated.');
    }
}
