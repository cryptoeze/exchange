<?php

namespace App\Http\Controllers;

use App\Models\ManualDeposit;
use App\Models\ManualDepositAddress;
use App\Models\User;
use App\Models\Withdrawal;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Admin review of withdrawals and manual deposits, plus the receiving addresses shown to users. Everything is audit-logged. */
final class AdminTreasuryController extends Controller
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    private function admin(Request $request): array
    {
        return ['name' => $request->user('admin')->name, 'email' => $request->user('admin')->email];
    }

    private function audit(Request $request, string $action, ?int $userId, array $details): void
    {
        DB::table('admin_audit_logs')->insert(['admin_id' => $request->user('admin')->id, 'action' => $action, 'target_user_id' => $userId, 'details' => json_encode($details), 'ip' => $request->ip(), 'created_at' => now()]);
    }

    public function withdrawals(Request $request)
    {
        $status = in_array($request->query('status'), ['pending', 'completed', 'rejected', 'cancelled'], true) ? $request->query('status') : 'pending';
        $list = Withdrawal::query()->where('status', $status)->orderByDesc('id')->limit(200)->get();
        $emails = User::query()->whereIn('id', $list->pluck('user_id'))->pluck('email', 'id');

        return inertia('Admin/Withdrawals', ['admin' => $this->admin($request), 'status' => $status, 'pendingCount' => Withdrawal::query()->where('status', 'pending')->count(),
            'rows' => $list->map(fn ($w) => ['id' => $w->id, 'user' => $emails[$w->user_id] ?? '#'.$w->user_id, 'userId' => $w->user_id, 'asset' => $w->asset, 'network' => $w->network, 'address' => $w->address,
                'amount' => Money::format((int) $w->amount, 4), 'fee' => Money::format((int) $w->fee, 4), 'net' => Money::format((int) $w->net, 4), 'status' => $w->status, 'txHash' => $w->tx_hash, 'reason' => $w->reason, 'at' => $w->created_at?->format('Y-m-d H:i')])->values()]);
    }

    public function reviewWithdrawal(Request $request, int $id)
    {
        $d = $request->validate(['decision' => 'required|in:complete,reject', 'tx_hash' => 'nullable|string|max:128', 'reason' => 'nullable|string|max:255']);
        try {
            DB::transaction(function () use ($request, $id, $d): void {
                $w = Withdrawal::query()->whereKey($id)->lockForUpdate()->first() ?? throw new DomainException('Withdrawal not found.');
                if ($w->status !== 'pending') {
                    throw new DomainException('This withdrawal was already handled.');
                }
                $adminId = $request->user('admin')->id;
                if ($d['decision'] === 'complete') {
                    $w->fill(['status' => 'completed', 'tx_hash' => $d['tx_hash'] ?? null, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                } else {
                    $this->ledger->apply($w->user_id, 'funding', $w->asset, (int) $w->amount, 'withdrawal_refund', ['ref_type' => 'withdrawal', 'ref_id' => $w->id, 'note' => 'rejected', 'idempotency_key' => "wd-refund:{$w->id}", 'created_by' => $adminId]);
                    $w->fill(['status' => 'rejected', 'reason' => $d['reason'] ?? null, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                }
                $this->audit($request, 'withdrawal.'.$d['decision'], $w->user_id, ['id' => $w->id, 'asset' => $w->asset, 'amount' => $w->amount, 'tx_hash' => $d['tx_hash'] ?? null, 'reason' => $d['reason'] ?? null]);
            }, 3);
        } catch (DomainException $e) {
            return back()->withErrors(['withdrawal' => $e->getMessage()]);
        }

        return back()->with('status', 'Withdrawal #'.$id.($d['decision'] === 'complete' ? ' marked as sent.' : ' rejected and refunded.'));
    }

    public function deposits(Request $request)
    {
        $status = in_array($request->query('status'), ['pending', 'approved', 'rejected'], true) ? $request->query('status') : 'pending';
        $list = ManualDeposit::query()->where('status', $status)->orderByDesc('id')->limit(200)->get();
        $emails = User::query()->whereIn('id', $list->pluck('user_id'))->pluck('email', 'id');

        return inertia('Admin/ManualDeposits', ['admin' => $this->admin($request), 'status' => $status, 'pendingCount' => ManualDeposit::query()->where('status', 'pending')->count(),
            'addresses' => ManualDepositAddress::query()->orderBy('sort')->orderBy('id')->get()->map(fn ($a) => ['id' => $a->id, 'asset' => $a->asset, 'network' => $a->network, 'label' => $a->label, 'address' => $a->address, 'min' => rtrim(rtrim(Money::format((int) $a->min_units, 8), '0'), '.'), 'note' => $a->note, 'enabled' => (bool) $a->enabled])->values(),
            'rows' => $list->map(fn ($m) => ['id' => $m->id, 'user' => $emails[$m->user_id] ?? '#'.$m->user_id, 'asset' => $m->asset, 'network' => $m->network, 'claimed' => rtrim(rtrim(Money::format((int) $m->claimed, 8), '0'), '.'), 'credited' => $m->credited !== null ? Money::format((int) $m->credited, 2) : null, 'txid' => $m->txid, 'status' => $m->status, 'reason' => $m->reason, 'at' => $m->created_at?->format('Y-m-d H:i')])->values()]);
    }

    public function saveAddress(Request $request)
    {
        $d = $request->validate(['id' => 'nullable|integer', 'asset' => ['required', 'regex:/^[A-Z0-9]{2,10}$/'], 'network' => ['required', 'regex:/^[A-Z0-9]{2,10}$/'], 'label' => 'required|string|max:60',
            'address' => ['nullable', 'string', 'max:128', 'regex:/^[A-Za-z0-9]*$/'], 'min' => ['required', 'regex:/^\d{1,8}(\.\d{1,8})?$/'], 'note' => 'nullable|string|max:255', 'enabled' => 'boolean']);
        $address = trim((string) ($d['address'] ?? ''));
        if (($d['enabled'] ?? false) && $address === '') {
            return back()->withErrors(['address' => 'Enter the receiving address before switching this method on.']);
        }
        $fields = ['asset' => $d['asset'], 'network' => $d['network'], 'label' => $d['label'], 'address' => $address, 'min_units' => Money::toUnits($d['min']), 'note' => $d['note'] ?? null, 'enabled' => (bool) ($d['enabled'] ?? false)];
        $row = ! empty($d['id']) ? ManualDepositAddress::query()->findOrFail($d['id']) : new ManualDepositAddress(['sort' => 99]);
        $old = $row->exists ? $row->address : null;
        $row->fill($fields)->save();
        $this->audit($request, 'deposit_address.save', null, ['id' => $row->id, 'network' => $row->network, 'old_address' => $old, 'address' => $address, 'enabled' => $row->enabled]);

        return back()->with('status', "Saved {$row->label}.");
    }

    public function reviewDeposit(Request $request, int $id)
    {
        $d = $request->validate(['decision' => 'required|in:approve,reject', 'amount' => ['nullable', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'reason' => 'nullable|string|max:255']);
        try {
            DB::transaction(function () use ($request, $id, $d): void {
                $m = ManualDeposit::query()->whereKey($id)->lockForUpdate()->first() ?? throw new DomainException('Deposit not found.');
                if ($m->status !== 'pending') {
                    throw new DomainException('This deposit was already handled.');
                }
                $adminId = $request->user('admin')->id;
                if ($d['decision'] === 'approve') {
                    $units = isset($d['amount']) && $d['amount'] !== '' ? Money::toUnits($d['amount']) : (int) $m->claimed;
                    if ($units <= 0) {
                        throw new DomainException('Enter the amount you actually received.');
                    }
                    $this->ledger->apply($m->user_id, 'funding', $m->asset, $units, 'deposit', ['ref_type' => 'manual_deposit', 'ref_id' => $m->id, 'note' => 'manual '.$m->network, 'idempotency_key' => "manual-deposit:{$m->id}", 'created_by' => $adminId]);
                    app(\App\Services\BonusService::class)->grantForDeposit($m->user_id, $m->asset, $units, 'manual_deposit', $m->id);
                    $m->fill(['status' => 'approved', 'credited' => $units, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                } else {
                    $m->fill(['status' => 'rejected', 'reason' => $d['reason'] ?? null, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                }
                $this->audit($request, 'manual_deposit.'.$d['decision'], $m->user_id, ['id' => $m->id, 'txid' => $m->txid, 'credited' => $m->credited, 'reason' => $d['reason'] ?? null]);
            }, 3);
        } catch (DomainException $e) {
            return back()->withErrors(['deposit' => $e->getMessage()]);
        }

        return back()->with('status', 'Deposit #'.$id.($d['decision'] === 'approve' ? ' credited.' : ' rejected.'));
    }
}
