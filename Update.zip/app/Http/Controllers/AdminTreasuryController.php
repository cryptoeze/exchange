<?php

namespace App\Http\Controllers;

use App\Models\ManualDeposit;
use App\Models\ManualDepositAddress;
use App\Models\User;
use App\Models\Withdrawal;
use App\Services\LedgerService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Admin review of withdrawals and manual deposits, plus the receiving addresses shown to users. Everything is audit-logged. */
final class AdminTreasuryController extends Controller
{
    use \App\Http\Controllers\Admin\Concerns\AdminHelpers;

    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function withdrawals(Request $request)
    {
        $tab = $this->pick($request, 'status', ['pending', 'completed', 'rejected', 'cancelled', 'all']) ?: 'pending';
        $q = trim((string) $request->query('q', ''));
        $asset = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $request->query('asset', '')));
        $network = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $request->query('network', '')));
        $id = ctype_digit((string) $request->query('id', '')) ? (int) $request->query('id') : 0;

        $base = DB::table('withdrawals as w')->join('users as u', 'u.id', '=', 'w.user_id');
        $query = (clone $base)->select(['w.*', 'u.email', 'u.name', 'u.kyc_status']);
        $tab !== 'all' && $query->where('w.status', $tab);
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($x) => $x->where('u.email', 'like', $this->like($q))->orWhere('u.name', 'like', $this->like($q))->orWhere('w.address', 'like', $this->like($q))->orWhere('w.tx_hash', $q)->orWhere('u.id', $digits));
        }
        $asset && $query->where('w.asset', $asset);
        $network && $query->where('w.network', $network);
        $id && $query->where('w.id', $id);
        $this->dateRange($query, $request, 'w.created_at');
        $query->orderByDesc('w.id');

        if ($request->boolean('export')) {
            return $this->csv('withdrawals', ['ID', 'Time', 'Email', 'Asset', 'Network', 'Address', 'Amount', 'Fee', 'Net', 'Status', 'TX hash', 'Reason'],
                (clone $query)->limit(50000)->get()->map(fn ($w) => [$w->id, $w->created_at, $w->email, $w->asset, $w->network, $w->address, $this->units($w->amount, 8), $this->units($w->fee, 8), $this->units($w->net, 8), $w->status, $w->tx_hash, $w->reason]));
        }

        [$items, $pager] = $this->paged($query, $request, 25);
        $reviewers = User::query()->whereIn('id', $items->pluck('reviewed_by')->filter()->unique())->pluck('email', 'id');
        $count = fn (string $st) => DB::table('withdrawals')->where('status', $st)->count();
        $stable = ['USDT', 'USDC'];
        $since = now()->subDays(30);

        return inertia('Admin/Withdrawals', ['admin' => $this->adminProps($request), 'tab' => $tab, 'pager' => $pager,
            'filters' => ['q' => $q, 'asset' => $asset, 'network' => $network, 'from' => (string) $this->day($request->query('from')), 'to' => (string) $this->day($request->query('to'))],
            'counts' => ['pending' => $count('pending'), 'completed' => $count('completed'), 'rejected' => $count('rejected'), 'cancelled' => $count('cancelled'), 'all' => DB::table('withdrawals')->count()],
            'stats' => ['pendingValue' => Money::format((int) DB::table('withdrawals')->where('status', 'pending')->whereIn('asset', $stable)->sum('net'), 2),
                'sent30' => Money::format((int) DB::table('withdrawals')->where('status', 'completed')->whereIn('asset', $stable)->where('reviewed_at', '>=', $since)->sum('net'), 2),
                'sentToday' => DB::table('withdrawals')->where('status', 'completed')->where('reviewed_at', '>=', now()->startOfDay())->count(),
                'fees30' => Money::format((int) DB::table('withdrawals')->where('status', 'completed')->whereIn('asset', $stable)->where('reviewed_at', '>=', $since)->sum('fee'), 2)],
            'assets' => DB::table('withdrawals')->distinct()->orderBy('asset')->pluck('asset')->values(), 'networks' => DB::table('withdrawals')->distinct()->orderBy('network')->pluck('network')->values(),
            'rows' => $items->map(fn ($w) => ['id' => $w->id, 'userId' => $w->user_id, 'email' => $w->email, 'name' => $w->name, 'kyc' => $w->kyc_status ?: 'none', 'asset' => $w->asset, 'network' => $w->network, 'address' => $w->address,
                'amount' => $this->units($w->amount, 4), 'fee' => $this->units($w->fee, 4), 'net' => $this->units($w->net, 4), 'status' => $w->status, 'txHash' => $w->tx_hash, 'reason' => $w->reason, 'by' => $reviewers[$w->reviewed_by] ?? null,
                'at' => substr((string) $w->created_at, 0, 16), 'doneAt' => $w->reviewed_at ? substr((string) $w->reviewed_at, 0, 16) : null])->values()]);
    }

    public function reviewWithdrawal(Request $request, int $id)
    {
        $d = $request->validate(['decision' => 'required|in:complete,reject', 'tx_hash' => 'nullable|string|max:128', 'reason' => 'nullable|string|max:255']);
        try {
            DB::transaction(function () use ($request, $id, $d): void {
                $w = Withdrawal::query()->whereKey($id)->lockForUpdate()->first() ?? throw new DomainException('Withdrawal not found.');
                if ($w->status !== 'pending') {
                    throw new DomainException('This withdrawal was already handled.');
                }
                $adminId = $request->user('admin')->id;
                if ($d['decision'] === 'complete') {
                    $w->fill(['status' => 'completed', 'tx_hash' => $d['tx_hash'] ?? null, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                } else {
                    $this->ledger->apply($w->user_id, 'funding', $w->asset, (int) $w->amount, 'withdrawal_refund', ['ref_type' => 'withdrawal', 'ref_id' => $w->id, 'note' => 'rejected', 'idempotency_key' => "wd-refund:{$w->id}", 'created_by' => $adminId]);
                    $w->fill(['status' => 'rejected', 'reason' => $d['reason'] ?? null, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                }
                \App\Services\NotificationService::event($w->user_id, $d['decision'] === 'complete' ? 'withdrawal_sent' : 'withdrawal_rejected', ['amount' => Money::format((int) ($d['decision'] === 'complete' ? $w->net : $w->amount), 4), 'asset' => $w->asset, 'network' => $w->network, 'address' => $w->address, 'txid' => $d['tx_hash'] ?? '—', 'reason' => $d['reason'] ?? 'Not specified']);
                $this->audit($request, 'withdrawal.'.$d['decision'], $w->user_id, ['id' => $w->id, 'asset' => $w->asset, 'amount' => $w->amount, 'tx_hash' => $d['tx_hash'] ?? null, 'reason' => $d['reason'] ?? null]);
            }, 3);
        } catch (DomainException $e) {
            return back()->withErrors(['withdrawal' => $e->getMessage()]);
        }

        return back()->with('status', 'Withdrawal #'.$id.($d['decision'] === 'complete' ? ' marked as sent.' : ' rejected and refunded.'));
    }

    public function deposits(Request $request)
    {
        $tab = $this->pick($request, 'tab', ['pending', 'approved', 'rejected', 'all', 'auto']) ?: 'pending';
        $q = trim((string) $request->query('q', ''));
        $asset = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $request->query('asset', '')));
        $network = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $request->query('network', '')));
        $id = ctype_digit((string) $request->query('id', '')) ? (int) $request->query('id') : 0;
        $auto = $tab === 'auto';
        $table = $auto ? 'deposits' : 'manual_deposits';

        $query = DB::table($table.' as d')->join('users as u', 'u.id', '=', 'd.user_id')->select(['d.*', 'u.email', 'u.name']);
        if (! $auto && in_array($tab, ['pending', 'approved', 'rejected'], true)) {
            $query->where('d.status', $tab);
        }
        if ($q !== '') {
            $digits = ctype_digit($q) ? (int) $q : 0;
            $query->where(fn ($x) => $x->where('u.email', 'like', $this->like($q))->orWhere('u.name', 'like', $this->like($q))->orWhere('u.id', $digits)->orWhere($auto ? 'd.tx_hash' : 'd.txid', $q));
        }
        $asset && $query->where('d.asset', $asset);
        $network && $query->where('d.network', $network);
        $id && $query->where('d.id', $id);
        $this->dateRange($query, $request, 'd.created_at');
        $query->orderByDesc('d.id');

        if ($request->boolean('export')) {
            return $this->csv($auto ? 'auto-deposits' : 'manual-deposits', ['ID', 'Time', 'Email', 'Asset', 'Network', $auto ? 'Paid' : 'Claimed', 'Credited', 'Status', 'TX'],
                (clone $query)->limit(50000)->get()->map(fn ($d) => [$d->id, $d->created_at, $d->email, $d->asset, $d->network, $auto ? ($d->paid_amount ?: $d->expected_amount) : $this->units($d->claimed, 8), $this->units($auto ? $d->credited_units : $d->credited, 8), $d->status, $auto ? $d->tx_hash : $d->txid]));
        }

        [$items, $pager] = $this->paged($query, $request, 25);
        $reviewers = $auto ? collect() : User::query()->whereIn('id', $items->pluck('reviewed_by')->filter()->unique())->pluck('email', 'id');
        $mc = fn (string $st) => DB::table('manual_deposits')->where('status', $st)->count();
        $since = now()->subDays(30);
        $stable = ['USDT', 'USDC'];

        return inertia('Admin/Deposits', ['admin' => $this->adminProps($request), 'tab' => $tab, 'pager' => $pager,
            'filters' => ['q' => $q, 'asset' => $asset, 'network' => $network, 'from' => (string) $this->day($request->query('from')), 'to' => (string) $this->day($request->query('to'))],
            'counts' => ['pending' => $mc('pending'), 'approved' => $mc('approved'), 'rejected' => $mc('rejected'), 'all' => DB::table('manual_deposits')->count(), 'auto' => DB::table('deposits')->count()],
            'stats' => ['pendingValue' => Money::format((int) DB::table('manual_deposits')->where('status', 'pending')->whereIn('asset', $stable)->sum('claimed'), 2),
                'manual30' => Money::format((int) DB::table('manual_deposits')->where('status', 'approved')->whereIn('asset', $stable)->where('reviewed_at', '>=', $since)->sum('credited'), 2),
                'auto30' => Money::format((int) DB::table('deposits')->whereIn('asset', $stable)->where('credited_at', '>=', $since)->sum('credited_units'), 2),
                'waitingAuto' => DB::table('deposits')->whereIn('status', ['waiting', 'confirming', 'confirmed', 'sending'])->count()],
            'assets' => DB::table($table)->distinct()->orderBy('asset')->pluck('asset')->values(), 'networks' => DB::table($table)->distinct()->orderBy('network')->pluck('network')->values(),
            'rows' => $items->map(fn ($d) => $auto
                ? ['id' => $d->id, 'userId' => $d->user_id, 'email' => $d->email, 'name' => $d->name, 'asset' => $d->asset, 'network' => $d->network, 'claimed' => $d->paid_amount ?: ($d->expected_amount ?: '—'), 'credited' => $d->credited_units ? $this->units($d->credited_units, 4) : null, 'txid' => $d->tx_hash ?: $d->pay_address, 'status' => $d->status, 'reason' => null, 'by' => null, 'at' => substr((string) $d->created_at, 0, 16)]
                : ['id' => $d->id, 'userId' => $d->user_id, 'email' => $d->email, 'name' => $d->name, 'asset' => $d->asset, 'network' => $d->network, 'claimed' => $this->units($d->claimed, 8), 'credited' => $d->credited !== null ? $this->units($d->credited, 4) : null, 'txid' => $d->txid, 'status' => $d->status, 'reason' => $d->reason, 'by' => $reviewers[$d->reviewed_by] ?? null, 'at' => substr((string) $d->created_at, 0, 16)])->values()]);
    }

    public function saveAddress(Request $request)
    {
        $d = $request->validate(['id' => 'nullable|integer', 'asset' => ['required', 'regex:/^[A-Z0-9]{2,10}$/'], 'network' => ['required', 'regex:/^[A-Z0-9]{2,10}$/'], 'label' => 'required|string|max:60',
            'address' => ['nullable', 'string', 'max:128', 'regex:/^[A-Za-z0-9]*$/'], 'min' => ['required', 'regex:/^\d{1,8}(\.\d{1,8})?$/'], 'note' => 'nullable|string|max:255', 'enabled' => 'boolean']);
        $address = trim((string) ($d['address'] ?? ''));
        if (($d['enabled'] ?? false) && $address === '') {
            return back()->withErrors(['address' => 'Enter the receiving address before switching this method on.']);
        }
        $fields = ['asset' => $d['asset'], 'network' => $d['network'], 'label' => $d['label'], 'address' => $address, 'min_units' => Money::toUnits($d['min']), 'note' => $d['note'] ?? null, 'enabled' => (bool) ($d['enabled'] ?? false)];
        $row = ! empty($d['id']) ? ManualDepositAddress::query()->findOrFail($d['id']) : new ManualDepositAddress(['sort' => 99]);
        $old = $row->exists ? $row->address : null;
        $row->fill($fields)->save();
        $this->audit($request, 'deposit_address.save', null, ['id' => $row->id, 'network' => $row->network, 'old_address' => $old, 'address' => $address, 'enabled' => $row->enabled]);

        return back()->with('status', "Saved {$row->label}.");
    }

    public function reviewDeposit(Request $request, int $id)
    {
        $d = $request->validate(['decision' => 'required|in:approve,reject', 'amount' => ['nullable', 'regex:/^\d{1,10}(\.\d{1,8})?$/'], 'reason' => 'nullable|string|max:255']);
        try {
            DB::transaction(function () use ($request, $id, $d): void {
                $m = ManualDeposit::query()->whereKey($id)->lockForUpdate()->first() ?? throw new DomainException('Deposit not found.');
                if ($m->status !== 'pending') {
                    throw new DomainException('This deposit was already handled.');
                }
                $adminId = $request->user('admin')->id;
                if ($d['decision'] === 'approve') {
                    $units = isset($d['amount']) && $d['amount'] !== '' ? Money::toUnits($d['amount']) : (int) $m->claimed;
                    if ($units <= 0) {
                        throw new DomainException('Enter the amount you actually received.');
                    }
                    $this->ledger->apply($m->user_id, 'funding', $m->asset, $units, 'deposit', ['ref_type' => 'manual_deposit', 'ref_id' => $m->id, 'note' => 'manual '.$m->network, 'idempotency_key' => "manual-deposit:{$m->id}", 'created_by' => $adminId]);
                    app(\App\Services\BonusService::class)->grantForDeposit($m->user_id, $m->asset, $units, 'manual_deposit', $m->id);
                    app(\App\Services\ReferralService::class)->payForDeposit($m->user_id, $m->asset, $units, 'manual_deposit', $m->id);
                    \App\Services\NotificationService::event($m->user_id, 'deposit_credited', ['amount' => Money::format($units, 4), 'asset' => $m->asset]);
                    $m->fill(['status' => 'approved', 'credited' => $units, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                } else {
                    $m->fill(['status' => 'rejected', 'reason' => $d['reason'] ?? null, 'reviewed_by' => $adminId, 'reviewed_at' => now()])->save();
                }
                $this->audit($request, 'manual_deposit.'.$d['decision'], $m->user_id, ['id' => $m->id, 'txid' => $m->txid, 'credited' => $m->credited, 'reason' => $d['reason'] ?? null]);
            }, 3);
        } catch (DomainException $e) {
            return back()->withErrors(['deposit' => $e->getMessage()]);
        }

        return back()->with('status', 'Deposit #'.$id.($d['decision'] === 'approve' ? ' credited.' : ' rejected.'));
    }
}
