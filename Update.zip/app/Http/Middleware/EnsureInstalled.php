<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class EnsureInstalled { public function handle(Request $request, Closure $next): Response { $locked=file_exists(storage_path('app/installed.lock')); if (!$locked && !$request->routeIs('install.*')) return redirect()->route('install.show'); if ($locked && $request->routeIs('install.*')) abort(404); return $next($request); } }
