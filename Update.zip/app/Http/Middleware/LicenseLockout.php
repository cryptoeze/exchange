<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Sold copies only (never the vendor's own install — config('license.authority') is true there, this middleware
 * no-ops). When `license:check` has locked this install (key revoked by the vendor, or it couldn't reach the
 * vendor's server for too long), EVERYTHING is blocked — frontend and admin panel alike, matching what was asked
 * for. No data is touched or deleted; this is purely an access gate, and it lifts itself automatically the next
 * time `license:check` confirms the key is active again.
 */
class LicenseLockout
{
    public function handle(Request $request, Closure $next): Response
    {
        if (config('license.authority') || ! config('app.license_locked') || $request->is('up', 'api/webhooks/*')) {
            return $next($request);
        }
        $msg = 'This installation is not licensed. Contact the vendor you purchased it from.';
        if ($request->expectsJson()) {
            return response()->json(['message' => $msg], 403);
        }

        return response()->view('license-locked', ['message' => $msg], 403);
    }
}
