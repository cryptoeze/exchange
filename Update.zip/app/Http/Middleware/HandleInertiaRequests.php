<?php
namespace App\Http\Middleware;
use Inertia\Middleware;
use Illuminate\Http\Request;
class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';

    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    public function share(Request $request): array
    {
        $user = $request->user();

        return [
            ...parent::share($request),
            'auth' => ['user' => $user ? [
                'id' => (int) $user->id,
                'name' => (string) $user->name,
                'email' => (string) $user->email,
                'emailVerified' => $user->email_verified_at !== null,
                'kyc' => (string) ($user->kyc_status ?? 'none'),
            ] : null],
            'adminRole' => fn () => $request->user('admin')?->admin_role ?: ($request->user('admin') ? 'super' : null),
            'adminBadges' => fn () => $request->user('admin') ? [
                'withdrawals' => \Illuminate\Support\Facades\DB::table('withdrawals')->where('status', 'pending')->count(),
                'deposits' => \Illuminate\Support\Facades\DB::table('manual_deposits')->where('status', 'pending')->count(),
                'kyc' => \Illuminate\Support\Facades\DB::table('kyc_submissions')->where('status', 'pending')->count(),
                'tickets' => \Illuminate\Support\Facades\DB::table('tickets')->where('status', 'open')->count(),
                'disputes' => \Illuminate\Support\Facades\DB::table('p2p_disputes')->where('status', 'open')->count(),
            ] : null,
            'flash' => ['status' => fn () => $request->session()->get('status')],
            'siteLogo' => fn () => config('app.logo_url'),
        ];
    }
}
