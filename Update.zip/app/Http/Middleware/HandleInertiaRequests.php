<?php
namespace App\Http\Middleware;
use Inertia\Middleware;
use Illuminate\Http\Request;
class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';

    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    public function share(Request $request): array
    {
        $user = $request->user();

        return [
            ...parent::share($request),
            'auth' => ['user' => $user ? [
                'id' => (int) $user->id,
                'name' => (string) $user->name,
                'email' => (string) $user->email,
                'emailVerified' => $user->email_verified_at !== null,
                'kyc' => (string) ($user->kyc_status ?? 'none'),
            ] : null],
            'adminRole' => fn () => $request->user('admin')?->admin_role ?: ($request->user('admin') ? 'super' : null),
            'flash' => ['status' => fn () => $request->session()->get('status')],
        ];
    }
}
