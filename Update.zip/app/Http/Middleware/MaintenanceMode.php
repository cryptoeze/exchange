<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Admin → Settings → Maintenance mode: users see a notice, the admin panel and webhooks keep working. */
class MaintenanceMode
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! config('app.maintenance_mode') || $request->is('admin', 'admin/*', 'up', 'api/webhooks/*', 'build/*')) {
            return $next($request);
        }
        $msg = (string) config('app.maintenance_message');
        if ($request->expectsJson()) {
            return response()->json(['message' => $msg], 503);
        }

        return response()->view('maintenance', ['message' => $msg, 'name' => config('app.name'), 'email' => config('app.support_email')], 503)->header('Retry-After', '900');
    }
}
