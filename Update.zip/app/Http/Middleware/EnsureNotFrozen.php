<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EnsureNotFrozen
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if ($user && ($user->status ?? 'active') === 'frozen') {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            if ($request->expectsJson()) {
                return response()->json(['message' => 'This account is frozen. Contact support.'], 403);
            }

            return redirect('/login')->withErrors(['email' => 'This account is frozen. Contact support.']);
        }

        return $next($request);
    }
}
