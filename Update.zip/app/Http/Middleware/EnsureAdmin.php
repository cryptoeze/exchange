<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsureAdmin
{
    /** Path prefixes (after "admin/") each non-super role may open. Super admins may open everything. */
    public const ROLE_PATHS = [
        'finance' => ['', 'deposits', 'withdrawals', 'gateways', 'transactions', 'users', 'referrals', 'api', 'security', 'futures', 'earn', 'por', 'orders'],
        'support' => ['', 'users', 'kyc', 'notifications', 'tickets', 'p2p', 'referrals', 'api', 'security', 'trades'],
    ];

    /** Money-moving writes only super and finance may do. */
    private function allowed(string $role, Request $request): bool
    {
        if ($role === 'super') {
            return true;
        }
        $path = trim(substr($request->path(), strlen('admin')), '/');
        $first = explode('/', $path)[0] ?? '';
        if (! in_array($first, self::ROLE_PATHS[$role] ?? [], true)) {
            return false;
        }
        if ($role === 'support' && $request->isMethod('POST') && preg_match('#^users/\d+/wallet#', $path)) {
            return false;
        }

        return true;
    }

    public function handle(Request $request, Closure $next): Response
    {
        $guard = Auth::guard('admin');
        if (! $guard->check()) {
            return redirect()->route('admin.login');
        }
        if ($guard->user()->role !== 'admin') {
            $guard->logout();
            abort(403);
        }
        if (! $this->allowed((string) ($guard->user()->admin_role ?: 'super'), $request)) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Your admin role cannot open this.'], 403);
            }
            abort(403, 'Your admin role cannot open this section.');
        }
        $response = $next($request);
        $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        $response->headers->set('Pragma', 'no-cache');

        return $response;
    }
}
