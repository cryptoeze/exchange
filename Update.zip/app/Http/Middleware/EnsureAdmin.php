<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;
class EnsureAdmin { public function handle(Request $request, Closure $next): Response { $guard=Auth::guard('admin'); if(!$guard->check()) return redirect()->route('admin.login'); if($guard->user()->role!=='admin'){ $guard->logout(); abort(403); } $response=$next($request); $response->headers->set('Cache-Control','no-store, no-cache, must-revalidate, private'); $response->headers->set('Pragma','no-cache'); return $response; } }
