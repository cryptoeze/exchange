<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FuturesPosition extends Model
{
    protected $guarded = [];
    protected $casts = ['closed_at' => 'datetime'];

    public function entry(): float
    {
        return $this->entry_micro / 100_000_000;
    }

    /** Position size in USDT units. */
    public function notional(): int
    {
        return $this->margin * $this->leverage;
    }

    /** Gross PnL in units at a given price. */
    public function pnlAt(float $price): int
    {
        $dir = $this->side === 'long' ? 1 : -1;

        return (int) floor($this->notional() * (($price - $this->entry()) / $this->entry()) * $dir);
    }

    /** Estimated liquidation price (isolated margin, fees ignored). */
    public function liqPrice(): float
    {
        $mmr = (float) config('trading.futures_maintenance_rate');
        $e = $this->entry();

        return $this->side === 'long' ? max(0.0, $e * (1 - 1 / $this->leverage + $mmr)) : $e * (1 + 1 / $this->leverage - $mmr);
    }
}
