<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ManualDeposit extends Model
{
    protected $guarded = [];
}
