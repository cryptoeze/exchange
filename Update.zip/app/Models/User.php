<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = ['name', 'email', 'password', 'role', 'referral_code', 'referred_by', 'phone', 'country'];
    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return ['email_verified_at' => 'datetime', 'password' => 'hashed'];
    }

    /** Every account gets a short unique referral code on creation. */
    protected static function booted(): void
    {
        static::creating(function (User $user): void {
            if (! $user->referral_code) {
                do { $code = strtoupper(Str::random(8)); } while (static::where('referral_code', $code)->exists());
                $user->referral_code = $code;
            }
        });
    }
}
