<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BotFollow extends Model
{
    protected $guarded = [];
    protected $casts = ['cycle_started_at' => 'datetime', 'auto_claim' => 'boolean'];
}
