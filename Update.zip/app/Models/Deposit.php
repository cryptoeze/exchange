<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['credited_at' => 'datetime'];
    }
}
