<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LedgerEntry extends Model
{
    public const UPDATED_AT = null;
    protected $guarded = [];
}
