<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DailyCheckin extends Model
{
    protected $guarded = [];
    protected $casts = ['day' => 'date:Y-m-d'];
}
