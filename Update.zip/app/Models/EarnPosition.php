<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EarnPosition extends Model
{
    protected $guarded = [];
    protected $casts = ['last_accrued_at' => 'datetime'];
}
