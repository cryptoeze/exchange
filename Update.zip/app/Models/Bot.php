<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bot extends Model
{
    protected $guarded = [];
    protected $casts = ['enabled' => 'boolean'];
}
