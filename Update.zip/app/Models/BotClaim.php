<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BotClaim extends Model
{
    protected $guarded = [];
    public const UPDATED_AT = null;
}
