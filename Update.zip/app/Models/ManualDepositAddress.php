<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ManualDepositAddress extends Model
{
    protected $guarded = [];
}
