<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * Hides the referral LINK on the Refer page (only the referral CODE stays visible) — or shows it again.
 * This is a database flag only, not a code change: a fresh install from a new Update.zip always shows the
 * link again unless this command is run on that site too. Run on the live site only, as asked.
 */
class ReferralLink extends Command
{
    protected $signature = 'rushx:referral-link {state : on (show the link, default) or off (hide it, code only)}';
    protected $description = 'Show or hide the referral link on the Refer page. Off = only the referral code is shown.';

    public function handle(): int
    {
        $state = strtolower((string) $this->argument('state'));
        if (! in_array($state, ['on', 'off'], true)) {
            $this->error('Pass "on" or "off".');

            return self::FAILURE;
        }
        if ($state === 'off') {
            DB::table('settings')->updateOrInsert(['key' => 'referral_link_hidden'], ['value' => '1', 'updated_at' => now()]);
            $this->info('Done. The Refer page now shows only the referral code — the link is hidden.');
        } else {
            DB::table('settings')->where('key', 'referral_link_hidden')->delete();
            $this->info('Done. The Refer page shows the referral link again.');
        }

        return self::SUCCESS;
    }
}
