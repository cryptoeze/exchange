<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

/** Run once per install (the buyer runs this with the key the vendor gave them). See LicenseCheck for the ongoing part. */
class LicenseActivate extends Command
{
    protected $signature = 'license:activate {key : The license key given to you by the vendor}';
    protected $description = 'Activate this install with a license key.';

    public function handle(): int
    {
        if (config('license.authority')) {
            $this->info('This is the vendor\'s own install (LICENSE_AUTHORITY=true) — it never needs a license.');

            return self::SUCCESS;
        }
        $key = strtoupper(trim((string) $this->argument('key')));
        $domain = parse_url((string) config('app.url'), PHP_URL_HOST) ?: (string) config('app.url');
        try {
            $r = Http::timeout(10)->post(rtrim((string) config('license.authority_url'), '/').'/api/webhooks/license/activate', ['key' => $key, 'domain' => $domain]);
        } catch (\Throwable $e) {
            $this->error('Could not reach the license server: '.$e->getMessage());

            return self::FAILURE;
        }
        if (! $r->successful() || ($r->json('status') !== 'active')) {
            $this->error('That key was rejected (wrong, already used on another domain, or revoked).');

            return self::FAILURE;
        }
        $now = now();
        foreach (['license_key' => $key, 'license_locked' => '0', 'license_fail_count' => '0'] as $k => $v) {
            DB::table('settings')->updateOrInsert(['key' => $k], ['value' => $v, 'updated_at' => $now]);
        }
        $this->info("Activated for {$domain}. This install checks in automatically from now on (routes/console.php schedule).");

        return self::SUCCESS;
    }
}
