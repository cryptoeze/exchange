<?php

namespace App\Console\Commands;

use App\Services\LimitOrderService;
use Illuminate\Console\Command;

class LimitOrdersFill extends Command
{
    protected $signature = 'orders:fill';
    protected $description = 'Fill spot limit orders whose price has been reached.';

    public function handle(LimitOrderService $limits): int
    {
        $this->info('Filled '.$limits->sweep().' limit orders.');

        return self::SUCCESS;
    }
}
