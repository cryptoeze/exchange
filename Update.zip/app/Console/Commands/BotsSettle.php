<?php

namespace App\Console\Commands;

use App\Models\Bot;
use App\Models\BotFollow;
use App\Services\BotService;
use Illuminate\Console\Command;

class BotsSettle extends Command
{
    protected $signature = 'bots:settle';
    protected $description = 'Pay completed cycles for followers who switched on auto-claim.';

    public function handle(BotService $bots): int
    {
        foreach (BotFollow::query()->where(['status' => 'active', 'auto_claim' => true])->distinct()->pluck('user_id') as $userId) {
            $bots->settleAuto((int) $userId);
        }
        $this->info('Done.');

        return self::SUCCESS;
    }
}
