<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Wipes every user, balance and transaction, leaving admin accounts, settings and
 * gateway configuration untouched. Use this to start fresh on a site that was
 * used for testing. This cannot be undone — there is no backup made.
 */
class ResetData extends Command
{
    protected $signature = 'rushx:reset-data {--yes : Skip the confirmation prompt}';
    protected $description = 'Delete all non-admin users and every balance/transaction. Admin accounts and settings are kept.';

    /** Tables wiped completely (no admin data in them). */
    private const WIPE = [
        'wallet_balances', 'ledger_entries', 'spot_orders', 'spot_limit_orders', 'futures_positions',
        'deposits', 'manual_deposits', 'conversions', 'earn_positions', 'bot_follows', 'bot_claims',
        'daily_checkins', 'referral_rewards', 'kyc_submissions', 'user_notifications', 'withdrawals',
        'login_events', 'price_alerts', 'ticket_messages', 'tickets', 'por_reserves',
        'p2p_messages', 'p2p_disputes', 'p2p_trades', 'p2p_ads', 'user_market_favorites', 'sessions',
    ];

    public function handle(): int
    {
        if (! $this->option('yes') && ! $this->confirm('This deletes ALL users and ALL their balances/transactions. Admin accounts and settings are kept. This cannot be undone. Continue?')) {
            $this->warn('Cancelled.');

            return self::SUCCESS;
        }

        DB::transaction(function (): void {
            foreach (self::WIPE as $table) {
                if (Schema::hasTable($table)) {
                    DB::table($table)->delete();
                }
            }
            DB::table('users')->where('role', '!=', 'admin')->delete();
        });

        $this->info('Done. All users, balances and transactions were removed. Admin accounts and settings were kept.');

        return self::SUCCESS;
    }
}
