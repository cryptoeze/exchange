<?php

namespace App\Console\Commands;

use App\Services\FuturesService;
use Illuminate\Console\Command;

class FuturesSweep extends Command
{
    protected $signature = 'futures:sweep';
    protected $description = 'Close futures positions that hit liquidation, stop-loss or take-profit.';

    public function handle(FuturesService $futures): int
    {
        $this->info('Closed '.$futures->sweep().' positions.');

        return self::SUCCESS;
    }
}
