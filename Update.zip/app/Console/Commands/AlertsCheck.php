<?php

namespace App\Console\Commands;

use App\Services\MarketDataService;
use App\Services\NotificationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class AlertsCheck extends Command
{
    protected $signature = 'alerts:check';
    protected $description = 'Fire price alerts whose target has been reached.';

    public function handle(MarketDataService $markets): int
    {
        $open = DB::table('price_alerts')->whereNull('triggered_at')->get();
        if ($open->isEmpty()) {
            return self::SUCCESS;
        }
        try {
            $snap = $markets->snapshot('spot');
        } catch (\Throwable) {
            return self::SUCCESS;
        }
        if (! empty($snap['meta']['stale'])) {
            return self::SUCCESS; // never alert on old prices
        }
        $price = [];
        foreach ($snap['markets'] as $m) {
            $price[(string) $m['symbol']] = (float) $m['lastPrice'];
        }
        $fired = 0;
        foreach ($open as $a) {
            $p = $price[$a->symbol] ?? null;
            if ($p === null || $p <= 0) {
                continue;
            }
            $hit = $a->direction === 'above' ? $p >= (float) $a->price : $p <= (float) $a->price;
            if ($hit && DB::table('price_alerts')->where('id', $a->id)->whereNull('triggered_at')->update(['triggered_at' => now()])) {
                NotificationService::event($a->user_id, 'price_alert', ['symbol' => $a->symbol, 'direction' => $a->direction === 'above' ? 'rose above' : 'fell below', 'target' => rtrim(rtrim(number_format((float) $a->price, 8, '.', ''), '0'), '.'), 'price' => rtrim(rtrim(number_format($p, 8, '.', ''), '0'), '.')]);
                $fired++;
            }
        }
        $this->info("Fired {$fired} alerts.");

        return self::SUCCESS;
    }
}
