<?php

namespace App\Console\Commands;

use App\Services\SettingsService;
use Illuminate\Console\Command;

/** Sets every trading/platform fee to 0% (spot, futures, convert, P2P). Safe to run any time; same as Admin → Settings. */
class ZeroFees extends Command
{
    protected $signature = 'rushx:zero-fees';
    protected $description = 'Set spot, futures, convert and P2P fees to 0%.';

    public function handle(SettingsService $settings): int
    {
        $settings->save(['spot_fee' => '0', 'futures_fee' => '0', 'convert_fee' => '0', 'p2p_fee' => '0']);
        $this->info('Done. Spot, futures, convert and P2P fees are now 0%. Change them any time in Admin -> Settings.');

        return self::SUCCESS;
    }
}
