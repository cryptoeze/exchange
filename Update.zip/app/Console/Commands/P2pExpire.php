<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class P2pExpire extends Command
{
    protected $signature = 'p2p:expire';
    protected $description = 'Cancel unpaid P2P orders whose payment window ended and return the escrow.';

    public function handle(): int
    {
        if (! class_exists(\App\Services\P2pService::class)) {
            return self::SUCCESS;
        }
        $this->info('Expired '.app(\App\Services\P2pService::class)->expireDue().' orders.');

        return self::SUCCESS;
    }
}
