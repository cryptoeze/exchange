<?php

namespace App\Console\Commands;

use App\Models\EarnProduct;
use App\Services\EarnService;
use Illuminate\Console\Command;

class EarnAccrue extends Command
{
    protected $signature = 'earn:accrue';
    protected $description = 'Pay accrued Earn interest for every open position (optional: interest is also settled when users open the page).';

    public function handle(EarnService $earn): int
    {
        $n = 0;
        foreach (EarnProduct::query()->get() as $product) {
            $n += $earn->settleProduct($product);
        }
        $this->info("Settled {$n} positions.");

        return self::SUCCESS;
    }
}
