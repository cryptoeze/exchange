<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

/**
 * Scheduled every 10 minutes (routes/console.php) on sold copies only — never on the vendor's own install
 * (config('license.authority') === true skips this entirely). Confirms the license is still active with the
 * vendor's server; locks the install (see LicenseLockout middleware) if the vendor revoked it, or unlocks it if
 * it had been locked and is active again. A revoke from the vendor takes effect within one check-in (~10 min).
 *
 * A network problem reaching the vendor's server does NOT lock the site immediately — only after several
 * consecutive failures (config('license.grace_failures'), default 6, ~1 hour) — so a brief outage on either
 * side never locks a paying, licensed site out of its own data.
 */
class LicenseCheck extends Command
{
    protected $signature = 'license:check';
    protected $description = 'Confirm the license is still active with the vendor; locks or unlocks this install accordingly.';

    public function handle(): int
    {
        if (config('license.authority')) {
            return self::SUCCESS; // the vendor's own install never checks itself.
        }
        $key = (string) (DB::table('settings')->where('key', 'license_key')->value('value') ?? '');
        if ($key === '') {
            return self::SUCCESS; // never activated yet — stays unlocked until the buyer runs license:activate.
        }
        $domain = parse_url((string) config('app.url'), PHP_URL_HOST) ?: (string) config('app.url');
        $now = now();
        try {
            $r = Http::timeout(10)->post(rtrim((string) config('license.authority_url'), '/').'/api/webhooks/license/check', ['key' => $key, 'domain' => $domain]);
        } catch (\Throwable) {
            $this->bumpFailures($now);

            return self::SUCCESS;
        }
        if ($r->successful() && $r->json('status') === 'active') {
            foreach (['license_locked' => '0', 'license_fail_count' => '0'] as $k => $v) {
                DB::table('settings')->updateOrInsert(['key' => $k], ['value' => $v, 'updated_at' => $now]);
            }

            return self::SUCCESS;
        }
        if ($r->status() === 403) {
            // The vendor's server explicitly said invalid/revoked — authoritative, lock right away.
            DB::table('settings')->updateOrInsert(['key' => 'license_locked'], ['value' => '1', 'updated_at' => $now]);

            return self::SUCCESS;
        }
        $this->bumpFailures($now); // some other failure (5xx, timeout-like non-exception) — treat as network trouble.

        return self::SUCCESS;
    }

    private function bumpFailures($now): void
    {
        $count = (int) (DB::table('settings')->where('key', 'license_fail_count')->value('value') ?? 0) + 1;
        DB::table('settings')->updateOrInsert(['key' => 'license_fail_count'], ['value' => (string) $count, 'updated_at' => $now]);
        if ($count > (int) config('license.grace_failures', 6)) {
            DB::table('settings')->updateOrInsert(['key' => 'license_locked'], ['value' => '1', 'updated_at' => $now]);
        }
    }
}
