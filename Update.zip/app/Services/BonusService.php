<?php

namespace App\Services;

use App\Models\LedgerEntry;

/** Deposit bonus: credited through the ledger as normal balance, once per deposit. */
final class BonusService
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function enabled(): bool
    {
        return (bool) config('bonus.enabled') && (float) config('bonus.percent') > 0;
    }

    /** Call inside the same transaction that credited the deposit. Returns the bonus in units (0 if none). */
    public function grantForDeposit(int $userId, string $asset, int $depositUnits, string $refType, int $refId): int
    {
        if (! $this->enabled() || $depositUnits <= 0) {
            return 0;
        }
        if (config('bonus.first_only') && LedgerEntry::query()->where(['user_id' => $userId, 'type' => 'deposit_bonus'])->exists()) {
            return 0;
        }
        $bonus = (int) floor($depositUnits * (float) config('bonus.percent') / 100);
        $cap = (int) round((float) config('bonus.max_per_deposit') * 1e8);
        if ($cap > 0) {
            $bonus = min($bonus, $cap);
        }
        if ($bonus <= 0) {
            return 0;
        }
        $this->ledger->apply($userId, 'funding', $asset, $bonus, 'deposit_bonus', [
            'ref_type' => $refType, 'ref_id' => $refId, 'idempotency_key' => "deposit-bonus:{$refType}:{$refId}", 'note' => config('bonus.percent').'% deposit bonus',
        ]);

        return $bonus;
    }
}
