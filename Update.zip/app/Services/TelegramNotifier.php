<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

/** Sends a message to the owner's configured Telegram chat. A no-op if the bot isn't configured. */
class TelegramNotifier
{
    public function toOwner(string $text): void
    {
        $token = (string) config('telegram.bot_token');
        $chat = (string) config('telegram.owner_chat_id');
        if ($token === '' || $chat === '') {
            return;
        }
        Http::timeout(10)->post("https://api.telegram.org/bot{$token}/sendMessage", ['chat_id' => $chat, 'text' => $text]);
    }

    public function toChat(string $chatId, string $text): void
    {
        $token = (string) config('telegram.bot_token');
        if ($token === '') {
            return;
        }
        Http::timeout(10)->post("https://api.telegram.org/bot{$token}/sendMessage", ['chat_id' => $chatId, 'text' => $text]);
    }
}
