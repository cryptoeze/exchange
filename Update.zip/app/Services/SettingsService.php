<?php

namespace App\Services;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** Admin-editable settings stored in the `settings` table and layered over config() at boot. */
final class SettingsService
{
    /** key => [config key, type, label, hint] */
    public const FIELDS = [
        // key => [config key, type, label, hint, group]
        'spot_fee' => ['trading.spot_fee_rate', 'rate', 'Spot trading fee %', 'Charged on every spot fill (e.g. 0.02)', 'Fees & trading limits'],
        'futures_fee' => ['trading.futures_fee_rate', 'rate', 'Futures fee % (on position size)', 'Charged at open and again at close (e.g. 0.05)', 'Fees & trading limits'],
        'futures_maint' => ['trading.futures_maintenance_rate', 'rate', 'Futures maintenance margin %', 'Liquidation happens when margin + PnL falls below this share of the position size', 'Fees & trading limits'],
        'futures_max_lev' => ['trading.futures_max_leverage', 'int', 'Futures max leverage (x)', '', 'Fees & trading limits'],
        'futures_min_margin' => ['trading.futures_min_margin_usdt', 'float', 'Futures min margin (USDT)', '', 'Fees & trading limits'],
        'futures_max_margin' => ['trading.futures_max_margin_usdt', 'float', 'Futures max margin per position (USDT)', '', 'Fees & trading limits'],
        'futures_enabled' => ['trading.futures_enabled', 'bool', 'Futures trading on', 'Switch off to stop new positions (open ones keep running)', 'Fees & trading limits'],
        'spot_min_quote' => ['trading.spot_min_quote_usdt', 'float', 'Spot min order (USDT)', '', 'Fees & trading limits'],
        'spot_max_quote' => ['trading.spot_max_quote_usdt', 'float', 'Spot max order (USDT)', '', 'Fees & trading limits'],
        'margin_alert' => ['trading.margin_alert_pct', 'float', 'Low-margin alert at % of buffer left', 'User is warned when only this % of the safety buffer remains (e.g. 25)', 'Fees & trading limits'],
        'bonus_enabled' => ['bonus.enabled', 'bool', 'Deposit bonus on', '', 'Bonuses & rewards'],
        'bonus_percent' => ['bonus.percent', 'float', 'Deposit bonus %', 'Added to Funding as real balance', 'Bonuses & rewards'],
        'bonus_first_only' => ['bonus.first_only', 'bool', 'Bonus on first deposit only', '', 'Bonuses & rewards'],
        'bonus_max' => ['bonus.max_per_deposit', 'float', 'Max bonus per deposit (USD)', '0 = no cap', 'Bonuses & rewards'],
        'rewards_enabled' => ['rewards.enabled', 'bool', 'Daily rewards on', '', 'Bonuses & rewards'],
        'rewards_amounts' => ['rewards.amounts', 'amounts', 'Daily reward amounts (7 days)', 'Comma separated, e.g. 0.10,0.15,0.25,0.40,0.60,0.80,2.00', 'Bonuses & rewards'],
        'referral_percent' => ['referral.percent', 'float', 'Referral commission %', 'Of every credited deposit, paid to the referrer. 0 = off', 'Bonuses & rewards'],
        'referral_max' => ['referral.max_per_deposit', 'float', 'Max commission per deposit (USD)', '0 = no cap', 'Bonuses & rewards'],
        'withdraw_enabled' => ['withdraw.enabled', 'bool', 'Withdrawals on', '', 'Gateways & compliance'],
        'kyc_required' => ['kyc.required_for_withdrawal', 'bool', 'KYC required to withdraw', 'Users need approved identity verification', 'Gateways & compliance'],
        'auto_deposit' => ['gateways.auto_deposit', 'bool', 'Auto deposits (NOWPayments) on', '', 'Gateways & compliance'],
        'manual_deposit' => ['gateways.manual_deposit', 'bool', 'Manual deposits on', '', 'Gateways & compliance'],
        'p2p_enabled' => ['p2p.enabled', 'bool', 'P2P marketplace on', 'Switch off to stop new ads and orders (open orders can still finish)', 'P2P'],
        'p2p_fee' => ['p2p.fee_pct', 'float', 'P2P fee % (taken from the coin the buyer receives)', '0 = free', 'P2P'],
        'mail_enabled' => ['mail-templates.enabled', 'bool', 'Send emails to users', 'Master switch for all notification emails (SMTP must be configured in .env)', 'Display & email'],
        'site_name' => ['app.name', 'text', 'Site name', 'Shown in emails and the browser title of new pages', 'Site setup'],
        'support_email' => ['app.support_email', 'text', 'Support email', 'Shown to users who need help', 'Site setup'],
        'maintenance' => ['app.maintenance_mode', 'bool', 'Maintenance mode', 'Users see a maintenance page; admin panel keeps working', 'Site setup'],
        'maintenance_msg' => ['app.maintenance_message', 'text', 'Maintenance message', 'e.g. We are upgrading. Back in 30 minutes.', 'Site setup'],
        'smtp_host' => ['mail.mailers.smtp.host', 'text', 'SMTP host', 'e.g. smtp.hostinger.com', 'Email (SMTP)'],
        'smtp_port' => ['mail.mailers.smtp.port', 'int', 'SMTP port', '465 (SSL) or 587 (TLS)', 'Email (SMTP)'],
        'smtp_user' => ['mail.mailers.smtp.username', 'text', 'SMTP username', '', 'Email (SMTP)'],
        'smtp_pass' => ['mail.mailers.smtp.password', 'secret', 'SMTP password', 'Stored encrypted. Leave as is to keep the current one', 'Email (SMTP)'],
        'smtp_scheme' => ['mail.mailers.smtp.scheme', 'text', 'SMTP security', 'smtps for port 465, smtp for 587/25 (leave empty for auto)', 'Email (SMTP)'],
        'mail_from' => ['mail.from.address', 'text', 'From address', 'e.g. no-reply@riseway.io', 'Email (SMTP)'],
        'mail_from_name' => ['mail.from.name', 'text', 'From name', '', 'Email (SMTP)'],
        'convert_enabled' => ['trading.convert_enabled', 'bool', 'Convert on', 'Switch off to stop instant conversions', 'Fees & trading limits'],
        'convert_fee' => ['trading.convert_fee_rate', 'rate', 'Convert fee %', '0 = free. Taken from the coin the user receives', 'Fees & trading limits'],
        'transfer_enabled' => ['trading.transfer_enabled', 'bool', 'Internal transfers on', 'Funding ⇄ Trading ⇄ other accounts', 'Fees & trading limits'],
        'pairs_off' => ['trading.disabled_pairs', 'list', 'Paused pairs', 'Managed from Admin → Markets', '_hidden'],
        'pkr_rate' => ['currency.pkr_rate', 'float', 'PKR per 1 USD (display only)', '', 'Display & email'],
    ];


    public function stored(): array
    {
        return DB::table('settings')->pluck('value', 'key')->all();
    }

    public function apply(): void
    {
        foreach ($this->stored() as $key => $raw) {
            if (! isset(self::FIELDS[$key]) || $raw === null) {
                continue;
            }
            [$cfg, $type] = self::FIELDS[$key];
            config([$cfg => $this->cast($raw, $type)]);
        }
        if (config('mail.mailers.smtp.host') && config('mail.mailers.smtp.host') !== '127.0.0.1' && ! empty($this->stored()['smtp_host'])) {
            config(['mail.default' => 'smtp']);
        }
        $this->applyWithdrawNetworks($this->stored());
        $this->applyDepositOff($this->stored());
        $this->applyLogo($this->stored());
    }

    /** Custom logo uploaded from Admin → Settings (falls back to the built-in RushX mark when not set). */
    private function applyLogo(array $stored): void
    {
        $path = trim((string) ($stored['site_logo'] ?? ''));
        config(['app.logo_url' => $path !== '' ? Storage::disk('public')->url($path) : null]);
    }

    /** Auto-deposit networks the admin switched off (Admin → Gateways). The full list stays in `coins_all` for the admin screen. */
    private function applyDepositOff(array $stored): void
    {
        $off = array_values(array_filter(array_map('trim', explode(',', (string) ($stored['dep_off'] ?? '')))));
        $all = (array) config('deposit-coins.coins');
        config(['deposit-coins.coins_all' => $all, 'deposit-coins.off' => $off]);
        if ($off) {
            config(['deposit-coins.coins' => array_values(array_filter(array_map(function ($c) use ($off) {
                $c['networks'] = array_values(array_filter($c['networks'], fn ($n) => ! in_array($n['code'], $off, true)));

                return $c['networks'] ? $c : null;
            }, $all)))]);
        }
    }

    public function saveDepositOff(array $codes): void
    {
        $clean = array_values(array_unique(array_filter(array_map(fn ($x) => preg_replace('/[^a-z0-9]/', '', strtolower((string) $x)), $codes))));
        DB::table('settings')->updateOrInsert(['key' => 'dep_off'], ['value' => implode(',', $clean), 'updated_at' => now()]);
    }

    /** Per-asset minimum, per-network fee and on/off overrides from Admin → Gateways. */
    private function applyWithdrawNetworks(array $stored): void
    {
        $all = [];
        foreach ((array) config('withdraw.assets') as $asset) {
            $t = $asset['ticker'];
            if (isset($stored["wd_min.$t"])) {
                $asset['min'] = (float) $stored["wd_min.$t"];
            }
            foreach ($asset['networks'] as &$n) {
                $k = "$t.{$n['code']}";
                if (isset($stored["wd_fee.$k"])) {
                    $n['fee'] = (float) $stored["wd_fee.$k"];
                }
                $n['off'] = ($stored["wd_off.$k"] ?? '0') === '1';
            }
            unset($n);
            $all[] = $asset;
        }
        config(['withdraw.assets_all' => $all]);
        config(['withdraw.assets' => array_values(array_filter(array_map(function ($a) {
            $a['networks'] = array_values(array_filter($a['networks'], fn ($n) => empty($n['off'])));

            return $a['networks'] ? $a : null;
        }, $all)))]);
    }

    public function saveWithdrawNetworks(array $rows): void
    {
        foreach ($rows as $r) {
            $t = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) ($r['ticker'] ?? '')));
            $c = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) ($r['code'] ?? '')));
            if ($t === '' || $c === '') {
                continue;
            }
            foreach (["wd_min.$t" => (string) max(0, (float) ($r['min'] ?? 0)), "wd_fee.$t.$c" => (string) max(0, (float) ($r['fee'] ?? 0)), "wd_off.$t.$c" => ! empty($r['off']) ? '1' : '0'] as $k => $v) {
                DB::table('settings')->updateOrInsert(['key' => $k], ['value' => $v, 'updated_at' => now()]);
            }
        }
    }

    public function savePairs(array $off): void
    {
        $clean = array_values(array_unique(array_filter(array_map(fn ($x) => preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $x)), $off))));
        DB::table('settings')->updateOrInsert(['key' => 'pairs_off'], ['value' => implode(',', $clean), 'updated_at' => now()]);
    }

    public function current(): array
    {
        $out = [];
        foreach (self::FIELDS as $key => [$cfg, $type]) {
            $v = config($cfg);
            $out[$key] = match ($type) {
                'bool' => (bool) $v,
                'secret' => $v ? '********' : '',
                'list' => implode(',', (array) $v),
                'amounts' => implode(',', array_map(fn ($a) => number_format((float) $a, 2, '.', ''), (array) $v)),
                'rate' => rtrim(rtrim(number_format((float) $v * 100, 4, '.', ''), '0'), '.') ?: '0',
                default => (string) $v,
            };
        }

        return $out;
    }

    public function save(array $input): void
    {
        foreach (self::FIELDS as $key => [, $type]) {
            if (! array_key_exists($key, $input)) {
                continue;
            }
            if ($type === 'list') {
                continue; // managed from Admin → Markets (savePairs)
            }
            if ($type === 'secret') {
                $plain = trim((string) $input[$key]);
                if ($plain === '' || $plain === '********') {
                    continue;
                }
                $value = Crypt::encryptString($plain);
            } else {
                $value = $type === 'bool' ? ($input[$key] ? '1' : '0') : trim((string) $input[$key]);
            }
            DB::table('settings')->updateOrInsert(['key' => $key], ['value' => $value, 'updated_at' => now()]);
        }
    }

    private function cast(string $raw, string $type): mixed
    {
        return match ($type) {
            'bool' => $raw === '1',
            'float' => (float) $raw,
            'int' => (int) $raw,
            'rate' => (float) $raw / 100,
            'amounts' => array_map('floatval', explode(',', $raw)),
            'text' => $raw,
            'secret' => $this->decrypt($raw),
            'list' => array_values(array_filter(array_map('trim', explode(',', $raw)))),
        };
    }

    private function decrypt(string $raw): string
    {
        try {
            return Crypt::decryptString($raw);
        } catch (\Throwable) {
            return '';
        }
    }
}
