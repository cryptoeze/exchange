<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

/** Admin-editable settings stored in the `settings` table and layered over config() at boot. */
final class SettingsService
{
    /** key => [config key, type, label, hint] */
    public const FIELDS = [
        'bonus_enabled' => ['bonus.enabled', 'bool', 'Deposit bonus on', ''],
        'bonus_percent' => ['bonus.percent', 'float', 'Deposit bonus %', 'Added to Funding as real balance'],
        'bonus_first_only' => ['bonus.first_only', 'bool', 'Bonus on first deposit only', ''],
        'bonus_max' => ['bonus.max_per_deposit', 'float', 'Max bonus per deposit (USD)', '0 = no cap'],
        'rewards_enabled' => ['rewards.enabled', 'bool', 'Daily rewards on', ''],
        'rewards_amounts' => ['rewards.amounts', 'amounts', 'Daily reward amounts (7 days)', 'Comma separated, e.g. 0.10,0.15,0.25,0.40,0.60,0.80,2.00'],
        'withdraw_enabled' => ['withdraw.enabled', 'bool', 'Withdrawals on', ''],
        'kyc_required' => ['kyc.required_for_withdrawal', 'bool', 'KYC required to withdraw', 'Users need approved identity verification'],
        'referral_percent' => ['referral.percent', 'float', 'Referral commission %', 'Of every credited deposit, paid to the referrer. 0 = off'],
        'referral_max' => ['referral.max_per_deposit', 'float', 'Max commission per deposit (USD)', '0 = no cap'],
        'pkr_rate' => ['currency.pkr_rate', 'float', 'PKR per 1 USD (display only)', ''],
    ];

    public function stored(): array
    {
        return DB::table('settings')->pluck('value', 'key')->all();
    }

    public function apply(): void
    {
        foreach ($this->stored() as $key => $raw) {
            if (! isset(self::FIELDS[$key]) || $raw === null) {
                continue;
            }
            [$cfg, $type] = self::FIELDS[$key];
            config([$cfg => $this->cast($raw, $type)]);
        }
    }

    public function current(): array
    {
        $out = [];
        foreach (self::FIELDS as $key => [$cfg, $type]) {
            $v = config($cfg);
            $out[$key] = $type === 'bool' ? (bool) $v : ($type === 'amounts' ? implode(',', array_map(fn ($a) => number_format((float) $a, 2, '.', ''), (array) $v)) : (string) $v);
        }

        return $out;
    }

    public function save(array $input): void
    {
        foreach (self::FIELDS as $key => [, $type]) {
            if (! array_key_exists($key, $input)) {
                continue;
            }
            $value = $type === 'bool' ? ($input[$key] ? '1' : '0') : trim((string) $input[$key]);
            DB::table('settings')->updateOrInsert(['key' => $key], ['value' => $value, 'updated_at' => now()]);
        }
    }

    private function cast(string $raw, string $type): mixed
    {
        return match ($type) {
            'bool' => $raw === '1',
            'float' => (float) $raw,
            'amounts' => array_map('floatval', explode(',', $raw)),
        };
    }
}
