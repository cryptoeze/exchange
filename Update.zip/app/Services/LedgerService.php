<?php

namespace App\Services;

use App\Models\LedgerEntry;
use App\Models\WalletBalance;
use DomainException;
use Illuminate\Database\QueryException;

/**
 * The only code allowed to change a balance. Every change is one locked read-modify-write
 * plus one append-only journal row. Call inside DB::transaction().
 */
final class LedgerService
{
    public const ACCOUNTS = ['funding', 'trading', 'copy', 'earn', 'bots'];

    public function balance(int $userId, string $account, string $asset): int
    {
        return (int) (WalletBalance::query()->where(['user_id' => $userId, 'account' => $account, 'asset' => $asset])->value('balance') ?? 0);
    }

    /**
     * @param array{ref_type?:string,ref_id?:int,idempotency_key?:string,created_by?:int,note?:string} $meta
     */
    public function apply(int $userId, string $account, string $asset, int $delta, string $type, array $meta = []): LedgerEntry
    {
        if (! in_array($account, self::ACCOUNTS, true)) {
            throw new DomainException('Unknown account.');
        }
        if ($delta === 0) {
            throw new DomainException('Amount must not be zero.');
        }
        $key = $meta['idempotency_key'] ?? null;
        if ($key !== null && ($existing = LedgerEntry::query()->where('idempotency_key', $key)->first())) {
            return $existing; // replay of the same request: no second effect
        }

        $row = $this->lockedRow($userId, $account, $asset);
        $next = (int) $row->balance + $delta;
        if ($next < 0) {
            throw new DomainException('Insufficient balance.');
        }
        $row->balance = $next;
        $row->save();

        return LedgerEntry::query()->create([
            'user_id' => $userId, 'account' => $account, 'asset' => $asset, 'amount' => $delta, 'balance_after' => $next,
            'type' => $type, 'ref_type' => $meta['ref_type'] ?? null, 'ref_id' => $meta['ref_id'] ?? null,
            'idempotency_key' => $key, 'created_by' => $meta['created_by'] ?? null, 'note' => isset($meta['note']) ? mb_substr($meta['note'], 0, 255) : null,
        ]);
    }

    private function lockedRow(int $userId, string $account, string $asset): WalletBalance
    {
        $find = fn () => WalletBalance::query()->where(['user_id' => $userId, 'account' => $account, 'asset' => $asset])->lockForUpdate()->first();
        if ($row = $find()) {
            return $row;
        }
        try {
            WalletBalance::query()->create(['user_id' => $userId, 'account' => $account, 'asset' => $asset, 'balance' => 0]);
        } catch (QueryException) {
            // created concurrently by another request; fall through and lock it
        }

        return $find() ?? throw new DomainException('Wallet unavailable.');
    }
}
