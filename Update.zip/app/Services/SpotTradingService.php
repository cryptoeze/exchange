<?php

namespace App\Services;

use App\Models\SpotOrder;
use App\Models\User;
use App\Support\Money;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * Independent (house-matched) spot market orders. Execution price comes from the server-side
 * market-data snapshot, never from the browser. All balance changes go through LedgerService.
 */
final class SpotTradingService
{
    public function __construct(private readonly LedgerService $ledger, private readonly MarketDataService $markets)
    {
    }

    /** @return array{price: float, base: string} */
    public function quote(string $symbol): array
    {
        $snapshot = $this->markets->snapshot('spot');
        $updated = strtotime((string) ($snapshot['meta']['updatedAt'] ?? '')) ?: 0;
        if (! empty($snapshot['meta']['stale']) || (time() - $updated) > (int) config('trading.max_price_age_seconds')) {
            throw new DomainException('Live prices are temporarily delayed. Please try again in a moment.');
        }
        foreach ($snapshot['markets'] as $market) {
            if (($market['symbol'] ?? '') === $symbol && ($market['marketType'] ?? '') === 'spot' && ($market['isTradable'] ?? true)) {
                $price = (float) $market['lastPrice'];
                if ($price <= 0) {
                    break;
                }

                return ['price' => $price, 'base' => (string) $market['baseAsset']];
            }
        }
        throw new DomainException('This market is not available for trading.');
    }

    /**
     * BUY: $amount is USDT to spend.  SELL: $amount is base-asset quantity to sell.
     */
    public function marketOrder(User $user, string $symbol, string $side, string $amount, ?string $idempotencyKey = null): SpotOrder
    {
        if (! in_array($side, ['buy', 'sell'], true)) {
            throw new DomainException('Invalid side.');
        }
        $q = $this->quote($symbol);
        $price = $q['price'];
        $base = $q['base'];
        $quoteAsset = (string) config('trading.quote_asset');
        $feeRate = (float) config('trading.spot_fee_rate');
        $units = Money::toUnits($amount);

        if ($side === 'buy') {
            $spend = $units;
            $min = Money::toUnits((float) config('trading.spot_min_quote_usdt'));
            $max = Money::toUnits((float) config('trading.spot_max_quote_usdt'));
            if ($spend < $min || $spend > $max) {
                throw new DomainException('Order size is outside the allowed range.');
            }
            $fee = (int) floor($spend * $feeRate);
            $baseQty = (int) floor(($spend - $fee) / $price);
            $quoteTotal = $spend;
        } else {
            $baseQty = $units;
            $gross = (int) floor($baseQty * $price);
            $min = Money::toUnits((float) config('trading.spot_min_quote_usdt'));
            $max = Money::toUnits((float) config('trading.spot_max_quote_usdt'));
            if ($gross < $min || $gross > $max) {
                throw new DomainException('Order size is outside the allowed range.');
            }
            $fee = (int) floor($gross * $feeRate);
            $quoteTotal = $gross;
        }
        if ($baseQty <= 0) {
            throw new DomainException('Order size is too small.');
        }

        return DB::transaction(function () use ($user, $symbol, $side, $price, $base, $quoteAsset, $baseQty, $quoteTotal, $fee, $idempotencyKey): SpotOrder {
            if ($idempotencyKey !== null && ($existing = SpotOrder::query()->where('idempotency_key', $idempotencyKey)->where('user_id', $user->id)->first())) {
                return $existing;
            }
            $order = SpotOrder::query()->create([
                'user_id' => $user->id, 'symbol' => $symbol, 'base_asset' => $base, 'side' => $side,
                'price_micro' => (int) round($price * Money::SCALE), 'base_qty' => $baseQty, 'quote_total' => $quoteTotal,
                'fee' => $fee, 'status' => 'filled', 'idempotency_key' => $idempotencyKey,
            ]);
            $meta = ['ref_type' => 'spot_order', 'ref_id' => $order->id];
            if ($side === 'buy') {
                $this->ledger->apply($user->id, 'funding', $quoteAsset, -$quoteTotal, 'spot_buy', $meta);
                $this->ledger->apply($user->id, 'funding', $base, $baseQty, 'spot_buy', $meta);
            } else {
                $this->ledger->apply($user->id, 'funding', $base, -$baseQty, 'spot_sell', $meta);
                $this->ledger->apply($user->id, 'funding', $quoteAsset, $quoteTotal - $fee, 'spot_sell', $meta);
            }

            return $order;
        }, 3);
    }
}
