<?php

namespace App\Services;

use Illuminate\Http\Client\Response;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

class MarketDataService
{
    private const SNAPSHOT_KEY = 'rushx.market-data.snapshot.v1';
    private const LAST_GOOD_KEY = 'rushx.market-data.last-good.v1';
    private const HEALTH_KEY = 'rushx.market-data.health.v1';

    /** @return array<string, mixed> */
    public function snapshot(string $type = 'both'): array
    {
        if (! in_array($type, ['spot', 'futures', 'both'], true)) {
            throw new RuntimeException('Unsupported market type.');
        }

        try {
            $snapshot = Cache::get(self::SNAPSHOT_KEY);
            if (is_array($snapshot) && isset($snapshot['markets'], $snapshot['highlights'])) {
                return $this->forType($snapshot, $type);
            }

            $snapshot = Cache::lock('rushx.market-data.refresh-lock.v1', 45)->block(8, function (): array {
                $cached = Cache::get(self::SNAPSHOT_KEY);
                if (is_array($cached) && isset($cached['markets'], $cached['highlights'])) {
                    return $cached;
                }

                $data = $this->fetchSnapshot();
                $seconds = max(2, (int) config('market-data.cache_seconds', 3));
                Cache::put(self::SNAPSHOT_KEY, $data, now()->addSeconds($seconds));
                Cache::put(self::LAST_GOOD_KEY, $data, now()->addSeconds(max($seconds, (int) config('market-data.stale_seconds', 600))));
                Cache::put(self::HEALTH_KEY, [
                    'status' => 'connected',
                    'updated_at' => $data['meta']['updatedAt'],
                    'spot_count' => $data['meta']['spotCount'],
                    'futures_count' => $data['meta']['futuresCount'],
                    'last_error' => null,
                ], now()->addSeconds(max(3600, (int) config('market-data.stale_seconds', 600))));

                return $data;
            });

            return $this->forType($snapshot, $type);
        } catch (Throwable $exception) {
            Log::warning('RushX market data provider request failed.', ['exception' => $exception::class]);
            Cache::put(self::HEALTH_KEY, [
                'status' => 'degraded',
                'updated_at' => data_get(Cache::get(self::LAST_GOOD_KEY), 'meta.updatedAt'),
                'spot_count' => data_get(Cache::get(self::LAST_GOOD_KEY), 'meta.spotCount', 0),
                'futures_count' => data_get(Cache::get(self::LAST_GOOD_KEY), 'meta.futuresCount', 0),
                'last_error' => 'Provider request failed. The last successful update is shown when available.',
            ], now()->addHour());

            $lastGood = Cache::get(self::LAST_GOOD_KEY);
            if (is_array($lastGood) && isset($lastGood['markets'], $lastGood['highlights'])) {
                $lastGood['meta']['stale'] = true;
                $lastGood['meta']['lastError'] = 'Live market data is temporarily unavailable; showing a cached snapshot.';

                return $this->forType($lastGood, $type);
            }

            throw new RuntimeException('Market data is temporarily unavailable.', previous: $exception);
        }
    }

    /** @return array<string, mixed> */
    public function health(): array
    {
        $health = Cache::get(self::HEALTH_KEY);
        $lastGood = Cache::get(self::LAST_GOOD_KEY);
        $updatedAt = is_array($health) ? ($health['updated_at'] ?? null) : data_get($lastGood, 'meta.updatedAt');
        $freshLimit = max(60, (int) config('market-data.refresh_seconds', 20) * 4);
        try {
            $isRecent = is_string($updatedAt) && Carbon::parse($updatedAt)->greaterThan(now()->subSeconds($freshLimit));
        } catch (Throwable) {
            $isRecent = false;
        }
        $hasStale = is_array($lastGood) && isset($lastGood['meta']['updatedAt']);

        return [
            'provider' => (string) config('market-data.provider', 'bybit'),
            'status' => $isRecent && empty($health['last_error'] ?? null) ? 'Connected' : ($hasStale ? 'Degraded' : 'Not checked yet'),
            'updatedAt' => $updatedAt,
            'spotCount' => (int) (is_array($health) ? ($health['spot_count'] ?? data_get($lastGood, 'meta.spotCount', 0)) : data_get($lastGood, 'meta.spotCount', 0)),
            'futuresCount' => (int) (is_array($health) ? ($health['futures_count'] ?? data_get($lastGood, 'meta.futuresCount', 0)) : data_get($lastGood, 'meta.futuresCount', 0)),
            'lastError' => is_array($health) ? ($health['last_error'] ?? null) : null,
            'refreshSeconds' => max(5, (int) config('market-data.refresh_seconds', 20)),
            'credentialsRequired' => false,
        ];
    }

    /** @return array<string, mixed> */
    private function fetchSnapshot(): array
    {
        if (config('market-data.provider') !== 'bybit') {
            throw new RuntimeException('The configured market data provider is not supported.');
        }

        $baseUrl = rtrim((string) config('market-data.base_url'), '/');
        if (! str_starts_with($baseUrl, 'https://')) {
            throw new RuntimeException('Market data provider URL must use HTTPS.');
        }

        $spotInstruments = $this->instruments('spot');
        $futuresInstruments = $this->instruments('linear');
        $spotTickers = $this->tickerMap('spot');
        $futuresTickers = $this->tickerMap('linear');

        $spot = $this->normalize($spotInstruments, $spotTickers, 'spot');
        $futures = $this->normalize($futuresInstruments, $futuresTickers, 'futures');
        $markets = [...$spot, ...$futures];
        usort($markets, static fn (array $a, array $b): int => $b['turnover24h'] <=> $a['turnover24h']);
        if ($spot === [] || $futures === []) {
            throw new RuntimeException('The market provider returned an empty active market set.');
        }

        $updatedAt = now()->toIso8601String();
        $spotByTurnover = $this->uniqueBases(array_values(array_filter($spot, static fn (array $market): bool => $market['turnover24h'] > 0)));
        usort($spotByTurnover, static fn (array $a, array $b): int => $b['turnover24h'] <=> $a['turnover24h']);
        $hotCrypto = $spotByTurnover;
        usort($hotCrypto, static fn (array $a, array $b): int =>
            ($b['turnover24h'] * (1 + min(100, abs($b['change24h'])) / 100)) <=>
            ($a['turnover24h'] * (1 + min(100, abs($a['change24h'])) / 100))
        );
        $gainers = array_values(array_filter($futures, static fn (array $market): bool => $market['change24h'] > 0));
        usort($gainers, static fn (array $a, array $b): int => $b['change24h'] <=> $a['change24h']);

        return [
            'markets' => $markets,
            'highlights' => [
                'hotCrypto' => array_slice($hotCrypto, 0, 3),
                'topGainers' => array_slice($this->uniqueBases($gainers), 0, 3),
                'topVolume24h' => array_slice($spotByTurnover, 0, 3),
            ],
            'meta' => [
                'provider' => 'Bybit',
                'updatedAt' => $updatedAt,
                'stale' => false,
                'lastError' => null,
                'spotCount' => count($spot),
                'futuresCount' => count($futures),
                'refreshSeconds' => max(5, (int) config('market-data.refresh_seconds', 20)),
                'topRankLimit' => max(1, (int) config('market-data.top_rank_limit', 50)),
            ],
        ];
    }

    /** @return array<string, mixed> */
    private function forType(array $snapshot, string $type): array
    {
        if ($type !== 'both') {
            $snapshot['markets'] = array_values(array_filter(
                $snapshot['markets'],
                static fn (array $market): bool => $market['marketType'] === $type,
            ));
        }

        return $snapshot;
    }

    /** @return array<string, array<string, mixed>> */
    private function tickerMap(string $category): array
    {
        $payload = $this->get('/v5/market/tickers', ['category' => $category]);
        $map = [];
        foreach ($payload['result']['list'] as $ticker) {
            if (is_array($ticker) && is_string($ticker['symbol'] ?? null)) {
                $map[$ticker['symbol']] = $ticker;
            }
        }

        return $map;
    }

    /** @return array<string, array<string, mixed>> */
    private function instruments(string $category): array
    {
        $cacheKey = 'rushx.market-data.instruments.'.$category.'.v1';
        $cached = Cache::get($cacheKey);
        if (is_array($cached)) {
            return $cached;
        }

        $cursor = null;
        $pages = 0;
        $result = [];
        $previousCursor = null;
        do {
            $params = ['category' => $category, 'status' => 'Trading', 'limit' => 1000];
            if ($cursor !== null) {
                $params['cursor'] = $cursor;
            }
            $payload = $this->get('/v5/market/instruments-info', $params);
            foreach ($payload['result']['list'] as $instrument) {
                if (is_array($instrument) && is_string($instrument['symbol'] ?? null)) {
                    $result[$instrument['symbol']] = $instrument;
                }
            }
            $next = $payload['result']['nextPageCursor'] ?? '';
            $cursor = is_string($next) && $next !== '' ? $next : null;
            $pages++;
            if ($cursor !== null && $cursor === $previousCursor) {
                throw new RuntimeException('The market provider repeated an instrument pagination cursor.');
            }
            $previousCursor = $cursor;
        } while ($category === 'linear' && $cursor !== null && $pages < 10);

        if ($cursor !== null) {
            throw new RuntimeException('The market provider returned more instrument pages than expected.');
        }
        if ($result === []) {
            throw new RuntimeException('The market provider returned no trading instruments.');
        }

        Cache::put($cacheKey, $result, now()->addSeconds(max(300, (int) config('market-data.instrument_cache_seconds', 21600))));

        return $result;
    }

    /** @return array<string, mixed> */
    private function get(string $path, array $query): array
    {
        $url = rtrim((string) config('market-data.base_url'), '/').$path;
        $response = Http::acceptJson()
            ->timeout(max(2, (int) config('market-data.timeout_seconds', 4)))
            ->retry(max(1, (int) config('market-data.retry_attempts', 1)), 150)
            ->get($url, $query)
            ->throw();

        return $this->payload($response);
    }

    /** @return array<string, mixed> */
    private function payload(Response $response): array
    {
        $payload = $response->json();
        if (! is_array($payload) || (int) ($payload['retCode'] ?? -1) !== 0
            || ! is_array($payload['result']['list'] ?? null)) {
            throw new RuntimeException('The market provider returned an invalid payload.');
        }

        return $payload;
    }

    /** @return array<int, array<string, mixed>> */
    private function normalize(array $instruments, array $tickers, string $marketType): array
    {
        $assets = (array) config('market-assets');
        $normalized = [];
        foreach ($instruments as $symbol => $instrument) {
            if (($instrument['status'] ?? null) !== 'Trading'
                || ($instrument['quoteCoin'] ?? null) !== 'USDT'
                || ! is_string($instrument['baseCoin'] ?? null)
                || $instrument['baseCoin'] === '') {
                continue;
            }

            $ticker = $tickers[$symbol] ?? null;
            if (! is_array($ticker)) {
                continue;
            }

            $values = [
                'lastPrice' => $ticker['lastPrice'] ?? null,
                'price24hPcnt' => $ticker['price24hPcnt'] ?? null,
                'highPrice24h' => $ticker['highPrice24h'] ?? null,
                'lowPrice24h' => $ticker['lowPrice24h'] ?? null,
                'volume24h' => $ticker['volume24h'] ?? null,
                'turnover24h' => $ticker['turnover24h'] ?? null,
            ];
            foreach ($values as $value) {
                if (! is_numeric($value) || ! is_finite((float) $value)) {
                    continue 2;
                }
            }
            if ((float) $values['lastPrice'] <= 0 || (float) $values['highPrice24h'] < 0
                || (float) $values['lowPrice24h'] < 0 || (float) $values['volume24h'] < 0
                || (float) $values['turnover24h'] < 0) {
                continue;
            }

            $base = strtoupper($instrument['baseCoin']);
            $asset = is_array($assets[$base] ?? null) ? $assets[$base] : [];
            $launchMs = is_numeric($instrument['launchTime'] ?? null) ? (int) $instrument['launchTime'] : null;
            $launchAt = $launchMs && $launchMs > 0 ? Carbon::createFromTimestampMs($launchMs)->toIso8601String() : null;
            $isNew = $launchMs !== null
                && $launchMs <= now()->getTimestampMs()
                && $launchMs >= now()->subDays(max(1, (int) config('market-data.new_listing_days', 30)))->getTimestampMs();

            $normalized[] = [
                'symbol' => (string) $symbol,
                'baseAsset' => $base,
                'quoteAsset' => 'USDT',
                'marketType' => $marketType,
                'displayName' => (string) ($asset['name'] ?? $base),
                'lastPrice' => (float) $values['lastPrice'],
                'change24h' => (float) $values['price24hPcnt'] * 100,
                'high24h' => (float) $values['highPrice24h'],
                'low24h' => (float) $values['lowPrice24h'],
                'volume24h' => (float) $values['volume24h'],
                'turnover24h' => (float) $values['turnover24h'],
                'isTradable' => true,
                'instrumentStatus' => (string) $instrument['status'],
                'launchTime' => $launchAt,
                'isNew' => $isNew,
                'categories' => array_values(array_intersect((array) ($asset['categories'] ?? []), ['AI', 'Meme', 'DeFi', 'Layer 1'])),
                'icon' => isset($asset['icon']) ? '/images/coins/'.$asset['icon'] : null,
            ];
        }

        return $normalized;
    }

    /** @return array<int, array<string, mixed>> */
    private function uniqueBases(array $markets): array
    {
        $seen = [];
        $unique = [];
        foreach ($markets as $market) {
            if (isset($seen[$market['baseAsset']])) {
                continue;
            }
            $seen[$market['baseAsset']] = true;
            $unique[] = $market;
        }

        return $unique;
    }
}
