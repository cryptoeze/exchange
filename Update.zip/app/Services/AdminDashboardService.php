<?php

namespace App\Services;

use App\Models\User;
use App\Support\Money;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class AdminDashboardService
{
    private function sum(string $account, string $asset = 'USDT'): string
    {
        return Money::format((int) DB::table('wallet_balances')->where(['account' => $account, 'asset' => $asset])->sum('balance'), 2);
    }

    public function snapshot(): array
    {
        $since = Carbon::now()->subDays(30);
        $auto30 = (int) DB::table('deposits')->whereIn('asset', ['USDT', 'USDC'])->where('credited_at', '>=', $since)->sum('credited_units');
        $manual30 = (int) DB::table('manual_deposits')->whereIn('asset', ['USDT', 'USDC'])->where('status', 'approved')->where('reviewed_at', '>=', $since)->sum('credited');

        return [
            'users' => [
                'available' => true,
                'total' => User::query()->count(),
                'today' => User::query()->where('created_at', '>=', Carbon::today())->count(),
                'latest' => User::query()->select(['id', 'name', 'email', 'email_verified_at', 'kyc_status', 'created_at'])->latest('id')->limit(5)->get()
                    ->map(fn (User $u) => ['id' => $u->id, 'name' => $u->name, 'email' => $u->email, 'verified' => $u->email_verified_at !== null, 'kyc' => $u->kyc_status ?: 'none', 'joined' => $u->created_at?->format('Y-m-d H:i:s')])->all(),
            ],
            'kyc' => ['available' => true, 'pending' => DB::table('kyc_submissions')->where('status', 'pending')->count(), 'verified' => User::query()->where('kyc_status', 'approved')->count()],
            'funding' => ['available' => true, 'total_usdt' => $this->sum('funding')],
            'trading_wallet' => ['available' => true, 'total_usdt' => $this->sum('trading')],
            'staking' => ['available' => true, 'total_usdt' => Money::format((int) DB::table('earn_positions')->sum('principal'), 2)],
            'deposits' => ['available' => true, 'volume_30d' => Money::format($auto30 + $manual30, 2), 'pending_count' => DB::table('manual_deposits')->where('status', 'pending')->count()],
            'withdrawals' => ['available' => true, 'pending_count' => DB::table('withdrawals')->where('status', 'pending')->count()],
            'trades' => ['available' => true, 'count_30d' => DB::table('spot_orders')->where('created_at', '>=', $since)->count() + DB::table('futures_positions')->where('created_at', '>=', $since)->count(), 'latest' => $this->latestTrades()],
            'queues' => [
                'tickets' => DB::table('tickets')->where('status', 'open')->count(),
                'disputes' => DB::table('p2p_disputes')->where('status', 'open')->count(),
                'positions' => DB::table('futures_positions')->where('status', 'open')->count(),
                'limit_orders' => DB::table('spot_limit_orders')->where('status', 'open')->count(),
            ],
            'generated_at' => Carbon::now()->format('H:i:s'),
            'bots' => ['available' => true, 'active_follows' => DB::table('bot_follows')->where('status', 'active')->count(), 'aum' => Money::format((int) DB::table('bot_follows')->where('status', 'active')->sum('capital'), 2)],
        ];
    }

    private function latestTrades(): array
    {
        $spot = DB::table('spot_orders')->join('users', 'users.id', '=', 'spot_orders.user_id')
            ->latest('spot_orders.id')->limit(8)->get(['users.email', 'spot_orders.symbol', 'spot_orders.side', 'spot_orders.quote_total as amt', 'spot_orders.created_at'])
            ->map(fn ($r) => ['user' => $r->email, 'pair' => $r->symbol, 'side' => strtoupper($r->side), 'value' => Money::format((int) $r->amt, 2), 'kind' => 'Spot', 'at' => (string) $r->created_at]);
        $fut = DB::table('futures_positions')->join('users', 'users.id', '=', 'futures_positions.user_id')
            ->latest('futures_positions.id')->limit(8)->get(['users.email', 'futures_positions.symbol', 'futures_positions.side', 'futures_positions.margin as amt', 'futures_positions.status', 'futures_positions.pnl', 'futures_positions.created_at'])
            ->map(fn ($r) => ['user' => $r->email, 'pair' => $r->symbol, 'side' => strtoupper($r->side).' · '.$r->status, 'value' => $r->pnl !== null ? Money::format((int) $r->pnl, 2) : Money::format((int) $r->amt, 2), 'kind' => 'Futures', 'at' => (string) $r->created_at]);

        return $spot->concat($fut)->sortByDesc('at')->take(8)->values()->all();
    }
}
