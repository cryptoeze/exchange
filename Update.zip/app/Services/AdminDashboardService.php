<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Schema;

class AdminDashboardService
{
    public function snapshot(): array
    {
        $usersAvailable = Schema::hasTable('users');

        return [
            'users' => [
                'available' => $usersAvailable,
                'total' => $usersAvailable ? User::query()->count() : null,
                'today' => $usersAvailable ? User::query()->where('created_at', '>=', Carbon::today())
                    ->where('created_at', '<', Carbon::tomorrow())->count() : null,
                'latest' => $usersAvailable
                    ? User::query()->select(['id', 'name', 'email', 'role', 'email_verified_at', 'created_at'])
                        ->latest('created_at')->latest('id')->limit(5)->get()
                        ->map(fn (User $user) => [
                            'id' => $user->id,
                            'name' => $user->name,
                            'email' => $user->email,
                            'verified' => $user->email_verified_at !== null,
                            'joined' => $user->created_at?->format('Y-m-d H:i:s'),
                        ])->all()
                    : [],
            ],
            // These domains do not exist in the installed schema yet. Keep them unavailable,
            // rather than presenting invented zeroes or guessing financial business rules.
            'kyc' => ['available' => false, 'pending' => null, 'verified' => null],
            'funding' => ['available' => false, 'total_usdt' => null],
            'trading_wallet' => ['available' => false, 'total_usdt' => null],
            'staking' => ['available' => false, 'total_usdt' => null],
            'deposits' => ['available' => false, 'volume_30d' => null, 'pending_count' => null],
            'withdrawals' => ['available' => false, 'pending_count' => null],
            'trades' => ['available' => false, 'count_30d' => null, 'latest' => []],
            'bots' => ['available' => false, 'active_follows' => null, 'aum' => null],
        ];
    }
}
