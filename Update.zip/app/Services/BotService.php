<?php

namespace App\Services;

use App\Models\Bot;
use App\Models\BotClaim;
use App\Models\BotFollow;
use App\Models\LedgerEntry;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * Yield strategies. Capital is held in the `bots` account. Every full 24h cycle pays capital x daily yield
 * (set by an administrator) minus the platform's profit share into the funding account. No random numbers.
 */
final class BotService
{
    public const CYCLE = 86_400;
    public const MAX_CYCLES = 30; // an unclaimed backlog is capped at 30 days

    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function cycles(BotFollow $follow): int
    {
        if ($follow->status !== 'active') {
            return 0;
        }

        return min(self::MAX_CYCLES, intdiv(max(0, now()->getTimestamp() - $follow->cycle_started_at->getTimestamp()), self::CYCLE));
    }

    /** @return array{gross:int,share:int,net:int} */
    public function payout(BotFollow $follow, Bot $bot, int $cycles): array
    {
        $gross = (int) floor($follow->capital * ((float) $bot->daily_yield_pct / 100) * $cycles);
        $share = (int) floor($gross * ((float) $bot->profit_share_pct / 100));

        return ['gross' => $gross, 'share' => $share, 'net' => $gross - $share];
    }

    private function lockedFollow(int $userId, int $botId): ?BotFollow
    {
        return BotFollow::query()->where(['user_id' => $userId, 'bot_id' => $botId])->lockForUpdate()->first();
    }

    public function follow(User $user, Bot $bot, int $units, bool $auto, ?string $key = null): void
    {
        if (! $bot->enabled) {
            throw new DomainException('This strategy is not open for new allocations.');
        }
        if ($units <= 0 || $units < (int) $bot->min_units) {
            throw new DomainException('Amount is below the minimum for this strategy.');
        }
        if ($bot->max_per_user && $units > (int) $bot->max_per_user) {
            throw new DomainException('Amount is above the maximum per user for this strategy.');
        }
        DB::transaction(function () use ($user, $bot, $units, $auto, $key): void {
            if ($key !== null && LedgerEntry::query()->where('idempotency_key', "{$user->id}:bot:{$key}:out")->exists()) {
                return;
            }
            if ($bot->capacity && (int) BotFollow::query()->where(['bot_id' => $bot->id, 'status' => 'active'])->sum('capital') + $units > (int) $bot->capacity) {
                throw new DomainException('This strategy has reached its capacity. Try again later.');
            }
            $follow = $this->lockedFollow($user->id, $bot->id);
            if ($follow && $follow->status === 'active') {
                throw new DomainException('You are already following this strategy. Stop it first to change the amount.');
            }
            if (! $follow) {
                BotFollow::query()->firstOrCreate(['user_id' => $user->id, 'bot_id' => $bot->id], ['capital' => 0, 'status' => 'stopped', 'cycle_started_at' => now()]);
                $follow = $this->lockedFollow($user->id, $bot->id);
            }
            $meta = ['ref_type' => 'bot_follow', 'ref_id' => $follow->id];
            $this->ledger->apply($user->id, 'funding', 'USDT', -$units, 'bot_allocate', $meta + ['idempotency_key' => $key ? "{$user->id}:bot:{$key}:out" : null]);
            $this->ledger->apply($user->id, 'bots', 'USDT', $units, 'bot_allocate', $meta + ['idempotency_key' => $key ? "{$user->id}:bot:{$key}:in" : null]);
            $follow->fill(['capital' => $units, 'status' => 'active', 'auto_claim' => $auto, 'cycle_started_at' => now()])->save();
        }, 3);
    }

    /** Pay all completed cycles. Returns the claim, or throws if none is due. Call inside a transaction with the follow locked. */
    private function payCycles(BotFollow $follow, Bot $bot): BotClaim
    {
        $cycles = $this->cycles($follow);
        if ($cycles < 1) {
            throw new DomainException('Nothing to claim yet. The next cycle is not complete.');
        }
        $p = $this->payout($follow, $bot, $cycles);
        if ($p['net'] > 0) {
            $this->ledger->apply($follow->user_id, 'funding', 'USDT', $p['net'], 'bot_profit', ['ref_type' => 'bot_follow', 'ref_id' => $follow->id]);
        }
        $claim = BotClaim::query()->create(['user_id' => $follow->user_id, 'bot_id' => $bot->id, 'cycles' => $cycles, 'capital' => $follow->capital] + $p);
        // Advance by whole cycles only, so the remainder of the current cycle is kept.
        $follow->cycle_started_at = $follow->cycle_started_at->copy()->addSeconds($cycles * self::CYCLE);
        $follow->save();

        return $claim;
    }

    public function claim(User $user, Bot $bot): BotClaim
    {
        return DB::transaction(function () use ($user, $bot): BotClaim {
            $follow = $this->lockedFollow($user->id, $bot->id);
            if (! $follow || $follow->status !== 'active') {
                throw new DomainException('You are not following this strategy.');
            }

            return $this->payCycles($follow, $bot);
        }, 3);
    }

    public function unfollow(User $user, Bot $bot): int
    {
        return DB::transaction(function () use ($user, $bot): int {
            $follow = $this->lockedFollow($user->id, $bot->id);
            if (! $follow || $follow->status !== 'active') {
                throw new DomainException('You are not following this strategy.');
            }
            if ($this->cycles($follow) >= 1) {
                $this->payCycles($follow, $bot); // pay what is already earned before returning capital
            }
            $capital = (int) $follow->capital;
            $meta = ['ref_type' => 'bot_follow', 'ref_id' => $follow->id];
            $this->ledger->apply($user->id, 'bots', 'USDT', -$capital, 'bot_release', $meta);
            $this->ledger->apply($user->id, 'funding', 'USDT', $capital, 'bot_release', $meta);
            $follow->fill(['capital' => 0, 'status' => 'stopped', 'auto_claim' => false])->save();

            return $capital;
        }, 3);
    }

    public function setAuto(User $user, Bot $bot, bool $auto): void
    {
        BotFollow::query()->where(['user_id' => $user->id, 'bot_id' => $bot->id, 'status' => 'active'])->update(['auto_claim' => $auto]);
    }

    /** Claim every completed cycle for the user's auto-claim follows. */
    public function settleAuto(int $userId): void
    {
        foreach (BotFollow::query()->where(['user_id' => $userId, 'status' => 'active', 'auto_claim' => true])->get() as $follow) {
            $bot = Bot::query()->find($follow->bot_id);
            if ($bot && $this->cycles($follow) >= 1) {
                try {
                    DB::transaction(function () use ($follow, $bot): void {
                        $locked = $this->lockedFollow($follow->user_id, $bot->id);
                        if ($locked && $locked->status === 'active' && $this->cycles($locked) >= 1) {
                            $this->payCycles($locked, $bot);
                        }
                    }, 3);
                } catch (DomainException) {
                    // nothing due after all
                }
            }
        }
    }

    /** Pay pending cycles for every follower of a bot at its current rate (used before an administrator changes the rate). */
    public function settleBot(Bot $bot): int
    {
        $count = 0;
        foreach (BotFollow::query()->where(['bot_id' => $bot->id, 'status' => 'active'])->pluck('user_id') as $userId) {
            try {
                DB::transaction(function () use ($userId, $bot): void {
                    $locked = $this->lockedFollow($userId, $bot->id);
                    if ($locked && $locked->status === 'active' && $this->cycles($locked) >= 1) {
                        $this->payCycles($locked, $bot);
                    }
                }, 3);
                $count++;
            } catch (DomainException) {
            }
        }

        return $count;
    }
}
