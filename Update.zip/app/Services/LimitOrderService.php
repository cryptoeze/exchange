<?php

namespace App\Services;

use App\Models\SpotOrder;
use App\Models\User;
use App\Support\Money;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * Spot limit orders (house-matched). The funds are moved to the 'hold' account when the order is placed and settle
 * when the server-side Bybit price reaches the limit. Resting orders fill at the better of limit and market price.
 */
final class LimitOrderService
{
    public function __construct(private readonly LedgerService $ledger, private readonly SpotTradingService $spot, private readonly MarketDataService $markets)
    {
    }

    public function place(User $user, string $symbol, string $side, string $price, string $qty, ?string $key = null, string $kind = 'limit'): object
    {
        if (! in_array($side, ['buy', 'sell'], true) || ! in_array($kind, ['limit', 'tp', 'sl'], true) || ($kind !== 'limit' && $side !== 'sell')) {
            throw new DomainException('Invalid order.');
        }
        $limit = (float) $price;
        $units = Money::toUnits($qty);
        if ($limit <= 0 || $units <= 0) {
            throw new DomainException('Enter a price and an amount.');
        }
        $q = $this->spot->quote($symbol);
        $mkt = $q['price'];
        if ($limit < $mkt * 0.2 || $limit > $mkt * 5) {
            throw new DomainException('Price is too far from the market price.');
        }
        if ($kind === 'tp' && $limit <= $mkt) {
            throw new DomainException('Take-profit price must be above the current price.');
        }
        if ($kind === 'sl' && $limit >= $mkt) {
            throw new DomainException('Stop-loss price must be below the current price.');
        }
        $notional = $units * $limit;
        if ($notional < Money::toUnits((float) config('trading.spot_min_quote_usdt')) || $notional > Money::toUnits((float) config('trading.spot_max_quote_usdt'))) {
            throw new DomainException('Order size is outside the allowed range.');
        }
        $quoteAsset = (string) config('trading.quote_asset');
        $rate = (float) config('trading.spot_fee_rate');
        $row = DB::transaction(function () use ($user, $symbol, $side, $kind, $limit, $units, $q, $quoteAsset, $rate, $key) {
            if (DB::table('spot_limit_orders')->where(['user_id' => $user->id, 'status' => 'open'])->count() >= 30) {
                throw new DomainException('You can have up to 30 open limit orders.');
            }
            $reserveAsset = $side === 'buy' ? $quoteAsset : $q['base'];
            $reserved = $side === 'buy' ? (int) ceil($units * $limit) + (int) ceil($units * $limit * $rate) : $units;
            $id = DB::table('spot_limit_orders')->insertGetId(['user_id' => $user->id, 'symbol' => $symbol, 'base_asset' => $q['base'], 'side' => $side, 'kind' => $kind, 'limit_price' => $limit, 'qty' => $units, 'reserve_asset' => $reserveAsset, 'reserved' => $reserved, 'status' => 'open', 'created_at' => now()]);
            $meta = ['ref_type' => 'limit_order', 'ref_id' => $id];
            $this->ledger->apply($user->id, 'funding', $reserveAsset, -$reserved, 'limit_hold', $meta);
            $this->ledger->apply($user->id, 'hold', $reserveAsset, $reserved, 'limit_hold', $meta);

            return DB::table('spot_limit_orders')->find($id);
        }, 3);
        // A limit that is already marketable fills straight away at the market price.
        if ($kind === 'limit' && (($side === 'buy' && $mkt <= $limit) || ($side === 'sell' && $mkt >= $limit))) {
            $this->fill($row->id, $mkt);
        }

        return DB::table('spot_limit_orders')->find($row->id);
    }

    public function cancel(User $user, int $id): void
    {
        DB::transaction(function () use ($user, $id): void {
            $o = DB::table('spot_limit_orders')->where(['id' => $id, 'user_id' => $user->id])->lockForUpdate()->first();
            if (! $o || $o->status !== 'open') {
                throw new DomainException('This order is no longer open.');
            }
            $meta = ['ref_type' => 'limit_order', 'ref_id' => $id];
            $this->ledger->apply($user->id, 'hold', $o->reserve_asset, -(int) $o->reserved, 'limit_release', $meta);
            $this->ledger->apply($user->id, 'funding', $o->reserve_asset, (int) $o->reserved, 'limit_release', $meta);
            DB::table('spot_limit_orders')->where('id', $id)->update(['status' => 'cancelled', 'closed_at' => now()]);
        }, 3);
    }

    /** Settle one open order at market price $p (caller has checked the limit is reached). */
    public function fill(int $id, float $p): bool
    {
        $quoteAsset = (string) config('trading.quote_asset');
        $rate = (float) config('trading.spot_fee_rate');
        $filled = DB::transaction(function () use ($id, $p, $quoteAsset, $rate) {
            $o = DB::table('spot_limit_orders')->where('id', $id)->lockForUpdate()->first();
            if (! $o || $o->status !== 'open') {
                return null;
            }
            $limit = (float) $o->limit_price;
            $buy = $o->side === 'buy';
            $e = $buy ? min($limit, $p) : (($o->kind ?? 'limit') === 'sl' ? $p : max($limit, $p));
            $qty = (int) $o->qty;
            $cost = (int) floor($qty * $e);
            $fee = (int) floor($cost * $rate);
            $total = $buy ? $cost + $fee : $cost;
            $order = SpotOrder::query()->create(['user_id' => $o->user_id, 'symbol' => $o->symbol, 'base_asset' => $o->base_asset, 'side' => $o->side, 'price_micro' => (int) round($e * Money::SCALE), 'base_qty' => $qty, 'quote_total' => $total, 'fee' => $fee, 'status' => 'filled']);
            $meta = ['ref_type' => 'spot_order', 'ref_id' => $order->id];
            $this->ledger->apply($o->user_id, 'hold', $o->reserve_asset, -(int) $o->reserved, 'limit_fill', $meta);
            if ($buy) {
                if ($o->reserved - $total > 0) {
                    $this->ledger->apply($o->user_id, 'funding', $quoteAsset, (int) $o->reserved - $total, 'limit_release', $meta);
                }
                $this->ledger->apply($o->user_id, 'funding', $o->base_asset, $qty, 'spot_buy', $meta);
            } else {
                $this->ledger->apply($o->user_id, 'funding', $quoteAsset, $cost - $fee, 'spot_sell', $meta);
            }
            DB::table('spot_limit_orders')->where('id', $id)->update(['status' => 'filled', 'spot_order_id' => $order->id, 'closed_at' => now()]);

            return [$o, $e];
        }, 3);
        if ($filled) {
            [$o, $e] = $filled;
            NotificationService::send($o->user_id, (($o->kind ?? 'limit') === 'tp' ? 'Take-profit triggered' : (($o->kind ?? 'limit') === 'sl' ? 'Stop-loss triggered' : 'Limit order filled')), ucfirst($o->side).' '.rtrim(rtrim(number_format($o->qty / 1e8, 8, '.', ''), '0'), '.').' '.$o->base_asset.' at '.rtrim(rtrim(number_format($e, 8, '.', ''), '0'), '.'), 'success', '/spot?pair='.$o->symbol);
        }

        return (bool) $filled;
    }

    /** Fill every open order whose limit the market has reached. Optionally one user's orders only. */
    public function sweep(?int $userId = null): int
    {
        $q = DB::table('spot_limit_orders')->where('status', 'open');
        if ($userId) {
            $q->where('user_id', $userId);
        }
        $open = $q->get();
        if ($open->isEmpty()) {
            return 0;
        }
        try {
            $snap = $this->markets->snapshot('spot');
            $updated = strtotime((string) ($snap['meta']['updatedAt'] ?? '')) ?: 0;
            if (! empty($snap['meta']['stale']) || (time() - $updated) > (int) config('trading.max_price_age_seconds')) {
                return 0;
            }
        } catch (\Throwable) {
            return 0;
        }
        $price = [];
        foreach ($snap['markets'] as $m) {
            if (($m['marketType'] ?? '') === 'spot') {
                $price[(string) $m['symbol']] = (float) $m['lastPrice'];
            }
        }
        $n = 0;
        foreach ($open as $o) {
            $p = $price[$o->symbol] ?? 0;
            $lim = (float) $o->limit_price;
            $hit = ($o->kind ?? 'limit') === 'sl' ? $p <= $lim : ($o->side === 'buy' ? $p <= $lim : $p >= $lim);
            if ($p > 0 && $hit) {
                $n += $this->fill($o->id, $p) ? 1 : 0;
            }
        }

        return $n;
    }
}
