<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

/** RFC 6238 time-based one-time passwords (Google Authenticator / Authy compatible) + hashed recovery codes. */
final class TotpService
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public function newSecret(): string
    {
        $bytes = random_bytes(20);
        $bits = '';
        foreach (str_split($bytes) as $c) {
            $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            $out .= self::ALPHABET[bindec(str_pad($chunk, 5, '0'))];
        }

        return $out;
    }

    private function decode(string $b32): string
    {
        $bits = '';
        foreach (str_split(strtoupper(preg_replace('/[^A-Z2-7]/i', '', $b32))) as $ch) {
            $bits .= str_pad(decbin(strpos(self::ALPHABET, $ch)), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) {
                $out .= chr(bindec($byte));
            }
        }

        return $out;
    }

    public function code(string $secret, ?int $time = null): string
    {
        $counter = intdiv($time ?? time(), 30);
        $hash = hash_hmac('sha1', pack('N*', 0, $counter), $this->decode($secret), true);
        $o = ord($hash[19]) & 0xf;
        $n = ((ord($hash[$o]) & 0x7f) << 24) | (ord($hash[$o + 1]) << 16) | (ord($hash[$o + 2]) << 8) | ord($hash[$o + 3]);

        return str_pad((string) ($n % 1000000), 6, '0', STR_PAD_LEFT);
    }

    public function verify(string $secret, string $code): bool
    {
        $code = preg_replace('/\D/', '', $code);
        if (strlen($code) !== 6) {
            return false;
        }
        foreach ([-1, 0, 1] as $drift) {
            if (hash_equals($this->code($secret, time() + $drift * 30), $code)) {
                return true;
            }
        }

        return false;
    }

    public function uri(string $secret, string $account): string
    {
        return 'otpauth://totp/'.rawurlencode('RushX:'.$account).'?secret='.$secret.'&issuer=RushX&algorithm=SHA1&digits=6&period=30';
    }

    /** @return string[] plain recovery codes (shown once) */
    public function enable(User $user, string $secret): array
    {
        $plain = [];
        for ($i = 0; $i < 8; $i++) {
            $plain[] = strtoupper(bin2hex(random_bytes(2))).'-'.strtoupper(bin2hex(random_bytes(2)));
        }
        DB::table('users')->where('id', $user->id)->update([
            'two_factor_secret' => Crypt::encryptString($secret), 'two_factor_enabled' => true,
            'two_factor_recovery' => json_encode(array_map(fn ($c) => hash('sha256', $c), $plain)),
        ]);

        return $plain;
    }

    public function disable(User $user): void
    {
        DB::table('users')->where('id', $user->id)->update(['two_factor_secret' => null, 'two_factor_enabled' => false, 'two_factor_recovery' => null]);
    }

    /** A 6-digit authenticator code, or an unused recovery code (which is then consumed). */
    public function check(User $user, string $input): bool
    {
        if (! $user->two_factor_enabled || ! $user->two_factor_secret) {
            return true;
        }
        $input = trim($input);
        if ($this->verify(Crypt::decryptString($user->two_factor_secret), $input)) {
            return true;
        }
        $hash = hash('sha256', strtoupper($input));
        $codes = json_decode((string) $user->two_factor_recovery, true) ?: [];
        if (($i = array_search($hash, $codes, true)) !== false) {
            unset($codes[$i]);
            DB::table('users')->where('id', $user->id)->update(['two_factor_recovery' => json_encode(array_values($codes))]);

            return true;
        }

        return false;
    }

    public function logLogin(?int $userId, ?string $email, string $area, bool $success, ?string $note = null): void
    {
        try {
            DB::table('login_events')->insert(['user_id' => $userId, 'email' => $email, 'area' => $area, 'success' => $success, 'note' => $note, 'ip' => request()->ip(), 'agent' => mb_substr((string) request()->userAgent(), 0, 190), 'created_at' => now()]);
        } catch (\Throwable) {
            // history is best-effort
        }
    }
}
