<?php

namespace App\Services;

use App\Models\User;
use App\Support\Money;
use Illuminate\Support\Facades\DB;

/** Pays the referrer a % of each credited deposit, once per deposit, through the ledger. */
final class ReferralService
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    public function payForDeposit(int $userId, string $asset, int $depositUnits, string $sourceType, int $sourceId): int
    {
        $percent = (float) config('referral.percent');
        if ($percent <= 0 || $depositUnits <= 0) {
            return 0;
        }
        $referrer = User::query()->whereKey($userId)->value('referred_by');
        if (! $referrer || (int) $referrer === $userId) {
            return 0;
        }
        $reward = (int) floor($depositUnits * $percent / 100);
        $cap = (int) round((float) config('referral.max_per_deposit') * 1e8);
        if ($cap > 0) {
            $reward = min($reward, $cap);
        }
        if ($reward <= 0 || DB::table('referral_rewards')->where(['source_type' => $sourceType, 'source_id' => $sourceId])->exists()) {
            return 0;
        }
        $this->ledger->apply((int) $referrer, 'funding', $asset, $reward, 'referral_reward', [
            'ref_type' => $sourceType, 'ref_id' => $sourceId, 'idempotency_key' => "referral:{$sourceType}:{$sourceId}", 'note' => "{$percent}% referral commission",
        ]);
        DB::table('referral_rewards')->insert(['referrer_id' => $referrer, 'referred_id' => $userId, 'source_type' => $sourceType, 'source_id' => $sourceId, 'asset' => $asset, 'amount' => $reward, 'created_at' => now()]);
        NotificationService::send((int) $referrer, 'Referral reward', 'You earned '.Money::format($reward, 4).' '.$asset.' from a friend’s deposit.', 'success', '/refer');

        return $reward;
    }
}
