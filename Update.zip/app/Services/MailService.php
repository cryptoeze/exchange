<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

/** Renders and sends the notification e-mails defined in config/mail-templates.php (admin-editable). */
final class MailService
{
    public function template(string $event): ?array
    {
        $base = config("mail-templates.events.$event");
        if (! $base) {
            return null;
        }
        $raw = DB::table('settings')->where('key', "mailtpl.$event")->value('value');
        $over = $raw ? (json_decode($raw, true) ?: []) : [];

        return array_merge($base, array_intersect_key($over, array_flip(['subject', 'heading', 'body', 'enabled'])), ['enabled' => (bool) ($over['enabled'] ?? true)]);
    }

    public function fill(string $text, array $vars): string
    {
        return preg_replace_callback('/\{(\w+)\}/', fn ($m) => array_key_exists($m[1], $vars) ? (string) $vars[$m[1]] : $m[0], $text);
    }

    public function render(string $event, array $vars): ?array
    {
        $t = $this->template($event);
        if (! $t) {
            return null;
        }
        $body = $this->fill($t['body'], $vars);

        return ['subject' => $this->fill($t['subject'], $vars), 'heading' => $this->fill($t['heading'], $vars), 'body' => $body, 'bodyHtml' => nl2br(e($body)), 'cta' => $t['cta'], 'url' => url($t['url']), 'type' => $t['type'], 'enabled' => $t['enabled']];
    }

    public function send(User|string $to, string $event, array $vars): bool
    {
        $m = $this->render($event, $vars);
        $email = $to instanceof User ? $to->email : $to;
        if (! $m || ! $m['enabled'] || ! $email) {
            return false;
        }
        try {
            Mail::send('emails.notice', $m, fn ($msg) => $msg->to($email)->subject($m['subject']));

            return true;
        } catch (\Throwable $e) {
            Log::warning('Notification email failed', ['event' => $event, 'error' => $e::class]);

            return false;
        }
    }
}
