<?php

namespace App\Services;

use App\Models\User;
use App\Support\Money;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Peer-to-peer escrow. The seller's coins sit in the ledger account "p2p" from the moment an order exists until the seller
 * releases them to the buyer, the order is cancelled/expired, or an administrator settles a dispute. Fiat moves outside RushX.
 */
final class P2pService
{
    public function __construct(private readonly LedgerService $ledger)
    {
    }

    private function must(): void
    {
        if (! config('p2p.enabled')) {
            throw new DomainException('P2P trading is switched off right now.');
        }
    }

    private function lockMeta(string $type, int $id): array
    {
        return ['ref_type' => $type, 'ref_id' => $id];
    }

    public function sys(int $tradeId, string $text): void
    {
        DB::table('p2p_messages')->insert(['trade_id' => $tradeId, 'user_id' => 0, 'body' => $text, 'created_at' => now()]);
    }

    /** @param array{side:string,coin:string,fiat:string,price:numeric,amount:string,min_fiat:numeric,max_fiat:numeric,methods:array,details?:array,terms?:?string,window_min?:int} $d */
    public function createAd(User $user, array $d): int
    {
        $this->must();
        $coins = config('p2p.coins');
        if (! isset($coins[$d['coin']]) || ! config('p2p.fiats.'.$d['fiat']) || ! in_array($d['side'], ['buy', 'sell'], true)) {
            throw new DomainException('Pick a supported coin and currency.');
        }
        $methods = array_values(array_intersect($d['methods'], config('p2p.methods')));
        if (! $methods) {
            throw new DomainException('Choose at least one payment method.');
        }
        $units = Money::toUnits((string) $d['amount']);
        $price = (float) $d['price'];
        if ($units <= 0 || $price <= 0) {
            throw new DomainException('Enter a price and an amount.');
        }
        if ((float) $d['min_fiat'] <= 0 || (float) $d['max_fiat'] < (float) $d['min_fiat']) {
            throw new DomainException('Check the minimum and maximum order limits.');
        }
        if ($d['side'] === 'sell') {
            foreach ($methods as $m) {
                if (trim((string) ($d['details'][$m] ?? '')) === '') {
                    throw new DomainException("Add your {$m} account details so buyers know where to pay.");
                }
            }
        }

        return DB::transaction(function () use ($user, $d, $units, $price, $methods) {
            if (DB::table('p2p_ads')->where('user_id', $user->id)->whereIn('status', ['online', 'offline'])->count() >= (int) config('p2p.max_ads')) {
                throw new DomainException('You have reached the maximum number of ads.');
            }
            $id = DB::table('p2p_ads')->insertGetId(['user_id' => $user->id, 'side' => $d['side'], 'coin' => $d['coin'], 'fiat' => $d['fiat'], 'price' => $price, 'total' => $units, 'available' => $units, 'min_fiat' => $d['min_fiat'], 'max_fiat' => $d['max_fiat'],
                'methods' => json_encode($methods), 'details' => $d['side'] === 'sell' ? json_encode(array_intersect_key($d['details'] ?? [], array_flip($methods))) : null, 'terms' => $d['terms'] ?? null, 'window_min' => max(10, min(60, (int) ($d['window_min'] ?? 15))), 'status' => 'online', 'created_at' => now(), 'updated_at' => now()]);
            if ($d['side'] === 'sell') { // the advertiser's coins go into escrow now
                $this->ledger->apply($user->id, 'funding', $d['coin'], -$units, 'p2p_escrow', $this->lockMeta('p2p_ad', $id));
                $this->ledger->apply($user->id, 'p2p', $d['coin'], $units, 'p2p_escrow', $this->lockMeta('p2p_ad', $id));
            }

            return $id;
        }, 3);
    }

    public function setAdStatus(User $user, int $adId, string $status): void
    {
        DB::transaction(function () use ($user, $adId, $status): void {
            $ad = DB::table('p2p_ads')->where(['id' => $adId, 'user_id' => $user->id])->lockForUpdate()->first();
            if (! $ad || $ad->status === 'closed') {
                throw new DomainException('Ad not found.');
            }
            if ($status === 'closed' && $ad->side === 'sell' && $ad->available > 0) {
                $this->ledger->apply($user->id, 'p2p', $ad->coin, -(int) $ad->available, 'p2p_release_ad', $this->lockMeta('p2p_ad', $adId));
                $this->ledger->apply($user->id, 'funding', $ad->coin, (int) $ad->available, 'p2p_release_ad', $this->lockMeta('p2p_ad', $adId));
                DB::table('p2p_ads')->where('id', $adId)->update(['available' => 0]);
            }
            DB::table('p2p_ads')->where('id', $adId)->update(['status' => $status, 'updated_at' => now()]);
        }, 3);
    }

    public function start(User $user, int $adId, string $fiatAmount, string $method, ?string $myDetails = null): string
    {
        $this->must();

        return DB::transaction(function () use ($user, $adId, $fiatAmount, $method, $myDetails) {
            $ad = DB::table('p2p_ads')->where('id', $adId)->lockForUpdate()->first();
            if (! $ad || $ad->status !== 'online') {
                throw new DomainException('This ad is not available any more.');
            }
            if ((int) $ad->user_id === $user->id) {
                throw new DomainException('You cannot trade with your own ad.');
            }
            $fiat = round((float) $fiatAmount, 2);
            if ($fiat < (float) $ad->min_fiat || $fiat > (float) $ad->max_fiat) {
                throw new DomainException('Amount must be between '.(float) $ad->min_fiat.' and '.(float) $ad->max_fiat.' '.$ad->fiat.'.');
            }
            $methods = json_decode($ad->methods, true) ?: [];
            if (! in_array($method, $methods, true)) {
                throw new DomainException('Choose one of the ad\'s payment methods.');
            }
            $qty = (int) floor($fiat / (float) $ad->price * 1e8);
            if ($qty <= 0 || $qty > (int) $ad->available) {
                throw new DomainException('Not enough coins left on this ad for that amount.');
            }
            if (DB::table('p2p_trades')->where(function ($q) use ($user) { $q->where('buyer_id', $user->id)->orWhere('seller_id', $user->id); })->whereIn('status', ['pending', 'paid', 'disputed'])->count() >= (int) config('p2p.max_open_orders')) {
                throw new DomainException('You have too many open orders. Finish some first.');
            }
            $sellAd = $ad->side === 'sell';
            $details = $sellAd ? (json_decode((string) $ad->details, true)[$method] ?? '') : trim((string) $myDetails);
            if ($details === '') {
                throw new DomainException($sellAd ? 'The seller has no details for this method.' : 'Enter your account details for '.$method.' so the buyer knows where to pay.');
            }
            $buyer = $sellAd ? $user->id : (int) $ad->user_id;
            $seller = $sellAd ? (int) $ad->user_id : $user->id;
            $ref = strtoupper(Str::random(12));
            $id = DB::table('p2p_trades')->insertGetId(['ref' => $ref, 'ad_id' => $adId, 'buyer_id' => $buyer, 'seller_id' => $seller, 'coin' => $ad->coin, 'fiat' => $ad->fiat, 'price' => $ad->price, 'qty' => $qty, 'fiat_amount' => $fiat, 'method' => $method, 'pay_details' => $details, 'status' => 'pending',
                'expires_at' => now()->addMinutes((int) $ad->window_min), 'created_at' => now(), 'updated_at' => now()]);
            if (! $sellAd) { // the responding seller escrows now
                $this->ledger->apply($seller, 'funding', $ad->coin, -$qty, 'p2p_escrow', $this->lockMeta('p2p_trade', $id));
                $this->ledger->apply($seller, 'p2p', $ad->coin, $qty, 'p2p_escrow', $this->lockMeta('p2p_trade', $id));
            }
            DB::table('p2p_ads')->where('id', $adId)->update(['available' => (int) $ad->available - $qty, 'updated_at' => now()]);
            $this->sys($id, 'Order opened. The buyer has '.$ad->window_min.' minutes to pay '.number_format($fiat, 2).' '.$ad->fiat.' with '.$method.' and press "I have paid".');
            $other = $user->id === $buyer ? $seller : $buyer;
            DB::afterCommit(fn () => NotificationService::event($other, 'p2p_order', ['title' => 'New P2P order', 'detail' => ($user->id === $buyer ? 'A buyer' : 'A seller').' opened an order for '.Money::format($qty, 6).' '.$ad->coin.' ('.number_format($fiat, 2).' '.$ad->fiat.'). Open it to continue.']));

            return $ref;
        }, 3);
    }

    private function trade(string $ref): object
    {
        $t = DB::table('p2p_trades')->where('ref', $ref)->lockForUpdate()->first();
        if (! $t) {
            throw new DomainException('Order not found.');
        }

        return $t;
    }

    private function notify(int $userId, string $title, string $detail): void
    {
        DB::afterCommit(fn () => NotificationService::event($userId, 'p2p_order', ['title' => $title, 'detail' => $detail]));
    }

    public function markPaid(User $user, string $ref): void
    {
        DB::transaction(function () use ($user, $ref): void {
            $t = $this->trade($ref);
            if ((int) $t->buyer_id !== $user->id) {
                throw new DomainException('Only the buyer can confirm payment.');
            }
            if ($t->status !== 'pending' || strtotime($t->expires_at) < time()) {
                throw new DomainException('This order can no longer be marked as paid.');
            }
            DB::table('p2p_trades')->where('id', $t->id)->update(['status' => 'paid', 'paid_at' => now(), 'updated_at' => now()]);
            $this->sys($t->id, 'The buyer says the payment was sent. Seller: check your account, then release the coins.');
            $this->notify((int) $t->seller_id, 'Buyer marked paid', 'Check that '.number_format((float) $t->fiat_amount, 2).' '.$t->fiat.' arrived, then release the coins.');
        }, 3);
    }

    private function giveBack(object $t): void
    {
        $ad = DB::table('p2p_ads')->where('id', $t->ad_id)->lockForUpdate()->first();
        $sellAd = $ad && $ad->side === 'sell';
        if ($sellAd && $ad->status !== 'closed') { // coins stay escrowed on the ad and become available again
            DB::table('p2p_ads')->where('id', $ad->id)->update(['available' => (int) $ad->available + (int) $t->qty]);

            return;
        }
        $this->ledger->apply((int) $t->seller_id, 'p2p', $t->coin, -(int) $t->qty, 'p2p_refund', $this->lockMeta('p2p_trade', $t->id));
        $this->ledger->apply((int) $t->seller_id, 'funding', $t->coin, (int) $t->qty, 'p2p_refund', $this->lockMeta('p2p_trade', $t->id));
        if ($ad && $ad->side === 'buy' && $ad->status !== 'closed') {
            DB::table('p2p_ads')->where('id', $ad->id)->update(['available' => (int) $ad->available + (int) $t->qty]);
        }
    }

    public function cancel(User $user, string $ref, bool $expired = false): void
    {
        DB::transaction(function () use ($user, $ref, $expired): void {
            $t = $this->trade($ref);
            if (! $expired && (int) $t->buyer_id !== $user->id) {
                throw new DomainException('Only the buyer can cancel an order.');
            }
            if ($t->status !== 'pending') {
                throw new DomainException('This order cannot be cancelled now.');
            }
            $this->giveBack($t);
            DB::table('p2p_trades')->where('id', $t->id)->update(['status' => $expired ? 'expired' : 'cancelled', 'closed_at' => now(), 'updated_at' => now()]);
            $this->sys($t->id, $expired ? 'The payment window ended. The order was cancelled and the coins returned.' : 'The buyer cancelled the order.');
            $this->notify((int) $t->seller_id, $expired ? 'P2P order expired' : 'P2P order cancelled', 'Order '.$t->ref.' was '.($expired ? 'closed because payment was not made in time.' : 'cancelled by the buyer.'));
            if ($expired) {
                $this->notify((int) $t->buyer_id, 'P2P order expired', 'Order '.$t->ref.' was closed because payment was not marked in time.');
            }
        }, 3);
    }

    public function expireDue(): int
    {
        $n = 0;
        foreach (DB::table('p2p_trades')->where('status', 'pending')->where('expires_at', '<', now())->limit(200)->pluck('ref') as $ref) {
            try {
                $this->cancel(new User(), $ref, true);
                $n++;
            } catch (DomainException) {
            }
        }

        return $n;
    }

    private function payOut(object $t, string $note): void
    {
        $fee = (int) floor((int) $t->qty * (float) config('p2p.fee_pct') / 100);
        $this->ledger->apply((int) $t->seller_id, 'p2p', $t->coin, -(int) $t->qty, 'p2p_release', $this->lockMeta('p2p_trade', $t->id) + ['note' => $note]);
        $this->ledger->apply((int) $t->buyer_id, 'funding', $t->coin, (int) $t->qty - $fee, 'p2p_release', $this->lockMeta('p2p_trade', $t->id) + ['note' => $note]);
    }

    public function release(User $user, string $ref): void
    {
        DB::transaction(function () use ($user, $ref): void {
            $t = $this->trade($ref);
            if ((int) $t->seller_id !== $user->id) {
                throw new DomainException('Only the seller can release the coins.');
            }
            if ($t->status !== 'paid') {
                throw new DomainException('The buyer has not marked this order as paid yet.');
            }
            $this->payOut($t, 'seller release');
            DB::table('p2p_trades')->where('id', $t->id)->update(['status' => 'completed', 'closed_at' => now(), 'updated_at' => now()]);
            $this->sys($t->id, 'The seller released the coins. Order complete.');
            $this->notify((int) $t->buyer_id, 'Coins released', Money::format((int) $t->qty, 6).' '.$t->coin.' arrived in your Funding account.');
        }, 3);
    }

    public function dispute(User $user, string $ref, string $reason): void
    {
        DB::transaction(function () use ($user, $ref, $reason): void {
            $t = $this->trade($ref);
            if (! in_array($user->id, [(int) $t->buyer_id, (int) $t->seller_id], true)) {
                throw new DomainException('Order not found.');
            }
            if ($t->status !== 'paid') {
                throw new DomainException('A dispute can only be opened after the buyer marked the order as paid.');
            }
            DB::table('p2p_trades')->where('id', $t->id)->update(['status' => 'disputed', 'updated_at' => now()]);
            DB::table('p2p_disputes')->insert(['trade_id' => $t->id, 'opened_by' => $user->id, 'reason' => mb_substr($reason, 0, 300), 'status' => 'open', 'created_at' => now()]);
            $this->sys($t->id, 'A dispute was opened: "'.mb_substr($reason, 0, 300).'". '.config('app.name').' support will review the chat and decide. The coins stay locked until then.');
            $other = $user->id === (int) $t->buyer_id ? (int) $t->seller_id : (int) $t->buyer_id;
            $this->notify($other, 'P2P dispute opened', 'Order '.$t->ref.' is in dispute. Support will review it.');
            DB::afterCommit(fn () => NotificationService::admins('P2P dispute', 'Order '.$t->ref.' · '.mb_substr($reason, 0, 80), '/admin/p2p'));
        }, 3);
    }

    public function resolve(int $adminId, string $ref, string $outcome, ?string $note): void
    {
        DB::transaction(function () use ($adminId, $ref, $outcome, $note): void {
            $t = $this->trade($ref);
            if ($t->status !== 'disputed') {
                throw new DomainException('This order is not in dispute.');
            }
            if ($outcome === 'release') {
                $this->payOut($t, 'admin release');
                $status = 'completed';
            } else {
                $this->giveBack($t);
                $status = 'cancelled';
            }
            DB::table('p2p_trades')->where('id', $t->id)->update(['status' => $status, 'resolution' => mb_substr(($outcome === 'release' ? 'Coins released to buyer' : 'Coins returned to seller').($note ? ': '.$note : ''), 0, 200), 'closed_at' => now(), 'updated_at' => now()]);
            DB::table('p2p_disputes')->where('trade_id', $t->id)->update(['status' => 'resolved', 'outcome' => $outcome, 'note' => $note, 'resolved_by' => $adminId, 'resolved_at' => now()]);
            $this->sys($t->id, 'Support decision: '.($outcome === 'release' ? 'coins released to the buyer' : 'coins returned to the seller').($note ? '. '.$note : '.'));
            foreach ([(int) $t->buyer_id, (int) $t->seller_id] as $uid) {
                $this->notify($uid, 'P2P dispute resolved', 'Order '.$t->ref.': '.($outcome === 'release' ? 'coins were released to the buyer.' : 'coins were returned to the seller.'));
            }
        }, 3);
    }

    public function message(User $user, string $ref, string $body): void
    {
        $t = DB::table('p2p_trades')->where('ref', $ref)->first();
        if (! $t || ! in_array($user->id, [(int) $t->buyer_id, (int) $t->seller_id], true)) {
            throw new DomainException('Order not found.');
        }
        if (in_array($t->status, ['cancelled', 'expired'], true)) {
            throw new DomainException('This order is closed.');
        }
        DB::table('p2p_messages')->insert(['trade_id' => $t->id, 'user_id' => $user->id, 'body' => mb_substr(trim($body), 0, 500), 'created_at' => now()]);
        $other = $user->id === (int) $t->buyer_id ? (int) $t->seller_id : (int) $t->buyer_id;
        NotificationService::send($other, 'New P2P message', mb_substr($body, 0, 90), 'info', '/p2p/orders/'.$t->ref);
    }
}
