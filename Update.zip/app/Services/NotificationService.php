<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

final class NotificationService
{
    public static function send(int $userId, string $title, ?string $body = null, string $type = 'info', ?string $url = null): void
    {
        try {
            DB::table('user_notifications')->insert(['user_id' => $userId, 'type' => $type, 'title' => mb_substr($title, 0, 140), 'body' => $body, 'url' => $url, 'created_at' => now()]);
        } catch (\Throwable) {
            // A failed notification must never break the money flow that triggered it.
        }
    }
}
