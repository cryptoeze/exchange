<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

final class NotificationService
{
    /** In-app notification + e-mail from an editable template (see config/mail-templates.php). Never throws. */
    public static function event(int $userId, string $event, array $vars = []): void
    {
        try {
            $user = \App\Models\User::query()->find($userId);
            if (! $user) {
                return;
            }
            $vars = ['name' => $user->name] + $vars;
            $mail = app(MailService::class);
            $m = $mail->render($event, $vars);
            if (! $m || ! $m['enabled']) {
                return;
            }
            self::send($userId, $m['subject'], mb_substr(preg_replace('/^Hi [^\n]*,\n+/', '', $m['body']), 0, 400), $m['type'], parse_url($m['url'], PHP_URL_PATH));
            if (config('mail-templates.enabled')) {
                $mail->send($user, $event, $vars);
            }
        } catch (\Throwable) {
            // Notifications must never break the money flow.
        }
    }

    /** Tell every administrator (shown in the admin bell and in their user-side bell). */
    public static function admins(string $title, ?string $body = null, ?string $url = null): void
    {
        try {
            $ids = \Illuminate\Support\Facades\DB::table('users')->where('role', 'admin')->pluck('id');
            foreach ($ids as $id) {
                DB::table('user_notifications')->insert(['user_id' => $id, 'type' => 'admin', 'title' => mb_substr($title, 0, 140), 'body' => $body, 'url' => $url, 'created_at' => now()]);
            }
        } catch (\Throwable) {
            // Never block the original action.
        }
    }

    public static function send(int $userId, string $title, ?string $body = null, string $type = 'info', ?string $url = null): void
    {
        try {
            DB::table('user_notifications')->insert(['user_id' => $userId, 'type' => $type, 'title' => mb_substr($title, 0, 140), 'body' => $body, 'url' => $url, 'created_at' => now()]);
        } catch (\Throwable) {
            // A failed notification must never break the money flow that triggered it.
        }
    }
}
