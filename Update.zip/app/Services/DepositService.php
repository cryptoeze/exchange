<?php

namespace App\Services;

use App\Models\Deposit;
use App\Models\User;
use App\Support\Money;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Auto deposits through NOWPayments. A user gets a payment address; when the provider reports the payment
 * as `finished` (verified with the provider API, never trusting the webhook body alone), the received amount
 * is credited exactly once to the user's funding wallet through the ledger.
 */
class DepositService
{
    public const FINAL_OK = ['finished'];
    public const FINAL_BAD = ['failed', 'refunded', 'expired'];

    public function __construct(private readonly NowPaymentsClient $client, private readonly LedgerService $ledger)
    {
    }

    /** @return array<string,array{asset:string,network:string}> */
    public function catalog(): array
    {
        $map = [];
        foreach ((array) config('deposit-coins.coins') as $coin) {
            foreach ($coin['networks'] as $network) {
                $map[$network['code']] = ['asset' => $coin['ticker'], 'network' => $network['name']];
            }
        }

        return $map;
    }

    public function create(User $user, string $code): Deposit
    {
        $entry = $this->catalog()[$code] ?? throw new DomainException('This currency is not supported.');
        if (! $this->client->configured()) {
            throw new DomainException('Deposits are not available right now.');
        }
        // Re-use a still-open address for the same currency so refreshing the page never spawns new addresses.
        $open = Deposit::query()->where('user_id', $user->id)->where('pay_currency_code', $code)->where('status', 'waiting')
            ->whereNull('credited_at')->where('created_at', '>=', now()->subMinutes(60))->latest('id')->first();
        if ($open) {
            return $open;
        }
        $orderId = 'RX'.$user->id.'-'.Str::upper(Str::random(12));
        $payload = [
            'price_amount' => (float) config('deposit-coins.reference_usd'),
            'price_currency' => 'usd',
            'pay_currency' => $code,
            'order_id' => $orderId,
            'order_description' => 'Wallet deposit',
            'ipn_callback_url' => rtrim((string) config('app.url'), '/').'/api/webhooks/nowpayments',
        ];
        $result = $this->client->createPayment($payload);
        $address = (string) ($result['pay_address'] ?? '');
        if ($address === '' || empty($result['payment_id'])) {
            throw new DomainException('The provider did not return a deposit address. Please try again.');
        }

        return Deposit::query()->create([
            'user_id' => $user->id, 'order_id' => $orderId, 'provider_payment_id' => (string) $result['payment_id'],
            'pay_currency_code' => $code, 'asset' => $entry['asset'], 'network' => $entry['network'], 'pay_address' => $address,
            'pay_extra_id' => isset($result['payin_extra_id']) ? (string) $result['payin_extra_id'] : null,
            'expected_amount' => isset($result['pay_amount']) ? (string) $result['pay_amount'] : null,
            'status' => (string) ($result['payment_status'] ?? 'waiting'),
        ]);
    }

    /** Re-read the payment from the provider and apply it (used by both the webhook and status polling). */
    public function sync(Deposit $deposit): Deposit
    {
        if ($deposit->provider_payment_id === null || $deposit->credited_at !== null || in_array($deposit->status, self::FINAL_BAD, true)) {
            return $deposit;
        }
        $remote = $this->client->getPayment($deposit->provider_payment_id);

        return $this->apply($deposit, $remote);
    }

    /** @param array<string,mixed> $remote verified provider payment object */
    public function apply(Deposit $deposit, array $remote): Deposit
    {
        return DB::transaction(function () use ($deposit, $remote): Deposit {
            $row = Deposit::query()->whereKey($deposit->id)->lockForUpdate()->firstOrFail();
            if ($row->credited_at !== null) {
                return $row;
            }
            // The provider payment must belong to this deposit.
            if ((string) ($remote['payment_id'] ?? '') !== (string) $row->provider_payment_id || (string) ($remote['order_id'] ?? $row->order_id) !== $row->order_id) {
                return $row;
            }
            $status = (string) ($remote['payment_status'] ?? $row->status);
            $row->status = $status;
            if (isset($remote['actually_paid'])) {
                $row->paid_amount = (string) $remote['actually_paid'];
            }
            if (! empty($remote['payin_hash'])) {
                $row->tx_hash = (string) $remote['payin_hash'];
            }
            if (in_array($status, self::FINAL_OK, true)) {
                $units = Money::toUnits(number_format((float) ($remote['actually_paid'] ?? 0), 8, '.', ''));
                if ($units > 0) {
                    $this->ledger->apply($row->user_id, 'funding', $row->asset, $units, 'deposit', [
                        'ref_type' => 'deposit', 'ref_id' => $row->id, 'idempotency_key' => 'deposit:'.$row->id, 'note' => $row->network,
                    ]);
                    app(BonusService::class)->grantForDeposit($row->user_id, $row->asset, $units, 'deposit', $row->id);
                    $row->credited_units = $units;
                    $row->credited_at = now();
                }
            }
            $row->save();

            return $row;
        }, 3);
    }
}
