<?php

namespace App\Services;

use App\Models\FuturesPosition;
use App\Models\User;
use App\Support\Money;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * Isolated-margin perpetual futures, house-matched at the server-side price feed. Margin is locked in the `futures`
 * ledger account; on close it returns to `trading` together with PnL. A user can never lose more than the margin.
 * Take-profit, stop-loss and liquidation are enforced here (sweep), never trusted to the browser.
 */
final class FuturesService
{
    public function __construct(private readonly LedgerService $ledger, private readonly MarketDataService $markets)
    {
    }

    /** @return array<string, float> symbol => last price */
    public function priceMap(): array
    {
        $snapshot = $this->markets->snapshot('futures');
        $updated = strtotime((string) ($snapshot['meta']['updatedAt'] ?? '')) ?: 0;
        if (! empty($snapshot['meta']['stale']) || (time() - $updated) > (int) config('trading.max_price_age_seconds')) {
            throw new DomainException('Live prices are temporarily delayed. Please try again in a moment.');
        }
        $map = [];
        foreach ($snapshot['markets'] as $m) {
            if (($m['marketType'] ?? '') === 'futures' && ($m['isTradable'] ?? true) && (float) $m['lastPrice'] > 0) {
                $map[(string) $m['symbol']] = (float) $m['lastPrice'];
            }
        }

        return $map;
    }

    private function fee(int $notional): int
    {
        return (int) floor($notional * (float) config('trading.futures_fee_rate'));
    }

    private function micro(?float $price): ?int
    {
        return $price !== null && $price > 0 ? (int) round($price * Money::SCALE) : null;
    }

    public function open(User $user, string $symbol, string $side, int $margin, int $leverage, ?float $tp, ?float $sl, ?string $key = null): FuturesPosition
    {
        if (! config('trading.futures_enabled')) {
            throw new DomainException('Futures trading is currently switched off.');
        }
        if (! in_array($side, ['long', 'short'], true)) {
            throw new DomainException('Invalid side.');
        }
        $maxLev = (int) config('trading.futures_max_leverage');
        if ($leverage < 1 || $leverage > $maxLev) {
            throw new DomainException("Leverage must be between 1x and {$maxLev}x.");
        }
        if ($margin < Money::toUnits((float) config('trading.futures_min_margin_usdt')) || $margin > Money::toUnits((float) config('trading.futures_max_margin_usdt'))) {
            throw new DomainException('Margin is outside the allowed range.');
        }
        $price = $this->priceMap()[$symbol] ?? throw new DomainException('This contract is not available for trading.');
        if ($side === 'long' ? (($tp !== null && $tp <= $price) || ($sl !== null && $sl >= $price)) : (($tp !== null && $tp >= $price) || ($sl !== null && $sl <= $price))) {
            throw new DomainException('Take-profit / stop-loss are on the wrong side of the current price.');
        }
        $fee = $this->fee($margin * $leverage);

        return DB::transaction(function () use ($user, $symbol, $side, $margin, $leverage, $tp, $sl, $key, $price, $fee): FuturesPosition {
            if ($key !== null && ($existing = FuturesPosition::query()->where('idempotency_key', "{$user->id}:{$key}")->first())) {
                return $existing;
            }
            if (FuturesPosition::query()->where(['user_id' => $user->id, 'status' => 'open'])->lockForUpdate()->count() >= (int) config('trading.futures_max_positions')) {
                throw new DomainException('You have reached the maximum number of open positions.');
            }
            $position = FuturesPosition::query()->create([
                'user_id' => $user->id, 'symbol' => $symbol, 'side' => $side, 'leverage' => $leverage, 'margin' => $margin, 'entry_micro' => $this->micro($price),
                'take_profit_micro' => $this->micro($tp), 'stop_loss_micro' => $this->micro($sl), 'status' => 'open', 'fee_open' => $fee, 'idempotency_key' => $key ? "{$user->id}:{$key}" : null,
            ]);
            $meta = ['ref_type' => 'futures_position', 'ref_id' => $position->id];
            $this->ledger->apply($user->id, 'trading', 'USDT', -$margin, 'futures_open', $meta);
            $this->ledger->apply($user->id, 'futures', 'USDT', $margin, 'futures_open', $meta);
            if ($fee > 0) {
                $this->ledger->apply($user->id, 'trading', 'USDT', -$fee, 'futures_fee', $meta + ['note' => 'open']);
            }

            return $position;
        }, 3);
    }

    /** Close at `$price`. Idempotent: an already-closed position is returned unchanged. */
    private function settle(int $id, float $price, string $reason): FuturesPosition
    {
        return DB::transaction(function () use ($id, $price, $reason): FuturesPosition {
            $p = FuturesPosition::query()->whereKey($id)->lockForUpdate()->firstOrFail();
            if ($p->status !== 'open') {
                return $p;
            }
            $pnl = $p->pnlAt($price);
            $closeNotional = (int) floor($p->notional() * ($price / $p->entry()));
            $fee = $reason === 'liquidation' ? 0 : $this->fee($closeNotional);
            $payout = $reason === 'liquidation' ? 0 : max(0, $p->margin + $pnl - $fee);
            $meta = ['ref_type' => 'futures_position', 'ref_id' => $p->id, 'note' => $reason];
            $this->ledger->apply($p->user_id, 'futures', 'USDT', -$p->margin, $reason === 'liquidation' ? 'futures_liquidation' : 'futures_close', $meta);
            if ($payout > 0) {
                $this->ledger->apply($p->user_id, 'trading', 'USDT', $payout, 'futures_close', $meta);
            }
            $p->fill(['status' => 'closed', 'close_micro' => $this->micro($price), 'close_reason' => $reason, 'pnl' => $pnl, 'fee_close' => $fee, 'closed_at' => now()])->save();

            return $p;
        }, 3);
    }

    public function close(User $user, int $id): FuturesPosition
    {
        $p = FuturesPosition::query()->where(['id' => $id, 'user_id' => $user->id])->first() ?? throw new DomainException('Position not found.');
        if ($p->status !== 'open') {
            return $p;
        }
        $price = $this->priceMap()[$p->symbol] ?? throw new DomainException('This contract is not available right now.');
        // A position already past its liquidation level is liquidated, not closed at a profit-less price.
        $reason = $this->triggerFor($p, $price)[0] ?? 'manual';

        return $this->settle($p->id, $reason === 'manual' ? $price : $this->triggerFor($p, $price)[1], $reason);
    }

    public function setTpSl(User $user, int $id, ?float $tp, ?float $sl): FuturesPosition
    {
        $p = FuturesPosition::query()->where(['id' => $id, 'user_id' => $user->id, 'status' => 'open'])->first() ?? throw new DomainException('Position not found.');
        $price = $this->priceMap()[$p->symbol] ?? throw new DomainException('This contract is not available right now.');
        if ($p->side === 'long' ? (($tp !== null && $tp <= $price) || ($sl !== null && $sl >= $price)) : (($tp !== null && $tp >= $price) || ($sl !== null && $sl <= $price))) {
            throw new DomainException('Take-profit / stop-loss are on the wrong side of the current price.');
        }
        $p->fill(['take_profit_micro' => $this->micro($tp), 'stop_loss_micro' => $this->micro($sl)])->save();

        return $p;
    }

    /** @return array{0:string,1:float}|null [reason, fill price] when the position must be closed at `$price`. */
    public function triggerFor(FuturesPosition $p, float $price): ?array
    {
        $mmr = (float) config('trading.futures_maintenance_rate');
        if ($p->margin + $p->pnlAt($price) - $p->notional() * $mmr <= 0) {
            return ['liquidation', $price];
        }
        $long = $p->side === 'long';
        if ($p->stop_loss_micro && ($long ? $price <= $p->stop_loss_micro / Money::SCALE : $price >= $p->stop_loss_micro / Money::SCALE)) {
            return ['sl', $p->stop_loss_micro / Money::SCALE];
        }
        if ($p->take_profit_micro && ($long ? $price >= $p->take_profit_micro / Money::SCALE : $price <= $p->take_profit_micro / Money::SCALE)) {
            return ['tp', $p->take_profit_micro / Money::SCALE];
        }

        return null;
    }

    /** Close every open position (optionally one user's) that has hit liquidation, stop-loss or take-profit. */
    public function sweep(?int $userId = null): int
    {
        $query = FuturesPosition::query()->where('status', 'open');
        if ($userId !== null) {
            $query->where('user_id', $userId);
        }
        $open = $query->get();
        if ($open->isEmpty()) {
            return 0;
        }
        try {
            $prices = $this->priceMap();
        } catch (DomainException) {
            return 0; // stale feed: never act on old prices
        }
        $closed = 0;
        foreach ($open as $p) {
            $price = $prices[$p->symbol] ?? null;
            if ($price === null) {
                continue;
            }
            if ($t = $this->triggerFor($p, $price)) {
                $this->settle($p->id, $t[1], $t[0]);
                $closed++;
            }
        }

        return $closed;
    }
}
