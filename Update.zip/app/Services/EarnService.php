<?php

namespace App\Services;

use App\Models\EarnPosition;
use App\Models\EarnProduct;
use App\Models\LedgerEntry;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * Flexible staking. Principal sits in the user's `earn` account; simple interest at the product's APR is paid into
 * the `funding` account. Interest is settled lazily (on stake / unstake / page view / `earn:accrue`) from the exact
 * elapsed seconds, so the amount is the same however often it is settled.
 */
final class EarnService
{
    private const YEAR_SECONDS = 31_536_000;

    public function __construct(private readonly LedgerService $ledger)
    {
    }

    /** Pay interest owed to a locked position. Call inside a transaction. Returns units paid. */
    private function accrue(EarnPosition $position, EarnProduct $product): int
    {
        $now = now();
        $seconds = max(0, $now->getTimestamp() - $position->last_accrued_at->getTimestamp());
        if ($position->principal <= 0) {
            $position->last_accrued_at = $now;
            $position->save();

            return 0;
        }
        $interest = (int) floor($position->principal * ((float) $product->apr_pct / 100) * $seconds / self::YEAR_SECONDS);
        if ($interest <= 0) {
            return 0; // keep the timestamp so the fraction is not lost
        }
        $this->ledger->apply($position->user_id, 'funding', $product->asset, $interest, 'earn_interest', ['ref_type' => 'earn_position', 'ref_id' => $position->id]);
        $position->last_accrued_at = $now;
        $position->save();

        return $interest;
    }

    private function lockedPosition(int $userId, EarnProduct $product): EarnPosition
    {
        $position = EarnPosition::query()->where(['user_id' => $userId, 'earn_product_id' => $product->id])->lockForUpdate()->first();
        if ($position) {
            return $position;
        }
        EarnPosition::query()->firstOrCreate(['user_id' => $userId, 'earn_product_id' => $product->id], ['principal' => 0, 'last_accrued_at' => now()]);

        return EarnPosition::query()->where(['user_id' => $userId, 'earn_product_id' => $product->id])->lockForUpdate()->firstOrFail();
    }

    public function settleUser(int $userId): void
    {
        foreach (EarnPosition::query()->where('user_id', $userId)->where('principal', '>', 0)->pluck('earn_product_id') as $productId) {
            $product = EarnProduct::query()->find($productId);
            if ($product) {
                DB::transaction(fn () => $this->accrue($this->lockedPosition($userId, $product), $product), 3);
            }
        }
    }

    /** Settle every open position of a product (used before an administrator changes its rate). */
    public function settleProduct(EarnProduct $product): int
    {
        $count = 0;
        foreach (EarnPosition::query()->where('earn_product_id', $product->id)->where('principal', '>', 0)->pluck('user_id') as $userId) {
            DB::transaction(fn () => $this->accrue($this->lockedPosition($userId, $product), $product), 3);
            $count++;
        }

        return $count;
    }

    public function stake(User $user, EarnProduct $product, int $units, string $from, ?string $key = null): void
    {
        if (! in_array($from, ['funding', 'trading'], true)) {
            throw new DomainException('Invalid source account.');
        }
        if (! $product->enabled) {
            throw new DomainException('This product is not open for new deposits.');
        }
        if ($units <= 0 || $units < (int) $product->min_units) {
            throw new DomainException('Amount is below the minimum for this product.');
        }
        if ($product->max_per_user && $units > (int) $product->max_per_user) {
            throw new DomainException('Amount is above the maximum per user for this product.');
        }
        DB::transaction(function () use ($user, $product, $units, $from, $key): void {
            if ($key !== null && LedgerEntry::query()->where('idempotency_key', "{$user->id}:stake:{$key}:out")->exists()) {
                return;
            }
            $position = $this->lockedPosition($user->id, $product);
            if ($product->max_per_user && (int) $position->principal + $units > (int) $product->max_per_user) {
                throw new DomainException('This would exceed the maximum stake per user for this product.');
            }
            if ($product->capacity && (int) \App\Models\EarnPosition::query()->where('earn_product_id', $product->id)->sum('principal') + $units > (int) $product->capacity) {
                throw new DomainException('This product has reached its capacity. Try again later.');
            }
            $this->accrue($position, $product);
            $this->ledger->apply($user->id, $from, $product->asset, -$units, 'earn_stake', ['ref_type' => 'earn_position', 'ref_id' => $position->id, 'idempotency_key' => $key ? "{$user->id}:stake:{$key}:out" : null]);
            $this->ledger->apply($user->id, 'earn', $product->asset, $units, 'earn_stake', ['ref_type' => 'earn_position', 'ref_id' => $position->id, 'idempotency_key' => $key ? "{$user->id}:stake:{$key}:in" : null]);
            $position->principal += $units;
            $position->save();
        }, 3);
    }

    public function unstake(User $user, EarnProduct $product, int $units, ?string $key = null): void
    {
        if ($units <= 0) {
            throw new DomainException('Enter an amount.');
        }
        DB::transaction(function () use ($user, $product, $units, $key): void {
            if ($key !== null && LedgerEntry::query()->where('idempotency_key', "{$user->id}:unstake:{$key}:out")->exists()) {
                return;
            }
            $position = $this->lockedPosition($user->id, $product);
            $this->accrue($position, $product);
            if ($units > $position->principal) {
                throw new DomainException('You cannot unstake more than you have staked.');
            }
            $this->ledger->apply($user->id, 'earn', $product->asset, -$units, 'earn_unstake', ['ref_type' => 'earn_position', 'ref_id' => $position->id, 'idempotency_key' => $key ? "{$user->id}:unstake:{$key}:out" : null]);
            $this->ledger->apply($user->id, 'funding', $product->asset, $units, 'earn_unstake', ['ref_type' => 'earn_position', 'ref_id' => $position->id, 'idempotency_key' => $key ? "{$user->id}:unstake:{$key}:in" : null]);
            $position->principal -= $units;
            $position->save();
        }, 3);
    }
}
