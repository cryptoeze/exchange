<?php

namespace App\Services;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use RuntimeException;

/** Thin NOWPayments REST client. The API key never leaves the server. */
class NowPaymentsClient
{
    public function configured(): bool
    {
        return (string) config('services.nowpayments.api_key') !== '';
    }

    /** @param array<string,mixed> $payload @return array<string,mixed> */
    public function createPayment(array $payload): array
    {
        $response = $this->http()->post('/v1/payment', $payload);
        if (! $response->successful()) {
            throw new RuntimeException('Provider rejected the payment request (HTTP '.$response->status().').');
        }

        return (array) $response->json();
    }

    /** @return array<string,mixed> */
    public function getPayment(string $paymentId): array
    {
        $response = $this->http()->get('/v1/payment/'.rawurlencode($paymentId));
        if (! $response->successful()) {
            throw new RuntimeException('Could not read payment status (HTTP '.$response->status().').');
        }

        return (array) $response->json();
    }

    /** HMAC-SHA512 over the JSON body with keys sorted recursively (NOWPayments IPN scheme). */
    public function validSignature(array $payload, ?string $header): bool
    {
        $secret = (string) config('services.nowpayments.ipn_secret');
        if ($secret === '' || ! $header) {
            return false;
        }
        $sort = function (array $data) use (&$sort): array {
            ksort($data);
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    $data[$key] = $sort($value);
                }
            }

            return $data;
        };
        $expected = hash_hmac('sha512', json_encode($sort($payload), JSON_UNESCAPED_SLASHES), $secret);

        return hash_equals($expected, strtolower(trim($header)));
    }

    private function http(): PendingRequest
    {
        return Http::baseUrl((string) config('services.nowpayments.base_url'))
            ->withHeaders(['x-api-key' => (string) config('services.nowpayments.api_key')])
            ->acceptJson()->asJson()->timeout((int) config('services.nowpayments.timeout', 15));
    }
}
