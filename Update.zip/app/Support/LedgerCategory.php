<?php

namespace App\Support;

/**
 * Groups the many ledger `type` values into the handful of categories the admin filters by.
 * To add a new ledger type: add it (or its prefix) here and it appears in Admin → Transactions automatically.
 */
final class LedgerCategory
{
    /** key => [label, exact types, type prefixes] */
    public const MAP = [
        'deposit' => ['Deposits', ['deposit'], []],
        'withdrawal' => ['Withdrawals', ['withdrawal_hold', 'withdrawal_refund'], []],
        'transfer' => ['Transfers', ['transfer_in', 'transfer_out'], []],
        'spot' => ['Spot trading', ['spot_buy', 'spot_sell', 'limit_hold', 'limit_release', 'limit_fill'], []],
        'futures' => ['Futures', [], ['futures_']],
        'convert' => ['Convert', ['convert_in', 'convert_out'], []],
        'earn' => ['Earn', [], ['earn']],
        'bots' => ['Bots', [], ['bot_']],
        'p2p' => ['P2P', ['p2p'], ['p2p_']],
        'rewards' => ['Bonuses & rewards', ['deposit_bonus', 'daily_reward', 'referral_reward'], []],
        'admin' => ['Admin adjustments', ['admin_credit', 'admin_debit'], []],
    ];

    /** @return array<int, array{0:string,1:string}> value/label pairs for a <select>. */
    public static function options(): array
    {
        return array_map(fn ($k, $v) => [$k, $v[0]], array_keys(self::MAP), self::MAP);
    }

    public static function types(string $category): array
    {
        return isset(self::MAP[$category]) ? self::MAP[$category][1] : [];
    }

    /** Add `WHERE (type IN (...) OR type LIKE 'prefix%')` to a query for the category. */
    public static function scope($query, string $category): void
    {
        if (! isset(self::MAP[$category])) {
            return;
        }
        [, $exact, $prefixes] = self::MAP[$category];
        $query->where(function ($w) use ($exact, $prefixes): void {
            if ($exact) {
                $w->whereIn('type', $exact);
            }
            foreach ($prefixes as $p) {
                $w->orWhere('type', 'like', $p.'%');
            }
        });
    }

    public static function of(string $type): string
    {
        foreach (self::MAP as $key => [, $exact, $prefixes]) {
            if (in_array($type, $exact, true)) {
                return $key;
            }
            foreach ($prefixes as $p) {
                if (str_starts_with($type, $p)) {
                    return $key;
                }
            }
        }

        return 'other';
    }

    public static function label(string $type): string
    {
        return ucfirst(str_replace('_', ' ', $type));
    }
}
