<?php

namespace App\Support;

use InvalidArgumentException;

/**
 * Balances are stored as integers in units of 1e-8 (no floating point in the ledger).
 */
final class Money
{
    public const SCALE = 100_000_000;
    public const MAX_UNITS = 900_000_000_000_000_000; // 9e9 whole units, well inside BIGINT

    /** Parse a plain decimal string ("12.5", "0.00000001") into integer units. */
    public static function toUnits(string|int|float $value): int
    {
        $string = is_float($value) ? number_format($value, 8, '.', '') : trim((string) $value);
        if (! preg_match('/^(\d{1,10})(?:\.(\d{1,8}))?$/', $string, $m)) {
            throw new InvalidArgumentException('Invalid amount.');
        }
        $units = ((int) $m[1]) * self::SCALE + (int) str_pad($m[2] ?? '', 8, '0');
        if ($units > self::MAX_UNITS) {
            throw new InvalidArgumentException('Amount too large.');
        }

        return $units;
    }

    /** Format integer units as a decimal string with up to 8 decimals (trailing zeros trimmed to $min). */
    public static function format(int $units, int $min = 2): string
    {
        $negative = $units < 0;
        $abs = abs($units);
        $whole = intdiv($abs, self::SCALE);
        $fraction = str_pad((string) ($abs % self::SCALE), 8, '0', STR_PAD_LEFT);
        $fraction = rtrim($fraction, '0');
        $fraction = str_pad($fraction, $min, '0');

        return ($negative ? '-' : '').$whole.($fraction === '' ? '' : '.'.$fraction);
    }
}
