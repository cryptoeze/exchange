<?php
namespace App\Providers;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        try {
            app(\App\Services\SettingsService::class)->apply();
        } catch (\Throwable) {
            // Table may not exist yet (before migrate); config defaults apply.
        }
    }
}
