import React from 'react';
import { createRoot } from 'react-dom/client';
import { createInertiaApp } from '@inertiajs/react';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/Admin/Dashboard';
import AdminSection from './pages/Admin/Section';
import Landing from './pages/Landing';
import PlatformPage from './pages/PlatformPage';
import MarketsPage from './pages/MarketsPage';
import MarketDetail from './pages/MarketDetail';
import SpotPage from './pages/SpotPage';
import Overview from './pages/Overview';
import Deposit from './pages/Deposit';
import AccountPage from './pages/AccountPage';
import Analysis from './pages/Analysis';
import OrderCenter from './pages/OrderCenter';
import Fees from './pages/Fees';
import Earn from './pages/Earn';
import Withdraw from './pages/Withdraw';
import Transfer from './pages/Transfer';
import Convert from './pages/Convert';
import CopyTrading from './pages/CopyTrading';
import AdminWithdrawals from './pages/Admin/Withdrawals';
import AdminManualDeposits from './pages/Admin/ManualDeposits';
import FuturesPage from './pages/FuturesPage';
import AdminFutures from './pages/Admin/Futures';
import Bots from './pages/Bots';
import AdminEarn from './pages/Admin/Earn';
import AdminBots from './pages/Admin/Bots';
import '../css/app.css';
import '../css/landing.css';
import '../css/landing-interactions.css';
import '../css/navigation.css';
import '../css/header-states.css';
import '../css/landing-reference.css';

createInertiaApp({
  resolve: (name) => ({ Landing, Dashboard, PlatformPage, MarketsPage, MarketDetail, SpotPage, Overview, Deposit, AccountPage, Analysis, OrderCenter, Fees, Earn, Bots, FuturesPage, Withdraw, Transfer, Convert, CopyTrading, 'Admin/Withdrawals': AdminWithdrawals, 'Admin/ManualDeposits': AdminManualDeposits, 'Admin/Futures': AdminFutures, 'Admin/Earn': AdminEarn, 'Admin/Bots': AdminBots, 'Admin/Dashboard': AdminDashboard, 'Admin/Section': AdminSection } as Record<string, React.ComponentType<any>>)[name],
  setup({ el, App, props }) { createRoot(el).render(<App {...props} />); },
  progress: { color: '#c7f432' },
});
