import React from 'react';
import { createRoot } from 'react-dom/client';
import { createInertiaApp, router } from '@inertiajs/react';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/Admin/Dashboard';
import AdminSection from './pages/Admin/Section';
import Landing from './pages/Landing';
import PlatformPage from './pages/PlatformPage';
import MarketsPage from './pages/MarketsPage';
import MarketDetail from './pages/MarketDetail';
import SpotPage from './pages/SpotPage';
import Overview from './pages/Overview';
import Deposit from './pages/Deposit';
import AccountPage from './pages/AccountPage';
import Analysis from './pages/Analysis';
import OrderCenter from './pages/OrderCenter';
import Fees from './pages/Fees';
import Earn from './pages/Earn';
import Withdraw from './pages/Withdraw';
import Transfer from './pages/Transfer';
import Convert from './pages/Convert';
import Home from './pages/Home';
import Rewards from './pages/Rewards';
import Profile from './pages/Profile';
import Refer from './pages/Refer';
import Notifications from './pages/Notifications';
import Kyc from './pages/Kyc';
import AdminSettings from './pages/Admin/Settings';
import AdminKyc from './pages/Admin/Kyc';
import AdminNotifications from './pages/Admin/Notifications';
import AdminAudit from './pages/Admin/Audit';
import AdminReferrals from './pages/Admin/Referrals';
import AdminUsers from './pages/Admin/Users';
import AdminGateways from './pages/Admin/Gateways';
import AdminEmailTemplates from './pages/Admin/EmailTemplates';
import Security from './pages/Security';
import AdminSecurity from './pages/Admin/Security';
import AdminTeam from './pages/Admin/Team';
import Alerts from './pages/Alerts';
import Tickets from './pages/Tickets';
import AdminTickets from './pages/Admin/Tickets';
import ProofOfReserves from './pages/ProofOfReserves';
import AdminPor from './pages/Admin/Por';
import P2p from './pages/P2p';
import P2pOrders from './pages/P2pOrders';
import P2pOrder from './pages/P2pOrder';
import P2pAds from './pages/P2pAds';
import AdminP2p from './pages/Admin/P2p';
import CopyTrading from './pages/CopyTrading';
import AdminWithdrawals from './pages/Admin/Withdrawals';
import AdminManualDeposits from './pages/Admin/ManualDeposits';
import FuturesPage from './pages/FuturesPage';
import AdminFutures from './pages/Admin/Futures';
import Bots from './pages/Bots';
import AdminEarn from './pages/Admin/Earn';
import AdminBots from './pages/Admin/Bots';
import '../css/app.css';
import '../css/landing.css';
import '../css/landing-interactions.css';
import '../css/navigation.css';
import '../css/header-states.css';
import '../css/landing-reference.css';
import '../css/light-theme.css';

createInertiaApp({
  resolve: (name) => ({ Landing, Dashboard, PlatformPage, MarketsPage, MarketDetail, SpotPage, Overview, Deposit, AccountPage, Analysis, OrderCenter, Fees, Earn, Bots, FuturesPage, Withdraw, Transfer, Convert, CopyTrading, Home, Rewards, Profile, Refer, Notifications, Kyc, 'Admin/Settings': AdminSettings, 'Admin/Kyc': AdminKyc, 'Admin/Notifications': AdminNotifications, 'Admin/Audit': AdminAudit, 'Admin/Referrals': AdminReferrals, 'Admin/Users': AdminUsers, 'Admin/Gateways': AdminGateways, 'Admin/EmailTemplates': AdminEmailTemplates, Security, 'Admin/Security': AdminSecurity, 'Admin/Team': AdminTeam, Alerts, Tickets, 'Admin/Tickets': AdminTickets, ProofOfReserves, 'Admin/Por': AdminPor, P2p, P2pOrders, P2pOrder, P2pAds, 'Admin/P2p': AdminP2p, 'Admin/Withdrawals': AdminWithdrawals, 'Admin/ManualDeposits': AdminManualDeposits, 'Admin/Futures': AdminFutures, 'Admin/Earn': AdminEarn, 'Admin/Bots': AdminBots, 'Admin/Dashboard': AdminDashboard, 'Admin/Section': AdminSection } as Record<string, React.ComponentType<any>>)[name],
  setup({ el, App, props }) { createRoot(el).render(<App {...props} />); },
  progress: { color: '#c7f432' },
});

/* App-like navigation feedback on phones: a short spinner while the next screen loads. */
(() => {
  if (typeof document === 'undefined') return;
  const el = document.createElement('div'); el.id = 'rx-navload'; el.setAttribute('aria-hidden', 'true'); el.innerHTML = '<i></i>';
  document.body.appendChild(el);
  let timer = 0;
  const show = () => { window.clearTimeout(timer); timer = window.setTimeout(() => el.classList.add('on'), 90); };
  const hide = () => { window.clearTimeout(timer); el.classList.remove('on'); };
  router.on('start', show); router.on('finish', hide);
  window.addEventListener('pageshow', hide);
  document.addEventListener('click', e => { // plain <a> links do a full page load
    const a = (e.target as HTMLElement).closest?.('a[href]') as HTMLAnchorElement | null;
    if (!a || e.defaultPrevented || a.target === '_blank' || a.hasAttribute('download') || e.metaKey || e.ctrlKey) return;
    const u = new URL(a.href, location.href); if (u.origin !== location.origin || (u.pathname === location.pathname && u.search === location.search) || u.hash) return;
    show();
  }, true);
})();
