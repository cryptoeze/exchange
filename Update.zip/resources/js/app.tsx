import React from 'react';
import { createRoot } from 'react-dom/client';
import { createInertiaApp } from '@inertiajs/react';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/Admin/Dashboard';
import AdminSection from './pages/Admin/Section';
import Landing from './pages/Landing';
import PlatformPage from './pages/PlatformPage';
import MarketsPage from './pages/MarketsPage';
import MarketDetail from './pages/MarketDetail';
import '../css/app.css';
import '../css/landing.css';
import '../css/landing-interactions.css';
import '../css/navigation.css';
import '../css/header-states.css';
import '../css/landing-reference.css';

createInertiaApp({
  resolve: (name) => ({ Landing, Dashboard, PlatformPage, MarketsPage, MarketDetail, 'Admin/Dashboard': AdminDashboard, 'Admin/Section': AdminSection } as Record<string, React.ComponentType<any>>)[name],
  setup({ el, App, props }) { createRoot(el).render(<App {...props} />); },
  progress: { color: '#c7f432' },
});
