export type MarketType = 'spot' | 'futures';
export type MarketCategory = 'All' | 'Top' | 'New' | 'AI' | 'Meme' | 'DeFi' | 'Layer 1';
export type Market = {
  symbol: string; baseAsset: string; quoteAsset: string; marketType: MarketType; displayName: string;
  lastPrice: number; change24h: number; high24h: number; low24h: number; volume24h: number;
  turnover24h: number; isTradable: boolean; launchTime: string | null; isNew: boolean;
  categories: string[]; icon: string | null;
};
export type MarketSnapshot = {
  markets: Market[];
  highlights: { hotCrypto: Market[]; topGainers: Market[]; topVolume24h: Market[] };
  meta: { provider: string; updatedAt: string; stale: boolean; lastError: string | null; refreshSeconds: number; spotCount: number; futuresCount: number; topRankLimit?: number };
};
export type Favorite = { symbol: string; marketType: MarketType };
