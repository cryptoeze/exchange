import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Market, MarketSnapshot } from '../types/market';
import { api, type WalletPayload } from './wallet';

/** Light/dark preference shared by every account page. */
export function useTheme(): [boolean, () => void] {
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  return [dark, () => setDark(v => !v)];
}

/** Live wallet balances (server ledger), refreshed every 8s while the tab is visible. */
export function useWallet(account: 'funding' | 'trading' = 'funding', enabled = true) {
  const [wallet, setWallet] = useState<WalletPayload | null>(null);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    if (!enabled) return;
    const r = await api<WalletPayload>(`/api/wallet?account=${account}`);
    if (r.ok) { setWallet(r.data); setError(''); } else if (r.status === 401) { window.location.href = '/login'; } else { setError('Balances could not be loaded.'); }
  }, [account, enabled]);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 3000); return () => window.clearInterval(t); }, [load]);
  return { wallet, setWallet, error, reload: load };
}

/** Live spot prices (server cache of the public price feed), refreshed every 5s. */
export function useSpotPrices() {
  const [markets, setMarkets] = useState<Market[]>([]);
  useEffect(() => {
    let active = true; let timer = 0;
    const load = async () => {
      try { const r = await fetch('/api/markets?type=spot', { headers: { Accept: 'application/json' } }); const d = await r.json() as MarketSnapshot; if (active && Array.isArray(d.markets)) setMarkets(d.markets); } catch { /* retry */ }
      if (active) timer = window.setTimeout(load, 2000);
    };
    void load(); return () => { active = false; window.clearTimeout(timer); };
  }, []);
  return useMemo(() => new Map(markets.map(m => [m.symbol, m])), [markets]);
}

export const COIN_NAMES: Record<string, string> = { USDT: 'Tether', USDC: 'USD Coin', BTC: 'Bitcoin', ETH: 'Ethereum', SOL: 'Solana', BNB: 'BNB', XRP: 'XRP', DOGE: 'Dogecoin', ADA: 'Cardano', TRX: 'TRON', TON: 'Toncoin', LTC: 'Litecoin', BCH: 'Bitcoin Cash' };
