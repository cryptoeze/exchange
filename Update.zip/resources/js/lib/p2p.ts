export type P2pConfig = { enabled: boolean; fee: number; coins: Record<string, number>; fiats: Record<string, { name: string; symbol: string }>; methods: string[] };
export type P2pAd = { id: number; side: 'buy' | 'sell'; coin: string; fiat: string; price: number; available: string; availableUnits: number; min: number; max: number; methods: string[]; terms: string | null; window: number; name: string; userId: number; completed: number; rate: number | null; seen: string; status?: string; total?: string };
export const STATUS_LABEL: Record<string, string> = { pending: 'Waiting for payment', paid: 'Paid · waiting for release', completed: 'Completed', cancelled: 'Cancelled', expired: 'Expired', disputed: 'In dispute' };
export const STATUS_TONE: Record<string, string> = { pending: '#f5a623', paid: '#3b82f6', completed: '#2ebd85', cancelled: '#8e8e93', expired: '#8e8e93', disputed: '#f6465d' };
export const initials = (n: string) => n.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase() || '?';
export const money = (v: number, d = 2) => v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
