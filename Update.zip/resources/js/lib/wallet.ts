import type { Market } from '../types/market';

export type Balance = { account: string; asset: string; balance: string; units: number };
export type HistoryItem = { id: number; title: string; type: string; asset: string; amount: string; positive: boolean; at: string | null };
export type WalletPayload = { balances: Balance[]; history: HistoryItem[]; serverTime: string };
export type OrderRow = { id: number; symbol: string; base: string; side: 'buy' | 'sell'; status: string; price: number; quantity: string; total: string; fee: string; at: string | null };

const STABLES = new Set(['USDT', 'USDC', 'USD']);

function xsrf(): string {
  const raw = document.cookie.split('; ').find(row => row.startsWith('XSRF-TOKEN='))?.split('=').slice(1).join('=') ?? '';
  return decodeURIComponent(raw);
}

export async function api<T>(url: string, body?: Record<string, unknown>): Promise<{ ok: boolean; status: number; data: T & { message?: string } }> {
  const response = await fetch(url, {
    method: body ? 'POST' : 'GET', credentials: 'same-origin',
    headers: { Accept: 'application/json', ...(body ? { 'Content-Type': 'application/json', 'X-XSRF-TOKEN': xsrf() } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

export function newKey(): string {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

/** USD value of a holding using live spot prices. USDT/USDC are 1:1. Unknown assets are 0 (not guessed). */
export function usdValue(asset: string, amount: number, prices: Map<string, Market>): number {
  if (STABLES.has(asset)) return amount;
  const market = prices.get(`${asset}USDT`);
  return market ? amount * market.lastPrice : 0;
}

/** Movement over the last 24h of the holding, derived from the exchange 24h change (not invented). */
export function change24hUsd(asset: string, amount: number, prices: Map<string, Market>): number {
  if (STABLES.has(asset)) return 0;
  const market = prices.get(`${asset}USDT`);
  if (!market) return 0;
  const value = amount * market.lastPrice;
  return value - value / (1 + market.change24h / 100);
}

export const usd = (value: number, digits = 2) => value.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
