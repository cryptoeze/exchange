import { Gift, Home, LineChart, Wallet, ArrowDownUp } from 'lucide-react';
import '../../css/mobile-home.css';

const LEFT = [{ k: 'home', label: 'Home', href: '/dashboard', Icon: Home }, { k: 'markets', label: 'Markets', href: '/markets', Icon: LineChart }] as const;
const RIGHT = [{ k: 'rewards', label: 'Rewards', href: '/rewards', Icon: Gift }, { k: 'assets', label: 'Assets', href: '/assets', Icon: Wallet }] as const;

/** App-style bottom navigation, shown on phones only (hidden above 820px). */
export default function MobileNav({ active }: { active?: 'home' | 'markets' | 'trade' | 'rewards' | 'assets' }) {
  const item = ({ k, label, href, Icon }: { k: string; label: string; href: string; Icon: typeof Home }) =>
    <a key={k} href={href} className={`mnav-item${active === k ? ' on' : ''}`} aria-current={active === k ? 'page' : undefined}><Icon aria-hidden="true"/><span>{label}</span></a>;
  return <nav className="mnav" aria-label="Main">
    {LEFT.map(item)}
    <a href="/spot" className={`mnav-trade${active === 'trade' ? ' on' : ''}`} aria-label="Trade"><span><ArrowDownUp aria-hidden="true"/></span><em>Trade</em></a>
    {RIGHT.map(item)}
  </nav>;
}
