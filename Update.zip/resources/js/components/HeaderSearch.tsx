import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { Search } from 'lucide-react';
import CoinImage from './CoinImage';
import type { Market, MarketSnapshot } from '../types/market';

type Tab = 'all' | 'spot' | 'futures';
const PAGE = 40;
const price = (p: number) => p >= 1000 ? p.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : p >= 1 ? p.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 }) : p.toLocaleString('en-US', { minimumFractionDigits: 6, maximumFractionDigits: 6 });
const href = (m: Market) => `/${m.marketType === 'futures' ? 'futures' : 'spot'}?pair=${m.symbol}`;

/** Header search: live coin list (All / Spot / Futures) that opens on focus, as in the reference. */
export default function HeaderSearch({ mobile = false, onNavigate }: { mobile?: boolean; onNavigate?: () => void }) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>('all');
  const [query, setQuery] = useState('');
  const [markets, setMarkets] = useState<Market[] | null>(null);
  const [failed, setFailed] = useState(false);
  const [limit, setLimit] = useState(PAGE);
  const [flash, setFlash] = useState<Record<string, 'up' | 'down'>>({});
  const root = useRef<HTMLDivElement>(null);
  const last = useRef(new Map<string, number>());

  useEffect(() => {
    if (!open) return;
    let active = true; let timer = 0;
    const load = async () => {
      try {
        const r = await fetch('/api/markets?type=both', { headers: { Accept: 'application/json' } });
        const d = await r.json() as MarketSnapshot;
        if (!active || !Array.isArray(d.markets)) throw new Error('bad');
        const next: Record<string, 'up' | 'down'> = {};
        for (const m of d.markets) { const key = `${m.marketType}:${m.symbol}`; const old = last.current.get(key); if (old !== undefined && old !== m.lastPrice) next[key] = m.lastPrice > old ? 'up' : 'down'; last.current.set(key, m.lastPrice); }
        setMarkets(d.markets.filter(m => m.quoteAsset === 'USDT' && m.lastPrice > 0)); setFailed(false); setFlash(next);
        window.setTimeout(() => active && setFlash({}), 600);
      } catch { if (active) setFailed(true); }
      if (active) timer = window.setTimeout(load, 2000);
    };
    void load(); return () => { active = false; window.clearTimeout(timer); };
  }, [open]);

  useEffect(() => {
    const dismiss = (e: PointerEvent) => { if (root.current && !root.current.contains(e.target as Node)) setOpen(false); };
    const keys = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('pointerdown', dismiss); document.addEventListener('keydown', keys);
    return () => { document.removeEventListener('pointerdown', dismiss); document.removeEventListener('keydown', keys); };
  }, []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase().replace(/[\/\s]/g, '').replace(/usdt$/, '');
    return (markets ?? []).filter(m => (tab === 'all' || m.marketType === tab) && (!q || m.baseAsset.toLowerCase().includes(q)))
      .sort((a, b) => b.turnover24h - a.turnover24h);
  }, [markets, tab, query]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const first = results[0];
    if (first) window.location.assign(href(first)); else if (query.trim()) window.location.assign(`/markets?search=${encodeURIComponent(query.trim())}`);
  };

  return <div className={`rxh-search-root${mobile ? ' is-mobile' : ''}`} ref={root}>
    <form className={mobile ? 'rxh-mobile-search-form' : 'rxh-search-field'} role="search" onSubmit={submit}>
      <Search aria-hidden="true"/>
      <input value={query} onFocus={() => setOpen(true)} onChange={e => { setQuery(e.target.value); setLimit(PAGE); setOpen(true); }} placeholder="Search crypto" aria-label="Search crypto" autoComplete="off" spellCheck={false} role="combobox" aria-expanded={open}/>
      <button type="submit" aria-label="Search markets"><span>Search</span></button>
    </form>
    {open && <div className="rxh-sd" role="listbox" aria-label="Markets">
      <div className="rxh-sd-tabs">{(['all', 'spot', 'futures'] as Tab[]).map(t => <button type="button" key={t} className={tab === t ? 'active' : ''} onClick={() => { setTab(t); setLimit(PAGE); }}>{t === 'all' ? 'All' : t === 'spot' ? 'Spot' : 'Futures'}</button>)}</div>
      <div className="rxh-sd-list" onScroll={e => { const el = e.currentTarget; if (el.scrollTop + el.clientHeight >= el.scrollHeight - 60) setLimit(l => l + 20); }}>
        {markets === null ? (failed ? <p className="rxh-sd-empty">Prices are temporarily unavailable.</p> : Array.from({ length: 6 }, (_, i) => <div className="rxh-sd-skel" key={i}><span/><i/><b/></div>))
          : results.length === 0 ? <p className="rxh-sd-empty">No pairs found</p>
          : results.slice(0, limit).map(m => { const key = `${m.marketType}:${m.symbol}`; return <a key={key} href={href(m)} role="option" aria-selected="false" className="rxh-sd-item" onClick={() => { setOpen(false); onNavigate?.(); }}>
            <span className="rxh-sd-coin"><CoinImage symbol={m.baseAsset} icon={m.icon}/></span>
            <span className="rxh-sd-pair"><b>{m.baseAsset}/USDT</b><em className={m.marketType === 'futures' ? 'fut' : ''}>{m.marketType === 'futures' ? 'PERP' : 'SPOT'}</em></span>
            <span className="rxh-sd-price"><b className={flash[key] ?? ''}>{price(m.lastPrice)}</b><small className={m.change24h >= 0 ? 'up' : 'down'}>{m.change24h >= 0 ? '+' : ''}{m.change24h.toFixed(2)}%</small></span></a>; })}
      </div>
    </div>}
  </div>;
}
