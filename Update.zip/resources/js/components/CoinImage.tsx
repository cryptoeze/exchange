import { useEffect, useMemo, useState } from 'react';

/** Coin logo with a fallback chain: RushX local icon -> open-source icon CDN -> TradingView symbol logo -> first letter. */
export default function CoinImage({ symbol, icon = null }: { symbol: string; icon?: string | null }) {
  const sources = useMemo(() => {
    const s = symbol.replace(/USDT$/, '');
    return [icon, `https://cdn.jsdelivr.net/gh/atomiclabs/cryptocurrency-icons@master/svg/color/${s.toLowerCase()}.svg`, `https://s3-symbol-logo.tradingview.com/crypto/XTVC${s.toUpperCase()}.svg`].filter((v): v is string => !!v);
  }, [symbol, icon]);
  const [index, setIndex] = useState(0);
  useEffect(() => setIndex(0), [sources]);
  if (index >= sources.length) return <i style={{ fontStyle: 'normal' }}>{symbol.slice(0, 1)}</i>;
  return <img src={sources[index]} alt="" loading="lazy" onError={() => setIndex(i => i + 1)} style={{ width: '100%', height: '100%', objectFit: 'contain', borderRadius: '50%' }}/>;
}
