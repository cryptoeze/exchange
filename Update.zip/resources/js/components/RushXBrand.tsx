import { usePage } from '@inertiajs/react';
import rushxMark from '../../images/rushx-mark.svg';

export default function RushXBrand() {
  // Admin → Settings can upload a custom logo; falls back to the built-in RushX mark when none is set.
  const { siteLogo } = usePage().props as { siteLogo?: string | null };
  return <a href="/" className="rxh-brand" aria-label="RushX home"><img src={siteLogo || rushxMark} alt=""/><span>Rush<span>X</span></span></a>;
}
