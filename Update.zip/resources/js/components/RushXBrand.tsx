import rushxMark from '../../images/rushx-mark.svg';

export default function RushXBrand() {
  return <a href="/" className="rxh-brand" aria-label="RushX home"><img src={rushxMark} alt=""/><span>Rush<span>X</span></span></a>;
}
