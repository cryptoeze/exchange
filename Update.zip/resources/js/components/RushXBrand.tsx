import { usePage } from '@inertiajs/react';
import rushxMark from '../../images/rushx-mark.svg';

export default function RushXBrand() {
  // Admin → Settings can upload a custom logo; falls back to the built-in RushX mark + wordmark when none is set.
  // Once a site has its own logo, it's already their complete brand mark — the "RushX" wordmark next to it would be wrong.
  const { siteLogo, siteName } = usePage().props as { siteLogo?: string | null; siteName?: string };
  const name = siteName || 'RushX';
  return <a href="/" className="rxh-brand" aria-label="Home"><img src={siteLogo || rushxMark} alt=""/>{!siteLogo && (name === 'RushX' ? <span>Rush<span>X</span></span> : <span>{name}</span>)}</a>;
}
