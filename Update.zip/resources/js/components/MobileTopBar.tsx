import { router } from '@inertiajs/react';
import { Bell, MessageCircle, Moon, Sun } from 'lucide-react';
import { useUnread } from '../lib/hooks';
import type { HeaderUser } from './RushXHeader';
import '../../css/mobile-home.css';

const initials = (n: string) => n.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'U';

/** The one phone header shared by Home, Assets and Rewards: profile, logo, bell (animated + red badge when unread), chat, theme. */
export default function MobileTopBar({ user, dark, onToggleTheme, scrolled = false }: { user: HeaderUser | null; dark: boolean; onToggleTheme: () => void; scrolled?: boolean }) {
  const unread = useUnread(!!user);
  return <header className={`mh-head mtb${scrolled ? ' scrolled' : ''}`}>
    <button type="button" className="mh-avatar" aria-label="Profile" onClick={() => router.visit('/profile')}>{initials(user?.name ?? 'User')}</button>
    <a className="mh-logo" href="/dashboard" aria-label="RushX home"><svg viewBox="0 0 100 100" fill="none" aria-hidden="true"><rect width="100" height="100" rx="24" fill="#c1f033" fillOpacity=".12"/><path d="M25 25 L45 25 L75 60 L75 75 L55 75 L25 40 Z" fill="currentColor"/><path d="M25 75 L25 60 L55 25 L75 25 L75 40 L45 75 Z" fill="#c1f033"/></svg><b>Rush<i>X</i></b></a>
    <span className="mh-hicons">
      <a href="/notifications" aria-label={unread ? `${unread} new notifications` : 'Notifications'} className={`mtb-bell${unread > 0 ? ' ring' : ''}`}><Bell/>{unread > 0 && <i className="bell-badge">{unread > 9 ? '9+' : unread}</i>}</a>
      <button type="button" aria-label="Live chat" onClick={() => (window as unknown as { rushxChat?: () => void }).rushxChat?.()}><MessageCircle/></button>
      <button type="button" aria-label="Toggle theme" onClick={onToggleTheme}>{dark ? <Sun/> : <Moon/>}</button>
    </span>
  </header>;
}
