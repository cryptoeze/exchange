import { useEffect, useRef, useState } from 'react';
import { Download, Share2, X } from 'lucide-react';

export type ShareData = { symbol: string; side: 'long' | 'short'; leverage: number; roePct: number; pnl: number; entry: number; exit: number | null; exitLabel: string; openedAt: string | null; closedAt: string | null; reason: string };

const W = 720; const H = 900;
const fmtP = (v: number | null) => v === null ? '—' : v.toLocaleString('en-US', { minimumFractionDigits: v > 1000 ? 1 : v > 1 ? 4 : 6, maximumFractionDigits: v > 1000 ? 1 : v > 1 ? 4 : 6 });
const dur = (a: string | null, b: string | null) => { if (!a) return '—'; const s = Math.max(0, ((b ? new Date(b) : new Date()).getTime() - new Date(a).getTime()) / 1000); const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : m ? `${m}m ${Math.floor(s % 60)}s` : `${Math.floor(s)}s`; };

function draw(c: HTMLCanvasElement, d: ShareData, code: string | null) {
  const x = c.getContext('2d'); if (!x) return;
  const win = d.roePct >= 0; const accent = win ? '#2ebd85' : '#f6465d';
  const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#0b0d0a'); g.addColorStop(1, win ? '#0d1f17' : '#24100f'); x.fillStyle = g; x.fillRect(0, 0, W, H);
  const glow = x.createRadialGradient(W * .75, H * .3, 10, W * .75, H * .3, 420); glow.addColorStop(0, win ? 'rgba(46,189,133,.28)' : 'rgba(246,70,93,.25)'); glow.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = glow; x.fillRect(0, 0, W, H);
  x.fillStyle = '#c1f033'; x.font = '800 44px Inter, sans-serif'; x.fillText('Rush', 48, 86); const rw = x.measureText('Rush').width; x.fillStyle = '#fff'; x.fillText('X', 48 + rw, 86);
  x.fillStyle = 'rgba(255,255,255,.55)'; x.font = '500 22px Inter, sans-serif'; x.textAlign = 'right'; x.fillText('Futures · Perpetual', W - 48, 84); x.textAlign = 'left';
  x.fillStyle = '#fff'; x.font = '800 54px Inter, sans-serif'; x.fillText(d.symbol, 48, 230);
  const tag = `${d.side === 'long' ? 'LONG' : 'SHORT'}  ${d.leverage}x`; x.font = '800 24px Inter, sans-serif'; const tw = x.measureText(tag).width + 36;
  x.fillStyle = win ? 'rgba(46,189,133,.18)' : 'rgba(246,70,93,.18)'; x.beginPath(); x.roundRect(48, 256, tw, 48, 12); x.fill(); x.fillStyle = d.side === 'long' ? '#2ebd85' : '#f6465d'; x.fillText(tag, 66, 290);
  x.fillStyle = accent; x.font = '900 128px Inter, sans-serif'; x.fillText(`${win ? '+' : ''}${d.roePct.toFixed(2)}%`, 44, 470);
  x.fillStyle = 'rgba(255,255,255,.6)'; x.font = '600 28px Inter, sans-serif'; x.fillText(`${win ? '+' : '-'}$${Math.abs(d.pnl).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT  ·  ${d.reason}`, 48, 524);
  const rows: Array<[string, string]> = [['Entry price', fmtP(d.entry)], [d.exitLabel, fmtP(d.exit)], ['Opened', d.openedAt ? new Date(d.openedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—'], ['Holding time', dur(d.openedAt, d.closedAt)]];
  rows.forEach(([k, v], i) => { const y = 600 + i * 62; x.fillStyle = 'rgba(255,255,255,.5)'; x.font = '500 26px Inter, sans-serif'; x.textAlign = 'left'; x.fillText(k, 48, y); x.fillStyle = '#fff'; x.font = '700 28px Inter, sans-serif'; x.textAlign = 'right'; x.fillText(v, W - 48, y); x.strokeStyle = 'rgba(255,255,255,.08)'; x.beginPath(); x.moveTo(48, y + 20); x.lineTo(W - 48, y + 20); x.stroke(); });
  x.textAlign = 'left'; x.fillStyle = 'rgba(255,255,255,.55)'; x.font = '500 22px Inter, sans-serif'; x.fillText('Trade on RushX · riseway.io', 48, H - 56);
  if (code) { x.textAlign = 'right'; x.fillStyle = '#c1f033'; x.font = '800 26px Inter, sans-serif'; x.fillText(`Code: ${code}`, W - 48, H - 54); x.textAlign = 'left'; }
}

export default function PnlShareCard({ data, code, onClose }: { data: ShareData; code: string | null; onClose: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null); const [msg, setMsg] = useState('');
  useEffect(() => { const c = ref.current; if (c) draw(c, data, code); }, [data, code]);
  const blob = () => new Promise<Blob | null>(res => ref.current?.toBlob(res, 'image/png'));
  const download = async () => { const b = await blob(); if (!b) return; const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `rushx-${data.symbol}-pnl.png`; a.click(); URL.revokeObjectURL(a.href); };
  const share = async () => {
    const b = await blob(); if (!b) return; const file = new File([b], `rushx-${data.symbol}.png`, { type: 'image/png' });
    try { if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: 'RushX trade' }); return; } } catch { return; }
    await download(); setMsg('Image saved — share it from your gallery.');
  };
  return <div className="pnl-bg" role="dialog" aria-modal="true" aria-label="Share trade" onClick={onClose}><div className="pnl-box" onClick={e => e.stopPropagation()}>
    <button type="button" className="pnl-x" aria-label="Close" onClick={onClose}><X/></button>
    <canvas ref={ref} width={W} height={H}/>
    <div className="pnl-acts"><button type="button" onClick={share}><Share2/> Share</button><button type="button" onClick={download}><Download/> Save image</button></div>
    {msg && <p className="pnl-msg">{msg}</p>}
  </div></div>;
}
