import type { ReactNode } from 'react';
import { Head, usePage } from '@inertiajs/react';
import RushXHeader, { type HeaderUser } from './RushXHeader';
import AccountSubNav from './AccountSubNav';
import { useTheme } from '../lib/hooks';
import MobileNav from './MobileNav';
import MobileTopBar from './MobileTopBar';
import '../../css/overview.css';
import '../../css/account-pages.css';

/** Shared shell for the account pages: header, secondary navigation, theme. */
export default function AccountLayout({ active, title, children, showNav = true, phoneBar = false }: { active: string; title: string; children: ReactNode; showNav?: boolean; phoneBar?: boolean }) {
  const pageProps = usePage().props as Record<string, unknown>;
  const user = (pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, toggle] = useTheme();
  return <><Head title={`${title} — RushX`}/>
    <div className={`ov-shell rx-dashboard${phoneBar ? ' rx-phonebar' : ''}`}>{phoneBar && user && <MobileTopBar user={user} dark={dark} onToggleTheme={toggle}/>}<RushXHeader user={user} dark={dark} onToggleTheme={toggle}/>
      {showNav && user && <AccountSubNav active={active}/>}
      {children}
      {user && <MobileNav active={active === 'Rewards' ? 'rewards' : undefined}/>}
    </div></>;
}
