import type { ReactNode } from 'react';
import { Head, usePage } from '@inertiajs/react';
import RushXHeader, { type HeaderUser } from './RushXHeader';
import AccountSubNav from './AccountSubNav';
import { useTheme } from '../lib/hooks';
import MobileNav from './MobileNav';
import '../../css/overview.css';
import '../../css/account-pages.css';

/** Shared shell for the account pages: header, secondary navigation, theme. */
export default function AccountLayout({ active, title, children, showNav = true }: { active: string; title: string; children: ReactNode; showNav?: boolean }) {
  const pageProps = usePage().props as Record<string, unknown>;
  const user = (pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, toggle] = useTheme();
  return <><Head title={`${title} — RushX`}/>
    <div className="ov-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={toggle}/>
      {showNav && user && <AccountSubNav active={active}/>}
      {children}
      {user && <MobileNav active={active === 'Rewards' ? 'rewards' : undefined}/>}
    </div></>;
}
