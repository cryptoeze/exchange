import { useState } from 'react';
import QRCode from 'qrcode';
import { api } from '../lib/wallet';

type Start = { secret: string; uri: string };
const base = (admin: boolean) => admin ? '/admin/security/2fa' : '/security/2fa';

/** Authenticator-app 2FA: set up (QR + confirm), view recovery codes once, or turn off. Used by the user and admin security pages. */
export default function TwoFactorPanel({ enabled: initial, admin = false }: { enabled: boolean; admin?: boolean }) {
  const [enabled, setEnabled] = useState(initial);
  const [setup, setSetup] = useState<(Start & { qr: string }) | null>(null);
  const [code, setCode] = useState(''); const [pw, setPw] = useState(''); const [off, setOff] = useState(false);
  const [codes, setCodes] = useState<string[] | null>(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const start = async () => { setErr(''); setBusy(true); const r = await api<Start>(`${base(admin)}/start`, {}); setBusy(false); if (!r.ok) { setErr(r.data.message ?? 'Could not start.'); return; } setSetup({ ...r.data, qr: await QRCode.toDataURL(r.data.uri, { margin: 1, width: 200 }) }); };
  const confirm = async () => { setErr(''); setBusy(true); const r = await api<{ recovery: string[] }>(`${base(admin)}/confirm`, { code }); setBusy(false); if (!r.ok) { setErr(r.data.message ?? 'Wrong code.'); return; } setCodes(r.data.recovery); setEnabled(true); setSetup(null); setCode(''); };
  const disable = async () => { setErr(''); setBusy(true); const r = await api(`${base(admin)}/disable`, { password: pw, code }); setBusy(false); if (!r.ok) { setErr(r.data.message ?? 'Could not turn off.'); return; } setEnabled(false); setOff(false); setPw(''); setCode(''); };
  const box = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 10, padding: '11px 12px', font: 'inherit', width: '100%' } as const;
  const btn = { border: 0, borderRadius: 10, padding: '12px 18px', background: '#c1f033', color: '#000', fontWeight: 800, cursor: 'pointer', font: 'inherit' } as const;
  return <div style={{ display: 'grid', gap: 12 }}>
    <p style={{ margin: 0, opacity: .8, fontSize: 14 }}>Two-factor authentication adds a 6-digit code from an authenticator app (Google Authenticator, Authy, Microsoft Authenticator) to every sign-in.</p>
    <p style={{ margin: 0 }}>Status: <b style={{ color: enabled ? '#2ebd85' : '#f5a623' }}>{enabled ? 'ON' : 'OFF'}</b></p>
    {err && <p role="alert" style={{ color: '#f6465d', margin: 0 }}>{err}</p>}
    {codes && <div style={{ border: '1px solid #c1f033', borderRadius: 12, padding: 14 }}><b>Save these recovery codes now</b><p style={{ margin: '6px 0', fontSize: 13, opacity: .8 }}>Each code works once if you lose your phone. They will not be shown again.</p><pre style={{ margin: 0, fontSize: 15, lineHeight: 1.7 }}>{codes.join('\n')}</pre><button type="button" style={{ ...btn, marginTop: 10 }} onClick={() => setCodes(null)}>I saved them</button></div>}
    {!enabled && !setup && <button type="button" style={btn} disabled={busy} onClick={start}>Set up authenticator</button>}
    {setup && <div style={{ display: 'grid', gap: 10 }}>
      <p style={{ margin: 0, fontSize: 14 }}>1. Scan this QR code in your authenticator app, or type the key by hand.</p>
      <img src={setup.qr} alt="2FA QR code" width={200} height={200} style={{ background: '#fff', borderRadius: 10, padding: 6 }}/>
      <code style={{ overflowWrap: 'anywhere', fontSize: 14 }}>{setup.secret}</code>
      <p style={{ margin: 0, fontSize: 14 }}>2. Enter the 6-digit code it shows:</p>
      <input style={box} inputMode="numeric" maxLength={6} value={code} onChange={e => setCode(e.target.value)} placeholder="123456"/>
      <button type="button" style={btn} disabled={busy || code.length < 6} onClick={confirm}>Turn on</button>
    </div>}
    {enabled && !off && <button type="button" style={{ ...btn, background: 'none', border: '1px solid rgba(246,70,93,.5)', color: '#f6465d' }} onClick={() => setOff(true)}>Turn off 2FA</button>}
    {enabled && off && <div style={{ display: 'grid', gap: 10 }}><input style={box} type="password" placeholder="Account password" value={pw} onChange={e => setPw(e.target.value)} autoComplete="current-password"/><input style={box} placeholder="6-digit code or recovery code" value={code} onChange={e => setCode(e.target.value)}/><button type="button" style={{ ...btn, background: '#f6465d', color: '#fff' }} disabled={busy} onClick={disable}>Confirm turn off</button></div>}
  </div>;
}
