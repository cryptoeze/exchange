import { useEffect, useState } from 'react';
import { ArrowRight, RefreshCw } from 'lucide-react';

type MarketAsset = {
  ticker: string;
  name: string;
  price: number;
  precision: number;
  changePercent: number;
  volumeUsd: number;
  icon: string | null;
};

type MarketSnapshot = { assets: MarketAsset[]; updatedAt: string; stale: boolean };
type ProviderMarket = { symbol: string; baseAsset: string; displayName: string; lastPrice: number; change24h: number; turnover24h: number; icon: string | null };
type ProviderSnapshot = { markets: ProviderMarket[]; meta: { updatedAt: string; stale: boolean; refreshSeconds: number } };
type Props = { onTrade: () => void; onAllMarkets: () => void; initialQuery?: string };

function formatPrice(price: number, precision: number) {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  }).format(price);
}

function formatVolume(volume: number) {
  const unit = volume >= 1e9 ? 1e9 : volume >= 1e6 ? 1e6 : 1;
  const suffix = volume >= 1e9 ? 'B' : volume >= 1e6 ? 'M' : '';
  return `$${(volume / unit).toLocaleString('en-US', { maximumFractionDigits: 1 })}${suffix}`;
}

function MarketRowSkeleton() {
  return <div className="lp-market-row lp-market-skeleton" aria-hidden="true">
    <span/><span/><span/><span className="lp-market-volume"/><span className="lp-market-trend"/><span/>
  </div>;
}

export default function MarketTable({ onTrade, onAllMarkets, initialQuery = '' }: Props) {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let active = true;
    let timer: number | undefined;
    let loading = false;
    const controller = new AbortController();

    const load = async () => {
      if (loading || !active) return;
      loading = true;
      try {
        const response = await fetch('/api/markets?type=spot&limit=6', {
          headers: { Accept: 'application/json' },
          signal: controller.signal,
        });
        const result = await response.json().catch(() => null) as (ProviderSnapshot & { message?: string }) | null;
        if (!response.ok) throw new Error(result?.message || 'Live prices could not load. Please try again.');
        if (!result || !Array.isArray(result.markets) || result.markets.length === 0) throw new Error('Live prices are unavailable right now. Please try again.');
        if (active) {
          setSnapshot({ assets: result.markets.map(market => ({ ticker: market.baseAsset, name: market.displayName, price: market.lastPrice, precision: market.lastPrice >= 1000 ? 2 : 4, changePercent: market.change24h, volumeUsd: market.turnover24h, icon: market.icon })), updatedAt: result.meta.updatedAt, stale: result.meta.stale });
          setError('');
        }
      } catch (reason) {
        if (active && !controller.signal.aborted) {
          const detail = reason instanceof Error ? reason.message : '';
          setError(detail && detail !== 'Failed to fetch' ? detail : 'Check your connection and try again.');
        }
      } finally {
        loading = false;
        if (active && !document.hidden) timer = window.setTimeout(load, 20_000);
      }
    };

    const onVisibilityChange = () => {
      if (document.hidden) {
        if (timer) window.clearTimeout(timer);
        timer = undefined;
      } else if (!timer && !loading) {
        void load();
      }
    };

    void load();
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      active = false;
      controller.abort();
      document.removeEventListener('visibilitychange', onVisibilityChange);
      if (timer) window.clearTimeout(timer);
    };
  }, [attempt]);

  const retry = () => {
    setError('');
    setSnapshot(null);
    setAttempt(value => value + 1);
  };

  const updatedTime = snapshot
    ? new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(snapshot.updatedAt))
    : null;
  const query = initialQuery.trim().toLowerCase();
  const visibleAssets = snapshot?.assets.filter(asset => !query || `${asset.name} ${asset.ticker} ${asset.ticker}/usdt`.toLowerCase().includes(query)) ?? [];

  return <section id="markets" className="lp-container lp-section" aria-labelledby="lp-markets-title">
    <div className="lp-section-head">
      <div>
        <span className="lp-kicker">MARKETS</span>
        <h2 id="lp-markets-title">Trade what’s <span>moving right now</span></h2>
        <p>Live spot market prices with 24-hour change and volume.</p>
      </div>
      <button className="lp-button lp-button-quiet" onClick={onAllMarkets}>All markets <ArrowRight/></button>
    </div>
    <div className="lp-market-card" role="table" aria-label="Live spot markets" aria-busy={!snapshot && !error}>
      <div className="lp-market-heading" role="row">
        <span role="columnheader">Asset</span><span role="columnheader">Price</span>
        <span role="columnheader">24h change</span><span className="lp-market-volume" role="columnheader">24h volume</span>
        <span className="lp-market-trend" role="columnheader">Exchange</span><span role="columnheader"/>
      </div>
      {visibleAssets.map(asset => <div className="lp-market-row" role="row" key={asset.ticker}>
        <span className="lp-market-asset" role="cell">{asset.icon ? <img src={asset.icon} alt="" loading="lazy" onError={event => { event.currentTarget.style.display = 'none'; }}/>: <i aria-hidden="true">{asset.ticker.slice(0,1)}</i>}<span><b>{asset.name}</b><small>{asset.ticker}/USDT</small></span></span>
        <b className="lp-market-price" role="cell">${formatPrice(asset.price, asset.precision)}</b>
        <b className={asset.changePercent >= 0 ? 'lp-positive' : 'lp-negative'} role="cell">{asset.changePercent >= 0 ? '+' : ''}{asset.changePercent.toFixed(2)}%</b>
        <span className="lp-market-volume lp-mono" role="cell">{formatVolume(asset.volumeUsd)}</span>
        <span className="lp-market-trend lp-exchange-name" role="cell">Bybit Spot</span>
        <span className="lp-market-action" role="cell"><button className="lp-market-trade" onClick={onTrade}>Trade</button></span>
      </div>)}
      {snapshot && visibleAssets.length === 0 && <div className="lp-market-state" role="status"><b>No matching spot pairs</b><span>Try searching by the asset name or symbol.</span></div>}
      {!snapshot && !error && <div aria-label="Loading market prices"><MarketRowSkeleton/><MarketRowSkeleton/><MarketRowSkeleton/></div>}
      {!snapshot && error && <div className="lp-market-state" role="alert"><b>Markets are temporarily unavailable</b><span>{error}</span><button onClick={retry}><RefreshCw/> Try again</button></div>}
      {snapshot && error && <div className="lp-market-state lp-market-state-inline" role="status"><span>Could not refresh. Showing the last available market prices.</span><button onClick={retry}><RefreshCw/> Retry</button></div>}
      <p className="lp-market-note" aria-live="polite">{snapshot?.stale ? 'Showing the last available prices · ' : 'Live public market data · '}{updatedTime ? `updated ${updatedTime} · ` : ''}Source: Bybit Spot. Prices may be delayed.</p>
    </div>
  </section>;
}
