import { useEffect, useState } from 'react';
import { ArrowRight, RefreshCw } from 'lucide-react';

type MarketAsset = {
  ticker: string;
  name: string;
  price: number;
  precision: number;
  changePercent: number;
  volumeUsd: number;
  icon: string | null;
};

type MarketSnapshot = { assets: MarketAsset[]; updatedAt: string; stale: boolean };
type ProviderMarket = { symbol: string; baseAsset: string; displayName: string; lastPrice: number; change24h: number; turnover24h: number; icon: string | null };
type ProviderSnapshot = { markets: ProviderMarket[]; meta: { updatedAt: string; stale: boolean; refreshSeconds: number } };
type Props = { onTrade: () => void; onAllMarkets: () => void; initialQuery?: string };

function formatPrice(price: number, precision: number) {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  }).format(price);
}

function formatVolume(volume: number) {
  const unit = volume >= 1e9 ? 1e9 : volume >= 1e6 ? 1e6 : 1;
  const suffix = volume >= 1e9 ? 'B' : volume >= 1e6 ? 'M' : '';
  return `$${(volume / unit).toLocaleString('en-US', { maximumFractionDigits: 1 })}${suffix}`;
}

export default function MarketTable({ onTrade, onAllMarkets, initialQuery = '' }: Props) {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let active = true;
    let timer: number | undefined;
    let loading = false;
    const controller = new AbortController();

    const load = async () => {
      if (loading || !active) return;
      loading = true;
      try {
        const response = await fetch('/api/markets?type=spot&limit=6', {
          headers: { Accept: 'application/json' },
          signal: controller.signal,
        });
        const result = await response.json().catch(() => null) as (ProviderSnapshot & { message?: string }) | null;
        if (!response.ok) throw new Error(result?.message || 'Live prices could not load. Please try again.');
        if (!result || !Array.isArray(result.markets) || result.markets.length === 0) throw new Error('Live prices are unavailable right now. Please try again.');
        if (active) {
          setSnapshot({ assets: result.markets.map(market => ({ ticker: market.baseAsset, name: market.displayName, price: market.lastPrice, precision: market.lastPrice >= 1 ? 2 : 4, changePercent: market.change24h, volumeUsd: market.turnover24h, icon: market.icon })), updatedAt: result.meta.updatedAt, stale: result.meta.stale });
          setError('');
        }
      } catch (reason) {
        if (active && !controller.signal.aborted) {
          const detail = reason instanceof Error ? reason.message : '';
          setError(detail && detail !== 'Failed to fetch' ? detail : 'Check your connection and try again.');
        }
      } finally {
        loading = false;
        if (active && !document.hidden) timer = window.setTimeout(load, 20_000);
      }
    };

    const onVisibilityChange = () => {
      if (document.hidden) {
        if (timer) window.clearTimeout(timer);
        timer = undefined;
      } else if (!timer && !loading) {
        void load();
      }
    };

    void load();
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      active = false;
      controller.abort();
      document.removeEventListener('visibilitychange', onVisibilityChange);
      if (timer) window.clearTimeout(timer);
    };
  }, [attempt]);

  const retry = () => {
    setError('');
    setSnapshot(null);
    setAttempt(value => value + 1);
  };

  const updatedTime = snapshot
    ? new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(snapshot.updatedAt))
    : null;
  const query = initialQuery.trim().toLowerCase();
  const visibleAssets = snapshot?.assets.filter(asset => !query || `${asset.name} ${asset.ticker} ${asset.ticker}/usdt`.toLowerCase().includes(query)) ?? [];

  const spark = (up: boolean) => up ? 'M0,22 L20,18 L40,14 L60,16 L80,8 L100,4' : 'M0,8 L20,12 L40,16 L60,10 L80,18 L100,20';
  return <section id="markets" className="rf-section" aria-labelledby="rf-markets-title">
    <div className="rf-container">
      <div className="rf-section-head">
        <div>
          <h2 id="rf-markets-title" className="rf-reveal">Trade what’s<br/>moving right now</h2>
          <p className="rf-reveal">Live prices streamed from the world's deepest order books. Sign up to start trading any pair instantly.</p>
        </div>
        <button type="button" className="rf-btn-ghost rf-reveal" onClick={onAllMarkets}>All markets <ArrowRight/></button>
      </div>
      <div className="rf-markets-card rf-reveal" aria-busy={!snapshot && !error}>
        <table className="rf-mkt-table" aria-label="Live spot markets">
          <thead><tr><th>Asset</th><th className="right">Price</th><th className="right">24h change</th><th className="right">24h volume</th><th className="right">Trend</th><th/></tr></thead>
          <tbody>
            {visibleAssets.map(asset => {
              const up = asset.changePercent >= 0;
              return <tr key={asset.ticker} onClick={onTrade}>
                <td><div className="rf-mkt-pair"><div className="rf-mkt-logo">{asset.icon ? <img src={asset.icon} alt="" loading="lazy" onError={event => { event.currentTarget.style.display = 'none'; }}/> : asset.ticker.slice(0, 1)}</div><div><div className="rf-mkt-name">{asset.name}</div><div className="rf-mkt-sym">{asset.ticker}/USDT</div></div></div></td>
                <td><div className="rf-mkt-num">${formatPrice(asset.price, asset.precision)}</div></td>
                <td><div className={`rf-mkt-chg ${up ? 'up' : 'dn'}`}>{up ? '+' : ''}{asset.changePercent.toFixed(2)}%</div></td>
                <td><div className="rf-mkt-vol">{formatVolume(asset.volumeUsd)}</div></td>
                <td><svg className="rf-mkt-spark" viewBox="0 0 100 28" preserveAspectRatio="none" aria-hidden="true"><path d={spark(up)} fill="none" stroke={up ? '#2EBD85' : '#F6465D'} strokeWidth="1.6" strokeLinecap="round"/></svg></td>
                <td style={{ textAlign: 'right' }}><button type="button" className="rf-mkt-trade" onClick={event => { event.stopPropagation(); onTrade(); }}>Trade</button></td>
              </tr>;
            })}
            {!snapshot && !error && [0, 1, 2].map(i => <tr className="rf-skel" key={i} aria-hidden="true">{[0, 1, 2, 3, 4, 5].map(j => <td key={j}><div/></td>)}</tr>)}
          </tbody>
        </table>
        {snapshot && visibleAssets.length === 0 && <div className="rf-mkt-state" role="status"><b>No matching spot pairs</b><span>Try searching by the asset name or symbol.</span></div>}
        {!snapshot && error && <div className="rf-mkt-state" role="alert"><b>Markets are temporarily unavailable</b><span>{error}</span><button type="button" onClick={retry}><RefreshCw width={14} height={14}/> Try again</button></div>}
        {snapshot && error && <div className="rf-mkt-state" role="status"><span>Could not refresh. Showing the last available market prices.</span><button type="button" onClick={retry}><RefreshCw width={14} height={14}/> Retry</button></div>}
        <p className="rf-mkt-note" aria-live="polite">{snapshot?.stale ? 'Showing the last available prices · ' : 'Live public market data · '}{updatedTime ? `updated ${updatedTime} · ` : ''}Source: Bybit Spot. Prices may be delayed.</p>
      </div>
    </div>
  </section>;
}
