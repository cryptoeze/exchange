import { BadgeCheck } from 'lucide-react';

/** Blue-lime tick shown next to a user's name once their identity (KYC) is approved. */
export default function VerifiedTick({ kyc }: { kyc?: string | null }) {
  if (kyc !== 'approved') return null;
  return <span className="vtick" title="Identity verified" aria-label="Identity verified"><BadgeCheck/></span>;
}
