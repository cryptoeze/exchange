/** Tether (USDT) mark drawn inline so it never depends on an external image host. */
export default function UsdtIcon({ size = 28 }: { size?: number | string }) {
  return <svg width={size} height={size} viewBox="0 0 32 32" role="img" aria-label="USDT" style={{ flex: '0 0 auto', borderRadius: '50%' }}>
    <circle cx="16" cy="16" r="16" fill="#26a17b"/>
    <path fill="#fff" d="M17.9 17.9v-.001c-.11.008-.678.042-1.94.042-1.01 0-1.72-.03-1.97-.042v.001c-3.88-.17-6.78-.85-6.78-1.66s2.9-1.49 6.78-1.66v2.64c.25.018.98.061 1.98.061 1.2 0 1.81-.05 1.93-.06v-2.64c3.87.17 6.76.85 6.76 1.66s-2.89 1.49-6.76 1.66m0-3.59v-2.36h5.41V8.34H8.7v3.61h5.41v2.36c-4.4.2-7.71 1.07-7.71 2.12s3.31 1.92 7.71 2.12v7.58h3.79v-7.58c4.39-.2 7.69-1.07 7.69-2.12s-3.3-1.92-7.69-2.12"/>
  </svg>;
}

/** USD Coin mark, inline for the same reason as USDT. */
export function UsdcIcon({ size = 28 }: { size?: number | string }) {
  return <svg width={size} height={size} viewBox="0 0 32 32" role="img" aria-label="USDC" style={{ flex: '0 0 auto', borderRadius: '50%' }}>
    <circle cx="16" cy="16" r="16" fill="#2775ca"/>
    <path fill="#fff" d="M20.4 18.5c0-2.3-1.4-3.1-4.1-3.4-1.9-.3-2.3-.8-2.3-1.6s.6-1.4 1.8-1.4c1.1 0 1.7.4 2 1.3.1.2.3.3.5.3h1c.3 0 .5-.2.5-.5v-.1c-.3-1.3-1.3-2.3-2.7-2.4V9.3c0-.3-.2-.5-.5-.6h-.9c-.3 0-.5.2-.6.6v1.4c-1.9.3-3.1 1.5-3.1 3.1 0 2.2 1.3 3 4.1 3.3 1.7.3 2.3.7 2.3 1.6 0 1-.9 1.6-2.1 1.6-1.7 0-2.2-.7-2.4-1.6-.1-.3-.3-.4-.5-.4h-1.1c-.3 0-.5.2-.5.5v.1c.3 1.6 1.3 2.7 3.2 3v1.4c0 .3.2.5.5.6h.9c.3 0 .5-.2.6-.6v-1.4c1.9-.3 3.2-1.6 3.2-3.3z"/>
  </svg>;
}
