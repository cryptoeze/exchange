import {
  ArrowLeftRight, BarChart3, BookOpen, Bot, Box, Calendar, CircleDollarSign,
  CircleHelp, ClipboardList, Copy, Download, FileText, Handshake, Landmark, LifeBuoy,
  LineChart, Percent, RefreshCw, Repeat, ShieldCheck, SlidersHorizontal, Sparkles, Upload, Wallet, Activity, type LucideIcon,
} from 'lucide-react';

export type NavItem = { label: string; href: string; description: string; icon: LucideIcon; soon?: boolean; auth?: boolean };
export type NavGroup = { label: string; items: NavItem[] };
export type PublicLink = { label: string; href: string };

/** Guest header: Markets/Trade/Bots/Earn ask the visitor to sign in; Fees reloads the landing page. */
export const publicLinks: PublicLink[] = [
  { label: 'Markets', href: '/login' },
  { label: 'Trade', href: '/login' },
  { label: 'Bots', href: '/login' },
  { label: 'Earn', href: '/login' },
  { label: 'Fees', href: '/' },
];

/** Authenticated header groups (Markets is a standalone link rendered after Buy Crypto). */
export const navGroups: NavGroup[] = [
  { label: 'Buy Crypto', items: [
    { label: 'P2P Trading', href: '/p2p', description: 'Buy and sell crypto directly with available payment methods.', icon: Handshake, soon: true },
    { label: 'Spot Trading', href: '/spot', description: 'Buy and sell supported assets on the RushX spot market.', icon: Repeat, soon: true },
  ] },
  { label: 'Trade', items: [
    { label: 'Convert', href: '/convert', description: 'Quick asset conversion without a full trading interface.', icon: RefreshCw, soon: true },
    { label: 'Spot', href: '/spot', description: 'Spot market access is planned for a later release.', icon: Repeat, soon: true },
    { label: 'Futures', href: '/futures', description: 'Perpetual and futures trading is not available yet.', icon: Calendar, soon: true },
    { label: 'DEX', href: '#dex', description: 'Decentralized trading is not available yet.', icon: Box, soon: true },
    { label: 'Events & Options', href: '#events', description: 'Events and options are not available yet.', icon: SlidersHorizontal, soon: true },
    { label: 'Trading Bots', href: '/bots', description: 'Automated strategies are not available yet.', icon: Bot, soon: true },
  ] },
  { label: 'Grow', items: [
    { label: 'Spot & Futures', href: '/spot', description: 'Trading products are planned for a later release.', icon: LineChart, soon: true },
    { label: 'Trading Bots', href: '/bots', description: 'Automated strategies are not available yet.', icon: Bot, soon: true },
    { label: 'Earn', href: '/earn', description: 'Earn products will appear here when available.', icon: CircleDollarSign, soon: true },
    { label: 'Copy Trading', href: '#copy', description: 'Copy trading is not available yet.', icon: Copy, soon: true },
  ] },
  { label: 'Institutional', items: [
    { label: 'Institutional services', href: '#institutional', description: 'Institutional access is being prepared for a future release.', icon: Landmark, soon: true },
  ] },
  { label: 'Learn', items: [
    { label: 'Learn Crypto', href: '/learn', description: 'Clear guides to digital assets and markets.', icon: BookOpen },
    { label: 'Getting Started', href: '/getting-started', description: 'Learn how to use RushX.', icon: Sparkles },
    { label: 'Crypto Prices', href: '/markets', description: 'Review public market data available on RushX.', icon: Activity },
    { label: 'FAQ / Help', href: '/faq', description: 'Answers to common questions.', icon: CircleHelp },
    { label: 'Blog', href: '/blog', description: 'Product and platform updates.', icon: FileText },
  ] },
  { label: 'More', items: [
    { label: 'Security', href: '/security', description: 'Account and platform security information.', icon: ShieldCheck },
    { label: 'Proof of Reserves', href: '/proof-of-reserves', description: 'Reserve reporting is not configured yet.', icon: FileText, soon: true },
    { label: 'Fees', href: '/fees', description: 'Platform fees will be published here.', icon: Percent },
    { label: 'System Status', href: '/status', description: 'Service status information.', icon: Activity },
    { label: 'Support', href: '/support', description: 'Get help with your RushX account.', icon: LifeBuoy },
  ] },
];

export const assetItems: NavItem[] = [
  { label: 'My Assets', href: '/assets', description: 'Your account asset overview.', icon: Wallet, auth: true },
  { label: 'Deposit', href: '/deposit', description: 'Deposit flow is not configured yet.', icon: Download, auth: true, soon: true },
  { label: 'Withdraw', href: '/withdraw', description: 'Withdrawal flow is not configured yet.', icon: Upload, auth: true, soon: true },
  { label: 'Transfer', href: '/transfer', description: 'Internal transfers are not configured yet.', icon: ArrowLeftRight, auth: true, soon: true },
  { label: 'Analysis', href: '/analysis', description: 'Portfolio analysis will be available here.', icon: BarChart3, auth: true, soon: true },
  { label: 'Order Center', href: '/orders', description: 'Orders are not connected yet.', icon: ClipboardList, auth: true, soon: true },
  { label: 'My Trading Fees', href: '/fees', description: 'Fee information and rates.', icon: Percent, auth: true },
  { label: 'PoR Reports', href: '/proof-of-reserves', description: 'Reserve reporting is not configured yet.', icon: FileText, auth: true, soon: true },
];
