import { useEffect, useMemo, useState } from 'react';
import { Link } from '@inertiajs/react';
import { ArrowDownToLine, ArrowLeftRight, ArrowUpFromLine, ChevronRight, Eye, EyeOff, MessageCircle, Repeat, Sparkles, TrendingUp, Wallet, X } from 'lucide-react';
import CoinImage from './CoinImage';
import MobileNav from './MobileNav';
import type { Market } from '../types/market';
import { change24hUsd, usd, usdValue, type Balance, type HistoryItem } from '../lib/wallet';
import '../../css/mobile-assets.css';

type Box = 'funding' | 'trading' | 'copy';
const boxOf = (a: string): Box => a === 'funding' ? 'funding' : a === 'trading' || a === 'futures' ? 'trading' : 'copy';
const COLORS = ['#c1f033', '#2ebd85', '#3b82f6', '#f59e0b', '#a855f7', '#8e8e93'];
const HIDE_KEY = 'rushx-hidden-coins';

function Spark({ change }: { change: number }) {
  const up = change >= 0; const k = Math.min(1, Math.abs(change) / 8 + .25);
  const pts = [0, 0.35, 0.2, 0.55, 0.45, 0.8, 1].map((v, i) => `${i ? 'L' : 'M'}${i * 10},${up ? 22 - v * 18 * k : 4 + v * 18 * k}`).join(' ');
  return <svg className={`ma-spark ${up ? 'up' : 'down'}`} viewBox="0 0 60 26" aria-hidden="true"><path d={pts} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}

export default function MobileAssets({ rows, prices, history, loaded, error, userName, onToggleTheme }: {
  rows: Array<Balance & { amount: number }>; prices: Map<string, Market>; history: HistoryItem[]; loaded: boolean; error: string; userName: string; onToggleTheme: () => void;
}) {
  const [hide, setHide] = useState(false);
  const [tab, setTab] = useState<'portfolio' | 'trading' | 'earn'>('portfolio');
  const [manage, setManage] = useState(false);
  const [all, setAll] = useState(false);
  const [hidden, setHidden] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem(HIDE_KEY) ?? '[]') as string[]; } catch { return []; } });
  useEffect(() => { try { localStorage.setItem(HIDE_KEY, JSON.stringify(hidden)); } catch { /* optional */ } }, [hidden]);
  const m = (t: string) => hide ? '••••' : t;

  const data = useMemo(() => {
    const by: Record<Box, number> = { funding: 0, trading: 0, copy: 0 }; let pnl = 0;
    const coins = new Map<string, number>();
    for (const r of rows) { const v = usdValue(r.asset, r.amount, prices); by[boxOf(r.account)] += v; pnl += change24hUsd(r.asset, r.amount, prices); coins.set(r.asset, (coins.get(r.asset) ?? 0) + v); }
    const total = by.funding + by.trading + by.copy;
    const list = [...coins.entries()].map(([asset, value]) => {
      const amount = rows.filter(r => r.asset === asset).reduce((s, r) => s + r.amount, 0);
      const mk = prices.get(`${asset}USDT`);
      return { asset, value, amount, change: asset === 'USDT' || asset === 'USDC' ? 0 : mk?.change24h ?? 0 };
    }).sort((a, b) => b.value - a.value);
    return { by, total, pnl, list };
  }, [rows, prices]);
  const pct = data.total - data.pnl > 0 ? data.pnl / (data.total - data.pnl) * 100 : 0;
  const shown = data.list.filter(c => !hidden.includes(c.asset));
  const top = data.list.slice(0, 5);
  const parts = top.map((c, i) => ({ ...c, p: data.total > 0 ? c.value / data.total * 100 : 0, color: COLORS[i] }));
  const others = data.total > 0 ? Math.max(0, 100 - parts.reduce((s, c) => s + c.p, 0)) : 0;
  const R = 34; const C = 2 * Math.PI * R; let off = 0;
  const segs = [...parts.map(p => ({ p: p.p, color: p.color })), ...(others > .5 ? [{ p: others, color: COLORS[5] }] : [])];
  const tradingRows = rows.filter(r => boxOf(r.account) === 'trading');
  const earnRows = rows.filter(r => boxOf(r.account) === 'copy');
  const pos = data.pnl >= 0;

  const Row = ({ c }: { c: typeof data.list[number] }) => <Link href="/spot" className="ma-row">
    <span className="ma-coin"><CoinImage symbol={c.asset} icon={prices.get(`${c.asset}USDT`)?.icon}/></span>
    <span className="ma-name"><b>{c.asset}</b><small>{c.asset === 'USDT' ? 'USDT Network' : `${c.asset} Network`}</small></span>
    <Spark change={c.change}/>
    <span className="ma-val"><b>{m(c.amount.toLocaleString('en-US', { maximumFractionDigits: 6 }))}</b><small>{m(`$${usd(c.value)}`)}</small></span>
  </Link>;

  const Hist = ({ items }: { items: HistoryItem[] }) => items.length === 0 ? <p className="ma-empty">No activity yet.</p> : <>{items.map(h => <div className="ma-tx" key={h.id}>
    <span className={`ma-txi ${h.positive ? 'up' : 'down'}`}>{h.positive ? <ArrowDownToLine size={16}/> : <ArrowUpFromLine size={16}/>}</span>
    <span className="ma-name"><b>{h.title}</b><small>{h.at ? new Date(h.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}</small></span>
    <span className={`ma-txv ${h.positive ? 'up' : 'down'}`}>{m(`${h.amount} ${h.asset}`)}</span>
  </div>)}</>;

  return <div className="ma-shell">
    <header className="ma-head">
      <span className="ma-hl"><button type="button" className="ma-avatar" onClick={onToggleTheme} aria-label="Toggle theme">{(userName || 'R').slice(0, 1).toUpperCase()}</button></span>
      <Link href="/dashboard" className="ma-logo" aria-label="RushX"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M6 6l20 20M26 6L6 26" stroke="#c1f033" strokeWidth="5" strokeLinecap="round"/></svg><b>Rush<i>X</i></b></Link>
      <span className="ma-hr"><button type="button" aria-label="Live chat" onClick={() => (window as unknown as { rushxChat?: () => void }).rushxChat?.()}><MessageCircle size={21}/></button></span>
    </header>

    <section className="ma-hero">
      <div className="ma-est">Est. total value <button type="button" onClick={() => setHide(v => !v)} aria-label="Toggle balance">{hide ? <EyeOff size={16}/> : <Eye size={16}/>}</button></div>
      <div className="ma-flex">
        <div>
          <div className="ma-bal">{loaded ? m(usd(data.total)) : '—'} <small>USD</small></div>
          <div className={`ma-pnl ${pos ? 'up' : 'down'}`}>{m(`${pos ? '+' : '-'}${usd(Math.abs(data.pnl))} (${pos ? '+' : '-'}${Math.abs(pct).toFixed(2)}%)`)} <em>24h</em></div>
        </div>
        <div className="ma-donut" aria-label="Allocation">
          <svg viewBox="0 0 100 100"><circle cx="50" cy="50" r={R} fill="none" stroke="var(--ov-line)" strokeWidth="9"/>
            {data.total > 0 && segs.map((s, i) => { const len = s.p / 100 * C; const el = <circle key={i} cx="50" cy="50" r={R} fill="none" stroke={s.color} strokeWidth="9" strokeDasharray={`${Math.max(0, len - 1)} ${C}`} strokeDashoffset={-off} transform="rotate(-90 50 50)"/>; off += len; return el; })}
          </svg>
          <span><b>{data.total > 0 && parts[0] ? `${Math.round(parts[0].p)}%` : '0%'}</b><small>{parts[0]?.asset ?? '—'}</small></span>
        </div>
      </div>
      <div className="ma-actions">
        <Link href="/deposit"><span><ArrowDownToLine size={20}/></span>Deposit</Link>
        <Link href="/withdraw"><span><ArrowUpFromLine size={20}/></span>Withdraw</Link>
        <Link href="/transfer"><span><ArrowLeftRight size={20}/></span>Transfer</Link>
        <Link href="/convert"><span><Repeat size={20}/></span>Convert</Link>
      </div>
    </section>

    {error && <p className="ma-err">{error}</p>}

    <section className="ma-cards">
      {([['Funding', data.by.funding, '/funding', Wallet], ['Trading', data.by.trading, '/spot', TrendingUp], ['Earn & Bots', data.by.copy, '/earn', Sparkles]] as const).map(([n, v, href, Ico]) =>
        <Link key={n} href={href} className="ma-card"><Ico size={18}/><small>{n}</small><b>{m(`$${usd(v)}`)}</b><ChevronRight size={14}/></Link>)}
    </section>

    <nav className="ma-tabs" role="tablist">{(['portfolio', 'trading', 'earn'] as const).map(t => <button key={t} type="button" role="tab" aria-selected={tab === t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>)}</nav>

    {tab === 'portfolio' && <>
      <section className="ma-sec">
        <div className="ma-sech"><h3>Asset</h3><button type="button" onClick={() => setManage(true)}>Manage Coins</button></div>
        {!loaded ? <p className="ma-empty">Loading…</p> : shown.length === 0 ? <div className="ma-blank"><p>{data.list.length ? 'All coins are hidden.' : 'No assets yet.'}</p><Link href="/deposit">Deposit now</Link></div> : shown.map(c => <Row key={c.asset} c={c}/>)}
      </section>
      {data.total > 0 && <section className="ma-sec">
        <div className="ma-sech"><h3>Portfolio Allocation</h3></div>
        {parts.map(p => <div className="ma-alloc" key={p.asset}><span><i style={{ background: p.color }}/>{p.asset}</span><div><u style={{ width: `${Math.max(2, p.p)}%`, background: p.color }}/></div><b>{hide ? '••' : `${p.p.toFixed(1)}%`}</b></div>)}
      </section>}
      <section className="ma-sec">
        <div className="ma-sech"><h3>Recent Transactions</h3>{history.length > 3 && <button type="button" onClick={() => setAll(true)}>View all</button>}</div>
        <Hist items={history.slice(0, 3)}/>
      </section>
    </>}

    {tab === 'trading' && <section className="ma-sec">
      <div className="ma-sech"><h3>Trading account</h3><b className="ma-sum">{m(`$${usd(data.by.trading)}`)}</b></div>
      {tradingRows.length === 0 ? <div className="ma-blank"><p>No trading balance yet.</p><Link href="/transfer">Transfer funds</Link></div> : tradingRows.map(r => <Row key={r.account + r.asset} c={{ asset: r.asset, amount: r.amount, value: usdValue(r.asset, r.amount, prices), change: 0 }}/>)}
      <Link href="/futures" className="ma-cta">Trade Futures</Link>
    </section>}

    {tab === 'earn' && <section className="ma-sec">
      <div className="ma-sech"><h3>Earn, Bots &amp; Copy</h3><b className="ma-sum">{m(`$${usd(data.by.copy)}`)}</b></div>
      {earnRows.length === 0 ? <div className="ma-blank"><Sparkles size={30}/><p>Start earning yield on your idle assets.</p><Link href="/earn">Explore Earn</Link></div> : earnRows.map(r => <Row key={r.account + r.asset} c={{ asset: r.asset, amount: r.amount, value: usdValue(r.asset, r.amount, prices), change: 0 }}/>)}
    </section>}

    {manage && <div className="ma-sheetbg" onClick={() => setManage(false)}><div className="ma-sheet" onClick={e => e.stopPropagation()}>
      <header><b>Manage Coins</b><button type="button" aria-label="Close" onClick={() => setManage(false)}><X size={20}/></button></header>
      {data.list.length === 0 ? <p className="ma-empty">No coins to manage.</p> : data.list.map(c => <label className="ma-man" key={c.asset}><span className="ma-coin"><CoinImage symbol={c.asset} icon={prices.get(`${c.asset}USDT`)?.icon}/></span><b>{c.asset}</b>
        <input type="checkbox" checked={!hidden.includes(c.asset)} onChange={() => setHidden(h => h.includes(c.asset) ? h.filter(x => x !== c.asset) : [...h, c.asset])}/><i/></label>)}
    </div></div>}
    {all && <div className="ma-sheetbg" onClick={() => setAll(false)}><div className="ma-sheet tall" onClick={e => e.stopPropagation()}>
      <header><b>Transaction history</b><button type="button" aria-label="Close" onClick={() => setAll(false)}><X size={20}/></button></header>
      <Hist items={history}/>
      <Link href="/orders" className="ma-cta">Open full orders</Link>
    </div></div>}
    <MobileNav active="assets"/>
  </div>;
}
