import { ArrowDownToLine, ArrowLeftRight, ArrowUpFromLine, Repeat, Users } from 'lucide-react';

const ITEMS = [
  { label: 'Deposit', href: '/deposit', Icon: ArrowDownToLine }, { label: 'Withdraw', href: '/withdraw', Icon: ArrowUpFromLine },
  { label: 'Transfer', href: '/transfer', Icon: ArrowLeftRight }, { label: 'Convert', href: '/convert', Icon: Repeat }, { label: 'P2P', href: '/p2p', Icon: Users },
];

/** Round grey action buttons, same on Home and Assets. */
export default function QuickActions() {
  return <nav className="qa" aria-label="Quick actions">{ITEMS.map(({ label, href, Icon }) => <a key={label} href={href}><span><Icon/></span>{label}</a>)}</nav>;
}
