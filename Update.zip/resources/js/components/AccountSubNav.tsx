import { Link } from '@inertiajs/react';

const ITEMS: Array<[string, string]> = [['Overview', '/assets'], ['Funding', '/funding'], ['Trading', '/trading'], ['Grow', '/earn'], ['Bots', '/bots'], ['Analysis', '/analysis'], ['Order center', '/orders'], ['Fees', '/fees']];

/** Secondary navigation shown on the account pages (Overview, Funding/Deposit, ...). */
export default function AccountSubNav({ active }: { active: string }) {
  return <nav className="ov-subnav" aria-label="Account sections"><div>{ITEMS.map(([label, href]) => <Link key={label} href={href} className={label === active ? 'active' : ''} aria-current={label === active ? 'page' : undefined}>{label}</Link>)}</div></nav>;
}
