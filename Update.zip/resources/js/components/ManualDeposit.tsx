import { useCallback, useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Check, Copy, Loader2 } from 'lucide-react';
import UsdtIcon from './UsdtIcon';
import { api } from '../lib/wallet';

type Addr = { id: number; asset: string; network: string; label: string; address: string; min: string; note: string | null };
type Row = { id: number; asset: string; network: string; claimed: string; credited: string | null; txid: string; status: string; reason: string | null; at: string | null };
const STATUS: Record<string, string> = { pending: 'Under review', approved: 'Credited', rejected: 'Rejected' };

/** Manual USDT deposit: show our address + QR, the user pays, submits the TXID, an admin verifies and credits. */
export default function ManualDeposit({ onChange }: { onChange?: () => void }) {
  const [addrs, setAddrs] = useState<Addr[] | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [sel, setSel] = useState<Addr | null>(null);
  const [qr, setQr] = useState('');
  const [copied, setCopied] = useState('');
  const [amount, setAmount] = useState('');
  const [txid, setTxid] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');

  const load = useCallback(async () => {
    const r = await api<{ addresses: Addr[]; rows: Row[] }>('/api/manual-deposits');
    if (r.ok) { setAddrs(r.data.addresses); setRows(r.data.rows); setSel(cur => cur ? r.data.addresses.find(a => a.id === cur.id) ?? r.data.addresses[0] ?? null : r.data.addresses[0] ?? null); }
  }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 5000); return () => window.clearInterval(t); }, [load]);
  useEffect(() => { if (sel) QRCode.toDataURL(sel.address, { width: 272, margin: 1, errorCorrectionLevel: 'H' }).then(setQr).catch(() => setQr('')); else setQr(''); }, [sel?.address]);

  const copy = async (text: string, key: string) => { try { await navigator.clipboard.writeText(text); setCopied(key); window.setTimeout(() => setCopied(''), 2000); } catch { /* clipboard blocked */ } };
  const min = sel ? Number(sel.min.replace(/,/g, '')) : 0;
  const amountOk = /^\d+(\.\d{1,8})?$/.test(amount) && Number(amount) >= min;
  const txOk = /^(0x)?[A-Za-z0-9]{16,128}$/.test(txid.trim());

  const submit = async () => {
    if (!sel || busy) return;
    setBusy(true); setError(''); setDone('');
    const r = await api<{ rows: Row[] }>('/api/manual-deposits', { address_id: sel.id, amount, txid: txid.trim() });
    setBusy(false);
    if (r.ok) { setRows(r.data.rows); setAmount(''); setTxid(''); setDone('Submitted. Your deposit will be credited as soon as it is verified.'); onChange?.(); } else setError(r.data.message ?? 'Could not submit the deposit.');
  };

  if (addrs === null) return <p className="dp-note"><Loader2 className="dp-spin"/> Loading…</p>;
  if (addrs.length === 0) return <div className="dp-note" role="status">Manual deposit is being set up and will be available shortly.</div>;
  const assetFamily = addrs.filter(a => a.asset === 'USDT');

  return <div>
    <div className="tw-coin"><UsdtIcon size={30}/><div><b>USDT</b><small>Tether</small></div></div>
    <div className="tw-lbl">Network</div>
    <div className="tw-nets" role="radiogroup" aria-label="Network">
      {assetFamily.map(a => <button key={a.id} type="button" role="radio" aria-checked={sel?.id === a.id} className={`tw-net${sel?.id === a.id ? ' on' : ''}`} onClick={() => { setSel(a); setError(''); setDone(''); }}><b>{a.network}</b><small>{a.label}</small></button>)}
    </div>
    {sel && <>
      <div className="tw-mq">
        <div className="dp-qr">{qr ? <img src={qr} alt={`${sel.network} deposit address QR code`}/> : <Loader2 className="dp-spin"/>}<span className="dp-qrlogo"><UsdtIcon size={34}/></span></div>
        <div className="tw-data">
          <div className="dp-lbl">Deposit address ({sel.network})</div>
          <div className="dp-addr"><code>{sel.address}</code><button type="button" aria-label="Copy address" onClick={() => copy(sel.address, 'addr')}>{copied === 'addr' ? <Check/> : <Copy/>}</button></div>
          <div className="dp-rows" style={{ marginTop: 16 }}><div><span>Minimum deposit</span><b>{sel.min} USDT</b></div></div>
        </div>
      </div>
      <p className="tw-warn">Send only <b>USDT</b> on the <b>{sel.label}</b> network to this address. Anything else may be lost. {sel.note}</p>
      <div className="tw-lbl" style={{ fontSize: 15, marginTop: 8 }}>After you have paid</div>
      <div className="tw-field"><label htmlFor="md-amt">Amount you sent</label><div className="tw-in"><input id="md-amt" inputMode="decimal" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ''))}/><span>USDT</span></div></div>
      <div className="tw-field"><label htmlFor="md-tx">Transaction hash (TXID)</label><div className="tw-in"><input id="md-tx" placeholder="Paste the TXID from your wallet" value={txid} onChange={e => setTxid(e.target.value)} autoComplete="off" spellCheck={false}/></div></div>
      {error && <div className="tw-err" role="alert">{error}</div>}
      {done && <div className="tw-ok" role="status">{done}</div>}
      <button type="button" className="tw-cta" disabled={!amountOk || !txOk || busy} onClick={submit}>{busy ? <Loader2 className="dp-spin"/> : !amountOk ? (amount ? `Minimum ${sel.min} USDT` : 'Enter the amount') : !txOk ? 'Enter the TXID' : 'Submit deposit'}</button>
    </>}
    <div className="tw-lbl" style={{ fontSize: 15, marginTop: 30 }}>Your manual deposits</div>
    {rows.length === 0 ? <p className="dp-none">No manual deposits yet.</p> : <div className="dp-scroll"><table><thead><tr><th>Time</th><th>Network</th><th>TXID</th><th>Amount</th><th>Status</th></tr></thead><tbody>
      {rows.map(d => <tr key={d.id}><td>{d.at ? new Date(d.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}</td><td>{d.network}</td><td><code>{d.txid.length > 18 ? `${d.txid.slice(0, 8)}…${d.txid.slice(-6)}` : d.txid}</code></td><td>{d.credited ?? d.claimed} USDT</td><td><span className={`tw-pill ${d.status}`} title={d.reason ?? ''}>{STATUS[d.status] ?? d.status}</span></td></tr>)}
    </tbody></table></div>}
  </div>;
}
