import { Fragment, useEffect, useRef, useState } from 'react';
import { router } from '@inertiajs/react';
import { Bell, Check, Copy, Eye, EyeOff, ChevronDown, Download, Globe, LogOut, Menu, MessageCircle, Moon, Sun, UserRound, Wallet, X } from 'lucide-react';
import Brand from './RushXBrand';
import HeaderSearch from './HeaderSearch';
import { api, usdValue, type WalletPayload } from '../lib/wallet';
import type { Market, MarketSnapshot } from '../types/market';
import { assetItems, navGroups, publicLinks, type NavItem } from './navigationConfig';

export type HeaderUser = { id: number; name: string; email: string; emailVerified: boolean };
type Props = { user?: HeaderUser | null; dark: boolean; onToggleTheme: () => void };

function initials(name: string) {
  const letters = name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]?.toLocaleUpperCase());
  return letters.join('') || <UserRound aria-hidden="true"/>;
}

/** Public-facing account number: 8 digits derived from the internal id (stable, not sequential-looking). */
export const uidOf = (id: number) => String(10000000 + ((id * 7919) % 89999999)).padStart(8, '0');

/** Live estimated total (Funding + Trading at server prices) shown in the profile menu. Polls only while the menu is open. */
function ProfileValue() {
  const [total, setTotal] = useState<number | null>(null);
  const [hidden, setHidden] = useState(() => { try { return localStorage.getItem('rushx-hide-total') === '1'; } catch { return false; } });
  useEffect(() => {
    let active = true; let timer = 0;
    const load = async () => {
      try {
        const [f, m] = await Promise.all([api<WalletPayload>('/api/wallet'), fetch('/api/markets?type=spot', { headers: { Accept: 'application/json' } }).then(r => r.json() as Promise<MarketSnapshot>)]);
        const prices = new Map<string, Market>((m.markets ?? []).map(x => [x.symbol, x]));
        const sum = (p?: WalletPayload) => (p?.balances ?? []).reduce((a, b) => a + usdValue(b.asset, b.units / 1e8, prices), 0);
        if (active && f.ok) setTotal(sum(f.data)); // the payload already lists every account (funding, trading, earn, bots, futures ...)
      } catch { /* keep last value */ }
      if (active) timer = window.setTimeout(load, 3000);
    };
    void load(); return () => { active = false; window.clearTimeout(timer); };
  }, []);
  const toggle = () => setHidden(h => { const n = !h; try { localStorage.setItem('rushx-hide-total', n ? '1' : '0'); } catch { /* optional */ } return n; });
  return <div className="rxh-pv"><div><span>Est. Total Value</span><button type="button" aria-label={hidden ? 'Show balance' : 'Hide balance'} onClick={toggle}>{hidden ? <EyeOff/> : <Eye/>}</button></div><b>{hidden ? '••••••' : total === null ? '…' : `$${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</b></div>;
}

function UidCopy({ id }: { id: number }) {
  const [ok, setOk] = useState(false);
  return <button type="button" className="rxh-uid" title="Copy UID" onClick={async () => { try { await navigator.clipboard.writeText(uidOf(id)); setOk(true); window.setTimeout(() => setOk(false), 1500); } catch { /* blocked */ } }}>UID: {uidOf(id)} {ok ? <Check/> : <Copy/>}</button>;
}

function MenuItem({ item, close, onPick }: { item: NavItem; close: () => void; onPick?: (item: NavItem) => void }) {
  const Icon = item.icon;
  const main = <a className="rxh-menu-item" role="menuitem" href={item.href} onClick={event => {
    if (item.soon && onPick) { event.preventDefault(); onPick(item); }
    close();
  }}>
    <span className="rxh-menu-icon"><Icon aria-hidden="true"/></span><span className="rxh-menu-copy"><b>{item.label}{item.soon && <small className="rxh-soon">Soon</small>}</b><small>{item.description}</small></span>
  </a>;
  if (!item.children) return main;
  return <div className="rxh-menu-group">{main}<div className="rxh-sub">{item.children.map(c => <a key={c} role="menuitem" href={item.href} onClick={close}><i aria-hidden="true"/>{c}</a>)}</div></div>;
}

/*
 * Header state comes from the server-shared Inertia `auth.user` prop, which is present in the
 * very first HTML response and refreshed on every visit (login, logout, expired session).
 * Guests therefore never receive or render any account-specific control.
 */
export default function RushXHeader({ user = null, dark, onToggleTheme }: Props) {
  const [open, setOpen] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [notice, setNotice] = useState('');
  const root = useRef<HTMLDivElement>(null);
  const groups = user ? [...navGroups] : [];
  const isGroupOpen = (label: string) => open === label;
  const toggle = (label: string) => setOpen(value => value === label ? null : label);
  // Desktop mouse: menus open on hover (short grace period so moving the cursor into the menu does not close it). Touch keeps tap-to-open.
  const click = (label: string) => (window.matchMedia('(hover: hover)').matches ? setOpen(label) : toggle(label));
  const leaveTimer = useRef(0);
  const hover = (label: string) => ({
    onPointerEnter: (e: React.PointerEvent) => { if (e.pointerType !== 'mouse') return; window.clearTimeout(leaveTimer.current); setOpen(label); },
    onPointerLeave: (e: React.PointerEvent) => { if (e.pointerType !== 'mouse') return; window.clearTimeout(leaveTimer.current); leaveTimer.current = window.setTimeout(() => setOpen(v => v === label ? null : v), 180); },
  });
  const closeAll = () => { setOpen(null); setDrawer(false); };
  const choose = (item: NavItem) => setNotice(`${item.label} is coming soon.`);

  useEffect(() => {
    const dismiss = (event: PointerEvent) => { if (root.current && !root.current.contains(event.target as Node)) { setOpen(null); setDrawer(false); } };
    const keys = (event: KeyboardEvent) => { if (event.key === 'Escape') { setOpen(null); setDrawer(false); } };
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', keys);
    return () => { document.removeEventListener('pointerdown', dismiss); document.removeEventListener('keydown', keys); };
  }, []);

  useEffect(() => {
    document.body.classList.toggle('rxh-lock-scroll', drawer);
    return () => document.body.classList.remove('rxh-lock-scroll');
  }, [drawer]);

  // Authentication state changed (login/logout/expiry): drop any open menu, drawer or private notice.
  useEffect(() => { closeAll(); setNotice(''); }, [user?.id]);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const showSoon = (label: string) => setNotice(`${label} is coming soon.`);
  const logout = () => router.post('/logout');

  return <div className={`rxh-root ${user ? 'rxh-auth' : 'rxh-guest'}`} ref={root}>
    <header className="rxh-header">
      <div className="rxh-inner">
        <Brand/>
        {user
          ? <nav className="rxh-desktop-nav" aria-label="Main navigation">
            {groups.map(group => <Fragment key={group.label}><div className="rxh-nav-group" {...hover(group.label)}>
              <button type="button" className="rxh-nav-trigger" aria-expanded={isGroupOpen(group.label)} aria-haspopup="menu" onClick={() => click(group.label)}>{group.label}<ChevronDown aria-hidden="true"/></button>
              {isGroupOpen(group.label) && <div className="rxh-mega-menu" role="menu">{group.items.map(item => <MenuItem key={item.label} item={item} close={() => setOpen(null)} onPick={choose}/>)}</div>}
            </div>{group.label === 'Buy Crypto' && <a className="rxh-standalone-link" href="/markets">Markets</a>}</Fragment>)}
          </nav>
          : <nav className="rxh-desktop-nav rxh-public-nav" aria-label="Main navigation">
            {publicLinks.map(link => <a key={link.label} className="rxh-standalone-link" href={link.href}>{link.label}</a>)}
          </nav>}
        <div className="rxh-actions">
          {user ? <>
            <HeaderSearch/>
            <a className="rxh-deposit" href="/deposit">Deposit</a>
            <div className="rxh-nav-group rxh-assets-group" {...hover('Assets')}>
              <button type="button" className="rxh-action-link" aria-expanded={isGroupOpen('Assets')} aria-haspopup="menu" onClick={() => click('Assets')}>Assets<ChevronDown aria-hidden="true"/></button>
              {isGroupOpen('Assets') && <div className="rxh-mega-menu rxh-assets-menu" role="menu">{assetItems.filter(item => item.auth).map(item => <MenuItem key={item.label} item={item} close={() => setOpen(null)} onPick={choose}/>)}</div>}
            </div>
            <div className="rxh-nav-group rxh-profile-group" {...hover('Profile')}>
              <button type="button" className="rxh-profile-trigger" aria-label="Account profile" aria-haspopup="menu" aria-expanded={isGroupOpen('Profile')} onClick={() => click('Profile')}><span className="rxh-avatar">{initials(user.name)}</span></button>
              {isGroupOpen('Profile') && <div className="rxh-profile-menu" role="menu">
                <div className="rxh-profile-summary"><span className="rxh-avatar rxh-avatar-lg">{initials(user.name)}</span><span><span className="rxh-pname"><b>{user.name || 'RushX user'}</b><em className={user.emailVerified ? 'ok' : ''}>{user.emailVerified ? 'Verified' : 'Unverified'}</em></span><UidCopy id={user.id}/></span></div>
                <ProfileValue/>
                <a href="/assets" role="menuitem" onClick={() => setOpen(null)}><Wallet/> My Assets</a><a href="/security" role="menuitem" onClick={() => setOpen(null)}><UserRound/> Security &amp; Settings</a>
                <button className="rxh-profile-theme" role="menuitem" type="button" onClick={onToggleTheme}>{dark ? <Sun/> : <Moon/>}{dark ? 'Light mode' : 'Dark mode'}</button>
                <button className="rxh-logout" role="menuitem" type="button" onClick={logout}><LogOut/> Logout</button>
              </div>}
            </div>
            <span className="rxh-utility-divider" aria-hidden="true"/>
            <div className="rxh-utility-actions" role="group" aria-label="Account tools">
              <button className="rxh-icon rxh-theme-btn" type="button" aria-label={`Switch to ${dark ? 'light' : 'dark'} mode`} title={dark ? 'Light mode' : 'Dark mode'} onClick={onToggleTheme}>{dark ? <Sun/> : <Moon/>}</button>
              <button className="rxh-icon" type="button" aria-label="Download app" title="Download app" onClick={() => showSoon('Download app')}><Download/></button>
              <a className="rxh-icon" href="/support" aria-label="Messages and support" title="Messages and support"><MessageCircle/></a>
              <button className="rxh-icon" type="button" aria-label="Notifications" title="Notifications" onClick={() => showSoon('Notifications')}><Bell/></button>
            </div>
          </> : <>
            <button className="rxh-icon rxh-globe" type="button" aria-label="Language: English" title="Language" onClick={() => showSoon('More languages')}><Globe/></button>
            <button className="rxh-icon rxh-theme" type="button" onClick={onToggleTheme} aria-label={`Switch to ${dark ? 'light' : 'dark'} mode`}>{dark ? <Sun/> : <Moon/>}</button>
            <a className="rxh-signin" href="/login">Sign in</a>
            <a className="rxh-signup" href="/login?mode=signup">Sign up</a>
          </>}
          <button className="rxh-icon rxh-mobile-chat" type="button" aria-label="Live chat" onClick={() => (window as unknown as { rushxChat?: () => void }).rushxChat?.()}><MessageCircle/></button>
          <button className="rxh-icon rxh-mobile-toggle" type="button" onClick={() => setDrawer(value => !value)} aria-expanded={drawer} aria-label={drawer ? 'Close menu' : 'Open menu'}>{drawer ? <X/> : <Menu/>}</button>
        </div>
      </div>
    </header>
    {drawer && <div className="rxh-mobile-layer"><button className="rxh-mobile-scrim" aria-label="Close navigation" onClick={() => setDrawer(false)}/><nav className="rxh-mobile-drawer" aria-label="Mobile navigation">
      <div className="rxh-mobile-head"><Brand/><button className="rxh-icon" onClick={() => setDrawer(false)} aria-label="Close navigation"><X/></button></div>
      {user && <HeaderSearch mobile onNavigate={() => setDrawer(false)}/>}
      {!user && <section className="rxh-mobile-group">{publicLinks.map(link => <a key={link.label} className="rxh-mobile-standalone" href={link.href} onClick={() => setDrawer(false)}>{link.label}</a>)}</section>}
      {groups.map(group => <Fragment key={group.label}><section className="rxh-mobile-group"><button type="button" aria-expanded={isGroupOpen(group.label)} onClick={() => toggle(group.label)}>{group.label}<ChevronDown/></button>{isGroupOpen(group.label) && group.items.map(item => <MenuItem key={item.label} item={item} close={() => setDrawer(false)} onPick={choose}/>)}</section>{group.label === 'Buy Crypto' && <a className="rxh-mobile-standalone" href="/markets" onClick={() => setDrawer(false)}>Markets</a>}</Fragment>)}
      {user && <section className="rxh-mobile-group"><button type="button" aria-expanded={isGroupOpen('Assets')} onClick={() => toggle('Assets')}>Assets<ChevronDown/></button>{isGroupOpen('Assets') && assetItems.filter(item => item.auth).map(item => <MenuItem key={item.label} item={item} close={() => setDrawer(false)} onPick={choose}/>)}</section>}
      {user && <section className="rxh-mobile-profile"><div><span className="rxh-avatar">{initials(user.name)}</span><span><b>{user.name}</b><small>{user.email}</small></span></div><p>{user.emailVerified ? 'Verified' : 'Unverified'} · UID {uidOf(user.id)}</p><a href="/assets" onClick={() => setDrawer(false)}>My Assets</a><a href="/security" onClick={() => setDrawer(false)}>Security &amp; Settings</a></section>}
      <div className="rxh-mobile-bottom"><button type="button" onClick={onToggleTheme}>{dark ? <Sun/> : <Moon/>}{dark ? 'Light mode' : 'Dark mode'}</button>{user ? <><button type="button" onClick={() => showSoon('Download app')}><Download/>Download app</button><a href="/support"><MessageCircle/>Support</a><button type="button" onClick={() => showSoon('Notifications')}><Bell/>Notifications</button><button type="button" onClick={logout}><LogOut/> Logout</button></> : <><a href="/login">Sign in</a><a href="/login?mode=signup">Sign up</a><a href="/support">Help</a></>}</div>
    </nav></div>}
    {notice && <div className="rxh-toast" role="status"><Check/>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss">×</button></div>}
  </div>;
}
