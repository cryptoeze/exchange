import { Fragment, useEffect, useRef, useState } from 'react';
import { router } from '@inertiajs/react';
import { Bell, Check, ChevronDown, Download, Globe, LogOut, Menu, MessageCircle, Moon, Sun, UserRound, Wallet, X } from 'lucide-react';
import Brand from './RushXBrand';
import HeaderSearch from './HeaderSearch';
import { assetItems, navGroups, publicLinks, type NavItem } from './navigationConfig';

export type HeaderUser = { id: number; name: string; email: string; emailVerified: boolean };
type Props = { user?: HeaderUser | null; dark: boolean; onToggleTheme: () => void };

function initials(name: string) {
  const letters = name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]?.toLocaleUpperCase());
  return letters.join('') || <UserRound aria-hidden="true"/>;
}

function MenuItem({ item, close, onPick }: { item: NavItem; close: () => void; onPick?: (item: NavItem) => void }) {
  const Icon = item.icon;
  return <a className="rxh-menu-item" role="menuitem" href={item.href} onClick={event => {
    if (item.soon && onPick) { event.preventDefault(); onPick(item); }
    close();
  }}>
    <span className="rxh-menu-icon"><Icon aria-hidden="true"/></span><span className="rxh-menu-copy"><b>{item.label}{item.soon && <small className="rxh-soon">Soon</small>}</b><small>{item.description}</small></span>
  </a>;
}

/*
 * Header state comes from the server-shared Inertia `auth.user` prop, which is present in the
 * very first HTML response and refreshed on every visit (login, logout, expired session).
 * Guests therefore never receive or render any account-specific control.
 */
export default function RushXHeader({ user = null, dark, onToggleTheme }: Props) {
  const [open, setOpen] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [notice, setNotice] = useState('');
  const root = useRef<HTMLDivElement>(null);
  const groups = user ? [...navGroups] : [];
  const isGroupOpen = (label: string) => open === label;
  const toggle = (label: string) => setOpen(value => value === label ? null : label);
  const closeAll = () => { setOpen(null); setDrawer(false); };
  const choose = (item: NavItem) => setNotice(`${item.label} is coming soon.`);

  useEffect(() => {
    const dismiss = (event: PointerEvent) => { if (root.current && !root.current.contains(event.target as Node)) { setOpen(null); setDrawer(false); } };
    const keys = (event: KeyboardEvent) => { if (event.key === 'Escape') { setOpen(null); setDrawer(false); } };
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', keys);
    return () => { document.removeEventListener('pointerdown', dismiss); document.removeEventListener('keydown', keys); };
  }, []);

  useEffect(() => {
    document.body.classList.toggle('rxh-lock-scroll', drawer);
    return () => document.body.classList.remove('rxh-lock-scroll');
  }, [drawer]);

  // Authentication state changed (login/logout/expiry): drop any open menu, drawer or private notice.
  useEffect(() => { closeAll(); setNotice(''); }, [user?.id]);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const showSoon = (label: string) => setNotice(`${label} is coming soon.`);
  const logout = () => router.post('/logout');

  return <div className={`rxh-root ${user ? 'rxh-auth' : 'rxh-guest'}`} ref={root}>
    <header className="rxh-header">
      <div className="rxh-inner">
        <Brand/>
        {user
          ? <nav className="rxh-desktop-nav" aria-label="Main navigation">
            {groups.map(group => <Fragment key={group.label}><div className="rxh-nav-group">
              <button type="button" className="rxh-nav-trigger" aria-expanded={isGroupOpen(group.label)} aria-haspopup="menu" onClick={() => toggle(group.label)}>{group.label}<ChevronDown aria-hidden="true"/></button>
              {isGroupOpen(group.label) && <div className="rxh-mega-menu" role="menu">{group.items.map(item => <MenuItem key={item.label} item={item} close={() => setOpen(null)} onPick={choose}/>)}</div>}
            </div>{group.label === 'Buy Crypto' && <a className="rxh-standalone-link" href="/markets">Markets</a>}</Fragment>)}
          </nav>
          : <nav className="rxh-desktop-nav rxh-public-nav" aria-label="Main navigation">
            {publicLinks.map(link => <a key={link.label} className="rxh-standalone-link" href={link.href}>{link.label}</a>)}
          </nav>}
        <div className="rxh-actions">
          {user ? <>
            <HeaderSearch/>
            <a className="rxh-deposit" href="/deposit">Deposit</a>
            <div className="rxh-nav-group rxh-assets-group">
              <button type="button" className="rxh-action-link" aria-expanded={isGroupOpen('Assets')} aria-haspopup="menu" onClick={() => toggle('Assets')}>Assets<ChevronDown aria-hidden="true"/></button>
              {isGroupOpen('Assets') && <div className="rxh-mega-menu rxh-assets-menu" role="menu">{assetItems.filter(item => item.auth).map(item => <MenuItem key={item.label} item={item} close={() => setOpen(null)} onPick={choose}/>)}</div>}
            </div>
            <div className="rxh-nav-group rxh-profile-group">
              <button type="button" className="rxh-profile-trigger" aria-label="Account profile" aria-haspopup="menu" aria-expanded={isGroupOpen('Profile')} onClick={() => toggle('Profile')}><span className="rxh-avatar">{initials(user.name)}</span></button>
              {isGroupOpen('Profile') && <div className="rxh-profile-menu" role="menu">
                <div className="rxh-profile-summary"><span className="rxh-avatar">{initials(user.name)}</span><span><b>{user.name || 'RushX user'}</b><small>{user.email}</small></span></div>
                <div className="rxh-profile-data"><span>Verification</span><b className={user.emailVerified ? 'is-verified' : ''}>{user.emailVerified ? 'Email verified' : 'Email not verified'}</b><span>UID</span><b>RX-{user.id}</b></div>
                <a href="/assets" role="menuitem" onClick={() => setOpen(null)}><Wallet/> My Assets</a><a href="/security" role="menuitem" onClick={() => setOpen(null)}><UserRound/> Security &amp; Settings</a>
                <button className="rxh-profile-theme" role="menuitem" type="button" onClick={onToggleTheme}>{dark ? <Sun/> : <Moon/>}{dark ? 'Light mode' : 'Dark mode'}</button>
                <button className="rxh-logout" role="menuitem" type="button" onClick={logout}><LogOut/> Logout</button>
              </div>}
            </div>
            <span className="rxh-utility-divider" aria-hidden="true"/>
            <div className="rxh-utility-actions" role="group" aria-label="Account tools">
              <button className="rxh-icon" type="button" aria-label="Download app" title="Download app" onClick={() => showSoon('Download app')}><Download/></button>
              <a className="rxh-icon" href="/support" aria-label="Messages and support" title="Messages and support"><MessageCircle/></a>
              <button className="rxh-icon" type="button" aria-label="Notifications" title="Notifications" onClick={() => showSoon('Notifications')}><Bell/></button>
            </div>
          </> : <>
            <button className="rxh-icon rxh-globe" type="button" aria-label="Language: English" title="Language" onClick={() => showSoon('More languages')}><Globe/></button>
            <button className="rxh-icon rxh-theme" type="button" onClick={onToggleTheme} aria-label={`Switch to ${dark ? 'light' : 'dark'} mode`}>{dark ? <Sun/> : <Moon/>}</button>
            <a className="rxh-signin" href="/login">Sign in</a>
            <a className="rxh-signup" href="/login?mode=signup">Sign up</a>
          </>}
          <button className="rxh-icon rxh-mobile-toggle" type="button" onClick={() => setDrawer(value => !value)} aria-expanded={drawer} aria-label={drawer ? 'Close menu' : 'Open menu'}>{drawer ? <X/> : <Menu/>}</button>
        </div>
      </div>
    </header>
    {drawer && <div className="rxh-mobile-layer"><button className="rxh-mobile-scrim" aria-label="Close navigation" onClick={() => setDrawer(false)}/><nav className="rxh-mobile-drawer" aria-label="Mobile navigation">
      <div className="rxh-mobile-head"><Brand/><button className="rxh-icon" onClick={() => setDrawer(false)} aria-label="Close navigation"><X/></button></div>
      {user && <HeaderSearch mobile onNavigate={() => setDrawer(false)}/>}
      {!user && <section className="rxh-mobile-group">{publicLinks.map(link => <a key={link.label} className="rxh-mobile-standalone" href={link.href} onClick={() => setDrawer(false)}>{link.label}</a>)}</section>}
      {groups.map(group => <Fragment key={group.label}><section className="rxh-mobile-group"><button type="button" aria-expanded={isGroupOpen(group.label)} onClick={() => toggle(group.label)}>{group.label}<ChevronDown/></button>{isGroupOpen(group.label) && group.items.map(item => <MenuItem key={item.label} item={item} close={() => setDrawer(false)} onPick={choose}/>)}</section>{group.label === 'Buy Crypto' && <a className="rxh-mobile-standalone" href="/markets" onClick={() => setDrawer(false)}>Markets</a>}</Fragment>)}
      {user && <section className="rxh-mobile-group"><button type="button" aria-expanded={isGroupOpen('Assets')} onClick={() => toggle('Assets')}>Assets<ChevronDown/></button>{isGroupOpen('Assets') && assetItems.filter(item => item.auth).map(item => <MenuItem key={item.label} item={item} close={() => setDrawer(false)} onPick={choose}/>)}</section>}
      {user && <section className="rxh-mobile-profile"><div><span className="rxh-avatar">{initials(user.name)}</span><span><b>{user.name}</b><small>{user.email}</small></span></div><p>{user.emailVerified ? 'Email verified' : 'Email not verified'} · UID RX-{user.id}</p><a href="/assets" onClick={() => setDrawer(false)}>My Assets</a><a href="/security" onClick={() => setDrawer(false)}>Security &amp; Settings</a></section>}
      <div className="rxh-mobile-bottom"><button type="button" onClick={onToggleTheme}>{dark ? <Sun/> : <Moon/>}{dark ? 'Light mode' : 'Dark mode'}</button>{user ? <><button type="button" onClick={() => showSoon('Download app')}><Download/>Download app</button><a href="/support"><MessageCircle/>Support</a><button type="button" onClick={() => showSoon('Notifications')}><Bell/>Notifications</button><button type="button" onClick={logout}><LogOut/> Logout</button></> : <><a href="/login">Sign in</a><a href="/login?mode=signup">Sign up</a><a href="/support">Help</a></>}</div>
    </nav></div>}
    {notice && <div className="rxh-toast" role="status"><Check/>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss">×</button></div>}
  </div>;
}
