/** Future TradingView integration boundary. No market feed or trading controls are wired in this phase. */
export type TradingChartProps = { symbol: string; interval?: string; compact?: boolean };
export function TradingChart({ symbol, interval = '1D', compact = false }: TradingChartProps) {
  return <section aria-label={`${symbol} chart placeholder`} data-symbol={symbol} data-interval={interval} data-compact={compact} className="chart-placeholder"><p>Chart integration will be connected in a later phase.</p></section>;
}
