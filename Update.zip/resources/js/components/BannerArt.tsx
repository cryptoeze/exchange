/** Hand-drawn RushX banner illustrations: soft grey line art with lime accents. */
const G = '#9a9a9f'; const D = '#2a2b2e'; const L = '#c1f033';
const S = { strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, strokeWidth: 2 };

export type ArtKind = 'rewards' | 'bots' | 'copy' | 'earn' | 'futures' | 'p2p';

export default function BannerArt({ kind }: { kind: ArtKind }) {
  return <svg fill="none" viewBox="0 0 140 110" width="116" height="92" aria-hidden="true" className="ba-art">
    <defs><radialGradient id={`g-${kind}`} cx="50%" cy="55%" r="55%"><stop offset="0" stopColor={L} stopOpacity=".22"/><stop offset="1" stopColor={L} stopOpacity="0"/></radialGradient></defs>
    <circle cx="70" cy="58" r="52" fill={`url(#g-${kind})`}/>
    <ellipse cx="70" cy="98" rx="46" ry="7" fill="#000" opacity=".35"/>
    {kind === 'rewards' && <g>
      <path d="M32 54 L70 72 L108 54 L108 88 L70 104 L32 88 Z" fill={D} stroke={G} {...S}/>
      <path d="M70 72 L70 104" stroke={G} {...S}/><path d="M32 54 L70 36 L108 54 L70 72 Z" fill="#34353a" stroke={G} {...S}/>
      <path d="M57 45 L95 63" stroke={L} {...S} strokeWidth={5}/><path d="M70 36 C58 20 40 30 54 38 C60 41 66 40 70 36 C74 40 80 41 86 38 C100 30 82 20 70 36 Z" fill="none" stroke={L} {...S}/>
      <circle cx="108" cy="30" r="9" fill="none" stroke={L} {...S}/><text x="108" y="34" fontSize="11" fontWeight="800" textAnchor="middle" fill={L}>$</text>
      <circle cx="26" cy="38" r="5" fill="none" stroke={G} {...S}/><path d="M118 70 l0 -8 M114 66 l8 0" stroke={G} {...S}/>
    </g>}
    {kind === 'bots' && <g>
      <rect x="40" y="38" width="60" height="46" rx="14" fill={D} stroke={G} {...S}/><path d="M70 38 L70 24" stroke={G} {...S}/><circle cx="70" cy="21" r="5" fill="none" stroke={L} {...S}/>
      <circle cx="56" cy="58" r="7" fill="none" stroke={L} {...S}/><circle cx="84" cy="58" r="7" fill="none" stroke={L} {...S}/><path d="M56 74 L84 74" stroke={G} {...S}/>
      <path d="M30 56 L30 66 M110 56 L110 66" stroke={G} {...S} strokeWidth={4}/>
      <path d="M44 100 L58 90 L72 95 L88 82 L100 86" stroke={L} {...S}/><circle cx="100" cy="86" r="3" fill={L}/>
    </g>}
    {kind === 'copy' && <g>
      <circle cx="54" cy="44" r="14" fill={D} stroke={G} {...S}/><path d="M28 86 C28 68 40 62 54 62 C68 62 80 68 80 86" fill={D} stroke={G} {...S}/>
      <circle cx="92" cy="50" r="14" fill="#34353a" stroke={L} {...S}/><path d="M66 92 C66 74 78 68 92 68 C106 68 118 74 118 92" fill="#34353a" stroke={L} {...S}/>
      <path d="M62 24 C72 14 86 14 96 24" stroke={G} {...S}/><path d="M92 20 L97 25 L90 28" stroke={G} {...S}/>
    </g>}
    {kind === 'earn' && <g>
      <ellipse cx="56" cy="88" rx="26" ry="9" fill={D} stroke={G} {...S}/><path d="M30 88 L30 78 C30 72 82 72 82 78 L82 88" fill={D} stroke={G} {...S}/>
      <ellipse cx="56" cy="72" rx="26" ry="9" fill={D} stroke={G} {...S}/><path d="M30 72 L30 62 C30 56 82 56 82 62 L82 72" fill={D} stroke={G} {...S}/>
      <ellipse cx="56" cy="56" rx="26" ry="9" fill="#34353a" stroke={L} {...S}/>
      <path d="M100 98 L100 60" stroke={G} {...S}/><path d="M100 76 C100 62 112 60 118 54 C118 66 110 74 100 76 Z" fill="none" stroke={L} {...S}/><path d="M100 66 C100 56 92 52 84 50 C84 60 90 66 100 66 Z" fill="none" stroke={L} {...S}/>
      <circle cx="56" cy="34" r="11" fill="none" stroke={L} {...S}/><text x="56" y="39" fontSize="13" fontWeight="800" textAnchor="middle" fill={L}>%</text>
    </g>}
    {kind === 'futures' && <g>
      <path d="M26 96 L26 22 M26 96 L116 96" stroke={G} {...S}/>
      {[[40, 70, 40, 54, 86, 94], [58, 60, 38, 78, 70, 90], [76, 50, 30, 82, 52, 88], [94, 38, 24, 68, 40, 74]].map(([x, t, , , , ], i) => <g key={i}><path d={`M${x} ${t - 8} L${x} ${t + 28}`} stroke={i % 2 ? L : G} {...S}/><rect x={x - 6} y={t} width="12" height={18 + i * 3} rx="3" fill={i % 2 ? '#2b3a10' : D} stroke={i % 2 ? L : G} {...S}/></g>)}
      <path d="M34 80 L58 62 L76 70 L108 34" stroke={L} {...S} strokeWidth={2.5}/><path d="M96 32 L109 33 L108 46" stroke={L} {...S} strokeWidth={2.5}/>
    </g>}
    {kind === 'p2p' && <g>
      <rect x="22" y="30" width="38" height="62" rx="8" fill={D} stroke={G} {...S}/><rect x="80" y="30" width="38" height="62" rx="8" fill="#34353a" stroke={L} {...S}/>
      <path d="M31 40 L51 40 M31 82 L51 82" stroke={G} {...S}/><path d="M89 40 L109 40 M89 82 L109 82" stroke={L} {...S}/>
      <path d="M62 52 L78 52 M72 46 L78 52 L72 58" stroke={L} {...S}/><path d="M78 70 L62 70 M68 64 L62 70 L68 76" stroke={G} {...S}/>
      <circle cx="41" cy="62" r="8" fill="none" stroke={G} {...S}/><circle cx="99" cy="62" r="8" fill="none" stroke={L} {...S}/>
    </g>}
  </svg>;
}
