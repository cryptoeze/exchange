import { useEffect, useRef, useState } from 'react';
import { AreaSeries, CandlestickSeries, ColorType, CrosshairMode, LineStyle, createChart, type IChartApi, type IPriceLine, type ISeriesApi, type UTCTimestamp } from 'lightweight-charts';
import { X } from 'lucide-react';

/** A horizontal marker on the chart: the user's position entry, liquidation, take-profit, stop-loss or average buy. */
export type ChartLine = { id: string; price: number; title: string; color: string; dashed?: boolean; onClose?: () => void };
type Candle = { t: number; o: number; h: number; l: number; c: number };
const UP = '#0ecb81'; const DOWN = '#f6465d';
const PERIOD: Record<string, number> = { '1': 60, '3': 180, '5': 300, '15': 900, '30': 1800, '60': 3600, '120': 7200, '240': 14400, D: 86400 };
const precisionOf = (p: number) => p >= 1000 ? 1 : p >= 1 ? 4 : p >= 0.001 ? 6 : 8;

/**
 * Clean RushX candle chart: candles only (no indicators, no drawing tools), live from Bybit's public stream,
 * candle countdown, dashed last-price line, and optional position lines with a close button.
 */
export default function LiveChart({ symbol, interval, dark, market, area = false, lines = [] }: { symbol: string; interval: string; dark: boolean; market: 'spot' | 'linear'; area?: boolean; lines?: ChartLine[] }) {
  const host = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | ISeriesApi<'Area'> | null>(null);
  const lineRefs = useRef<Map<string, IPriceLine>>(new Map());
  const lastRef = useRef<Candle | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [left, setLeft] = useState('');
  const [ys, setYs] = useState<Record<string, number>>({});
  const [retry, setRetry] = useState(0);
  const linesRef = useRef(lines); linesRef.current = lines;

  useEffect(() => {
    const el = host.current; if (!el) return; let dead = false; let ws: WebSocket | null = null; let ping = 0; let poll = 0; let wsOpen = false; let reconnect = 0;
    setState('loading'); lineRefs.current.clear(); lastRef.current = null;
    const txt = dark ? '#8e8e93' : '#6b7280'; const grid = dark ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.06)';
    const chart = createChart(el, {
      autoSize: true,
      layout: { background: { type: ColorType.Solid, color: dark ? '#000000' : '#ffffff' }, textColor: txt, fontSize: 12, fontFamily: 'Inter, -apple-system, sans-serif' },
      grid: { vertLines: { color: grid }, horzLines: { color: grid } },
      crosshair: { mode: CrosshairMode.Normal, vertLine: { color: txt, width: 1, style: LineStyle.Dashed, labelBackgroundColor: dark ? '#2b2f36' : '#374151' }, horzLine: { color: txt, width: 1, style: LineStyle.Dashed, labelBackgroundColor: dark ? '#2b2f36' : '#374151' } },
      rightPriceScale: { borderVisible: false, scaleMargins: { top: 0.1, bottom: 0.12 } },
      timeScale: { borderVisible: false, timeVisible: true, secondsVisible: interval === '1', rightOffset: 6, barSpacing: 8, minBarSpacing: 2 },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
    });
    chartRef.current = chart;
    const series = area
      ? chart.addSeries(AreaSeries, { lineColor: UP, topColor: 'rgba(14,203,129,0.28)', bottomColor: 'rgba(14,203,129,0)', lineWidth: 2, priceLineStyle: LineStyle.Dashed })
      : chart.addSeries(CandlestickSeries, { upColor: UP, downColor: DOWN, borderUpColor: UP, borderDownColor: DOWN, wickUpColor: UP, wickDownColor: DOWN, priceLineStyle: LineStyle.Dashed });
    seriesRef.current = series;
    const put = (c: Candle) => { lastRef.current = c; if (area) (series as ISeriesApi<'Area'>).update({ time: c.t as UTCTimestamp, value: c.c }); else (series as ISeriesApi<'Candlestick'>).update({ time: c.t as UTCTimestamp, open: c.o, high: c.h, low: c.l, close: c.c }); };

    const load = async () => {
      try {
        const r = await fetch(`/api/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&market=${market}&limit=500`, { headers: { Accept: 'application/json' } });
        if (!r.ok) throw new Error('kline');
        const { candles } = await r.json() as { candles: Candle[] }; if (dead) return;
        if (!candles.length) throw new Error('empty');
        const p = precisionOf(candles[candles.length - 1].c);
        series.applyOptions({ priceFormat: { type: 'price', precision: p, minMove: Number((1 / 10 ** p).toFixed(p)) } });
        if (area) (series as ISeriesApi<'Area'>).setData(candles.map(c => ({ time: c.t as UTCTimestamp, value: c.c })));
        else (series as ISeriesApi<'Candlestick'>).setData(candles.map(c => ({ time: c.t as UTCTimestamp, open: c.o, high: c.h, low: c.l, close: c.c })));
        lastRef.current = candles[candles.length - 1]; chart.timeScale().scrollToRealTime(); setState('ready');
      } catch { if (!dead) setState('error'); }
    };
    const refresh = async () => { // REST fallback: re-pull the newest candles
      try { const r = await fetch(`/api/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&market=${market}&limit=10`); if (!r.ok) return; const { candles } = await r.json() as { candles: Candle[] }; if (!dead) candles.slice(-3).forEach(put); } catch { /* next tick */ }
    };
    const connect = () => {
      try {
        ws = new WebSocket(`wss://stream.bybit.com/v5/public/${market}`);
        ws.onopen = () => { wsOpen = true; ws?.send(JSON.stringify({ op: 'subscribe', args: [`kline.${interval}.${symbol}`] })); ping = window.setInterval(() => { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ op: 'ping' })); }, 20000); };
        ws.onmessage = e => { try { const m = JSON.parse(e.data as string) as { topic?: string; data?: Array<{ start: number; open: string; high: string; low: string; close: string }> }; if (m.topic?.startsWith('kline.') && m.data) m.data.forEach(k => put({ t: Math.floor(k.start / 1000), o: +k.open, h: +k.high, l: +k.low, c: +k.close })); } catch { /* ignore */ } };
        ws.onclose = () => { wsOpen = false; window.clearInterval(ping); if (!dead) reconnect = window.setTimeout(connect, 2500); };
        ws.onerror = () => ws?.close();
      } catch { /* polling covers it */ }
    };
    void load().then(() => { if (!dead) connect(); });
    poll = window.setInterval(() => { if (!wsOpen && !document.hidden) void refresh(); }, 3000);
    const tick = window.setInterval(() => { // countdown + y positions of closable lines
      const p = PERIOD[interval]; setLeft(p ? (() => { const s = p - (Math.floor(Date.now() / 1000) % p); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; })() : '');
      const next: Record<string, number> = {}; for (const l of linesRef.current) if (l.onClose) { const y = series.priceToCoordinate(l.price); if (y !== null) next[l.id] = Math.round(y); }
      setYs(prev => { const a = Object.keys(next); return a.length === Object.keys(prev).length && a.every(k => prev[k] === next[k]) ? prev : next; });
    }, 400);
    return () => { dead = true; window.clearInterval(tick); window.clearInterval(poll); window.clearInterval(ping); window.clearTimeout(reconnect); try { ws?.close(); } catch { /* closed */ } chart.remove(); chartRef.current = null; seriesRef.current = null; lineRefs.current.clear(); };
  }, [symbol, interval, dark, market, area, retry]);

  useEffect(() => { // keep position lines in sync without rebuilding the chart
    const s = seriesRef.current; if (!s) return; const seen = new Set<string>();
    for (const l of lines) {
      seen.add(l.id); const opts = { price: l.price, color: l.color, lineWidth: 1 as const, lineStyle: l.dashed ? LineStyle.Dashed : LineStyle.Solid, axisLabelVisible: true, title: l.title };
      const have = lineRefs.current.get(l.id); if (have) have.applyOptions(opts); else lineRefs.current.set(l.id, s.createPriceLine(opts));
    }
    for (const [id, pl] of lineRefs.current) if (!seen.has(id)) { s.removePriceLine(pl); lineRefs.current.delete(id); }
  }, [lines, state]);

  return <div className="lc-wrap">
    <div ref={host} className="lc-host"/>
    {state === 'loading' && <div className="lc-msg">Loading chart…</div>}
    {state === 'error' && <div className="lc-msg">Chart data could not be loaded. <button type="button" onClick={() => setRetry(n => n + 1)}>Retry</button></div>}
    {state === 'ready' && left && <span className="lc-timer" aria-label="Time left in this candle">{left}</span>}
    {state === 'ready' && lines.filter(l => l.onClose && ys[l.id] !== undefined).map(l => <button key={l.id} type="button" className="lc-close" style={{ top: ys[l.id] - 11 }} aria-label={`Close ${l.title}`} onClick={l.onClose}><X/></button>)}
  </div>;
}
