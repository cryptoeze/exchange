import { useEffect, useMemo, useRef, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ArrowDownUp, ArrowRight, CheckCircle2, ChevronDown, Loader2, Search } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import AccountSubNav from '../components/AccountSubNav';
import CoinImage from '../components/CoinImage';
import { COIN_NAMES, useSpotPrices, useWallet } from '../lib/hooks';
import { api, newKey } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/treasury.css';

type Row = { id: number; from: string; to: string; spent: string; received: string; at: string | null };
const STABLE = new Set(['USDT', 'USDC']);
const trim = (n: number, d = 8) => { const s = n.toFixed(d); return s.includes('.') ? s.replace(/0+$/, '').replace(/\.$/, '') : s; };
const show = (n: number) => n >= 1000 ? n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : n >= 1 ? n.toFixed(4) : n >= 0.001 ? n.toFixed(6) : n.toFixed(8);

export default function Convert() {
  const user = ((usePage().props as Record<string, unknown>).auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const prices = useSpotPrices();
  const { wallet, reload } = useWallet('funding');
  const [from, setFrom] = useState('USDT'); const [to, setTo] = useState('BTC');
  const [amount, setAmount] = useState('');
  const [open, setOpen] = useState<'from' | 'to' | null>(null); const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  const loadRows = async () => { const r = await api<{ rows: Row[] }>('/api/convert'); if (r.ok) setRows(r.data.rows); };
  useEffect(() => { void loadRows(); }, []);
  useEffect(() => { const c = (e: PointerEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(null); }; document.addEventListener('pointerdown', c); return () => document.removeEventListener('pointerdown', c); }, []);

  const bal = (a: string) => (wallet?.balances.filter(b => b.account === 'funding' && b.asset === a).reduce((s, b) => s + b.units / 1e8, 0)) ?? 0;
  const usd = (a: string) => STABLE.has(a) ? 1 : prices.get(`${a}USDT`)?.lastPrice ?? 0;
  const coins = useMemo(() => {
    const set = new Set<string>(['USDT', 'USDC']);
    prices.forEach(m => { if (m.quoteAsset === 'USDT' && m.isTradable) set.add(m.baseAsset); });
    wallet?.balances.forEach(b => set.add(b.asset));
    return [...set].filter(a => usd(a) > 0).sort((a, b) => (bal(b) > 0 ? 1 : 0) - (bal(a) > 0 ? 1 : 0) || a.localeCompare(b));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prices, wallet]);
  const shown = coins.filter(c => c !== (open === 'from' ? to : from) && (!q || c.toLowerCase().includes(q.toLowerCase()) || (COIN_NAMES[c] ?? '').toLowerCase().includes(q.toLowerCase()))).slice(0, 120);

  const rate = usd(from) > 0 && usd(to) > 0 ? usd(from) / usd(to) : 0;
  const amt = Number(amount) || 0;
  const avail = bal(from);
  const label = busy ? '' : !amt ? 'Convert' : amt > avail ? 'Insufficient balance' : !rate ? 'Price unavailable' : 'Convert';
  const can = !busy && amt > 0 && amt <= avail + 1e-9 && rate > 0;
  const pick = (c: string) => { if (open === 'from') setFrom(c); else setTo(c); setOpen(null); setQ(''); setAmount(''); };
  const swap = () => { setFrom(to); setTo(from); setAmount(''); };

  const submit = async () => {
    setBusy(true); setMsg(null);
    const r = await api<{ rows: Row[] }>('/api/convert', { from, to, amount, idempotency_key: newKey() });
    setBusy(false);
    if (r.ok) { setRows(r.data.rows); setAmount(''); setMsg({ ok: true, text: `Converted ${amt} ${from}` }); void reload(); } else setMsg({ ok: false, text: r.data.message ?? 'Conversion failed.' });
  };

  const Pill = ({ side, asset }: { side: 'from' | 'to'; asset: string }) => <div className="cv-dd">
    <button type="button" className="cv-pill" onClick={() => { setOpen(open === side ? null : side); setQ(''); }} aria-haspopup="listbox" aria-expanded={open === side}><span className="cv-ico"><CoinImage symbol={asset}/></span><b>{asset}</b><ChevronDown/></button>
    {open === side && <div className="cv-menu" role="listbox"><div className="cv-search"><Search/><input autoFocus placeholder="Search crypto" value={q} onChange={e => setQ(e.target.value)}/></div>
      <div className="cv-list">{shown.map(c => <button type="button" role="option" key={c} className="cv-item" onClick={() => pick(c)}><span className="cv-ico"><CoinImage symbol={c}/></span><span><b>{c}</b><small>{COIN_NAMES[c] ?? c}</small></span><em>{bal(c) > 0 ? trim(bal(c), 6) : ''}</em></button>)}</div></div>}
  </div>;

  return <><Head title="Convert — RushX"/>
    <div className="ov-shell dp-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>
    <AccountSubNav active="Funding"/>
    <main className="cv-main">
      <div className="cv-layout">
        <div className="cv-hero"><h1>Convert</h1><p>Zero fees, no slippage.</p><div><span><CheckCircle2/> Instant settlement</span><span><CheckCircle2/> Guaranteed price</span></div></div>
        <div className="cv-widget" ref={box}>
          <h2>Convert</h2>
          <div className="cv-group">
            <div className="cv-box"><div className="cv-top"><span>From</span><span>Balance: <u>{show(avail)}</u> {from} <button type="button" className="cv-max" onClick={() => setAmount(avail > 0 ? trim(Math.floor(avail * 1e8) / 1e8) : '')}>MAX</button></span></div>
              <div className="cv-mid"><input inputMode="decimal" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ''))} aria-label="Amount to convert"/><Pill side="from" asset={from}/></div></div>
            <button type="button" className="cv-swap" onClick={swap} aria-label="Swap assets"><ArrowDownUp/></button>
            <div className="cv-box"><div className="cv-top"><span>To</span></div>
              <div className="cv-mid"><input readOnly placeholder="0.00" value={amt && rate ? trim(amt * rate) : ''} aria-label="You receive"/><Pill side="to" asset={to}/></div></div>
          </div>
          <div className="cv-info"><span>Estimated Rate</span><b>{rate ? `1 ${from} ≈ ${show(rate)} ${to}` : '--'}</b></div>
          {msg && <div className={msg.ok ? 'tw-ok' : 'tw-err'} role="status" style={{ marginTop: 16 }}>{msg.text}</div>}
          <button type="button" className="tw-cta" style={{ marginTop: 20 }} disabled={!can} onClick={submit}>{busy ? <Loader2 className="dp-spin"/> : label}</button>
        </div>
      </div>
      <h3 className="cv-h">Recent conversions</h3>
      <div className="cv-table"><table><thead><tr><th>Date</th><th>Swap Pair</th><th>Spent</th><th>Received</th><th>Status</th></tr></thead><tbody>
        {rows.length === 0 ? <tr><td colSpan={5} className="cv-empty">No conversions yet. Your most recent conversions will be shown here.</td></tr> : rows.map(r => <tr key={r.id}>
          <td>{r.at ? new Date(r.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}</td>
          <td><span className="cv-pair"><span className="cv-ico"><CoinImage symbol={r.from}/></span><ArrowRight/><span className="cv-ico"><CoinImage symbol={r.to}/></span></span></td>
          <td>{r.spent} {r.from}</td><td className="up">+ {r.received} {r.to}</td><td><span className="tw-pill completed">Completed</span></td></tr>)}
      </tbody></table></div>
    </main></div></>;
}
