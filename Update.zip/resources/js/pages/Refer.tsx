import { useState } from 'react';
import { Head } from '@inertiajs/react';
import { Check, Copy, Gift, Link2, Users } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import '../../css/profile.css';

type Props = { code: string; link: string; total: number; invited: Array<{ name: string; at: string | null }> };

export default function Refer({ code, link, total, invited }: Props) {
  const [done, setDone] = useState('');
  const copy = async (what: 'code' | 'link') => {
    try { await navigator.clipboard.writeText(what === 'code' ? code : link); } catch { /* clipboard may be blocked */ }
    setDone(what); if (navigator.vibrate) navigator.vibrate(12); window.setTimeout(() => setDone(''), 1800);
  };
  return <AccountLayout active="Rewards" title="Refer & earn" showNav={false}>
    <Head title="Refer & earn — RushX"/>
    <main className="pf-wrap">
      <section className="pf-hero"><span className="pf-ic"><Gift/></span><h1>Invite friends to RushX</h1><p>Share your code or link. Friends can also type your code while creating their account.</p></section>
      <section className="pf-card">
        <div className="pf-copy"><small>Your referral code</small><b>{code}</b><button type="button" onClick={() => copy('code')}>{done === 'code' ? <><Check/> Copied</> : <><Copy/> Copy code</>}</button></div>
        <div className="pf-copy"><small>Your referral link</small><b className="sm">{link}</b><button type="button" onClick={() => copy('link')}>{done === 'link' ? <><Check/> Copied</> : <><Link2/> Copy link</>}</button></div>
      </section>
      <section className="pf-stat"><Users/><span><b>{total}</b><small>{total === 1 ? 'friend joined' : 'friends joined'}</small></span></section>
      <h2 className="pf-h">People you invited</h2>
      <section className="pf-card flat">{invited.length === 0 ? <p className="pf-empty">Nobody has joined with your code yet.</p> : invited.map((u, i) => <div className="pf-row static" key={i}><span className="pf-av">{u.name.slice(0, 1)}</span><span className="pf-txt"><b>{u.name}</b><small>{u.at ? new Date(u.at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''}</small></span></div>)}</section>
    </main>
  </AccountLayout>;
}
