import { useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import { Check, Copy, Gift, Link2, Users } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import '../../css/profile.css';

type Props = { code: string; link: string | null; total: number; invited: Array<{ name: string; at: string | null }> };

export default function Refer({ code, link, total, invited }: Props) {
  const brandName = (usePage().props as { siteName?: string }).siteName || 'RushX';
  const [done, setDone] = useState('');
  const copy = async (what: 'code' | 'link') => {
    try { await navigator.clipboard.writeText(what === 'code' ? code : (link ?? '')); } catch { /* clipboard may be blocked */ }
    setDone(what); if (navigator.vibrate) navigator.vibrate(12); window.setTimeout(() => setDone(''), 1800);
  };
  return <AccountLayout active="Rewards" title="Refer & earn" showNav={false}>
    <Head title={`Refer & earn — ${brandName}`}/>
    <main className="pf-wrap">
      <section className="pf-hero"><span className="pf-ic"><Gift/></span><h1>Invite friends to {brandName}</h1><p>{link ? 'Share your code or link. Friends can also type your code while creating their account.' : 'Share your code. Friends type it while creating their account.'}</p></section>
      <section className="pf-card">
        <div className="pf-copy"><small>Your referral code</small><b>{code}</b><button type="button" onClick={() => copy('code')}>{done === 'code' ? <><Check/> Copied</> : <><Copy/> Copy code</>}</button></div>
        {link && <div className="pf-copy"><small>Your referral link</small><b className="sm">{link}</b><button type="button" onClick={() => copy('link')}>{done === 'link' ? <><Check/> Copied</> : <><Link2/> Copy link</>}</button></div>}
      </section>
      <section className="pf-stat"><Users/><span><b>{total}</b><small>{total === 1 ? 'friend joined' : 'friends joined'}</small></span></section>
      <h2 className="pf-h">People you invited</h2>
      <section className="pf-card flat">{invited.length === 0 ? <p className="pf-empty">Nobody has joined with your code yet.</p> : invited.map((u, i) => <div className="pf-row static" key={i}><span className="pf-av">{u.name.slice(0, 1)}</span><span className="pf-txt"><b>{u.name}</b><small>{u.at ? new Date(u.at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''}</small></span></div>)}</section>
    </main>
  </AccountLayout>;
}
