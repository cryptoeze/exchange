import { useCallback, useEffect, useMemo, useState } from 'react';
import { Head } from '@inertiajs/react';
import { ArrowLeft, BellRing, Trash2 } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import { COIN_NAMES, useSpotPrices, useTheme } from '../lib/hooks';
import { api } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/profile.css';

type Alert = { id: number; symbol: string; direction: 'above' | 'below'; price: string; triggered: boolean; at: string };
const field = { background: 'var(--ov-input)', color: 'var(--ov-text)', border: '1px solid var(--ov-line)', borderRadius: 10, padding: 12, font: 'inherit', width: '100%' } as const;

export default function Alerts() {
  useTheme(); const prices = useSpotPrices();
  const [list, setList] = useState<Alert[] | null>(null); const [sym, setSym] = useState('BTCUSDT'); const [dir, setDir] = useState<'above' | 'below'>('above'); const [price, setPrice] = useState(''); const [err, setErr] = useState('');
  const load = useCallback(async () => { const r = await api<{ alerts: Alert[] }>('/api/alerts'); if (r.ok) setList(r.data.alerts); }, []);
  useEffect(() => { void load(); }, [load]);
  const opts = useMemo(() => [...prices.values()].filter(m => m.quoteAsset === 'USDT' && m.isTradable).sort((a, b) => b.turnover24h - a.turnover24h).slice(0, 120), [prices]);
  const now = prices.get(sym)?.lastPrice;
  const add = async () => { setErr(''); const r = await api<{ alerts: Alert[] }>('/api/alerts', { symbol: sym, direction: dir, price }); if (r.ok) { setList(r.data.alerts); setPrice(''); } else setErr(r.data.message ?? 'Could not save.'); };
  const del = async (id: number) => { const r = await api<{ alerts: Alert[] }>(`/api/alerts/${id}/delete`, {}); if (r.ok) setList(r.data.alerts); };
  return <><Head title="Price alerts — RushX"/>
    <div className="ov-shell pf-shell rx-dashboard">
      <header className="pf-top"><button type="button" aria-label="Back" onClick={() => (window.history.length > 1 ? window.history.back() : (window.location.href = '/profile'))}><ArrowLeft/></button><b>Price alerts</b><span/></header>
      <section className="pf-card" style={{ margin: 16, padding: 16, display: 'grid', gap: 10 }}>
        <select style={field} value={sym} onChange={e => setSym(e.target.value)}>{opts.map(m => <option key={m.symbol} value={m.symbol}>{m.baseAsset}/USDT · {COIN_NAMES[m.baseAsset] ?? m.baseAsset}</option>)}{opts.length === 0 && <option value={sym}>{sym}</option>}</select>
        <small style={{ opacity: .7 }}>Now: {now ? now.toLocaleString('en-US', { maximumFractionDigits: 8 }) : '—'} USDT</small>
        <div style={{ display: 'flex', gap: 8 }}>{(['above', 'below'] as const).map(d => <button key={d} type="button" onClick={() => setDir(d)} style={{ flex: 1, padding: 11, borderRadius: 10, border: '1px solid var(--ov-line)', background: dir === d ? '#c1f033' : 'none', color: dir === d ? '#000' : 'inherit', fontWeight: 800, cursor: 'pointer' }}>Rises above</button>).slice(0, 1)}
          <button type="button" onClick={() => setDir('below')} style={{ flex: 1, padding: 11, borderRadius: 10, border: '1px solid var(--ov-line)', background: dir === 'below' ? '#c1f033' : 'none', color: dir === 'below' ? '#000' : 'inherit', fontWeight: 800, cursor: 'pointer' }}>Falls below</button></div>
        <input style={field} inputMode="decimal" placeholder="Target price (USDT)" value={price} onChange={e => setPrice(e.target.value)}/>
        {err && <small role="alert" style={{ color: '#f6465d' }}>{err}</small>}
        <button type="button" onClick={add} disabled={!price} style={{ border: 0, borderRadius: 10, padding: 13, background: '#c1f033', color: '#000', fontWeight: 800, cursor: 'pointer' }}><BellRing size={16} style={{ verticalAlign: -3 }}/> Create alert</button>
        <small style={{ opacity: .65 }}>You will get a notification (and an email) once the price is reached. Checked every minute.</small>
      </section>
      <h2 className="pf-h">My alerts</h2><section className="pf-card flat" style={{ margin: '0 16px' }}>
        {list === null ? <p className="pf-empty">Loading…</p> : list.length === 0 ? <p className="pf-empty">No alerts yet.</p> : list.map(a => <div className="pf-row static" key={a.id}><span className="pf-txt"><b>{a.symbol.replace('USDT', '')}/USDT {a.direction === 'above' ? '≥' : '≤'} {a.price}</b><small>{a.triggered ? 'Triggered' : 'Waiting'} · {a.at}</small></span><button type="button" aria-label="Delete alert" onClick={() => del(a.id)} style={{ background: 'none', border: 0, color: '#f6465d', cursor: 'pointer' }}><Trash2 size={18}/></button></div>)}
      </section>
      <MobileNav active="markets"/>
    </div></>;
}
