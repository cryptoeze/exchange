import { useCallback, useEffect, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ArrowLeftRight, ArrowUpDown, Loader2 } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import AccountSubNav from '../components/AccountSubNav';
import UsdtIcon from '../components/UsdtIcon';
import { api, newKey, type WalletPayload } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/deposit.css';
import '../../css/treasury.css';

const fmt = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const floor2 = (n: number) => Math.floor(n * 100) / 100;

export default function Transfer() {
  const user = ((usePage().props as Record<string, unknown>).auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [funding, setFunding] = useState(0);
  const [trading, setTrading] = useState(0);
  const [toTrading, setToTrading] = useState(true);
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  const usdt = (p: WalletPayload) => p.balances.filter(b => b.asset === 'USDT').reduce((s, b) => s + b.units / 1e8, 0);
  const load = useCallback(async () => {
    const [f, t] = await Promise.all([api<WalletPayload>('/api/wallet'), api<WalletPayload>('/api/wallet?account=trading')]);
    if (f.ok) setFunding(usdt(f.data)); if (t.ok) setTrading(usdt(t.data));
  }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 3000); return () => window.clearInterval(t); }, [load]);

  const from = toTrading ? funding : trading; const to = toTrading ? trading : funding;
  const amt = Number(amount) || 0;
  const label = busy ? '' : !amount || amt <= 0 ? 'Enter an amount' : amt > from ? 'Insufficient balance' : 'Confirm Transfer';
  const submit = async () => {
    setBusy(true); setMsg(null);
    const r = await api<WalletPayload>('/api/wallet/transfer', { from: toTrading ? 'funding' : 'trading', to: toTrading ? 'trading' : 'funding', amount, idempotency_key: newKey() });
    setBusy(false);
    if (r.ok) { setAmount(''); setMsg({ ok: true, text: 'Transfer successful.' }); void load(); } else setMsg({ ok: false, text: r.data.message ?? 'Transfer failed.' });
  };

  return <><Head title="Transfer — RushX"/>
    <div className="ov-shell dp-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>
    <AccountSubNav active="Funding"/>
    <main className="tw-card">
      <h1><ArrowLeftRight/> Internal Transfer</h1>
      <div className="tw-dir">
        <div><span><small>From</small><b>{toTrading ? 'Funding Account' : 'Trading Account'}</b></span><span className="r"><small>Balance</small><b>{fmt(from)} USDT</b></span></div>
        <button type="button" className={`tw-swap${toTrading ? '' : ' flip'}`} aria-label="Swap direction" onClick={() => { setToTrading(v => !v); setAmount(''); setMsg(null); }}><ArrowUpDown/></button>
        <div><span><small>To</small><b>{toTrading ? 'Trading Account' : 'Funding Account'}</b></span><span className="r"><small>Balance</small><b>{fmt(to)} USDT</b></span></div>
      </div>
      <span className="tw-lbl">Asset</span>
      <div className="tw-coin"><UsdtIcon size={28}/><b>USDT</b><small>Tether</small></div>
      <div className="tw-field"><label htmlFor="t-amt">Transfer Amount</label>
        <div className="tw-in big"><input id="t-amt" inputMode="decimal" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ''))}/><span>USDT</span><button type="button" className="tw-max" onClick={() => setAmount(from > 0 ? floor2(from).toFixed(2) : '')}>Max</button></div>
        <div className="tw-hint" style={{ justifyContent: 'flex-end' }}><span>Available to transfer:&nbsp;<b>{fmt(from)} USDT</b></span></div></div>
      {msg && <div className={msg.ok ? 'tw-ok' : 'tw-err'} role="status">{msg.text}</div>}
      <button type="button" className="tw-cta" disabled={busy || label !== 'Confirm Transfer'} onClick={submit}>{busy ? <Loader2 className="dp-spin"/> : label}</button>
    </main></div></>;
}
