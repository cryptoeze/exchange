import { useCallback, useEffect, useMemo, useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import { ArrowRightLeft, ChevronDown, Clock, List, Loader2, Search, X } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import LiveChart, { type ChartLine } from '../components/LiveChart';
import CoinImage from '../components/CoinImage';
import type { Favorite, Market, MarketSnapshot } from '../types/market';
import { api, newKey, type OrderRow, type WalletPayload } from '../lib/wallet';
import '../../css/spot.css';

type Props = { pair?: string; auth?: { user: HeaderUser | null } };
type Level = [string, string];
type Trade = { p: string; v: string; S: string; T: number };
type Ticker = { price: number; high: number; low: number; turnover: number; change: number };

const TIMEFRAMES = [['1m', '1'], ['5m', '5'], ['15m', '15'], ['1H', '60'], ['4H', '240'], ['1D', 'D']] as const;
const ROWS = 14;

function decimals(price: number): [number, number] {
  if (price > 1000) return [2, 5];
  if (price > 1) return [4, 4];
  if (price > 0.001) return [6, 2];
  return [8, 0];
}
function fmtPrice(value: number, ref = value) {
  if (!Number.isFinite(value)) return '—';
  const d = decimals(ref)[0];
  return value.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
}
function fmtVol(value: number) {
  if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K`;
  return value.toFixed(2);
}
function fmtAmt(value: number, ref: number) {
  if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K`;
  return value.toFixed(decimals(ref)[1] || 4);
}
function pct(value: number) { return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`; }

function Logo({ market, size = 22 }: { market?: Pick<Market, 'icon' | 'baseAsset'>; size?: number }) {
  return <span className="sp-logo" style={{ width: size, height: size }}>{market ? <CoinImage symbol={market.baseAsset} icon={market.icon}/> : null}</span>;
}

export default function SpotPage({ pair: initialPair = 'BTCUSDT', auth }: Props) {
  const pageProps = usePage().props as Record<string, unknown>;
  const user = auth?.user ?? ((pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null);
  const brandName = (pageProps.siteName as string | undefined) || 'RushX';
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [symbol, setSymbol] = useState(initialPair);
  const [markets, setMarkets] = useState<Market[]>([]);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [leftTab, setLeftTab] = useState<'all' | 'favorites' | 'top'>('all');
  const [query, setQuery] = useState('');
  const [tf, setTf] = useState('1');
  const [ticker, setTicker] = useState<Ticker | null>(null);
  const [dir, setDir] = useState<'up' | 'down'>('up');
  const [asks, setAsks] = useState<Level[]>([]);
  const [bids, setBids] = useState<Level[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [rightTab, setRightTab] = useState<'book' | 'trades'>('book');
  const [pane, setPane] = useState<'trade' | 'book' | 'trades' | 'orders'>('trade'); // phone only: one panel at a time, the rest stay hidden until tapped
  const [chartOpen, setChartOpen] = useState(true);
  const [sidePane, setSidePane] = useState<'Buy' | 'Sell'>('Buy');
  const pickPane = (k: typeof pane) => { setPane(k); if (k === 'book' || k === 'trades') setRightTab(k); };
  const [orderTab, setOrderTab] = useState<'market' | 'limit' | 'tpsl'>('market');
  const [histTab, setHistTab] = useState<'open' | 'history'>('history');
  type LimitRow = { id: number; symbol: string; base: string; side: 'buy' | 'sell'; kind?: 'limit' | 'tp' | 'sl'; price: string; qty: string; status: string; at: string };
  const [tp, setTp] = useState<{ kind: 'tp' | 'sl'; price: string; qty: string }>({ kind: 'tp', price: '', qty: '' });
  const [limits, setLimits] = useState<LimitRow[]>([]);
  const [lp, setLp] = useState<{ buy: { price: string; qty: string }; sell: { price: string; qty: string } }>({ buy: { price: '', qty: '' }, sell: { price: '', qty: '' } });
  const loadLimits = useCallback(async () => { const r = await api<{ open: LimitRow[] }>('/api/spot/limit'); if (r.ok) setLimits(r.data.open); }, []);
  const [buyAmt, setBuyAmt] = useState(''); const [sellAmt, setSellAmt] = useState('');
  const [buyPct, setBuyPct] = useState(0); const [sellPct, setSellPct] = useState(0);
  const [notice, setNotice] = useState('');
  const [noticeKind, setNoticeKind] = useState<'ok' | 'err'>('ok');
  const [wallet, setWallet] = useState<WalletPayload | null>(null);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [busy, setBusy] = useState<'buy' | 'sell' | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [chartHeight, setChartHeight] = useState(440);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  useEffect(() => { if (!user) return; void loadLimits(); const t = window.setInterval(() => { if (!document.hidden) void loadLimits(); }, 10000); return () => window.clearInterval(t); }, [user, loadLimits]);
  useEffect(() => { if (!notice) return; const t = window.setTimeout(() => setNotice(''), 3600); return () => window.clearTimeout(t); }, [notice]);

  // Pair list from the RushX market-data endpoint.
  useEffect(() => {
    let active = true; let timer = 0; const controller = new AbortController();
    const load = async () => {
      try {
        const response = await fetch('/api/markets?type=spot', { headers: { Accept: 'application/json' }, signal: controller.signal, credentials: 'same-origin' });
        const data = await response.json() as MarketSnapshot;
        if (active && Array.isArray(data.markets)) setMarkets(data.markets);
      } catch { /* list retries */ }
      if (active) timer = window.setTimeout(load, 20_000);
    };
    void load();
    return () => { active = false; controller.abort(); window.clearTimeout(timer); };
  }, []);
  useEffect(() => {
    (async () => {
      if (user) {
        try { const r = await fetch('/api/market-favorites', { headers: { Accept: 'application/json' }, credentials: 'same-origin' }); const d = await r.json() as { favorites: Favorite[] }; if (r.ok) setFavorites(new Set(d.favorites.filter(f => f.marketType === 'spot').map(f => f.symbol))); } catch { /* optional */ }
      } else {
        try { const l = JSON.parse(localStorage.getItem('rushx-market-favorites') ?? '[]') as Favorite[]; setFavorites(new Set(l.filter(f => f.marketType === 'spot').map(f => f.symbol))); } catch { /* optional */ }
      }
    })();
  }, [user]);

  const refreshAccount = useCallback(async () => {
    if (!user) return;
    const [w, o] = await Promise.all([api<WalletPayload>('/api/wallet'), api<{ orders: OrderRow[] }>('/api/spot/orders')]);
    if (w.ok) setWallet(w.data);
    if (o.ok) setOrders(o.data.orders);
  }, [user]);
  useEffect(() => { void refreshAccount(); const t = window.setInterval(() => { if (!document.hidden) void refreshAccount(); }, 6000); return () => window.clearInterval(t); }, [refreshAccount]);

  const current = markets.find(m => m.symbol === symbol);
  const base = symbol.replace(/USDT$/, '');
  const funding = (asset: string) => (wallet?.balances.find(b => b.account === 'funding' && b.asset === asset)?.units ?? 0) / 1e8;
  const usdtBal = funding('USDT'); const baseBal = funding(base);
  // Average buy price of what the user currently holds on this pair, drawn on the chart (only when order history explains the balance).
  const holdLines: ChartLine[] = (() => {
    if (baseBal <= 0 || !ticker) return [];
    let q = 0; let avg = 0;
    for (const o of [...orders].reverse().filter(x => x.symbol === symbol && x.status === 'filled')) {
      const qty = Number(String(o.quantity).replace(/,/g, '')); if (o.side === 'buy') { avg = (avg * q + o.price * qty) / (q + qty || 1); q += qty; } else q = Math.max(0, q - qty);
    }
    if (q <= 0 || avg <= 0 || Math.abs(q - baseBal) / baseBal > 0.02) return [];
    const pnl = (ticker.price - avg) * baseBal; const ratio = (ticker.price / avg - 1) * 100;
    return [{ id: 'hold', price: avg, color: pnl >= 0 ? '#0ecb81' : '#f6465d', dashed: true, title: `HOLD ${baseBal.toFixed(6).replace(/0+$/, '').replace(/\.$/, '')} ${base}  ${pnl >= 0 ? '+' : '-'}$${Math.abs(pnl).toFixed(2)} (${ratio >= 0 ? '+' : ''}${ratio.toFixed(2)}%)` }];
  })();
  useEffect(() => {
    if (current && !ticker) { setTicker({ price: current.lastPrice, high: current.high24h, low: current.low24h, turnover: current.turnover24h, change: current.change24h }); }
  }, [current, ticker]);
  useEffect(() => { document.title = `${base}/USDT ${ticker ? fmtPrice(ticker.price) : ''} — ${brandName} Spot`; }, [base, ticker, brandName]);

  // Live Bybit public stream: ticker, order book, trades.
  useEffect(() => {
    setTicker(null); setAsks([]); setBids([]); setTrades([]);
    const askMap = new Map<string, string>(); const bidMap = new Map<string, string>();
    let ws: WebSocket | null = null; let ping = 0; let retry = 0; let closed = false; let lastBook = 0; let prev = 0;
    const flushBook = () => {
      const sort = (m: Map<string, string>, desc: boolean) => [...m.entries()].filter(([, v]) => parseFloat(v) > 0).sort((a, b) => desc ? parseFloat(b[0]) - parseFloat(a[0]) : parseFloat(a[0]) - parseFloat(b[0])).slice(0, ROWS) as Level[];
      setAsks(sort(askMap, false)); setBids(sort(bidMap, true));
    };
    const apply = (m: Map<string, string>, levels: Level[] | undefined) => { levels?.forEach(([p, v]) => { if (parseFloat(v) === 0) m.delete(p); else m.set(p, v); }); };
    const connect = () => {
      ws = new WebSocket('wss://stream.bybit.com/v5/public/spot');
      ws.onopen = () => { ws?.send(JSON.stringify({ op: 'subscribe', args: [`tickers.${symbol}`, `orderbook.50.${symbol}`, `publicTrade.${symbol}`] })); ping = window.setInterval(() => { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ op: 'ping' })); }, 20_000); };
      ws.onmessage = event => {
        try {
          const msg = JSON.parse(event.data); if (!msg.topic || !msg.data) return;
          if (msg.topic.startsWith('tickers.')) {
            const d = msg.data; const price = parseFloat(d.lastPrice);
            if (price > 0) { setDir(price >= prev ? 'up' : 'down'); prev = price; setTicker(t => ({ price, high: d.highPrice24h ? parseFloat(d.highPrice24h) : t?.high ?? 0, low: d.lowPrice24h ? parseFloat(d.lowPrice24h) : t?.low ?? 0, turnover: d.turnover24h ? parseFloat(d.turnover24h) : t?.turnover ?? 0, change: d.price24hPcnt ? parseFloat(d.price24hPcnt) * 100 : t?.change ?? 0 })); }
          } else if (msg.topic.startsWith('orderbook.')) {
            if (msg.type === 'snapshot') { askMap.clear(); bidMap.clear(); }
            apply(askMap, msg.data.a); apply(bidMap, msg.data.b);
            const now = Date.now(); if (now - lastBook > 120) { lastBook = now; flushBook(); }
          } else if (msg.topic.startsWith('publicTrade.')) {
            setTrades(list => [...(msg.data as Trade[]).slice().reverse(), ...list].slice(0, 40));
          }
        } catch { /* ignore malformed frame */ }
      };
      const reconnect = () => { window.clearInterval(ping); if (!closed) { retry = window.setTimeout(connect, 2000); } };
      ws.onclose = reconnect; ws.onerror = () => ws?.close();
    };
    connect();
    return () => { closed = true; window.clearInterval(ping); window.clearTimeout(retry); ws?.close(); };
  }, [symbol]);

  const select = useCallback((next: string) => {
    if (next === symbol) { setDrawer(false); return; }
    setSymbol(next); setDrawer(false); setBuyAmt(''); setSellAmt(''); setBuyPct(0); setSellPct(0);
    window.history.replaceState({}, '', `/spot?pair=${next}`);
  }, [symbol]);

  const list = useMemo(() => {
    let items = markets;
    if (leftTab === 'favorites') items = items.filter(m => favorites.has(m.symbol));
    if (leftTab === 'top') items = items.slice(0, 50);
    const q = query.trim().toLowerCase(); if (q) items = items.filter(m => m.symbol.toLowerCase().includes(q) || m.displayName.toLowerCase().includes(q));
    return items.slice(0, 120);
  }, [markets, leftTab, favorites, query]);

  const ref = ticker?.price ?? current?.lastPrice ?? 0;
  const cumulative = (levels: Level[]) => { let sum = 0; return levels.map(([p, v]) => { sum += parseFloat(p) * parseFloat(v); return sum; }); };
  const askCum = cumulative(asks); const bidCum = cumulative(bids);
  const maxCum = Math.max(askCum[askCum.length - 1] ?? 0, bidCum[bidCum.length - 1] ?? 0, 1);

  const startResize = (event: React.PointerEvent) => {
    event.preventDefault(); const startY = event.clientY; const startH = chartHeight;
    const move = (e: PointerEvent) => setChartHeight(Math.max(260, Math.min(window.innerHeight - 220, startH + e.clientY - startY)));
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
  };

  const flash = (text: string, kind: 'ok' | 'err') => { setNoticeKind(kind); setNotice(text); };
  const place = async (side: 'Buy' | 'Sell') => {
    if (!user) { router.visit('/login'); return; }
    const key = side.toLowerCase() as 'buy' | 'sell';
    const amount = (key === 'buy' ? buyAmt : sellAmt).trim();
    if (!/^\d+(\.\d{1,8})?$/.test(amount) || Number(amount) <= 0) { flash('Enter a valid amount.', 'err'); return; }
    if (busy) return;
    setBusy(key);
    try {
      const r = await api<WalletPayload & { order: OrderRow }>('/api/spot/orders', { symbol, side: key, amount, idempotency_key: newKey() });
      if (r.ok) {
        flash(`${side === 'Buy' ? 'Bought' : 'Sold'} ${r.data.order.quantity} ${base} at ${fmtPrice(r.data.order.price)}`, 'ok');
        setWallet({ balances: r.data.balances, history: r.data.history, serverTime: r.data.serverTime });
        if (key === 'buy') { setBuyAmt(''); setBuyPct(0); } else { setSellAmt(''); setSellPct(0); }
        void refreshAccount();
      } else {
        flash(r.status === 419 ? 'Session expired. Refresh the page and try again.' : (r.data.message ?? 'Order failed.'), 'err');
      }
    } catch { flash('Network error. Please try again.', 'err'); }
    finally { setBusy(null); }
  };
  const pick = (kind: 'Buy' | 'Sell', n: number) => {
    const buy = kind === 'Buy'; const bal = buy ? usdtBal : baseBal; const digits = buy ? 2 : 6;
    const value = n === 0 ? '' : (Math.floor(bal * (n / 100) * 10 ** digits) / 10 ** digits).toFixed(digits);
    (buy ? setBuyAmt : setSellAmt)(value); (buy ? setBuyPct : setSellPct)(n);
  };
  const book = (
    <>
      <div className="sp-ob-head"><span>Price (USDT)</span><span>Amount ({base})</span></div>
      <div className="sp-ob-rows sp-asks">{[...asks].reverse().map(([p, v], i) => { const idx = asks.length - 1 - i; return <div className="sp-ob-row ask" key={p}><i style={{ width: `${Math.min(100, (askCum[idx] / maxCum) * 100)}%` }}/><b>{fmtPrice(parseFloat(p), ref)}</b><span>{fmtAmt(parseFloat(v), ref)}</span></div>; })}</div>
      <div className="sp-ob-mid"><b className={dir}>{ticker ? fmtPrice(ticker.price) : '---.--'}</b></div>
      <div className="sp-ob-rows sp-bids">{bids.map(([p, v], i) => <div className="sp-ob-row bid" key={p}><i style={{ width: `${Math.min(100, (bidCum[i] / maxCum) * 100)}%` }}/><b>{fmtPrice(parseFloat(p), ref)}</b><span>{fmtAmt(parseFloat(v), ref)}</span></div>)}</div>
    </>
  );
  const tape = (
    <>
      <div className="sp-ob-head"><span>Price (USDT)</span><span className="grow">Amount</span><span className="time">Time</span></div>
      <div className="sp-tape">{trades.map((t, i) => <div className="sp-tape-row" key={`${t.T}-${i}`}><b className={t.S === 'Buy' ? 'up' : 'down'}>{fmtPrice(parseFloat(t.p), ref)}</b><span className="grow">{fmtAmt(parseFloat(t.v), ref)}</span><span className="time">{new Date(Number(t.T)).toLocaleTimeString('en-US', { hour12: false })}</span></div>)}</div>
    </>
  );

  const placeLimit = async (kind: 'Buy' | 'Sell') => {
    if (!user) { router.visit('/login'); return; }
    const k = kind.toLowerCase() as 'buy' | 'sell'; const v = lp[k];
    if (!/^\d+(\.\d+)?$/.test(v.price) || !/^\d+(\.\d{1,8})?$/.test(v.qty) || Number(v.price) <= 0 || Number(v.qty) <= 0) { flash('Enter a price and an amount.', 'err'); return; }
    setBusy(k);
    try {
      const r = await api<{ open: LimitRow[]; placed: string }>('/api/spot/limit', { symbol, side: k, price: v.price, amount: v.qty });
      if (r.ok) { setLimits(r.data.open); flash(r.data.placed === 'filled' ? `${kind === 'Buy' ? 'Bought' : 'Sold'} ${v.qty} ${base} at market` : `Limit ${k} placed at ${v.price}`, 'ok'); setLp(x => ({ ...x, [k]: { ...x[k], qty: '' } })); if (r.data.placed !== 'filled') setHistTab('open'); void refreshAccount(); }
      else flash(r.data.message ?? 'Order failed.', 'err');
    } catch { flash('Network error. Please try again.', 'err'); } finally { setBusy(null); }
  };
  const cancelLimit = async (id: number) => { const r = await api<{ open: LimitRow[] }>(`/api/spot/limit/${id}/cancel`, {}); if (r.ok) { setLimits(r.data.open); void refreshAccount(); flash('Order cancelled.', 'ok'); } else flash(r.data.message ?? 'Could not cancel.', 'err'); };
  const limitSide = (kind: 'Buy' | 'Sell') => {
    const k = kind.toLowerCase() as 'buy' | 'sell'; const buy = k === 'buy'; const v = lp[k];
    const set = (patch: Partial<{ price: string; qty: string }>) => setLp(x => ({ ...x, [k]: { ...x[k], ...patch } }));
    const total = Number(v.price) * Number(v.qty) || 0;
    const fillPct = (n: number) => { const px = Number(v.price) || ref; if (!px) return; const q = buy ? (usdtBal * n / 100) / (px * (1 + 0.001)) : baseBal * n / 100; set({ qty: q > 0 ? q.toFixed(6).replace(/0+$/, '').replace(/\.$/, '') : '' }); };
    return <div className="sp-side">
      <div className="sp-input"><span className="pre">Price</span><input type="number" inputMode="decimal" step="any" placeholder={ref ? fmtPrice(ref) : '0'} value={v.price} onChange={e => set({ price: e.target.value })} aria-label={`${kind} limit price`}/><span className="suf">USDT</span></div>
      <div className="sp-input"><span className="pre">Amount</span><input type="number" inputMode="decimal" step="any" placeholder="0.00" value={v.qty} onChange={e => set({ qty: e.target.value })} aria-label={`${kind} limit amount`}/><span className="suf">{base}</span></div>
      <div className="sp-slider"><div className="sp-marks">{[25, 50, 75, 100].map(n => <button type="button" key={n} onClick={() => fillPct(n)}>{n}%</button>)}<button type="button" onClick={() => ref && set({ price: String(ref) })}>Last</button></div></div>
      <div className="sp-avail"><span>Total: <b>{total ? total.toLocaleString('en-US', { maximumFractionDigits: 2 }) : '—'}</b> USDT · Available: <b>{user ? (buy ? usdtBal.toFixed(2) : baseBal.toFixed(6).replace(/0+$/, '').replace(/\.$/, '') || '0') : '—'}</b> {buy ? 'USDT' : base}</span></div>
      <button type="button" className={`sp-trade ${buy ? 'buy' : 'sell'}`} disabled={busy !== null} onClick={() => placeLimit(kind)}>{!user ? 'Sign in to trade' : busy === k ? 'Placing…' : `${kind} ${base} (Limit)`}</button>
    </div>;
  };
  const placeTpsl = async () => {
    if (!user) { router.visit('/login'); return; }
    if (!/^\d+(\.\d+)?$/.test(tp.price) || !/^\d+(\.\d{1,8})?$/.test(tp.qty) || Number(tp.price) <= 0 || Number(tp.qty) <= 0) { flash('Enter a trigger price and an amount.', 'err'); return; }
    setBusy('sell');
    try {
      const r = await api<{ open: LimitRow[] }>('/api/spot/limit', { symbol, side: 'sell', price: tp.price, amount: tp.qty, kind: tp.kind });
      if (r.ok) { setLimits(r.data.open); flash(`${tp.kind === 'tp' ? 'Take-profit' : 'Stop-loss'} set at ${tp.price}`, 'ok'); setTp(x => ({ ...x, qty: '' })); setHistTab('open'); void refreshAccount(); }
      else flash(r.data.message ?? 'Order failed.', 'err');
    } catch { flash('Network error. Please try again.', 'err'); } finally { setBusy(null); }
  };
  const tpslPanel = () => {
    const fillPct = (n: number) => { const q = baseBal * n / 100; setTp(x => ({ ...x, qty: q > 0 ? q.toFixed(6).replace(/0+$/, '').replace(/\.$/, '') : '' })); };
    const px = Number(tp.price) || 0; const total = px * Number(tp.qty) || 0;
    return <div className="sp-side">
      <div className="sp-tpk" role="group"><button type="button" className={`buy${tp.kind === 'tp' ? ' on' : ''}`} onClick={() => setTp(x => ({ ...x, kind: 'tp' }))}>Take profit</button><button type="button" className={`sell${tp.kind === 'sl' ? ' on' : ''}`} onClick={() => setTp(x => ({ ...x, kind: 'sl' }))}>Stop loss</button></div>
      <div className="sp-input"><span className="pre">Trigger</span><input type="number" inputMode="decimal" step="any" placeholder={ref ? fmtPrice(ref) : '0'} value={tp.price} onChange={e => setTp(x => ({ ...x, price: e.target.value }))} aria-label="Trigger price"/><span className="suf">USDT</span></div>
      <div className="sp-input"><span className="pre">Amount</span><input type="number" inputMode="decimal" step="any" placeholder="0.00" value={tp.qty} onChange={e => setTp(x => ({ ...x, qty: e.target.value }))} aria-label="Amount to sell"/><span className="suf">{base}</span></div>
      <div className="sp-slider"><div className="sp-marks">{[25, 50, 75, 100].map(n => <button type="button" key={n} onClick={() => fillPct(n)}>{n}%</button>)}</div></div>
      <div className="sp-avail"><span>{tp.kind === 'tp' ? 'Sells when price rises to the trigger.' : 'Sells when price falls to the trigger.'} Est. <b>{total ? total.toLocaleString('en-US', { maximumFractionDigits: 2 }) : '—'}</b> USDT · Available: <b>{user ? baseBal.toFixed(6).replace(/0+$/, '').replace(/\.$/, '') || '0' : '—'}</b> {base}</span></div>
      <button type="button" className="sp-trade sell" disabled={busy !== null} onClick={placeTpsl}>{!user ? 'Sign in to trade' : busy === 'sell' ? 'Placing…' : `Set ${tp.kind === 'tp' ? 'take-profit' : 'stop-loss'}`}</button>
    </div>;
  };
  const side = (kind: 'Buy' | 'Sell') => {
    const buy = kind === 'Buy'; const value = buy ? buyAmt : sellAmt; const pctVal = buy ? buyPct : sellPct;
    const setValue = buy ? setBuyAmt : setSellAmt; const setP = buy ? setBuyPct : setSellPct;
    return <div className="sp-side">
      <div className="sp-input disabled"><span className="pre">Price</span><input readOnly value="Market"/><span className="suf">USDT</span></div>
      <div className="sp-input"><span className="pre">Amount</span><input type="number" inputMode="decimal" step="any" placeholder="Min 0.00001" value={value} onChange={e => { setValue(e.target.value); setP(0); }} aria-label={`${kind} amount`}/><span className="suf">{buy ? 'USDT' : base}</span></div>
      <div className="sp-slider"><input type="range" min={0} max={100} value={pctVal} style={{ background: `linear-gradient(to right, var(--sp-sub) ${pctVal}%, var(--sp-line) ${pctVal}%)` }} onChange={e => pick(kind, Number(e.target.value))} aria-label={`${kind} percentage`}/><div className="sp-marks">{[0, 25, 50, 75, 100].map(n => <button type="button" key={n} onClick={() => pick(kind, n)}>{n}%</button>)}</div></div>
      <div className="sp-avail"><span>Available: <b>{user ? (buy ? usdtBal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : baseBal.toFixed(6).replace(/0+$/, '').replace(/\.$/, '') || '0') : '—'}</b> {buy ? 'USDT' : base}</span>{buy && <button type="button" className="sp-xfer" aria-label="Transfer funds" onClick={() => router.visit('/assets')}><ArrowRightLeft aria-hidden="true"/></button>}</div>
      <button type="button" className={`sp-trade ${buy ? 'buy' : 'sell'}`} disabled={busy !== null} onClick={() => place(kind)}>{!user ? 'Sign in to trade' : busy === kind.toLowerCase() ? 'Placing…' : `${kind} ${base}`}</button>
    </div>;
  };

  return <><Head title={`Spot Trading — ${brandName}`}><meta name="theme-color" content={dark ? '#000000' : '#ffffff'}/></Head>
    <div className="sp-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>
    {notice && <div className={`sp-toast ${noticeKind}`} role="status">{notice}</div>}
    <div className="sp-layout">
      <aside className={`sp-left${drawer ? ' open' : ''}`}>
        <div className="sp-drawer-head"><b>Select pair</b><button type="button" aria-label="Close pairs" onClick={() => setDrawer(false)}><X/></button></div>
        <div className="sp-search"><Search/><input placeholder="Search crypto" value={query} onChange={e => setQuery(e.target.value)} autoComplete="off" spellCheck={false} aria-label="Search trading pairs"/></div>
        <div className="sp-ltabs">{(['all', 'favorites', 'top'] as const).map(t => <button type="button" key={t} className={leftTab === t ? 'active' : ''} onClick={() => setLeftTab(t)}>{t === 'all' ? 'All' : t === 'favorites' ? 'Favorites' : 'Top'}</button>)}</div>
        <div className="sp-lhead"><span>Trading pair</span><span><i>Last price</i><i>Change</i></span></div>
        <div className="sp-list">{markets.length === 0 ? <div className="sp-empty"><Loader2 className="spin"/></div> : list.length === 0 ? <div className="sp-empty">{leftTab === 'favorites' ? 'Star markets on the Markets page to see them here.' : 'No pairs found'}</div> : list.map(m => <button type="button" className={`sp-pair${m.symbol === symbol ? ' active' : ''}`} key={m.symbol} onClick={() => select(m.symbol)}>
          <span className="pl"><Logo market={m}/><span><b>{m.baseAsset}/USDT</b><small>Vol {fmtVol(m.turnover24h)}</small></span></span>
          <span className="pr"><span>{fmtPrice(m.lastPrice)}</span><span className={m.change24h >= 0 ? 'up' : 'down'}>{pct(m.change24h)}</span></span>
        </button>)}</div>
      </aside>
      {drawer && <button type="button" className="sp-scrim" aria-label="Close pairs" onClick={() => setDrawer(false)}/>}

      <main className="sp-center" data-pane={pane} data-chart={chartOpen ? 1 : 0}>
        <div className="sp-head">
          <button type="button" className="sp-pairbtn" onClick={() => setDrawer(true)} aria-label="Change trading pair"><Logo market={current ?? { icon: null, baseAsset: base }} size={26}/><h1>{base}/USDT</h1><ChevronDown/></button>
          <div className={`sp-price ${dir}`}>{ticker ? fmtPrice(ticker.price) : '---.--'}</div>
          <div className={`sp-change ${(ticker?.change ?? 0) >= 0 ? 'up' : 'down'}`}>{ticker ? pct(ticker.change) : ''}</div>
          <div className="sp-stats">
            <div><span>24h High</span><b>{ticker ? fmtPrice(ticker.high, ref) : '--'}</b></div>
            <div><span>24h Low</span><b>{ticker ? fmtPrice(ticker.low, ref) : '--'}</b></div>
            <div><span>24h Vol(USDT)</span><b>{ticker ? `${(ticker.turnover / 1e6).toFixed(2)}M` : '--'}</b></div>
          </div>
        </div>

        <div className="sp-tfbar" role="group" aria-label="Chart timeframe">{TIMEFRAMES.map(([label, value]) => <button type="button" key={value} className={tf === value ? 'active' : ''} onClick={() => setTf(value)}>{label}</button>)}<button type="button" className="sp-chartbtn" onClick={() => setChartOpen(v => !v)} aria-expanded={chartOpen}>{chartOpen ? 'Hide' : 'Chart'}</button></div>
        <div className="sp-chart" style={{ height: chartHeight }} hidden={!chartOpen}><LiveChart symbol={symbol} interval={tf} dark={dark} market="spot" lines={holdLines}/></div>
        <div className="sp-resizer" onPointerDown={startResize} role="separator" aria-orientation="horizontal" aria-label="Resize chart"/>

        <div className="sp-panes" role="tablist">{([['trade', 'Trade'], ['book', 'Order book'], ['trades', 'Recent trades'], ['orders', 'My orders']] as const).map(([k, l]) => <button type="button" role="tab" aria-selected={pane === k} key={k} className={pane === k ? 'on' : ''} onClick={() => pickPane(k)}>{l}</button>)}</div>
        <section className="sp-mobile-book" aria-label="Order book">
          <div className="sp-rtabs"><button type="button" className={rightTab === 'book' ? 'active' : ''} onClick={() => setRightTab('book')}>Order book</button><button type="button" className={rightTab === 'trades' ? 'active' : ''} onClick={() => setRightTab('trades')}>Recent trades</button></div>
          {rightTab === 'book' ? book : tape}
        </section>

        <section className="sp-order">
          <div className="sp-otabs">{([['market', 'Market'], ['limit', 'Limit'], ['tpsl', 'TP/SL']] as const).map(([k, l]) => <button type="button" key={k} className={orderTab === k ? 'active' : ''} onClick={() => setOrderTab(k)}>{l}</button>)}</div>
          <div className="sp-bsw" role="group"><button type="button" className={`buy${sidePane === 'Buy' ? ' on' : ''}`} onClick={() => setSidePane('Buy')}>Buy</button><button type="button" className={`sell${sidePane === 'Sell' ? ' on' : ''}`} onClick={() => setSidePane('Sell')}>Sell</button></div>
          <div className="sp-sides" data-s={orderTab === 'tpsl' ? 'Sell' : sidePane}>{orderTab === 'tpsl' ? tpslPanel() : orderTab === 'limit' ? <>{limitSide('Buy')}{limitSide('Sell')}</> : <>{side('Buy')}{side('Sell')}</>}</div>
        </section>

        <section className="sp-history">
          <div className="sp-htabs"><button type="button" className={histTab === 'open' ? 'active' : ''} onClick={() => setHistTab('open')}>Open orders ({limits.length})</button><button type="button" className={histTab === 'history' ? 'active' : ''} onClick={() => setHistTab('history')}>Order history</button></div>
          {histTab === 'open' ? (limits.length === 0 ? <div className="sp-hempty"><List/><b>No open orders</b><span>Limit orders waiting for their price appear here.</span></div>
            : <div className="sp-orders"><table><thead><tr><th>Time</th><th>Pair</th><th>Side</th><th>Price</th><th>Amount</th><th/></tr></thead><tbody>{limits.map(o => <tr key={o.id}><td>{new Date(o.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td><td><b>{o.symbol}</b></td><td className={o.side === 'buy' ? 'up' : 'down'}>{o.side === 'buy' ? 'Buy' : 'Sell'}</td><td>{o.kind === 'tp' ? 'TP ≥ ' : o.kind === 'sl' ? 'SL ≤ ' : ''}{o.price}</td><td>{o.qty} {o.base}</td><td><button type="button" className="sp-cancel" onClick={() => cancelLimit(o.id)}>Cancel</button></td></tr>)}</tbody></table></div>)
          : orders.length === 0 ? <div className="sp-hempty"><Clock/><b>{user ? 'No order history' : 'Sign in to see your orders'}</b><span>Your filled orders will be listed here.</span></div>
          : <div className="sp-orders"><table><thead><tr><th>Time</th><th>Pair</th><th>Side</th><th>Executed price</th><th>Amount / Total</th><th>Status</th></tr></thead><tbody>{orders.map(o => <tr key={o.id}><td>{o.at ? new Date(o.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}</td><td><b>{o.symbol}</b></td><td className={o.side === 'buy' ? 'up' : 'down'}>{o.side === 'buy' ? 'Buy' : 'Sell'}</td><td>${fmtPrice(o.price)}</td><td>{o.quantity} {o.base} / ${o.total}</td><td className="muted">Filled</td></tr>)}</tbody></table></div>}
        </section>
      </main>

      <aside className="sp-right">
        <div className="sp-rtabs"><button type="button" className={rightTab === 'book' ? 'active' : ''} onClick={() => setRightTab('book')}>Order book</button><button type="button" className={rightTab === 'trades' ? 'active' : ''} onClick={() => setRightTab('trades')}>Recent trades</button></div>
        {rightTab === 'book' ? book : tape}
      </aside>
    </div></div></>;
}
