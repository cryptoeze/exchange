import { useCallback, useEffect, useState } from 'react';
import { Check, ChevronDown, Eye, EyeOff } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { api, newKey, usd } from '../lib/wallet';
import '../../css/earn-bots.css';

type Product = { id: number; asset: string; name: string; apr: number; minAmount: string; enabled: boolean; staked: string; stakedUnits: number; funding: string; trading: string };
type Payload = { products: Product[]; totalStaked: string; yesterday: string; totalEarned: string };

/** Staking dashboard. Interest is real: it is paid into the Funding account at the rate set by the platform. */
export default function Earn() {
  const [data, setData] = useState<Payload | null>(null);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<number | null>(null);
  const [mode, setMode] = useState<'stake' | 'unstake'>('stake');
  const [from, setFrom] = useState<'funding' | 'trading'>('funding');
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ ok: boolean; text: string } | null>(null);
  const [visible, setVisible] = useState(true);
  const [key, setKey] = useState(newKey);

  const load = useCallback(async () => {
    const r = await api<Payload>('/api/earn');
    if (r.status === 401) { window.location.href = '/login'; return; }
    if (r.ok) { setData(r.data); setError(''); setSelected(cur => cur ?? r.data.products[0]?.id ?? null); } else setError('Earn data could not be loaded.');
  }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 15000); return () => window.clearInterval(t); }, [load]);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(null), 4000); return () => window.clearTimeout(t); }, [toast]);

  const product = data?.products.find(p => p.id === selected) ?? null;
  const available = product ? (mode === 'stake' ? Number(from === 'funding' ? product.funding : product.trading) : product.stakedUnits / 1e8) : 0;
  const value = Number(amount);
  const min = product ? Number(product.minAmount.replace(/,/g, '')) : 0;
  const valid = !!product && /^\d+(\.\d{1,8})?$/.test(amount) && value > 0 && value <= available + 1e-9 && (mode === 'unstake' || (value >= min && product.enabled));
  const mask = (t: string) => visible ? t : '********';

  const submit = async () => {
    if (!product || !valid || busy) return;
    setBusy(true);
    const r = await api<Payload>(mode === 'stake' ? '/api/earn/stake' : '/api/earn/unstake', { product_id: product.id, amount, from, idempotency_key: key });
    setBusy(false);
    if (r.ok) { setData(r.data); setAmount(''); setKey(newKey()); setToast({ ok: true, text: mode === 'stake' ? `Staked ${product.asset}` : `Unstaked ${product.asset}` }); } else setToast({ ok: false, text: r.data.message ?? 'Request failed.' });
  };
  const fmtAvail = (n: number) => n === 0 ? '0.00' : String(Math.floor(n * 1e8) / 1e8);

  return <AccountLayout active="Grow" title="Earn">
    <main className="ea-grid">
      <div>
        <h1 className="ea-h1">Staking Dashboard</h1>
        <p className="ea-p">Earn passive income on your idle assets with flexible staking. Unstake any time.</p>
        <section className="ea-card">
          <div className="ea-lbl">TOTAL STAKED BALANCE <button type="button" aria-label={visible ? 'Hide balances' : 'Show balances'} onClick={() => setVisible(v => !v)}>{visible ? <Eye/> : <EyeOff/>}</button></div>
          <div className="ea-big"><span>{data ? mask(usd(Number(data.totalStaked.replace(/,/g, '')))) : '—'}</span><small>USDT</small></div>
          <div className="ea-pills"><span className="ea-pill">Est. Yesterday's Profit: <b className="up">{data ? mask(`+${data.yesterday} USDT`) : '—'}</b></span><span className="ea-pill">Total earned: <b className="up">{data ? mask(`${data.totalEarned} USDT`) : '—'}</b></span></div>
        </section>
        <h2 className="ea-h2">Available Staking Products</h2>
        <div className="ea-table"><table><thead><tr><th>Asset</th><th>Est. APR</th><th>Term</th><th className="r">Your stake</th></tr></thead>
          <tbody>{!data ? <tr><td colSpan={4} className="ea-empty">{error || 'Loading…'}</td></tr> : data.products.length === 0 ? <tr><td colSpan={4} className="ea-empty">No staking products are open right now.</td></tr> : data.products.map(p => <tr key={p.id} className={p.id === selected ? 'sel' : ''} onClick={() => setSelected(p.id)}>
            <td><div className="ea-asset"><span className="ea-ico">{p.asset.slice(0, 1)}</span><div><b>{p.asset} <em>STABLE</em></b><small>{p.name}{!p.enabled && ' · closed to new deposits'}</small></div></div></td>
            <td className="apr">{p.apr.toFixed(2)}%</td><td>Flexible</td><td className="r">{mask(`${usd(p.stakedUnits / 1e8)} ${p.asset}`)}</td></tr>)}</tbody></table></div>
      </div>

      <aside className="ea-box">
        <div className="ea-tabs"><button type="button" className={mode === 'stake' ? 'active' : ''} onClick={() => { setMode('stake'); setAmount(''); }}>Stake</button><button type="button" className={mode === 'unstake' ? 'active' : ''} onClick={() => { setMode('unstake'); setAmount(''); }}>Unstake</button></div>
        <div className="ea-body">
          <label className="ea-l">{mode === 'stake' ? 'PAY FROM ACCOUNT' : 'RECEIVE TO ACCOUNT'}</label>
          {mode === 'stake' ? <div className="ea-select"><select value={from} onChange={e => { setFrom(e.target.value as 'funding' | 'trading'); setAmount(''); }} aria-label="Pay from account"><option value="funding">Funding Account</option><option value="trading">Trading Account</option></select><ChevronDown/></div>
            : <div className="ea-select static">Funding Account</div>}
          <label className="ea-l">AMOUNT</label>
          <div className="ea-input"><input inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value.replace(/[^\d.]/g, ''))} placeholder="0.00" aria-label="Amount" autoComplete="off"/><span>{product?.asset ?? 'USDT'}</span><button type="button" onClick={() => setAmount(available > 0 ? fmtAvail(available) : '')}>MAX</button></div>
          <div className="ea-avail">Available: <b>{mask(fmtAvail(available))}</b> {product?.asset ?? 'USDT'}</div>
          {product && mode === 'stake' && <p className="ea-hint">Minimum {product.minAmount} {product.asset}. Interest accrues every second and is paid to your Funding account.</p>}
          <button type="button" className={`ea-submit${valid ? ' ready' : ''}`} disabled={!valid || busy} onClick={submit}>{busy ? 'Processing…' : `${mode === 'stake' ? 'Stake' : 'Unstake'} ${product?.asset ?? 'USDT'}`}</button>
        </div>
      </aside>
    </main>
    {toast && <div className={`ea-toast ${toast.ok ? 'ok' : 'bad'}`} role="status"><Check/>{toast.text}</div>}
  </AccountLayout>;
}
