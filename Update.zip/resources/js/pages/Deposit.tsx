import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import QRCode from 'qrcode';
import { Check, ChevronDown, Copy, Download, FileText, Inbox, Loader2, Search } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import AccountSubNav from '../components/AccountSubNav';
import ManualDeposit from '../components/ManualDeposit';
import CoinImage from '../components/CoinImage';
import { api } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/deposit.css';
import '../../css/treasury.css';

type Network = { code: string; name: string; logo: string };
type Coin = { ticker: string; name: string; logo: string; networks: Network[] };
type DepositRow = { id: number; orderId: string; asset: string; network: string; address: string; memo: string | null; status: string; expected: string | null; paid: string | null; txHash: string | null; credited: string | null; at: string | null };

/** Provider logo with a fallback: USDT/USDC are drawn inline, anything else falls back to the shared icon chain if the image fails. */
function Logo({ src, ticker, className = '' }: { src: string; ticker: string; className?: string }) {
  const [bad, setBad] = useState(false);
  const inline = ticker === 'USDT' || ticker === 'USDC' || bad || !src;
  return inline ? <span className={`dp-ico ${className}`}><CoinImage symbol={ticker}/></span> : <img className={className} src={src} alt="" onError={() => setBad(true)}/>;
}

const FAQ = ['How do I make a deposit?', 'Why have I still not received my deposit?', 'How do I find my deposit address and tag/memos?', 'How to check the deposit progress?'];
const STATUS: Record<string, [string, 'wait' | 'busy' | 'ok' | 'bad', number]> = {
  waiting: ['Awaiting deposit', 'wait', 0], confirming: ['Confirming', 'busy', 40], confirmed: ['Confirming', 'busy', 70], sending: ['Crediting', 'busy', 90],
  finished: ['Received', 'ok', 100], partially_paid: ['Partially paid — contact support', 'bad', 60], failed: ['Failed', 'bad', 0], refunded: ['Refunded', 'bad', 0], expired: ['Expired', 'bad', 0],
};
const label = (status: string) => STATUS[status] ?? [status, 'wait', 0];
const short = (value: string, keep = 8) => value.length > keep * 2 + 3 ? `${value.slice(0, keep)}…${value.slice(-keep)}` : value;

export default function Deposit({ coins, available, manualAvailable = false, bonusPercent = 0 }: { coins: Coin[]; available: boolean; manualAvailable?: boolean; bonusPercent?: number }) {
  const [mode, setMode] = useState<'auto' | 'manual'>(() => (typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('mode') === 'manual') ? 'manual' : 'auto');
  const pageProps = usePage().props as Record<string, unknown>;
  const user = (pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [coin, setCoin] = useState<Coin | null>(null);
  const [network, setNetwork] = useState<Network | null>(null);
  const [open, setOpen] = useState<'coin' | 'net' | null>(null);
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [deposit, setDeposit] = useState<DepositRow | null>(null);
  const [history, setHistory] = useState<DepositRow[]>([]);
  const [qr, setQr] = useState('');
  const [copied, setCopied] = useState(false);
  const historyRef = useRef<HTMLDivElement>(null);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  useEffect(() => { const close = (e: PointerEvent) => { if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(null); }; document.addEventListener('pointerdown', close); return () => document.removeEventListener('pointerdown', close); }, []);

  const loadHistory = useCallback(async () => { const r = await api<{ deposits: DepositRow[] }>('/api/deposits'); if (r.ok) setHistory(r.data.deposits); }, []);
  useEffect(() => { void loadHistory(); const t = window.setInterval(() => { if (!document.hidden) void loadHistory(); }, 12000); return () => window.clearInterval(t); }, [loadHistory]);

  // Poll the open deposit so status changes (and the credit) appear without a refresh.
  useEffect(() => {
    if (!deposit || ['finished', 'failed', 'expired', 'refunded'].includes(deposit.status)) return;
    const t = window.setInterval(async () => { const r = await api<{ deposit: DepositRow }>(`/api/deposits/${deposit.orderId}`); if (r.ok) { setDeposit(r.data.deposit); if (r.data.deposit.status !== deposit.status) void loadHistory(); } }, 5000);
    return () => window.clearInterval(t);
  }, [deposit, loadHistory]);

  useEffect(() => { if (deposit) QRCode.toDataURL(deposit.address, { width: 272, margin: 1, errorCorrectionLevel: 'H', color: { dark: '#000000', light: '#ffffff' } }).then(setQr).catch(() => setQr('')); else setQr(''); }, [deposit?.address]);

  const filtered = useMemo(() => { const q = query.trim().toLowerCase(); return q ? coins.filter(c => c.ticker.toLowerCase().includes(q) || c.name.toLowerCase().includes(q)) : coins; }, [coins, query]);

  const pickCoin = (c: Coin) => { setCoin(c); setNetwork(null); setDeposit(null); setError(''); setOpen(c.networks.length ? 'net' : null); setQuery(''); };
  const pickNetwork = async (n: Network) => {
    setNetwork(n); setOpen(null); setError(''); setDeposit(null); setBusy(true);
    const r = await api<{ deposit: DepositRow }>('/api/deposits', { currency: n.code });
    setBusy(false);
    if (r.ok) { setDeposit(r.data.deposit); void loadHistory(); } else setError(r.data.message ?? 'Could not create a deposit address.');
  };
  const copy = async (text: string) => { try { await navigator.clipboard.writeText(text); setCopied(true); window.setTimeout(() => setCopied(false), 2200); } catch { /* clipboard blocked */ } };
  const exportCsv = () => {
    const rows = [['Time', 'Address', 'Transaction ID', 'Crypto', 'Network', 'Amount', 'Status'], ...history.map(d => [d.at ?? '', d.address, d.txHash ?? '', d.asset, d.network, d.credited ?? d.paid ?? '', label(d.status)[0]])];
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); link.download = 'deposits.csv'; link.click(); URL.revokeObjectURL(link.href);
  };

  const step1 = coin ? 'completed' : 'active'; const step2 = !coin ? 'faded' : network ? 'completed' : 'active'; const step3 = deposit ? 'active' : 'faded';
  const [statusText, statusKind] = deposit ? label(deposit.status) : ['', 'wait' as const];

  return <><Head title="Deposit — RushX"/>
    <div className="ov-shell dp-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>
    <AccountSubNav active="Funding"/>
    <main className="dp-main">
      <h1 className="dp-title">Deposit</h1>
      {bonusPercent > 0 && <div className="tw-bonus" role="note"><b>+{bonusPercent}% bonus</b> on every deposit — added to your Funding balance as real, tradable balance.</div>}
      <div className="tw-switch" role="tablist" aria-label="Deposit method"><button type="button" role="tab" aria-selected={mode === 'auto'} className={mode === 'auto' ? 'on' : ''} onClick={() => setMode('auto')}>Auto (NOWPayments)</button><button type="button" role="tab" aria-selected={mode === 'manual'} className={mode === 'manual' ? 'on' : ''} onClick={() => setMode('manual')}>Manual USDT{manualAvailable ? '' : ' · soon'}</button></div>
      <div className="dp-grid">
        {mode === 'manual' ? <div className="dp-steps"><ManualDeposit/></div> : <div className="dp-steps" ref={wrap}>
          {!available && <div className="dp-note" role="status">Deposits are being set up and will be available shortly.</div>}
          <div className={`dp-step ${step1}${open === 'coin' ? ' focus' : ''}`}>
            <span className="dp-dot">{coin ? <Check/> : 1}</span><div className="dp-stitle">Select crypto</div>
            <div className="dp-select">
              <button type="button" className={`dp-box${open === 'coin' ? ' open' : ''}`} onClick={() => setOpen(open === 'coin' ? null : 'coin')} aria-haspopup="listbox" aria-expanded={open === 'coin'} disabled={!available}>
                {coin ? <span className="dp-val"><Logo src={coin.logo} ticker={coin.ticker}/>{coin.ticker}</span> : <span className="dp-ph">Search crypto</span>}<ChevronDown/>
              </button>
              {open === 'coin' && <div className="dp-menu" role="listbox">
                <div className="dp-search"><Search/><input autoFocus placeholder="Search crypto" value={query} onChange={e => setQuery(e.target.value)} aria-label="Search crypto"/></div>
                {filtered.length === 0 ? <p className="dp-none">No results</p> : filtered.map(c => <button type="button" role="option" key={c.ticker} className="dp-item" onClick={() => pickCoin(c)}><Logo src={c.logo} ticker={c.ticker}/><span><b>{c.ticker}</b><small>{c.name}</small></span></button>)}
              </div>}
            </div>
          </div>

          <div className={`dp-step ${step2}${open === 'net' ? ' focus' : ''}`}>
            <span className="dp-dot">{network ? <Check/> : 2}</span><div className="dp-stitle">Select network {busy && <Loader2 className="dp-spin"/>}</div>
            <div className="dp-select">
              <button type="button" className={`dp-box${open === 'net' ? ' open' : ''}`} onClick={() => coin && setOpen(open === 'net' ? null : 'net')} aria-haspopup="listbox" aria-expanded={open === 'net'} disabled={!coin}>
                {network ? <span className="dp-val">{network.name}</span> : <span className="dp-ph">Select network</span>}<ChevronDown/>
              </button>
              {open === 'net' && coin && <div className="dp-menu" role="listbox">
                <div className="dp-mhead"><span>Network</span><span>Arrival</span></div>
                {coin.networks.map(n => <button type="button" role="option" key={n.code} className="dp-item between" onClick={() => pickNetwork(n)}><b>{n.name}</b><small>~ 2 min</small></button>)}
              </div>}
            </div>
            {error && <p className="dp-err" role="alert">{error}</p>}
          </div>

          <div className={`dp-step ${step3}`}>
            <span className="dp-dot">3</span><div className="dp-stitle">Deposit details</div>
            {deposit && <div className="dp-details">
              <div className="dp-qr">{qr ? <img src={qr} alt="Deposit address QR code"/> : <Loader2 className="dp-spin"/>}{coin && <Logo className="dp-qrlogo" src={network?.logo || coin.logo} ticker={coin.ticker}/>}</div>
              <div className="dp-data">
                <div><div className="dp-lbl">Address</div><div className="dp-addr"><code>{deposit.address}</code><button type="button" aria-label="Copy address" onClick={() => copy(deposit.address)}>{copied ? <Check/> : <Copy/>}</button></div></div>
                {deposit.memo && <div><div className="dp-lbl">Memo / Tag (required)</div><div className="dp-addr"><code>{deposit.memo}</code><button type="button" aria-label="Copy memo" onClick={() => copy(deposit.memo!)}><Copy/></button></div></div>}
                <div className="dp-rows">
                  <div><span>Minimum deposit</span><b>1.00 USD</b></div>
                  <div><span>Expected arrival</span><b>~ 2 minutes</b></div>
                  <div><span>Status</span><b className={`dp-pill ${statusKind}`}><i/>{statusText}{deposit.credited && ` · +${deposit.credited} ${deposit.asset}`}</b></div>
                </div>
                <p className="dp-warn">Send only {deposit.asset} on the {deposit.network} network to this address. Other assets or networks may be lost.</p>
              </div>
            </div>}
          </div>
        </div>}

        <aside className="dp-faq"><h2>FAQ</h2>{FAQ.map(q => <a key={q} href="/faq">{q}</a>)}</aside>
      </div>

      {mode === 'auto' && <section className="dp-table" ref={historyRef}>
        <header><div className="dp-tab">All deposits</div><div className="dp-tools"><button type="button" onClick={exportCsv} disabled={history.length === 0}><Download/> Export</button><button type="button" onClick={() => historyRef.current?.scrollIntoView({ behavior: 'smooth' })}><FileText/> View history</button></div></header>
        <div className="dp-scroll"><table><thead><tr><th>Time</th><th>Address</th><th>Transaction ID</th><th>Crypto</th><th>Amount</th><th>Progress</th><th>Status</th></tr></thead>
          <tbody>{history.length === 0 ? <tr><td colSpan={7}><div className="dp-empty"><span><Inbox/></span><b>No deposits yet</b><small>Your completed deposit history will be shown here.</small></div></td></tr> : history.map(d => { const [text, kind, pct] = label(d.status); return <tr key={d.id}>
            <td>{d.at ? new Date(d.at).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}</td>
            <td><code>{short(d.address, 6)}</code><small>{d.network}</small></td>
            <td>{d.txHash ? <code>{short(d.txHash, 6)}</code> : '—'}</td>
            <td>{d.asset}</td><td>{d.credited ?? d.paid ?? '—'}</td>
            <td><span className="dp-bar"><i style={{ width: `${pct}%` }}/></span></td>
            <td className={`dp-st ${kind}`}>{text}</td></tr>; })}</tbody></table></div>
      </section>}
    </main><MobileNav active="assets"/></div></>;
}
