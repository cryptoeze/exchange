import { useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import { ArrowLeft } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import TwoFactorPanel from '../components/TwoFactorPanel';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import { useTheme } from '../lib/hooks';
import '../../css/overview.css';
import '../../css/profile.css';

type Ev = { ok: boolean; note: string | null; ip: string | null; agent: string | null; at: string };
const input = { background: 'var(--ov-input)', color: 'var(--ov-text)', border: '1px solid var(--ov-line)', borderRadius: 10, padding: '12px', font: 'inherit', width: '100%' } as const;

export default function Security({ twoFactor, history }: { twoFactor: boolean; history: Ev[] }) {
  const props = usePage().props as { auth?: { user?: HeaderUser | null }; flash?: { status?: string }; errors?: Record<string, string>; siteName?: string };
  const brandName = props.siteName || 'RushX';
  const [dark, toggle] = useTheme();
  const [f, setF] = useState({ current: '', password: '', password_confirmation: '' });
  return <><Head title={`Security — ${brandName}`}/>
    <div className="ov-shell pf-shell rx-dashboard">
      <div className="sec-desktop"><RushXHeader user={props.auth?.user ?? null} dark={dark} onToggleTheme={toggle}/></div>
      <header className="pf-top sec-mobile"><button type="button" aria-label="Back" onClick={() => (window.history.length > 1 ? window.history.back() : (window.location.href = '/profile'))}><ArrowLeft/></button><b>Security</b><span/></header>
      <h2 className="pf-h">Two-factor authentication</h2><section className="pf-card" style={{ padding: 16 }}><TwoFactorPanel enabled={twoFactor}/></section>
      <h2 className="pf-h">Change password</h2><section className="pf-card" style={{ padding: 16, display: 'grid', gap: 10 }}>
        {props.flash?.status && <p role="status" style={{ color: '#2ebd85', margin: 0 }}>{props.flash.status}</p>}{Object.values(props.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d', margin: 0 }}>{m}</p>)}
        <input style={input} type="password" placeholder="Current password" autoComplete="current-password" value={f.current} onChange={e => setF({ ...f, current: e.target.value })}/>
        <input style={input} type="password" placeholder="New password (12+ chars, letters and numbers)" autoComplete="new-password" value={f.password} onChange={e => setF({ ...f, password: e.target.value })}/>
        <input style={input} type="password" placeholder="Repeat new password" autoComplete="new-password" value={f.password_confirmation} onChange={e => setF({ ...f, password_confirmation: e.target.value })}/>
        <button type="button" style={{ border: 0, borderRadius: 10, padding: 13, background: '#c1f033', color: '#000', fontWeight: 800, cursor: 'pointer' }} onClick={() => router.post('/security/password', f, { preserveScroll: true, onSuccess: () => setF({ current: '', password: '', password_confirmation: '' }) })}>Update password</button>
      </section>
      <h2 className="pf-h">Recent sign-ins</h2><section className="pf-card flat">
        {history.length === 0 ? <p className="pf-empty">No sign-ins recorded yet.</p> : history.map((e, i) => <div className="pf-row static" key={i}><span className="pf-txt"><b style={{ color: e.ok ? undefined : '#f6465d' }}>{e.ok ? 'Signed in' : 'Failed attempt'}{e.note ? ` · ${e.note}` : ''}</b><small>{e.ip} · {e.at}</small><small style={{ opacity: .6 }}>{(e.agent ?? '').slice(0, 70)}</small></span></div>)}
      </section>
      <MobileNav active="home"/>
    </div></>;
}
