import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import { Share2, ArrowLeft, ArrowRightLeft, CandlestickChart, ChevronDown, Clock, List, LineChart, Loader2, Maximize2, Minimize2, Pencil, Search, X } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import CoinImage from '../components/CoinImage';
import MobileNav from '../components/MobileNav';
import LiveChart, { type ChartLine } from '../components/LiveChart';
import PnlShareCard, { type ShareData } from '../components/PnlShareCard';
import type { Market, MarketSnapshot } from '../types/market';
import { api, newKey } from '../lib/wallet';
import '../../css/spot.css';
import '../../css/futures.css';
import '../../css/mobile-futures.css';

type Level = [string, string];
type Trade = { p: string; v: string; S: string; T: number };
type Ticker = { price: number; high: number; low: number; turnover: number; change: number; mark?: number; funding?: number; oi?: number; nextFunding?: number };
type Pos = { id: number; symbol: string; side: 'long' | 'short'; leverage: number; margin: string; marginUnits: number; entry: number; mark: number | null; liq: number; tp: number | null; sl: number | null; pnl: string; pnlUnits: number; roe: number; status: string; close: number | null; reason: string | null; net: string; feeOpen: string; feeClose: string; at: string | null; closedAt: string | null };
type State = { trading: string; tradingUnits: number; funding: string; positions: Pos[]; history: Pos[]; config: { maxLeverage: number; feeRate: number; minMargin: number; enabled: boolean } };

const TIMEFRAMES = [['1m', '1'], ['5m', '5'], ['15m', '15'], ['1H', '60'], ['4H', '240'], ['1D', 'D']] as const;
const ROWS = 14;
const REASON: Record<string, string> = { manual: 'Closed', tp: 'Take profit', sl: 'Stop loss', liquidation: 'Liquidated' };

function decimals(price: number): [number, number] { if (price > 1000) return [1, 3]; if (price > 1) return [4, 2]; if (price > 0.001) return [6, 0]; return [8, 0]; }
function fmtPrice(value: number | null | undefined, ref = value ?? 0) {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  const d = decimals(ref)[0]; return value.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
}
function fmtVol(value: number) { if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B`; if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`; if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K`; return value.toFixed(2); }
function fmtAmt(value: number, ref: number) { if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`; if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K`; return value.toFixed(decimals(ref)[1] || 3); }
const pct = (v: number) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}%`;
const usd = (v: number, d = 2) => v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
const signed = (v: number) => `${v >= 0 ? '+' : '-'}$${usd(Math.abs(v))}`;

export default function FuturesPage({ pair: initialPair = 'BTCUSDT', pnlShare = false, referralCode = null }: { pair?: string; pnlShare?: boolean; referralCode?: string | null }) {
  const [shareData, setShareData] = useState<ShareData | null>(null);
  const pageProps = usePage().props as Record<string, unknown>;
  const user = (pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [symbol, setSymbol] = useState(initialPair);
  const [markets, setMarkets] = useState<Market[]>([]);
  const [query, setQuery] = useState('');
  const [tf, setTf] = useState('1'); const [area, setArea] = useState(false); const [full, setFull] = useState(false);
  const [, setNowTick] = useState(0); useEffect(() => { const id = window.setInterval(() => setNowTick(n => n + 1), 1000); return () => window.clearInterval(id); }, []);
  const [ticker, setTicker] = useState<Ticker | null>(null); const [dir, setDir] = useState<'up' | 'down'>('up');
  const [asks, setAsks] = useState<Level[]>([]); const [bids, setBids] = useState<Level[]>([]); const [trades, setTrades] = useState<Trade[]>([]);
  const [rightTab, setRightTab] = useState<'book' | 'trades'>('book');
  const [bookOpen, setBookOpen] = useState(false); // phone: order book is hidden until the user asks for it
  const [histTab, setHistTab] = useState<'positions' | 'open' | 'history'>('positions');
  const [state, setState] = useState<State | null>(null);
  const [leverage, setLeverage] = useState(() => { try { return Number(localStorage.getItem('rushx-fut-lev')) || 10; } catch { return 10; } });
  const [levModal, setLevModal] = useState(false); const [tpslFor, setTpslFor] = useState<Pos | null>(null);
  const [f, setF] = useState({ long: { margin: '', tp: '', sl: '', pct: 0 }, short: { margin: '', tp: '', sl: '', pct: 0 } });
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState(''); const [noticeKind, setNoticeKind] = useState<'ok' | 'err'>('ok');
  const [drawer, setDrawer] = useState(false); const [chartHeight, setChartHeight] = useState(480);
  const seen = useRef<Set<number>>(new Set());

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  useEffect(() => { if (!notice) return; const t = window.setTimeout(() => setNotice(''), 3800); return () => window.clearTimeout(t); }, [notice]);
  useEffect(() => { document.body.style.overflow = full ? 'hidden' : ''; return () => { document.body.style.overflow = ''; }; }, [full]);
  const flash = (text: string, kind: 'ok' | 'err') => { setNoticeKind(kind); setNotice(text); };

  // Contract list (server cache of the public price feed).
  useEffect(() => {
    let active = true; let timer = 0;
    const load = async () => {
      try { const r = await fetch('/api/markets?type=futures', { headers: { Accept: 'application/json' } }); const d = await r.json() as MarketSnapshot; if (active && Array.isArray(d.markets)) setMarkets(d.markets.filter(m => m.quoteAsset === 'USDT')); } catch { /* retry */ }
      if (active) timer = window.setTimeout(load, 3000);
    };
    void load(); return () => { active = false; window.clearTimeout(timer); };
  }, []);

  // Account state. The server settles TP / SL / liquidation on every call.
  const refresh = useCallback(async () => {
    const r = await api<State>('/api/futures/state');
    if (r.status === 401) { window.location.href = '/login'; return; }
    if (!r.ok) return;
    const next = r.data;
    const now = new Set(next.positions.map(p => p.id));
    seen.current.forEach(id => { if (!now.has(id)) { const h = next.history.find(x => x.id === id); if (h && h.reason && h.reason !== 'manual') flash(`${h.symbol} ${h.side} ${REASON[h.reason]?.toLowerCase()} · ${signed(Number(h.net.replace(/,/g, '')))}`, h.reason === 'tp' ? 'ok' : 'err'); } });
    seen.current = now; setState(next);
  }, []);
  useEffect(() => { void refresh(); const t = window.setInterval(() => { if (!document.hidden) void refresh(); }, 1500); return () => window.clearInterval(t); }, [refresh]);

  const current = markets.find(m => m.symbol === symbol);
  const base = symbol.replace(/USDT$/, '');
  useEffect(() => { if (current && !ticker) setTicker({ price: current.lastPrice, high: current.high24h, low: current.low24h, turnover: current.turnover24h, change: current.change24h }); }, [current, ticker]);
  useEffect(() => { document.title = `${base}USDT Perp ${ticker ? fmtPrice(ticker.price) : ''} — RushX Futures`; }, [base, ticker]);

  // Live linear stream: ticker, order book, trades.
  useEffect(() => {
    setTicker(null); setAsks([]); setBids([]); setTrades([]);
    const askMap = new Map<string, string>(); const bidMap = new Map<string, string>();
    let ws: WebSocket | null = null; let ping = 0; let retry = 0; let closed = false; let lastBook = 0; let prev = 0;
    const flushBook = () => { const sort = (m: Map<string, string>, desc: boolean) => [...m.entries()].filter(([, v]) => parseFloat(v) > 0).sort((a, b) => desc ? parseFloat(b[0]) - parseFloat(a[0]) : parseFloat(a[0]) - parseFloat(b[0])).slice(0, ROWS) as Level[]; setAsks(sort(askMap, false)); setBids(sort(bidMap, true)); };
    const apply = (m: Map<string, string>, levels: Level[] | undefined) => { levels?.forEach(([p, v]) => { if (parseFloat(v) === 0) m.delete(p); else m.set(p, v); }); };
    const connect = () => {
      ws = new WebSocket('wss://stream.bybit.com/v5/public/linear');
      ws.onopen = () => { ws?.send(JSON.stringify({ op: 'subscribe', args: [`tickers.${symbol}`, `orderbook.50.${symbol}`, `publicTrade.${symbol}`] })); ping = window.setInterval(() => { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ op: 'ping' })); }, 20_000); };
      ws.onmessage = event => {
        try {
          const msg = JSON.parse(event.data); if (!msg.topic || !msg.data) return;
          if (msg.topic.startsWith('tickers.')) { const d = msg.data; const price = parseFloat(d.lastPrice); if (price > 0) { setDir(price >= prev ? 'up' : 'down'); prev = price; setTicker(t => ({ price, high: d.highPrice24h ? parseFloat(d.highPrice24h) : t?.high ?? 0, low: d.lowPrice24h ? parseFloat(d.lowPrice24h) : t?.low ?? 0, turnover: d.turnover24h ? parseFloat(d.turnover24h) : t?.turnover ?? 0, change: d.price24hPcnt ? parseFloat(d.price24hPcnt) * 100 : t?.change ?? 0, mark: d.markPrice ? parseFloat(d.markPrice) : t?.mark, funding: d.fundingRate ? parseFloat(d.fundingRate) : t?.funding, oi: d.openInterestValue ? parseFloat(d.openInterestValue) : t?.oi, nextFunding: d.nextFundingTime ? parseInt(d.nextFundingTime, 10) : t?.nextFunding })); } }
          else if (msg.topic.startsWith('orderbook.')) { if (msg.type === 'snapshot') { askMap.clear(); bidMap.clear(); } apply(askMap, msg.data.a); apply(bidMap, msg.data.b); const now = Date.now(); if (now - lastBook > 120) { lastBook = now; flushBook(); } }
          else if (msg.topic.startsWith('publicTrade.')) setTrades(list => [...(msg.data as Trade[]).slice().reverse(), ...list].slice(0, 40));
        } catch { /* ignore malformed frame */ }
      };
      ws.onclose = () => { window.clearInterval(ping); if (!closed) retry = window.setTimeout(connect, 2000); }; ws.onerror = () => ws?.close();
    };
    connect(); return () => { closed = true; window.clearInterval(ping); window.clearTimeout(retry); ws?.close(); };
  }, [symbol]);

  const select = useCallback((next: string) => {
    setDrawer(false); if (next === symbol) return; setSymbol(next); setF(v => ({ long: { ...v.long, margin: '', pct: 0 }, short: { ...v.short, margin: '', pct: 0 } })); window.history.replaceState({}, '', `/futures?pair=${next}`);
  }, [symbol]);

  const list = useMemo(() => { const q = query.trim().toLowerCase(); return (q ? markets.filter(m => m.symbol.toLowerCase().includes(q)) : markets).slice(0, 150); }, [markets, query]);
  const ref = ticker?.price ?? current?.lastPrice ?? 0;
  const cumulative = (levels: Level[]) => { let sum = 0; return levels.map(([p, v]) => (sum += parseFloat(p) * parseFloat(v))); };
  const askCum = cumulative(asks); const bidCum = cumulative(bids); const maxCum = Math.max(askCum[askCum.length - 1] ?? 0, bidCum[bidCum.length - 1] ?? 0, 1);
  const cfg = state?.config ?? { maxLeverage: 100, feeRate: 0.0005, minMargin: 1, enabled: true };
  const avail = (state?.tradingUnits ?? 0) / 1e8;
  const priceOf = (sym: string) => sym === symbol && ticker ? ticker.price : (markets.find(m => m.symbol === sym)?.lastPrice ?? null);

  const startResize = (event: React.PointerEvent) => { event.preventDefault(); const y0 = event.clientY; const h0 = chartHeight; const move = (e: PointerEvent) => setChartHeight(Math.max(300, Math.min(window.innerHeight - 220, h0 + e.clientY - y0))); const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); }; window.addEventListener('pointermove', move); window.addEventListener('pointerup', up); };

  const setLev = (n: number) => { const v = Math.max(1, Math.min(cfg.maxLeverage, Math.round(n) || 1)); setLeverage(v); try { localStorage.setItem('rushx-fut-lev', String(v)); } catch { /* optional */ } };
  const maxMargin = () => avail / (1 + leverage * cfg.feeRate);
  const pick = (side: 'long' | 'short', n: number) => setF(v => ({ ...v, [side]: { ...v[side], pct: n, margin: n === 0 ? '' : (Math.floor(maxMargin() * (n / 100) * 100) / 100).toFixed(2) } }));

  const openTrade = async (side: 'long' | 'short') => {
    const d = f[side]; const margin = Number(d.margin);
    if (!/^\d+(\.\d{1,8})?$/.test(d.margin) || margin <= 0) { flash('Enter a valid margin.', 'err'); return; }
    if (margin < cfg.minMargin) { flash(`Minimum margin is ${cfg.minMargin} USDT.`, 'err'); return; }
    if (margin * (1 + leverage * cfg.feeRate) > avail + 1e-9) { flash('Insufficient Trading balance (margin + fee).', 'err'); return; }
    if (busy) return; setBusy(side);
    const r = await api<State>('/api/futures/open', { symbol, side, margin: d.margin, leverage, tp: d.tp ? Number(d.tp) : null, sl: d.sl ? Number(d.sl) : null, idempotency_key: newKey() });
    setBusy(null);
    if (r.ok) { flash(`${side === 'long' ? 'Long' : 'Short'} ${base} opened`, 'ok'); setState(r.data); seen.current = new Set(r.data.positions.map(p => p.id)); setF(v => ({ ...v, [side]: { margin: '', tp: '', sl: '', pct: 0 } })); setHistTab('positions'); }
    else flash(r.status === 419 ? 'Session expired. Refresh the page and try again.' : (r.data.message ?? 'Order failed.'), 'err');
  };
  const closePos = async (p: Pos) => {
    if (busy) return; setBusy(`c${p.id}`);
    const r = await api<State>('/api/futures/close', { position_id: p.id }); setBusy(null);
    if (r.ok) { setState(r.data); seen.current = new Set(r.data.positions.map(x => x.id)); const h = r.data.history.find(x => x.id === p.id); flash(`Position closed · ${h ? signed(Number(h.net.replace(/,/g, ''))) : ''}`, 'ok'); }
    else flash(r.data.message ?? 'Could not close the position.', 'err');
  };

  const livePnl = (p: Pos) => { const mark = priceOf(p.symbol) ?? p.mark ?? p.entry; const dirn = p.side === 'long' ? 1 : -1; const pnl = (p.marginUnits / 1e8) * p.leverage * ((mark - p.entry) / p.entry) * dirn; return { mark, pnl, roe: (pnl / (p.marginUnits / 1e8)) * 100 }; };
  const shareOf = (p: Pos): ShareData => {
    if (p.status === 'closed') { const net = Number(p.net.replace(/,/g, '')); const m = Number(p.margin.replace(/,/g, '')); return { symbol: p.symbol, side: p.side, leverage: p.leverage, roePct: m > 0 ? net / m * 100 : 0, pnl: net, entry: p.entry, exit: p.close, exitLabel: 'Exit price', openedAt: p.at, closedAt: p.closedAt, reason: REASON[p.reason ?? 'manual'] }; }
    const l = livePnl(p); return { symbol: p.symbol, side: p.side, leverage: p.leverage, roePct: l.roe, pnl: l.pnl, entry: p.entry, exit: l.mark, exitLabel: 'Mark price', openedAt: p.at, closedAt: null, reason: 'Open position' };
  };
  const shareBtn = (p: Pos) => pnlShare ? <button type="button" className="pnl-sharebtn" aria-label="Share trade" title="Share" onClick={() => setShareData(shareOf(p))}><Share2/></button> : null;
  const mine = (state?.positions ?? []).filter(p => p.symbol === symbol);
  const chartLines: ChartLine[] = mine.flatMap(p => { const l = livePnl(p); const col = l.pnl >= 0 ? '#0ecb81' : '#f6465d'; return [
    { id: `e${p.id}`, price: p.entry, title: `${p.side === 'long' ? 'LONG' : 'SHORT'} ${p.leverage}x  ${signed(l.pnl)}`, color: col, onClose: () => closePos(p) },
    { id: `l${p.id}`, price: p.liq, title: 'Liq', color: '#f6465d', dashed: true },
    ...(p.tp ? [{ id: `t${p.id}`, price: p.tp, title: 'TP', color: '#0ecb81', dashed: true }] : []),
    ...(p.sl ? [{ id: `s${p.id}`, price: p.sl, title: 'SL', color: '#f6465d', dashed: true }] : []),
  ]; });

  const book = <>
    <div className="sp-ob-head"><span>Price (USDT)</span><span>Size ({base})</span></div>
    <div className="sp-ob-rows sp-asks">{[...asks].reverse().map(([p, v], i) => { const idx = asks.length - 1 - i; return <div className="sp-ob-row ask" key={p}><i style={{ width: `${Math.min(100, (askCum[idx] / maxCum) * 100)}%` }}/><b>{fmtPrice(parseFloat(p), ref)}</b><span>{fmtAmt(parseFloat(v), ref)}</span></div>; })}</div>
    <div className="sp-ob-mid"><b className={dir}>{ticker ? fmtPrice(ticker.price) : '---.--'}</b></div>
    <div className="sp-ob-rows sp-bids">{bids.map(([p, v], i) => <div className="sp-ob-row bid" key={p}><i style={{ width: `${Math.min(100, (bidCum[i] / maxCum) * 100)}%` }}/><b>{fmtPrice(parseFloat(p), ref)}</b><span>{fmtAmt(parseFloat(v), ref)}</span></div>)}</div>
  </>;
  const tape = <>
    <div className="sp-ob-head"><span>Price (USDT)</span><span className="grow">Size</span><span className="time">Time</span></div>
    <div className="sp-tape">{trades.map((t, i) => <div className="sp-tape-row" key={`${t.T}-${i}`}><b className={t.S === 'Buy' ? 'up' : 'down'}>{fmtPrice(parseFloat(t.p), ref)}</b><span className="grow">{fmtAmt(parseFloat(t.v), ref)}</span><span className="time">{new Date(Number(t.T)).toLocaleTimeString('en-US', { hour12: false })}</span></div>)}</div>
  </>;

  const [phone, setPhone] = useState(() => typeof window !== 'undefined' && window.matchMedia('(max-width: 820px)').matches);
  useEffect(() => { const mq = window.matchMedia('(max-width: 820px)'); const fn = () => setPhone(mq.matches); mq.addEventListener('change', fn); return () => mq.removeEventListener('change', fn); }, []);
  const [showTpsl, setShowTpsl] = useState(false);
  // On phones one shared form drives both Long and Short buttons, so both sides are kept in step.
  const setShared = (patch: Partial<{ margin: string; tp: string; sl: string; pct: number }>) => setF(v => ({ long: { ...v.long, ...patch }, short: { ...v.short, ...patch } }));
  const pickShared = (n: number) => setShared({ pct: n, margin: n === 0 ? '' : (Math.floor(maxMargin() * (n / 100) * 100) / 100).toFixed(2) });
  const shared = f.long;
  const sharedMargin = Number(shared.margin) || 0;
  const sharedSize = sharedMargin * leverage;

  const side = (kind: 'long' | 'short') => {
    const d = f[kind]; const long = kind === 'long'; const m = Number(d.margin) || 0; const size = m * leverage; const fee = size * cfg.feeRate;
    const e = ref; const liq = e > 0 ? (long ? e * (1 - 1 / leverage + 0.005) : e * (1 + 1 / leverage - 0.005)) : 0;
    const set = (patch: Partial<typeof d>) => setF(v => ({ ...v, [kind]: { ...v[kind], ...patch } }));
    return <div className="sp-side">
      <div className="sp-input disabled"><span className="pre">Price</span><input readOnly value="Market"/><span className="suf">USDT</span></div>
      <div className="sp-input"><span className="pre">Margin</span><input type="number" inputMode="decimal" step="any" placeholder="Amount" value={d.margin} onChange={e2 => set({ margin: e2.target.value, pct: 0 })} aria-label={`${kind} margin`}/><span className="suf">USDT</span></div>
      <div className="sp-slider"><input type="range" min={0} max={100} value={d.pct} style={{ background: `linear-gradient(to right, var(--sp-sub) ${d.pct}%, var(--sp-line) ${d.pct}%)` }} onChange={e2 => pick(kind, Number(e2.target.value))} aria-label={`${kind} percentage`}/><div className="sp-marks">{[0, 25, 50, 75, 100].map(n => <button type="button" key={n} onClick={() => pick(kind, n)}>{n}%</button>)}</div></div>
      <div className="fu-tpsl"><div className="sp-input"><input type="number" inputMode="decimal" step="any" placeholder="TP Price" value={d.tp} onChange={e2 => set({ tp: e2.target.value })} aria-label={`${kind} take profit`}/><span className="suf">USDT</span></div><div className="sp-input"><input type="number" inputMode="decimal" step="any" placeholder="SL Price" value={d.sl} onChange={e2 => set({ sl: e2.target.value })} aria-label={`${kind} stop loss`}/><span className="suf">USDT</span></div></div>
      <div className="fu-quote"><span>Size <b>${usd(size)}</b></span><span>Fee <b>{usd(fee, 4)}</b></span><span>Est. liq <b>{m > 0 ? fmtPrice(liq, ref) : '--'}</b></span></div>
      <div className="sp-avail"><span>Avail: <b>{usd(avail)}</b> USDT</span>{long && <a className="sp-xfer" aria-label="Transfer funds" href="/trading?transfer=1"><ArrowRightLeft aria-hidden="true"/></a>}</div>
      <button type="button" className={`sp-trade ${long ? 'buy' : 'sell'}`} disabled={busy !== null || !cfg.enabled} onClick={() => openTrade(kind)}>{!cfg.enabled ? 'Futures paused' : busy === kind ? 'Opening…' : long ? 'Open Long' : 'Open Short'}</button>
    </div>;
  };

  const buyPct = (() => { const b = bids.slice(0, 10).reduce((a, [p, v]) => a + parseFloat(p) * parseFloat(v), 0); const a2 = asks.slice(0, 10).reduce((a, [p, v]) => a + parseFloat(p) * parseFloat(v), 0); return b + a2 > 0 ? (b / (b + a2)) * 100 : 50; })();
  const phoneHead = <div className="fm-top">
    <nav className="fm-tabs" aria-label="Trading sections">{[['Convert', '/convert'], ['Spot', '/spot'], ['Futures', ''], ['Bots', '/bots'], ['Copy', '/copy']].map(([l, h]) => h ? <a key={l} href={h}>{l}</a> : <b key={l}>{l}</b>)}</nav>
    <div className="fm-bar"><button type="button" className="fm-ic" aria-label="Back" onClick={() => window.history.length > 1 ? window.history.back() : (window.location.href = '/dashboard')}><ArrowLeft/></button>
      <button type="button" className="fm-pair" onClick={() => setDrawer(true)} aria-label="Change contract"><span className="fm-logo"><CoinImage symbol={base} icon={current?.icon}/></span><b>{base}USDT</b><em>PERP</em><ChevronDown/></button>
      <span className="fm-acts"><button type="button" className="fm-ic" aria-label={area ? 'Candles' : 'Area chart'} onClick={() => setArea(a => !a)}>{area ? <CandlestickChart/> : <LineChart/>}</button><button type="button" className="fm-ic" aria-label="Fullscreen chart" onClick={() => setFull(v => !v)}>{full ? <Minimize2/> : <Maximize2/>}</button></span></div>
    <div className="fm-price"><b className={ticker ? dir : `${dir} fm-skel`}>{ticker ? fmtPrice(ticker.price) : '---.--'}</b><span className={(ticker?.change ?? 0) >= 0 ? 'up' : 'down'}>{ticker ? pct(ticker.change) : ''}</span></div>
    <div className="fm-stats"><div><small>24h High</small><b className={ticker ? undefined : 'fm-skel'}>{ticker ? fmtPrice(ticker.high, ref) : '--'}</b></div><div><small>24h Low</small><b className={ticker ? undefined : 'fm-skel'}>{ticker ? fmtPrice(ticker.low, ref) : '--'}</b></div><div><small>24h Vol(USDT)</small><b className={ticker ? undefined : 'fm-skel'}>{ticker ? `${(ticker.turnover / 1e6).toFixed(2)}M` : '--'}</b></div></div>
  </div>;
  const phoneTrade = <><button type="button" className="fm-bktoggle" aria-expanded={bookOpen} onClick={() => setBookOpen(v => !v)}>Order book <ChevronDown style={{ transform: bookOpen ? 'rotate(180deg)' : 'none' }}/></button><section className={`fm-trade${bookOpen ? '' : ' nobook'}`}>
    <div className="fm-form">
      <div className="fm-row"><button type="button" className="fm-dd" aria-disabled="true" onClick={() => flash('Isolated margin only — each position has its own margin and can lose at most that margin. Cross margin is not available yet.', 'ok')}>Isolated</button><button type="button" className="fm-dd" onClick={() => setLevModal(true)}>{leverage}x <ChevronDown/></button></div>
      <div className="fm-dd wide" aria-disabled="true">Market order</div>
      <div className="fm-in"><input type="number" inputMode="decimal" step="any" placeholder="Margin Amount" value={shared.margin} onChange={e => setShared({ margin: e.target.value, pct: 0 })} aria-label="Margin amount"/><span>USDT</span></div>
      <div className="fm-pcts">{[[25, '25%'], [50, '50%'], [75, '75%'], [100, 'Max']].map(([n, l]) => <button type="button" key={n} onClick={() => pickShared(Number(n))}>{l}</button>)}</div>
      <label className="fm-chk"><input type="checkbox" checked={showTpsl} onChange={e => { setShowTpsl(e.target.checked); if (!e.target.checked) setShared({ tp: '', sl: '' }); }}/> TP/SL</label>
      {showTpsl && <div className="fm-tpsl"><div className="fm-in"><input type="number" inputMode="decimal" step="any" placeholder="Take Profit" value={shared.tp} onChange={e => setShared({ tp: e.target.value })} aria-label="Take profit"/><span>USDT</span></div><div className="fm-in"><input type="number" inputMode="decimal" step="any" placeholder="Stop Loss" value={shared.sl} onChange={e => setShared({ sl: e.target.value })} aria-label="Stop loss"/><span>USDT</span></div></div>}
      <div className="fm-lev"><input type="range" min={1} max={cfg.maxLeverage} value={leverage} style={{ background: `linear-gradient(to right, var(--sp-neon) ${((leverage - 1) / Math.max(1, cfg.maxLeverage - 1)) * 100}%, rgba(128,128,128,.25) 0)` }} onChange={e => setLev(Number(e.target.value))} aria-label="Leverage"/>
        <div>{[1, 25, 50, 75, 100].filter(n => n <= cfg.maxLeverage).map(n => <button type="button" key={n} onClick={() => setLev(n)}>{n}x</button>)}</div></div>
      <div className="fm-quote"><span>Size <b>${usd(sharedSize)}</b></span><span>Fee <b>{usd(sharedSize * cfg.feeRate, 4)}</b></span></div>
      <div className="fm-avail"><span>Trading Balance (USDT)</span><a href="/transfer" aria-label="Transfer funds"><b>${usd(avail)}</b> <ArrowRightLeft/></a></div>
      <div className="fm-btns"><button type="button" className="buy" disabled={busy !== null || !cfg.enabled} onClick={() => openTrade('long')}>{busy === 'long' ? 'Opening…' : 'Buy / Long'}</button><button type="button" className="sell" disabled={busy !== null || !cfg.enabled} onClick={() => openTrade('short')}>{busy === 'short' ? 'Opening…' : 'Sell / Short'}</button></div>
    </div>
    {bookOpen && <div className="fm-book"><div className="fm-bh"><span>Price</span><span>USDT</span></div>
      <div className="fm-rows">{asks.slice(0, 5).reverse().map(([p, v]) => <div className="ask" key={p}><i style={{ width: `${Math.min(100, (parseFloat(p) * parseFloat(v)) / Math.max(1, ...asks.slice(0, 5).map(a => parseFloat(a[0]) * parseFloat(a[1]))) * 100)}%` }}/><b>{fmtPrice(parseFloat(p), ref)}</b><span>{fmtAmt(parseFloat(p) * parseFloat(v), ref)}</span></div>)}</div>
      <div className={`fm-mid ${dir}`}>{ticker ? fmtPrice(ticker.price) : '---.--'}</div>
      <div className="fm-rows">{bids.slice(0, 5).map(([p, v]) => <div className="bid" key={p}><i style={{ width: `${Math.min(100, (parseFloat(p) * parseFloat(v)) / Math.max(1, ...bids.slice(0, 5).map(a => parseFloat(a[0]) * parseFloat(a[1]))) * 100)}%` }}/><b>{fmtPrice(parseFloat(p), ref)}</b><span>{fmtAmt(parseFloat(p) * parseFloat(v), ref)}</span></div>)}</div>
      <div className="fm-ratio"><div><b className="up">{buyPct.toFixed(1)}% Buy</b><b className="down">{(100 - buyPct).toFixed(1)}% Sell</b></div><span><i style={{ width: `${buyPct}%` }}/></span></div>
    </div>}
  </section></>;
  const phoneCards = !state || state.positions.length === 0 ? <div className="sp-hempty"><Clock/><b>{state ? 'No open positions' : 'Loading…'}</b><span>Open a long or short above to start trading {base}USDT.</span></div>
    : <div className="fm-cards">{state.positions.map(p => { const l = livePnl(p); const up2 = l.pnl >= 0; const size = (p.marginUnits / 1e8) * p.leverage; return <article key={p.id}>
      <header><span className={`fu-badge ${p.side}`}>{p.side.toUpperCase()} {p.leverage}x</span><b>{p.symbol} Perp</b></header>
      <div className="fm-pnl"><div><small>Unrealized PnL (USDT)</small><b className={up2 ? 'up' : 'down'}>{signed(l.pnl)}</b></div><div><small>ROE</small><b className={up2 ? 'up' : 'down'}>{pct(l.roe)}</b></div></div>
      <dl><div><dt>Size (USDT)</dt><dd>{usd(size)}</dd></div><div><dt>Margin (USDT)</dt><dd>${p.margin}</dd></div><div><dt>Entry Price</dt><dd>{fmtPrice(p.entry, p.entry)}</dd></div><div><dt>Mark Price</dt><dd className={up2 ? 'up' : 'down'}>{fmtPrice(l.mark, p.entry)}</dd></div><div><dt>Est. Liq Price</dt><dd className="down">{fmtPrice(p.liq, p.entry)}</dd></div><div><dt>TP/SL</dt><dd>{p.tp ? fmtPrice(p.tp, p.entry) : '--'} / {p.sl ? fmtPrice(p.sl, p.entry) : '--'}</dd></div></dl>
      <footer><button type="button" onClick={() => setTpslFor(p)}>TP/SL</button>{pnlShare && <button type="button" onClick={() => setShareData(shareOf(p))}>Share</button>}{p.symbol === symbol ? <button type="button" className="close" disabled={busy === `c${p.id}`} onClick={() => closePos(p)}>{busy === `c${p.id}` ? '…' : 'Close'}</button> : <button type="button" className="close" onClick={() => select(p.symbol)}>Switch pair</button>}</footer></article>; })}</div>;

  return <><Head title="Futures — RushX"><meta name="theme-color" content={dark ? '#000000' : '#ffffff'}/></Head>
    <div className={`sp-shell fu-shell rx-dashboard${phone ? ' fm-phone' : ''}`}>{phone ? phoneHead : <RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>}
    {notice && <div className={`sp-toast ${noticeKind}`} role="status">{notice}</div>}
    <div className="sp-layout">
      <aside className={`sp-left${drawer ? ' open' : ''}`}>
        <div className="sp-drawer-head"><b>Select contract</b><button type="button" aria-label="Close contracts" onClick={() => setDrawer(false)}><X/></button></div>
        <div className="sp-search"><Search/><input placeholder="Search perpetuals" value={query} onChange={e => setQuery(e.target.value)} autoComplete="off" spellCheck={false} aria-label="Search contracts"/></div>
        <div className="sp-ltabs"><button type="button" className="active">USDT-M</button></div>
        <div className="sp-lhead"><span>Contract</span><span><i>Last price</i><i>Change</i></span></div>
        <div className="sp-list">{markets.length === 0 ? <div className="sp-empty"><Loader2 className="spin"/></div> : list.length === 0 ? <div className="sp-empty">No contracts found</div> : list.map(m => <button type="button" className={`sp-pair${m.symbol === symbol ? ' active' : ''}`} key={m.symbol} onClick={() => select(m.symbol)}>
          <span className="pl"><span className="sp-logo" style={{ width: 22, height: 22 }}><CoinImage symbol={m.baseAsset} icon={m.icon}/></span><span><b>{m.baseAsset} <em className="fu-perp">Perp</em></b><small>Vol {fmtVol(m.turnover24h)}</small></span></span>
          <span className="pr"><span>{fmtPrice(m.lastPrice)}</span><span className={m.change24h >= 0 ? 'up' : 'down'}>{pct(m.change24h)}</span></span></button>)}</div>
      </aside>
      {drawer && <button type="button" className="sp-scrim" aria-label="Close contracts" onClick={() => setDrawer(false)}/>}

      <main className="sp-center">
        {!phone && <div className="sp-head">
          <button type="button" className="sp-pairbtn" onClick={() => setDrawer(true)} aria-label="Change contract"><span className="sp-logo" style={{ width: 26, height: 26 }}><CoinImage symbol={base} icon={current?.icon}/></span><h1>{base}USDT Perp</h1><ChevronDown/></button>
          <div className={`sp-price ${dir}`}>{ticker ? fmtPrice(ticker.price) : '---.--'}</div>
          <div className={`sp-change ${(ticker?.change ?? 0) >= 0 ? 'up' : 'down'}`}>{ticker ? pct(ticker.change) : ''}</div>
          <div className="sp-stats"><div><span>24h High</span><b>{ticker ? fmtPrice(ticker.high, ref) : '--'}</b></div><div><span>24h Low</span><b>{ticker ? fmtPrice(ticker.low, ref) : '--'}</b></div><div><span>24h Vol(USDT)</span><b>{ticker ? `${(ticker.turnover / 1e6).toFixed(2)}M` : '--'}</b></div></div>
        </div>}

        <div className={`fu-chartwrap${full ? ' full' : ''}`}>
          <div className="sp-tfbar" role="group" aria-label="Chart timeframe">{TIMEFRAMES.map(([label, value]) => <button type="button" key={value} className={tf === value ? 'active' : ''} onClick={() => setTf(value)}>{label}</button>)}
            <span className="fu-tools"><button type="button" className={!area ? 'active' : ''} aria-label="Candles" title="Candles" onClick={() => setArea(false)}><CandlestickChart/></button><button type="button" className={area ? 'active' : ''} aria-label="Area chart" title="Area" onClick={() => setArea(true)}><LineChart/></button><button type="button" aria-label={full ? 'Exit full screen' : 'Full screen chart'} title="Full screen" onClick={() => setFull(v => !v)}>{full ? <Minimize2/> : <Maximize2/>}</button></span></div>
          <div className="sp-chart fu-chart" style={full ? undefined : { height: chartHeight }}>
            <LiveChart symbol={symbol} interval={tf} dark={dark} market="linear" area={area} lines={chartLines}/>
            {mine.length > 0 && <div className="fu-lines">{mine.map(p => { const l = livePnl(p); return <span key={p.id} className={l.pnl >= 0 ? 'up' : 'down'}><b className={p.side}>{p.side.toUpperCase()} {p.leverage}x</b> Entry {fmtPrice(p.entry, ref)} · Liq {fmtPrice(p.liq, ref)} · {signed(l.pnl)}</span>; })}</div>}
          </div>
        </div>
        <div className="sp-resizer" onPointerDown={startResize} role="separator" aria-orientation="horizontal" aria-label="Resize chart"/>

        {phone ? phoneTrade : <>
        <section className="sp-mobile-book" aria-label="Order book"><div className="sp-rtabs"><button type="button" className={rightTab === 'book' ? 'active' : ''} onClick={() => setRightTab('book')}>Order book</button><button type="button" className={rightTab === 'trades' ? 'active' : ''} onClick={() => setRightTab('trades')}>Recent trades</button></div>{rightTab === 'book' ? book : tape}</section>

        <section className="sp-order">
          <div className="fu-margin"><button type="button" className="fu-chip" onClick={() => flash('Isolated margin only — each position has its own margin and can lose at most that margin. Cross margin is not available yet.', 'ok')}>Isolated</button><button type="button" className="fu-chip" onClick={() => setLevModal(true)}>{leverage}x <Pencil/></button></div>
          <div className="sp-otabs"><button type="button" onClick={() => flash('Limit orders are coming soon.', 'ok')}>Limit <small className="fu-soon">Soon</small></button><button type="button" className="active">Market</button></div>
          <div className="sp-sides">{side('long')}{side('short')}</div>
        </section>

        </>}

        <section className="sp-history">
          <div className="sp-htabs"><button type="button" className={histTab === 'positions' ? 'active' : ''} onClick={() => setHistTab('positions')}>Positions ({state?.positions.length ?? 0})</button><button type="button" className={histTab === 'open' ? 'active' : ''} onClick={() => setHistTab('open')}>Open Orders (0)</button><button type="button" className={histTab === 'history' ? 'active' : ''} onClick={() => setHistTab('history')}>Order History</button></div>
          {histTab === 'open' ? <div className="sp-hempty"><List/><b>No open orders</b><span>Market orders fill instantly. Limit orders will appear here when available.</span></div>
            : histTab === 'positions' ? (phone ? phoneCards : !state || state.positions.length === 0 ? <div className="sp-hempty"><Clock/><b>{state ? 'No open positions' : 'Loading…'}</b><span>Open a long or short above to start trading {base}USDT.</span></div> :
              <div className="sp-orders"><table><thead><tr><th>Contract</th><th>Margin</th><th>Entry Price</th><th>Mark Price</th><th>Est. Liq</th><th>Unrealized PNL (ROE)</th><th>TP/SL</th><th>Action</th></tr></thead><tbody>{state.positions.map(p => { const l = livePnl(p); return <tr key={p.id}>
                <td><span className={`fu-badge ${p.side}`}>{p.side.toUpperCase()} {p.leverage}x</span> <b>{p.symbol}</b></td><td>${p.margin}</td><td>{fmtPrice(p.entry, p.entry)}</td><td className={l.pnl >= 0 ? 'up' : 'down'}>{fmtPrice(l.mark, p.entry)}</td><td className="down">{fmtPrice(p.liq, p.entry)}</td>
                <td className={l.pnl >= 0 ? 'up' : 'down'}><b>{signed(l.pnl)}</b> <small>({pct(l.roe)})</small> {shareBtn(p)}</td>
                <td>{p.tp ? fmtPrice(p.tp, p.entry) : '--'} / {p.sl ? fmtPrice(p.sl, p.entry) : '--'} <button type="button" className="fu-edit" aria-label="Edit take-profit and stop-loss" onClick={() => setTpslFor(p)}><Pencil/></button></td>
                <td>{p.symbol === symbol ? <button type="button" className="fu-close" disabled={busy === `c${p.id}`} onClick={() => closePos(p)}>{busy === `c${p.id}` ? '…' : 'Close'}</button> : <button type="button" className="fu-close" onClick={() => select(p.symbol)}>Switch</button>}</td></tr>; })}</tbody></table></div>)
            : (!state || state.history.length === 0 ? <div className="sp-hempty"><Clock/><b>No order history</b><span>Closed positions are listed here.</span></div> :
              <div className="sp-orders"><table><thead><tr><th>Time</th><th>Contract</th><th>Side</th><th>Entry Price</th><th>Close Price</th><th>Margin</th><th>Closed by</th><th>Realized PNL</th></tr></thead><tbody>{state.history.map(p => { const n = Number(p.net.replace(/,/g, '')); return <tr key={p.id}>
                <td className="muted">{p.closedAt ? new Date(p.closedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}</td><td><span className={`fu-badge ${p.side}`}>{p.side.toUpperCase()} {p.leverage}x</span> <b>{p.symbol}</b></td><td className={p.side === 'long' ? 'up' : 'down'}>{p.side === 'long' ? 'Long' : 'Short'}</td><td>{fmtPrice(p.entry, p.entry)}</td><td>{fmtPrice(p.close, p.entry)}</td><td>${p.margin}</td><td className="muted">{REASON[p.reason ?? 'manual']}</td><td className={n >= 0 ? 'up' : 'down'}><b>{signed(n)}</b> {shareBtn(p)}</td></tr>; })}</tbody></table></div>)}
        </section>
      </main>

      <aside className="sp-right"><div className="sp-rtabs"><button type="button" className={rightTab === 'book' ? 'active' : ''} onClick={() => setRightTab('book')}>Order book</button><button type="button" className={rightTab === 'trades' ? 'active' : ''} onClick={() => setRightTab('trades')}>Recent trades</button></div>{rightTab === 'book' ? book : tape}</aside>
    </div>

    {levModal && <div className="fu-modal" role="dialog" aria-modal="true" aria-label="Adjust leverage" onClick={() => setLevModal(false)}><div onClick={e => e.stopPropagation()}>
      <header><b>Adjust Leverage</b><button type="button" aria-label="Close" onClick={() => setLevModal(false)}><X/></button></header>
      <div className="fu-levbig"><input type="number" min={1} max={cfg.maxLeverage} value={leverage} onChange={e => setLev(Number(e.target.value))} aria-label="Leverage"/><span>x</span></div>
      <input type="range" min={1} max={cfg.maxLeverage} value={leverage} className="fu-levrange" style={{ background: `linear-gradient(to right, var(--sp-neon) ${((leverage - 1) / Math.max(1, cfg.maxLeverage - 1)) * 100}%, var(--sp-line) 0)` }} onChange={e => setLev(Number(e.target.value))} aria-label="Leverage slider"/>
      <div className="fu-levmarks">{[1, 5, 10, 25, 50, 75, 100].filter(n => n <= cfg.maxLeverage).map(n => <button type="button" key={n} className={leverage === n ? 'active' : ''} onClick={() => setLev(n)}>{n}x</button>)}</div>
      <p className="fu-warn">Higher leverage means a closer liquidation price. Fee: {(cfg.feeRate * 100).toFixed(3)}% of position size on open and close.</p>
      <button type="button" className="fu-confirm" onClick={() => setLevModal(false)}>Confirm</button></div></div>}
    {phone && <MobileNav active="trade"/>}
    {tpslFor && <TpSlModal pos={tpslFor} onClose={() => setTpslFor(null)} onDone={s => { setState(s); setTpslFor(null); flash('TP/SL updated', 'ok'); }}/>}
    </div>{shareData && <PnlShareCard data={shareData} code={referralCode} onClose={() => setShareData(null)}/>}
    </>;
}

function TpSlModal({ pos, onClose, onDone }: { pos: Pos; onClose: () => void; onDone: (s: State) => void }) {
  const [tp, setTp] = useState(pos.tp ? String(pos.tp) : ''); const [sl, setSl] = useState(pos.sl ? String(pos.sl) : ''); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const submit = async () => { setBusy(true); setErr(''); const r = await api<State>('/api/futures/tpsl', { position_id: pos.id, tp: tp ? Number(tp) : null, sl: sl ? Number(sl) : null }); setBusy(false); if (r.ok) onDone(r.data); else setErr(r.data.message ?? 'Could not update.'); };
  return <div className="fu-modal" role="dialog" aria-modal="true" aria-label="Edit TP/SL" onClick={onClose}><div onClick={e => e.stopPropagation()}>
    <header><b>TP/SL — {pos.symbol} {pos.side.toUpperCase()} {pos.leverage}x</b><button type="button" aria-label="Close" onClick={onClose}><X/></button></header>
    <p className="fu-warn">Entry {fmtPrice(pos.entry, pos.entry)} · Liq {fmtPrice(pos.liq, pos.entry)}. Leave a field empty to remove it.</p>
    <div className="sp-input"><span className="pre">TP</span><input type="number" inputMode="decimal" step="any" placeholder="Take profit" value={tp} onChange={e => setTp(e.target.value)}/><span className="suf">USDT</span></div>
    <div className="sp-input"><span className="pre">SL</span><input type="number" inputMode="decimal" step="any" placeholder="Stop loss" value={sl} onChange={e => setSl(e.target.value)}/><span className="suf">USDT</span></div>
    {err && <p className="fu-err" role="alert">{err}</p>}
    <button type="button" className="fu-confirm" disabled={busy} onClick={submit}>{busy ? 'Saving…' : 'Confirm'}</button></div></div>;
}
