import { useCallback, useEffect, useMemo, useState } from 'react';
import { Head, Link, usePage } from '@inertiajs/react';
import { ArrowLeftRight, ChevronDown, ChevronRight, Eye, EyeOff, Search, SlidersHorizontal, Users, Wallet, X } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import AccountSubNav from '../components/AccountSubNav';
import type { Market, MarketSnapshot } from '../types/market';
import { api, change24hUsd, newKey, usd, usdValue, type WalletPayload } from '../lib/wallet';
import '../../css/overview.css';

type AccountKey = 'funding' | 'trading' | 'copy';
const NAMES: Record<string, string> = { USDT: 'Tether', USDC: 'USD Coin', BTC: 'Bitcoin', ETH: 'Ethereum', SOL: 'Solana', BNB: 'BNB', XRP: 'XRP' };

function CoinIcon({ asset, prices }: { asset: string; prices: Map<string, Market> }) {
  const [broken, setBroken] = useState(false);
  const icon = prices.get(`${asset}USDT`)?.icon;
  return <span className="ov-coin">{icon && !broken ? <img src={icon} alt="" onError={() => setBroken(true)}/> : <i>{asset.slice(0, 1)}</i>}</span>;
}

export default function Overview() {
  const pageProps = usePage().props as Record<string, unknown>;
  const user = (pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [wallet, setWallet] = useState<WalletPayload | null>(null);
  const [error, setError] = useState('');
  const [markets, setMarkets] = useState<Market[]>([]);
  const [visible, setVisible] = useState(true);
  const [tab, setTab] = useState<AccountKey>('funding');
  const [query, setQuery] = useState('');
  const [modal, setModal] = useState(false);
  const [trail, setTrail] = useState<number[]>([]);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);

  const loadWallet = useCallback(async () => {
    const r = await api<WalletPayload>('/api/wallet');
    if (r.ok) { setWallet(r.data); setError(''); } else if (r.status === 401) { window.location.href = '/login'; } else { setError('Balances could not be loaded.'); }
  }, []);
  useEffect(() => { void loadWallet(); const t = window.setInterval(() => { if (!document.hidden) void loadWallet(); }, 8000); return () => window.clearInterval(t); }, [loadWallet]);
  useEffect(() => {
    let active = true; let timer = 0;
    const load = async () => {
      try { const r = await fetch('/api/markets?type=spot', { headers: { Accept: 'application/json' } }); const d = await r.json() as MarketSnapshot; if (active && Array.isArray(d.markets)) setMarkets(d.markets); } catch { /* retry */ }
      if (active) timer = window.setTimeout(load, 5000);
    };
    void load(); return () => { active = false; window.clearTimeout(timer); };
  }, []);

  const prices = useMemo(() => new Map(markets.map(m => [m.symbol, m])), [markets]);
  const rows = useMemo(() => (wallet?.balances ?? []).map(b => ({ ...b, amount: b.units / 1e8 })).filter(b => b.amount > 0), [wallet]);
  const totals = useMemo(() => {
    const by: Record<AccountKey, number> = { funding: 0, trading: 0, copy: 0 }; let pnl = 0;
    for (const r of rows) { by[r.account as AccountKey] += usdValue(r.asset, r.amount, prices); pnl += change24hUsd(r.asset, r.amount, prices); }
    return { by, total: by.funding + by.trading + by.copy, pnl };
  }, [rows, prices]);
  useEffect(() => { if (wallet) setTrail(list => [...list, totals.total].slice(-40)); }, [totals.total, wallet]);

  const list = rows.filter(r => r.account === tab && (!query || r.asset.toLowerCase().includes(query.toLowerCase())))
    .sort((a, b) => usdValue(b.asset, b.amount, prices) - usdValue(a.asset, a.amount, prices));
  const mask = (text: string) => visible ? text : '******';
  const pnlPct = totals.total - totals.pnl > 0 ? (totals.pnl / (totals.total - totals.pnl)) * 100 : 0;

  const spark = useMemo(() => {
    const pts = trail.length > 1 ? trail : [0, 0]; const min = Math.min(...pts); const max = Math.max(...pts); const span = max - min || 1;
    return pts.map((v, i) => `${i ? 'L' : 'M'}${(i / (pts.length - 1)) * 140},${35 - ((v - min) / span) * 30}`).join(' ');
  }, [trail]);

  return <><Head title="Overview — RushX"/>
    <div className="ov-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>
    <AccountSubNav active="Overview"/>
    <main className="ov-main">
      <div className="ov-left">
        <section className="ov-card">
          <div className="ov-top">
            <div>
              <div className="ov-lbl">Estimated total value <button type="button" aria-label={visible ? 'Hide balances' : 'Show balances'} onClick={() => setVisible(v => !v)}>{visible ? <Eye/> : <EyeOff/>}</button></div>
              <div className="ov-total"><span>{wallet ? mask(usd(totals.total)) : '—'}</span><small>USD <ChevronDown/></small></div>
              <div className="ov-pnl">Today's PnL {wallet && <b className={totals.pnl >= 0 ? 'up' : 'down'}>{mask(`${totals.pnl >= 0 ? '+' : ''}${usd(totals.pnl)} (${pnlPct.toFixed(2)}%)`)}</b>}</div>
              <div className="ov-actions"><Link href="/deposit" className="primary">Deposit</Link><Link href="/withdraw">Withdraw</Link><button type="button" onClick={() => setModal(true)}>Transfer</button><Link href="/earn">Earn</Link></div>
            </div>
            <svg className="ov-spark" width="140" height="40" viewBox="0 0 140 40" aria-hidden="true"><path d={spark} fill="none" stroke={totals.pnl >= 0 ? 'var(--ov-green)' : 'var(--ov-red)'} strokeWidth="2" strokeLinejoin="round"/></svg>
          </div>
          <div className="ov-chev"><ChevronDown/></div>
        </section>

        <section className="ov-card">
          <h2>Portfolio</h2>
          <div className="ov-boxes">
            {([['funding', 'Funding', Wallet], ['trading', 'Trading', ArrowLeftRight], ['copy', 'Copy Trading', Users]] as const).map(([key, label, Icon]) => <button type="button" key={key} className={tab === key ? 'active' : ''} onClick={() => setTab(key)}><span><Icon/> {label}</span><b>{wallet ? mask(`$${usd(totals.by[key])}`) : '—'}</b></button>)}
          </div>
          <div className="ov-search"><label><Search/><input placeholder="Search" value={query} onChange={e => setQuery(e.target.value)} aria-label="Search assets"/></label><SlidersHorizontal aria-hidden="true"/></div>
          <table className="ov-table"><thead><tr><th>Name</th><th>Amount</th><th>Valuation/Spot PnL</th></tr></thead>
            <tbody>{!wallet ? <tr><td colSpan={3} className="ov-empty">{error || 'Loading balances…'}</td></tr> : list.length === 0 ? <tr><td colSpan={3} className="ov-empty">No assets in this account yet.</td></tr> : list.map(r => <tr key={`${r.account}-${r.asset}`} onClick={() => window.location.assign(`/spot?pair=${r.asset}USDT`)}>
              <td><div className="ov-name"><CoinIcon asset={r.asset} prices={prices}/><div><b>{r.asset}</b><small>{NAMES[r.asset] ?? r.asset}</small></div></div></td>
              <td>{mask(r.amount >= 1 ? r.amount.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 }) : r.amount.toFixed(8).replace(/0+$/, '').replace(/\.$/, ''))}</td>
              <td>{mask(usdValue(r.asset, r.amount, prices) < 0.01 ? '<$0.01' : `$${usd(usdValue(r.asset, r.amount, prices))}`)}</td>
            </tr>)}</tbody></table>
        </section>
      </div>

      <aside className="ov-right"><section className="ov-card">
        <header><h2>Recent funding history</h2><Link href="/orders">View more <ChevronRight/></Link></header>
        {!wallet ? <p className="ov-empty">Loading…</p> : wallet.history.length === 0 ? <p className="ov-empty">No activity yet.</p> : wallet.history.map(h => <div className="ov-hist" key={h.id}>
          <div><b>{h.title}</b><small>{h.at ? new Date(h.at).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}</small></div>
          <span className={h.positive ? 'up' : 'down'}>{mask(`${h.amount} ${h.asset}`)}</span>
        </div>)}
      </section></aside>
    </main>
    {modal && <TransferModal funding={rows.find(r => r.account === 'funding' && r.asset === 'USDT')?.amount ?? 0} trading={rows.find(r => r.account === 'trading' && r.asset === 'USDT')?.amount ?? 0} onClose={() => setModal(false)} onDone={p => { setWallet(p); setModal(false); }}/>}
    </div></>;
}

function TransferModal({ funding, trading, onClose, onDone }: { funding: number; trading: number; onClose: () => void; onDone: (payload: WalletPayload) => void }) {
  const [from, setFrom] = useState<'funding' | 'trading'>('funding');
  const [amount, setAmount] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [key] = useState(newKey);
  const to = from === 'funding' ? 'trading' : 'funding'; const max = from === 'funding' ? funding : trading;
  const submit = async () => {
    setErr(''); if (!/^\d+(\.\d{1,8})?$/.test(amount) || Number(amount) <= 0) { setErr('Enter a valid amount.'); return; }
    setBusy(true); const r = await api<WalletPayload>('/api/wallet/transfer', { from, to, amount, idempotency_key: key }); setBusy(false);
    if (r.ok) onDone(r.data); else setErr(r.data.message ?? 'Transfer failed.');
  };
  return <div className="ov-modal" role="dialog" aria-modal="true" aria-label="Transfer" onClick={onClose}><div onClick={e => e.stopPropagation()}>
    <header><b>Transfer</b><button type="button" aria-label="Close" onClick={onClose}><X/></button></header>
    <div className="ov-tr"><div><small>From {from === 'funding' ? 'Funding' : 'Trading'} Account</small><b>${usd(max)}</b></div><button type="button" aria-label="Swap direction" onClick={() => setFrom(to)}><ArrowLeftRight/></button><div><small>To {to === 'funding' ? 'Funding' : 'Trading'} Account</small></div></div>
    <label>Amount (USDT)<div className="ov-amt"><input inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00"/><button type="button" onClick={() => setAmount(String(Math.floor(max * 1e8) / 1e8))}>Max</button></div></label>
    {err && <p className="ov-err" role="alert">{err}</p>}
    <button type="button" className="ov-confirm" disabled={busy} onClick={submit}>{busy ? 'Please wait…' : 'Confirm'}</button>
  </div></div>;
}
