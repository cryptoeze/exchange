import { useCallback, useEffect, useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import { ListOrdered, Megaphone, X } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { api } from '../lib/wallet';
import { initials, money, type P2pAd, type P2pConfig } from '../lib/p2p';
import '../../css/p2p.css';

export default function P2p() {
  const p2pPageProps = usePage().props as { auth?: { user?: unknown }; siteName?: string };
  const user = p2pPageProps.auth?.user ?? null;
  const brandName = p2pPageProps.siteName || 'RushX';
  const [cfg, setCfg] = useState<P2pConfig | null>(null);
  const [want, setWant] = useState<'buy' | 'sell'>('buy');
  const [coin, setCoin] = useState('USDT'); const [fiat, setFiat] = useState(''); const [method, setMethod] = useState(''); const [amount, setAmount] = useState('');
  const [ads, setAds] = useState<P2pAd[] | null>(null);
  const [pick, setPick] = useState<P2pAd | null>(null);
  useEffect(() => { void api<P2pConfig>('/api/p2p/config').then(r => { if (r.ok) setCfg(r.data); }); }, []);
  const load = useCallback(async () => {
    const q = new URLSearchParams({ want, coin }); if (fiat) q.set('fiat', fiat); if (method) q.set('method', method); if (Number(amount) > 0) q.set('amount', amount);
    const r = await api<{ ads: P2pAd[] }>(`/api/p2p/ads?${q}`); if (r.ok) setAds(r.data.ads);
  }, [want, coin, fiat, method, amount]);
  useEffect(() => { setAds(null); void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 10000); return () => window.clearInterval(t); }, [load]);

  return <AccountLayout active="P2P" title="P2P" showNav={false} phoneBar>
    <Head title={`P2P — ${brandName}`}/>
    <main className="p2-wrap">
      <div className="p2-top">
        <div className="p2-seg"><button type="button" className={want === 'buy' ? 'on buy' : ''} onClick={() => setWant('buy')}>Buy</button><button type="button" className={want === 'sell' ? 'on sell' : ''} onClick={() => setWant('sell')}>Sell</button></div>
        <div className="p2-links"><a href="/p2p/orders"><ListOrdered size={16}/> My orders</a><a href="/p2p/ads"><Megaphone size={16}/> My ads</a></div>
      </div>
      {cfg && !cfg.enabled && <p className="p2-note">P2P is paused right now. You can still finish open orders.</p>}
      <div className="p2-coins">{cfg && Object.keys(cfg.coins).map(c => <button type="button" key={c} className={coin === c ? 'on' : ''} onClick={() => setCoin(c)}>{c}</button>)}</div>
      <div className="p2-filters">
        <input inputMode="decimal" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} aria-label="Amount in fiat"/>
        <select value={fiat} onChange={e => setFiat(e.target.value)} aria-label="Currency"><option value="">All currencies</option>{cfg && Object.entries(cfg.fiats).map(([k, v]) => <option key={k} value={k}>{k} · {v.name}</option>)}</select>
        <select value={method} onChange={e => setMethod(e.target.value)} aria-label="Payment method"><option value="">All payment methods</option>{cfg?.methods.map(m => <option key={m}>{m}</option>)}</select>
      </div>
      {ads === null ? <p className="p2-empty">Loading offers…</p> : ads.length === 0 ? <div className="p2-empty"><b>No offers match.</b><span>Try another currency or payment method, or <a href="/p2p/ads">post your own ad</a>.</span></div> :
        <div className="p2-list">{ads.map(a => <article key={a.id} className="p2-ad">
          <header><span className="p2-av">{initials(a.name)}</span><span className="p2-who"><b>{a.name}</b><small>{a.completed} orders · {a.rate === null ? 'new' : `${a.rate}% completion`}</small></span></header>
          <div className="p2-price"><b>{money(a.price)}</b> <em>{a.fiat}</em><small>per {a.coin}</small></div>
          <dl><div><dt>Available</dt><dd>{a.available} {a.coin}</dd></div><div><dt>Limit</dt><dd>{money(a.min, 0)} – {money(a.max, 0)} {a.fiat}</dd></div></dl>
          <div className="p2-methods">{a.methods.map(m => <span key={m}>{m}</span>)}</div>
          <button type="button" className={`p2-cta ${want}`} onClick={() => (user ? setPick(a) : router.visit('/login'))}>{want === 'buy' ? `Buy ${a.coin}` : `Sell ${a.coin}`}</button>
        </article>)}</div>}
      {pick && <TradeModal ad={pick} want={want} onClose={() => setPick(null)}/>}
    </main>
  </AccountLayout>;
}

function TradeModal({ ad, want, onClose }: { ad: P2pAd; want: 'buy' | 'sell'; onClose: () => void }) {
  const [fiat, setFiat] = useState(''); const [method, setMethod] = useState(ad.methods[0]); const [details, setDetails] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const qty = Number(fiat) > 0 ? Number(fiat) / ad.price : 0;
  const go = async () => {
    setErr(''); setBusy(true);
    const r = await api<{ ref: string }>('/api/p2p/trades', { ad_id: ad.id, fiat_amount: fiat, method, details });
    setBusy(false);
    if (r.ok) router.visit(`/p2p/orders/${r.data.ref}`); else setErr(r.data.message ?? 'Could not open the order.');
  };
  return <div className="p2-bg" onClick={onClose}><div className="p2-modal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}>
    <header><b>{want === 'buy' ? 'Buy' : 'Sell'} {ad.coin}</b><button type="button" aria-label="Close" onClick={onClose}><X/></button></header>
    <p className="p2-sub">{ad.name} · {money(ad.price)} {ad.fiat} per {ad.coin} · pay window {ad.window} min</p>
    <label>{want === 'buy' ? 'I want to pay' : 'I want to receive'}<span className="p2-in"><input inputMode="decimal" autoFocus value={fiat} onChange={e => setFiat(e.target.value)} placeholder={`${money(ad.min, 0)} – ${money(ad.max, 0)}`}/><i>{ad.fiat}</i></span></label>
    <p className="p2-calc">{want === 'buy' ? 'You receive' : 'You sell'} ≈ <b>{qty ? qty.toFixed(ad.coin === 'BTC' ? 6 : 4) : '0'} {ad.coin}</b></p>
    <label>Payment method<select value={method} onChange={e => setMethod(e.target.value)}>{ad.methods.map(m => <option key={m}>{m}</option>)}</select></label>
    {want === 'sell' && <label>Your {method} account details<textarea value={details} onChange={e => setDetails(e.target.value)} placeholder="Where the buyer should send the money (account number, name, phone…)" maxLength={300}/></label>}
    {want === 'sell' && <p className="p2-sub">Your {ad.coin} is locked in escrow as soon as the order opens.</p>}
    {ad.terms && <details className="p2-terms"><summary>Advertiser terms</summary><p>{ad.terms}</p></details>}
    {err && <p className="p2-err" role="alert">{err}</p>}
    <button type="button" className={`p2-cta ${want}`} disabled={busy || !fiat} onClick={go}>{busy ? 'Opening…' : want === 'buy' ? `Buy ${ad.coin}` : `Sell ${ad.coin}`}</button>
  </div></div>;
}
