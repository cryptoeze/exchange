import { COUNTRIES } from '../lib/countries';
import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Head, router, useForm, usePage } from '@inertiajs/react';
import {
  ArrowRight, Bot, CandlestickChart, Leaf, Check, CircleHelp, Eye, EyeOff, Globe2,
  LockKeyhole, Send, ShieldCheck, Users, X, Zap,
} from 'lucide-react';
import rushxMark from '../../images/rushx-mark.svg';
import MarketTable from '../components/landing/MarketTable';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';

type AuthMode = 'signin' | 'signup' | 'forgot' | 'reset' | 'twofactor';
type Props = {
  authOpen?: boolean;
  authMode?: AuthMode;
  resetToken?: string;
  resetEmail?: string;
  flash?: { status?: string };
};
type AuthFields = {
  code: string;
  referral_code: string;
  name: string;
  email: string;
  country: string;
  dial: string;
  phone: string;
  password: string;
  password_confirmation: string;
  remember: boolean;
  token: string;
};

const products = [
  { icon: CandlestickChart, theme: 't-trade', title: 'Spot & Futures', copy: 'Sub-millisecond execution on 800+ pairs with up to 100× leverage and pro-grade order types.', cta: 'Start trading' },
  { icon: Bot, theme: 't-bots', title: 'Trading bots', copy: 'Allocate to vetted strategies and earn on a 24-hour cycle. Set it once, claim profits automatically.', cta: 'Browse strategies' },
  { icon: Leaf, theme: 't-earn', title: 'Earn', copy: 'Stake stablecoins for predictable yield. Flexible terms, no lockups, daily compounding.', cta: 'Earn now' },
  { icon: Users, theme: 't-copy', title: 'Copy trading', copy: 'Mirror top-ranked traders one-tap. Adjust risk, pause anytime, their wins on your wallet.', cta: 'Discover traders' },
];

const footerColumns = [
  { title: 'Markets', links: ['Markets', 'P2P Trading', 'Spot Trading', 'Convert'] },
  { title: 'Platform', links: ['Futures Trading', 'Trading Bots', 'Earn'] },
  { title: 'Learn', links: ['Learn Crypto', 'Getting Started', 'FAQ / Help', 'Blog'] },
  { title: 'Support', links: ['Security', 'Proof of Reserves', 'Fees', 'System Status', 'Support'] },
];

const footerHref: Record<string, string> = { 'Markets': '/markets', 'P2P Trading': '/p2p', 'Spot Trading': '/spot', 'Convert': '/convert', 'Futures Trading': '/futures', 'Trading Bots': '/bots', 'Earn': '/earn', 'Learn Crypto': '/learn', 'Getting Started': '/getting-started', 'FAQ / Help': '/faq', 'Blog': '/blog', 'Security': '/security', 'Proof of Reserves': '/proof-of-reserves', 'Fees': '/fees', 'System Status': '/status', 'Support': '/support' };

function Brand({ footer = false }: { footer?: boolean }) {
  return <a href="/" className={`lp-brand${footer ? ' lp-brand-footer' : ''}`} aria-label="RushX home">
    <img src={rushxMark} alt=""/><span>Rush<span>X</span></span>
  </a>;
}

function useLiveBtc() {
  const [btc, setBtc] = useState<{ price: number; change: number } | null>(null);
  useEffect(() => {
    let active = true; let timer: number | undefined;
    const load = async () => {
      try {
        const response = await fetch('/api/markets?type=spot&limit=6', { headers: { Accept: 'application/json' } });
        const result = await response.json();
        const market = result?.markets?.find((item: { baseAsset: string }) => item.baseAsset === 'BTC');
        if (active && market) setBtc({ price: market.lastPrice, change: market.change24h });
      } catch { /* keep placeholder */ }
      if (active) timer = window.setTimeout(load, 20_000);
    };
    void load();
    return () => { active = false; if (timer) window.clearTimeout(timer); };
  }, []);
  return btc;
}

function TerminalPreview() {
  const btc = useLiveBtc();
  const asks = [['67,433.30','0.42','28,322'],['67,432.90','0.6','40,460'],['67,432.50','0.78','52,597'],['67,432.10','0.96','64,735']];
  const bids = [['67,425.40','0.32','21,576'],['67,425.00','0.53','35,735'],['67,424.60','0.74','49,894'],['67,424.20','0.95','64,053']];
  const up = (btc?.change ?? 0) >= 0;
  return <div className="rf-reveal rf-visual" aria-label="Trading terminal preview">
    <div className="rf-terminal">
      <div className="rf-term-bar"><span className="dot r"/><span className="dot y"/><span className="dot g"/><span className="url">riseway.io/trade · BTCUSDT</span></div>
      <div className="rf-term-body">
        <div className="rf-term-chart">
          <div className="rf-tc-head">
            <div><div className="rf-tc-pair">BTC / USDT</div><div className="rf-tc-price">{btc ? `$${btc.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '$—'}</div><div className={`rf-tc-chg${up ? '' : ' dn'}`}>{btc ? `${up ? '+' : ''}${btc.change.toFixed(2)}%` : ''}</div></div>
            <div className="rf-tc-tabs"><span className="rf-tc-tab">1m</span><span className="rf-tc-tab">5m</span><span className="rf-tc-tab active">1H</span><span className="rf-tc-tab">1D</span></div>
          </div>
          <svg className="rf-tc-svg" viewBox="0 0 400 220" preserveAspectRatio="none" aria-hidden="true">
            <defs><linearGradient id="rfFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#C1F033" stopOpacity=".25"/><stop offset="100%" stopColor="#C1F033" stopOpacity="0"/></linearGradient></defs>
            <line x1="0" y1="50" x2="400" y2="50" stroke="rgba(255,255,255,0.04)"/><line x1="0" y1="110" x2="400" y2="110" stroke="rgba(255,255,255,0.04)"/><line x1="0" y1="170" x2="400" y2="170" stroke="rgba(255,255,255,0.04)"/>
            <path d="M0,180 L40,160 L80,140 L120,150 L160,120 L200,90 L240,100 L280,70 L320,60 L360,40 L400,30 L400,220 L0,220 Z" fill="url(#rfFill)"/>
            <path d="M0,180 L40,160 L80,140 L120,150 L160,120 L200,90 L240,100 L280,70 L320,60 L360,40 L400,30" fill="none" stroke="#C1F033" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ filter: 'drop-shadow(0 0 8px rgba(193,240,51,0.4))' }}/>
            <circle cx="400" cy="30" r="6" fill="#C1F033" opacity=".3"/><circle cx="400" cy="30" r="3" fill="#C1F033"/>
            <g opacity=".6"><rect x="20" y="155" width="3" height="20" fill="#2EBD85"/><rect x="60" y="135" width="3" height="22" fill="#2EBD85"/><rect x="100" y="138" width="3" height="14" fill="#F6465D"/><rect x="140" y="115" width="3" height="28" fill="#2EBD85"/><rect x="180" y="85" width="3" height="20" fill="#2EBD85"/><rect x="220" y="92" width="3" height="14" fill="#F6465D"/><rect x="260" y="65" width="3" height="20" fill="#2EBD85"/><rect x="300" y="55" width="3" height="16" fill="#2EBD85"/><rect x="340" y="35" width="3" height="18" fill="#2EBD85"/></g>
          </svg>
        </div>
        <div className="rf-term-side">
          <div className="rf-ts-section"><h4>Order book <span style={{ color: '#5B5D65' }}>ASK</span></h4>{asks.map(([p,a,t]) => <div className="rf-ts-row" key={p}><span className="px-r">{p}</span><span className="sz">{a}</span><span className="tot">{t}</span></div>)}</div>
          <div className="rf-ts-section" style={{ background: 'rgba(193,240,51,0.04)' }}><h4 style={{ color: '#C1F033' }}>SPREAD <span style={{ color: '#5B5D65' }}>0.01%</span></h4></div>
          <div className="rf-ts-section"><h4>BID</h4>{bids.map(([p,a,t]) => <div className="rf-ts-row" key={p}><span className="px-g">{p}</span><span className="sz">{a}</span><span className="tot">{t}</span></div>)}</div>
        </div>
      </div>
    </div>
    <div className="rf-float rf-float-pnl"><div className="lbl">Today’s PnL</div><div className="val">+$2,847.20</div></div>
    <div className="rf-float rf-float-vol"><div className="lbl">24h volume</div><div className="val" style={{ color: '#fff' }}>$2.4B</div></div>
  </div>;
}

function AuthDialog({
  mode, onMode, onClose, resetToken = '', resetEmail = '', status,
}: {
  mode: AuthMode;
  onMode: (mode: AuthMode) => void;
  onClose: () => void;
  resetToken?: string;
  resetEmail?: string;
  status?: string;
}) {
  const [showPassword, setShowPassword] = useState(false);
  const dialogRef = useRef<HTMLElement>(null);
  const form = useForm<AuthFields>({
    code: '', referral_code: (typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('ref') ?? '' : '').toUpperCase().slice(0, 12), name: '', email: resetEmail, country: 'Pakistan', dial: '+92', phone: '', password: '', password_confirmation: '', remember: false, token: resetToken,
  });
  const signup = mode === 'signup';
  const forgot = mode === 'forgot';
  const reset = mode === 'reset';

  useEffect(() => {
    const dialog = dialogRef.current;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const focusFirst = () => dialog?.querySelector<HTMLElement>('input:not([type="hidden"]), button')?.focus();
    const frame = requestAnimationFrame(focusFirst);
    const trapFocus = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab' || !dialog) return;
      const items = [...dialog.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),[tabindex]:not([tabindex="-1"])')];
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', trapFocus);
    return () => {
      cancelAnimationFrame(frame);
      document.removeEventListener('keydown', trapFocus);
      if (previous?.isConnected) previous.focus();
    };
  }, [onClose]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (mode === 'twofactor') form.post('/login/2fa', { onFinish: () => form.reset('code') });
    else if (signup) form.post('/register', { onFinish: () => form.reset('password', 'password_confirmation') });
    else if (forgot) form.post('/forgot-password', { onFinish: () => form.reset('password', 'password_confirmation') });
    else if (reset) form.post('/reset-password', { onFinish: () => form.reset('password', 'password_confirmation') });
    else form.post('/login', { onFinish: () => form.reset('password') });
  };

  return <div className="lp-auth-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="lp-auth-dialog" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="lp-auth-heading">
      <button type="button" className="lp-auth-close" onClick={onClose} aria-label="Close dialog"><X/></button>
      <Brand/>
      {(mode === 'signin' || signup) && <div className="lp-auth-tabs" role="group" aria-label="Account access">
        <button type="button" aria-pressed={!signup} className={!signup ? 'active' : ''} onClick={() => onMode('signin')}>Sign in</button>
        <button type="button" aria-pressed={signup} className={signup ? 'active' : ''} onClick={() => onMode('signup')}>Sign up</button>
      </div>}
      <h2 id="lp-auth-heading">{mode === 'twofactor' ? 'Two-factor authentication' : signup ? 'Create your account' : forgot ? 'Reset your password' : reset ? 'Choose a new password' : 'Welcome back'}</h2>
      <p className="lp-auth-sub">{mode === 'twofactor' ? 'Enter the 6-digit code from your authenticator app, or a recovery code.' : signup ? 'Start with your RushX account.' : forgot ? 'We’ll email you a secure password reset link.' : reset ? 'Create a new password for your account.' : 'Sign in to your RushX account.'}</p>
      {status && <div className="lp-form-success" role="status">{status}</div>}
      {Object.keys(form.errors).length > 0 && <div className="lp-form-alert" role="alert">{Object.values(form.errors)[0]}</div>}
      <form onSubmit={submit} className="lp-auth-form">
        {mode === 'twofactor' && <label>Authentication code<input autoFocus inputMode="text" autoComplete="one-time-code" value={form.data.code} onChange={e => form.setData('code', e.target.value)} placeholder="123456" maxLength={20} required/>{form.errors.code && <small className="lp-field-error">{form.errors.code}</small>}</label>}
        {signup && <label>Full name<input autoComplete="name" value={form.data.name} onChange={e => form.setData('name',e.target.value)} placeholder="Your name" required maxLength={100}/>{form.errors.name && <small className="lp-field-error">{form.errors.name}</small>}</label>}
        {(mode === 'signin' || signup || forgot || reset) && <label>Email address<input type="email" autoComplete="email" value={form.data.email} onChange={e => form.setData('email',e.target.value)} placeholder="you@example.com" required maxLength={190}/>{form.errors.email && <small className="lp-field-error">{form.errors.email}</small>}</label>}
        {signup && <label>Country<select value={form.data.country} onChange={e => { const c = COUNTRIES.find(x => x.name === e.target.value); form.setData(d => ({ ...d, country: e.target.value, dial: c?.dial ?? d.dial })); }} required>{COUNTRIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}</select>{form.errors.country && <small className="lp-field-error">{form.errors.country}</small>}</label>}
        {signup && <label>Mobile number<span className="lp-phone"><select aria-label="Country code" value={form.data.dial} onChange={e => form.setData('dial', e.target.value)}>{Array.from(new Set(COUNTRIES.map(c => c.dial))).sort((a, b) => Number(a.slice(1)) - Number(b.slice(1))).map(d => <option key={d} value={d}>{d}</option>)}</select><input type="tel" inputMode="numeric" autoComplete="tel-national" placeholder="3001234567" value={form.data.phone} onChange={e => form.setData('phone', e.target.value.replace(/\D/g, '').slice(0, 14))} required minLength={5}/></span>{(form.errors.phone || form.errors.dial) && <small className="lp-field-error">{form.errors.phone || form.errors.dial}</small>}</label>}
        {(mode === 'signin' || signup || reset) && <label>{reset ? 'New password' : 'Password'}<span className="lp-password-wrap"><input type={showPassword ? 'text' : 'password'} autoComplete={signup || reset ? 'new-password' : 'current-password'} value={form.data.password} onChange={e => form.setData('password',e.target.value)} placeholder={signup || reset ? 'Create a strong password' : 'Enter your password'} required minLength={signup || reset ? 12 : undefined}/><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOff/> : <Eye/>}</button></span>{form.errors.password && <small className="lp-field-error">{form.errors.password}</small>}</label>}
        {signup || reset ? <label>Confirm password<input type="password" autoComplete="new-password" value={form.data.password_confirmation} onChange={e => form.setData('password_confirmation',e.target.value)} placeholder="Enter password again" required/>{form.errors.password_confirmation && <small className="lp-field-error">{form.errors.password_confirmation}</small>}</label> : null}
        {signup && <label>Referral code <small style={{ opacity: .6 }}>(optional)</small><input value={form.data.referral_code} onChange={e => form.setData('referral_code', e.target.value.toUpperCase().slice(0, 12))} placeholder="Enter code if you have one" autoComplete="off" maxLength={12}/>{form.errors.referral_code && <span className="lp-field-error" role="alert">{form.errors.referral_code}</span>}</label>}
        {mode === 'reset' && <input type="hidden" name="token" value={form.data.token}/>}
        {mode === 'signin' && <label className="lp-remember"><input type="checkbox" checked={form.data.remember} onChange={e => form.setData('remember',e.target.checked)}/> Remember me</label>}
        <button className="lp-submit" disabled={form.processing}>{form.processing ? 'Please wait…' : mode === 'twofactor' ? 'Verify' : signup ? 'Create account' : forgot ? 'Email reset link' : reset ? 'Update password' : 'Sign in'} <ArrowRight/></button>
      </form>
      {mode === 'signin' && <button className="lp-auth-text-button" type="button" onClick={() => onMode('forgot')}>Forgot password?</button>}
      {(forgot || reset) && <button className="lp-auth-text-button" type="button" onClick={() => onMode('signin')}>Back to sign in</button>}
      {mode === 'twofactor' && <button className="lp-auth-text-button" type="button" onClick={() => router.post('/login/2fa/cancel')}>Back to sign in</button>}
      <div className="lp-auth-security"><ShieldCheck/> Secure account access <span/><LockKeyhole/> Encrypted session</div>
    </section>
  </div>;
}

function ComingSoonDialog({ title, onClose }: { title: string; onClose: () => void }) {
  const dialogRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const dialog = dialogRef.current;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const frame = requestAnimationFrame(() => dialog?.querySelector<HTMLElement>('button')?.focus());
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { onClose(); return; }
      if (event.key !== 'Tab' || !dialog) return;
      const items = [...dialog.querySelectorAll<HTMLElement>('button:not([disabled]),[tabindex]:not([tabindex="-1"])')];
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', onKey);
    return () => { cancelAnimationFrame(frame); document.removeEventListener('keydown', onKey); document.body.style.overflow = oldOverflow; };
  }, [onClose]);
  return <div className="lp-auth-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="lp-feature-dialog" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="lp-feature-heading">
      <button type="button" className="lp-auth-close" onClick={onClose} aria-label="Close dialog"><X/></button>
      <div className="lp-feature-icon"><CandlestickChart/></div><span className="lp-kicker">RUSHX PLATFORM</span>
      <h2 id="lp-feature-heading">{title}</h2><p>This section is planned for a future release. It is not available yet.</p>
      <button type="button" className="lp-submit" onClick={onClose}>Got it <Check/></button>
    </section>
  </div>;
}

export default function Landing({ authOpen = false, authMode = 'signin', resetToken, resetEmail, flash }: Props) {
  const shared = usePage().props as { auth?: { user?: HeaderUser | null } };
  const authenticatedUser = shared.auth?.user ?? null;
  const [dark, setDark] = useState(() => {
    try { return typeof localStorage === 'undefined' || localStorage.getItem('rushx-theme') !== 'light'; }
    catch { return true; }
  });
  const [feature, setFeature] = useState('');
  const lastFocusedRef = useRef<HTMLElement | null>(null);
  const mode = authMode;
  const closeFeature = useCallback(() => setFeature(''), []);

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.body.classList.add('landing-page');
    try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* Preference is optional. */ }
    return () => { document.body.classList.remove('landing-page'); };
  }, [dark]);

  useEffect(() => {
    if (!authOpen) {
      document.body.style.overflow = '';
      requestAnimationFrame(() => lastFocusedRef.current?.focus());
      return;
    }
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = oldOverflow; };
  }, [authOpen]);


  const rememberTrigger = () => { lastFocusedRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null; };
  const setAuthMode = useCallback((next: AuthMode) => router.get(`/login?mode=${next}`, {}, { preserveScroll: true }), []);
  const openAuth = (next: AuthMode) => { rememberTrigger(); setAuthMode(next); };
  const closeAuth = useCallback(() => router.get('/', {}, { preserveScroll: true }), []);
  const openFeature = (title: string) => setFeature(title);

  useEffect(() => {
    const items = Array.from(document.querySelectorAll('.rf-reveal'));
    if (!('IntersectionObserver' in window)) { items.forEach(el => el.classList.add('in')); return; }
    const io = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('in'); io.unobserve(entry.target); } }), { threshold: 0.1, rootMargin: '0px 0px -10% 0px' });
    items.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  return <>
    <Head title="RushX — Digital asset markets">
      <meta name="description" content="Explore RushX digital asset markets and account tools."/>
      <meta name="theme-color" content={dark ? '#050505' : '#f6f7f4'}/>
    </Head>
    <div className="lp-site">
        <RushXHeader user={authenticatedUser} dark={dark} onToggleTheme={() => setDark(value => !value)}/>
      {flash?.status && <div className="lp-flash" role="status">{flash.status}</div>}

      <main className="rf-page">
        <div className="rf-glow"/><div className="rf-grid-bg"/>
        <section className="rf-container rf-hero">
          <div>
            <span className="rf-eyebrow"><span className="pulse"/> Live · trusted by 70M+ traders</span>
            <h1>Trade smarter on the<br/><span className="rf-accent">institutional</span> exchange</h1>
            <p>Spot, futures, automated bots, and yield products — built for both first-time buyers and pros, on one premium terminal.</p>
            <div className="rf-cta-row"><button type="button" className="rf-btn-primary" onClick={() => openAuth('signup')}>Sign up free <ArrowRight/></button><button type="button" className="rf-btn-ghost" onClick={() => openAuth('signin')}>Sign in</button></div>
            <div className="rf-trust"><span><ShieldCheck/> Bank-grade custody</span><span><Zap/> 0.02% fees from</span><span><Globe2/> 180+ countries</span></div>
          </div>
          <TerminalPreview/>
        </section>
        <section className="rf-stats"><div className="rf-container"><div className="rf-stats-grid">
          <div className="rf-reveal"><div className="rf-stat-val"><span className="a">70M+</span></div><div className="rf-stat-lbl">Verified traders</div></div>
          <div className="rf-reveal"><div className="rf-stat-val">$<span className="a">2.4T</span></div><div className="rf-stat-lbl">Lifetime volume</div></div>
          <div className="rf-reveal"><div className="rf-stat-val"><span className="a">800+</span></div><div className="rf-stat-lbl">Trading pairs</div></div>
          <div className="rf-reveal"><div className="rf-stat-val"><span className="a">180</span>+</div><div className="rf-stat-lbl">Countries supported</div></div>
        </div></div></section>
        <MarketTable onTrade={() => openAuth('signup')} onAllMarkets={() => openAuth('signup')}/>
        <section id="products" className="rf-section" style={{ paddingTop: 0 }}><div className="rf-container">
          <div className="rf-section-head"><div><h2 className="rf-reveal">One platform.<br/>Every way to grow.</h2><p className="rf-reveal">From spot trading to automated strategies and yield products — built for first-time buyers and institutional desks alike.</p></div></div>
          <div className="rf-products">{products.map(({ icon: Icon, theme, title, copy, cta }) => <button type="button" className={`rf-product ${theme} rf-reveal`} key={title} onClick={() => openFeature(title)}><div className="rf-prod-icon"><Icon/></div><h3>{title}</h3><p>{copy}</p><div className="rf-product-cta">{cta} <ArrowRight/></div></button>)}</div>
        </div></section>
        <section className="lp-container lp-cta-wrap"><div className="lp-cta"><span className="lp-kicker">START WITH RUSHX</span><h2>Trade with the pros.<br/><span>Start in minutes.</span></h2><p>Create an account to explore the RushX dashboard and available tools.</p><button type="button" className="lp-button lp-button-primary lp-button-large" onClick={() => openAuth('signup')}>Create free account <ArrowRight/></button><div className="lp-cta-lock"><Check/> Simple account setup <span/> <LockKeyhole/> Protected sign-in</div></div></section>
      </main>

      <footer id="footer" className="lp-footer"><div className="lp-container"><div className="lp-footer-grid"><div className="lp-footer-brand"><Brand footer/><p>Trade spot and futures, copy bots, earn yield and move money by P2P — one secure account, live market prices and 24/7 support.</p><div className="lp-footer-social" aria-label="Social channels not configured"><span aria-label="X social"><b>𝕏</b></span><span aria-label="Telegram community"><Send/></span><span aria-label="Help center"><CircleHelp/></span></div></div>{footerColumns.map(column=><div key={column.title}><h4>{column.title}</h4>{column.links.map(label=>footerHref[label]?<a href={footerHref[label]} key={label}>{label}</a>:<button type="button" onClick={() => openFeature(label)} key={label}>{label}</button>)}</div>)}</div><div className="lp-footer-bottom"><span>© 2017 – 2026 <b>RushX Exchange</b></span><span>Live market prices via Bybit</span><div><button type="button" onClick={() => openFeature('Terms of Service')}>Terms of Service</button><button type="button" onClick={() => openFeature('Privacy')}>Privacy</button><button type="button" onClick={() => openFeature('AML / KYC')}>AML / KYC</button><button type="button" onClick={() => openFeature('Fees')}>Fees</button></div></div></div></footer>
      {authOpen && <AuthDialog key={`${mode}-${resetToken ?? ''}`} mode={mode} onMode={setAuthMode} onClose={closeAuth} resetToken={resetToken} resetEmail={resetEmail} status={flash?.status}/>} 
      {feature && <ComingSoonDialog title={feature} onClose={closeFeature}/>} 
    </div>
  </>;
}
