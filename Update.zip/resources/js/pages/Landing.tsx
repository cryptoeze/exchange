import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Head, router, useForm, usePage } from '@inertiajs/react';
import {
  ArrowRight, Bot, MessageSquare, CandlestickChart, Leaf, Check, CircleHelp, Eye, EyeOff, Globe2,
  LockKeyhole, Send, ShieldCheck, Users, X, Zap,
} from 'lucide-react';
import rushxMark from '../../images/rushx-mark.svg';
import MarketTable from '../components/landing/MarketTable';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';

type AuthMode = 'signin' | 'signup' | 'forgot' | 'reset';
type Props = {
  authOpen?: boolean;
  authMode?: AuthMode;
  resetToken?: string;
  resetEmail?: string;
  flash?: { status?: string };
};
type AuthFields = {
  name: string;
  email: string;
  password: string;
  password_confirmation: string;
  remember: boolean;
  token: string;
};

const products = [
  { icon: CandlestickChart, title: 'Spot & Futures', copy: 'Sub-millisecond execution on 800+ pairs with up to 100× leverage and pro-grade order types.', cta: 'Start trading' },
  { icon: Bot, title: 'Trading bots', copy: 'Allocate to vetted strategies and earn on a 24-hour cycle. Set it once, claim profits automatically.', cta: 'Browse strategies' },
  { icon: Leaf, title: 'Earn', copy: 'Stake stablecoins for predictable yield. Flexible terms, no lockups, daily compounding.', cta: 'Earn now' },
  { icon: Users, title: 'Copy trading', copy: 'Mirror top-ranked traders one-tap. Adjust risk, pause anytime, their wins on your wallet.', cta: 'Discover traders' },
];

const footerColumns = [
  { title: 'Products', links: ['Spot', 'Futures', 'Convert', 'Events & Options', 'Copy trading', 'Trading bots', 'Agent Trade Kit', 'xAssets'] },
  { title: 'Grow', links: ['Earn', 'Loan', 'Jumpstart', 'Rewards', 'Referrals', 'VIP program', 'Marketplace'] },
  { title: 'Institutional', links: ['Institutional home', 'API docs', 'TradingView', 'RushX Ventures', 'Listing application', 'RushX Protect', 'Proof of Reserves'] },
  { title: 'Support', links: ['Help center', 'My tickets', 'System status', 'Security of funds', 'News & blog', 'Livestream'] },
];

function Brand({ footer = false }: { footer?: boolean }) {
  return <a href="/" className={`lp-brand${footer ? ' lp-brand-footer' : ''}`} aria-label="RushX home">
    <img src={rushxMark} alt=""/><span>Rush<span>X</span></span>
  </a>;
}

function MarketChart() {
  return <svg className="lp-chart-svg" viewBox="0 0 560 250" preserveAspectRatio="none" aria-label="Illustrative BTC market chart" role="img">
    <defs><linearGradient id="landingChartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--lp-accent)" stopOpacity=".29"/><stop offset="1" stopColor="var(--lp-accent)" stopOpacity="0"/></linearGradient></defs>
    <path d="M0 205 C18 195 21 208 43 188 S66 194 85 172 S108 182 126 151 S149 168 168 130 S192 147 211 108 S232 124 251 93 S278 112 296 79 S319 95 338 62 S359 77 380 50 S407 71 427 40 S452 55 471 29 S502 44 522 17 S543 29 560 8 L560 250 L0 250Z" fill="url(#landingChartFill)"/>
    <path d="M0 205 C18 195 21 208 43 188 S66 194 85 172 S108 182 126 151 S149 168 168 130 S192 147 211 108 S232 124 251 93 S278 112 296 79 S319 95 338 62 S359 77 380 50 S407 71 427 40 S452 55 471 29 S502 44 522 17 S543 29 560 8" fill="none" stroke="var(--lp-accent)" strokeWidth="3" strokeLinecap="round"/>
  </svg>;
}

function TerminalPreview() {
  const asks = [['67,433.30','0.42','28,322'],['67,432.90','0.60','40,460'],['67,432.50','0.78','52,597'],['67,432.10','0.96','64,735']];
  const bids = [['67,425.40','0.32','21,576'],['67,425.00','0.53','35,735'],['67,424.60','0.74','49,894'],['67,424.20','0.95','64,053']];
  return <div className="lp-terminal-wrap"><div className="lp-terminal" aria-label="Trading terminal preview">
    <div className="lp-terminal-bar"><span className="lp-window-dots"><i/><i/><i/></span><span className="lp-terminal-url">rushx.exchange/trade · BTCUSDT</span></div>
    <div className="lp-terminal-summary"><div><span className="lp-pair">BTC / USDT</span><div className="lp-terminal-price"><strong>$84,500.90</strong><small className="lp-positive">+0.39%</small></div></div><div className="lp-intervals"><span>1m</span><span>5m</span><b>1H</b><span>1D</span></div></div>
    <div className="lp-terminal-main"><div className="lp-terminal-chart"><div className="lp-chart-grid"><i/><i/><i/><i/></div><MarketChart/></div>
      <aside className="lp-orderbook"><div className="lp-orderbook-title"><b>ORDER BOOK</b></div>{asks.map(([price,amount,total])=><div className="lp-book-row lp-ask" key={price}><span>{price}</span><span>{amount}</span><i>{total}</i></div>)}<div className="lp-book-spread"><b>SPREAD</b><small>0.01%</small></div><div className="lp-orderbook-title"><b>BID</b></div>{bids.map(([price,amount,total])=><div className="lp-book-row lp-bid" key={price}><span>{price}</span><span>{amount}</span><i>{total}</i></div>)}</aside>
    </div>
  </div>
  <div className="lp-float lp-float-pnl"><small>TODAY’S PNL</small><b>+$2,847.20</b></div>
  <div className="lp-float lp-float-vol"><small>24H VOLUME</small><b>$2.4B</b></div></div>;
}

function AuthDialog({
  mode, onMode, onClose, resetToken = '', resetEmail = '', status,
}: {
  mode: AuthMode;
  onMode: (mode: AuthMode) => void;
  onClose: () => void;
  resetToken?: string;
  resetEmail?: string;
  status?: string;
}) {
  const [showPassword, setShowPassword] = useState(false);
  const dialogRef = useRef<HTMLElement>(null);
  const form = useForm<AuthFields>({
    name: '', email: resetEmail, password: '', password_confirmation: '', remember: false, token: resetToken,
  });
  const signup = mode === 'signup';
  const forgot = mode === 'forgot';
  const reset = mode === 'reset';

  useEffect(() => {
    const dialog = dialogRef.current;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const focusFirst = () => dialog?.querySelector<HTMLElement>('input:not([type="hidden"]), button')?.focus();
    const frame = requestAnimationFrame(focusFirst);
    const trapFocus = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab' || !dialog) return;
      const items = [...dialog.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),[tabindex]:not([tabindex="-1"])')];
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', trapFocus);
    return () => {
      cancelAnimationFrame(frame);
      document.removeEventListener('keydown', trapFocus);
      if (previous?.isConnected) previous.focus();
    };
  }, [onClose]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (signup) form.post('/register', { onFinish: () => form.reset('password', 'password_confirmation') });
    else if (forgot) form.post('/forgot-password', { onFinish: () => form.reset('password', 'password_confirmation') });
    else if (reset) form.post('/reset-password', { onFinish: () => form.reset('password', 'password_confirmation') });
    else form.post('/login', { onFinish: () => form.reset('password') });
  };

  return <div className="lp-auth-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="lp-auth-dialog" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="lp-auth-heading">
      <button type="button" className="lp-auth-close" onClick={onClose} aria-label="Close dialog"><X/></button>
      <Brand/>
      {(mode === 'signin' || signup) && <div className="lp-auth-tabs" role="group" aria-label="Account access">
        <button type="button" aria-pressed={!signup} className={!signup ? 'active' : ''} onClick={() => onMode('signin')}>Sign in</button>
        <button type="button" aria-pressed={signup} className={signup ? 'active' : ''} onClick={() => onMode('signup')}>Sign up</button>
      </div>}
      <h2 id="lp-auth-heading">{signup ? 'Create your account' : forgot ? 'Reset your password' : reset ? 'Choose a new password' : 'Welcome back'}</h2>
      <p className="lp-auth-sub">{signup ? 'Start with your RushX account.' : forgot ? 'We’ll email you a secure password reset link.' : reset ? 'Create a new password for your account.' : 'Sign in to your RushX account.'}</p>
      {status && <div className="lp-form-success" role="status">{status}</div>}
      {Object.keys(form.errors).length > 0 && <div className="lp-form-alert" role="alert">{Object.values(form.errors)[0]}</div>}
      <form onSubmit={submit} className="lp-auth-form">
        {signup && <label>Full name<input autoComplete="name" value={form.data.name} onChange={e => form.setData('name',e.target.value)} placeholder="Your name" required maxLength={100}/>{form.errors.name && <small className="lp-field-error">{form.errors.name}</small>}</label>}
        {(mode === 'signin' || signup || forgot || reset) && <label>Email address<input type="email" autoComplete="email" value={form.data.email} onChange={e => form.setData('email',e.target.value)} placeholder="you@example.com" required maxLength={190}/>{form.errors.email && <small className="lp-field-error">{form.errors.email}</small>}</label>}
        {(mode === 'signin' || signup || reset) && <label>{reset ? 'New password' : 'Password'}<span className="lp-password-wrap"><input type={showPassword ? 'text' : 'password'} autoComplete={signup || reset ? 'new-password' : 'current-password'} value={form.data.password} onChange={e => form.setData('password',e.target.value)} placeholder={signup || reset ? 'Create a strong password' : 'Enter your password'} required minLength={signup || reset ? 12 : undefined}/><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOff/> : <Eye/>}</button></span>{form.errors.password && <small className="lp-field-error">{form.errors.password}</small>}</label>}
        {signup || reset ? <label>Confirm password<input type="password" autoComplete="new-password" value={form.data.password_confirmation} onChange={e => form.setData('password_confirmation',e.target.value)} placeholder="Enter password again" required/>{form.errors.password_confirmation && <small className="lp-field-error">{form.errors.password_confirmation}</small>}</label> : null}
        {mode === 'reset' && <input type="hidden" name="token" value={form.data.token}/>}
        {mode === 'signin' && <label className="lp-remember"><input type="checkbox" checked={form.data.remember} onChange={e => form.setData('remember',e.target.checked)}/> Remember me</label>}
        <button className="lp-submit" disabled={form.processing}>{form.processing ? 'Please wait…' : signup ? 'Create account' : forgot ? 'Email reset link' : reset ? 'Update password' : 'Sign in'} <ArrowRight/></button>
      </form>
      {mode === 'signin' && <button className="lp-auth-text-button" type="button" onClick={() => onMode('forgot')}>Forgot password?</button>}
      {(forgot || reset) && <button className="lp-auth-text-button" type="button" onClick={() => onMode('signin')}>Back to sign in</button>}
      <div className="lp-auth-security"><ShieldCheck/> Secure account access <span/><LockKeyhole/> Encrypted session</div>
    </section>
  </div>;
}

function ComingSoonDialog({ title, onClose }: { title: string; onClose: () => void }) {
  const dialogRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const dialog = dialogRef.current;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const frame = requestAnimationFrame(() => dialog?.querySelector<HTMLElement>('button')?.focus());
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { onClose(); return; }
      if (event.key !== 'Tab' || !dialog) return;
      const items = [...dialog.querySelectorAll<HTMLElement>('button:not([disabled]),[tabindex]:not([tabindex="-1"])')];
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', onKey);
    return () => { cancelAnimationFrame(frame); document.removeEventListener('keydown', onKey); document.body.style.overflow = oldOverflow; };
  }, [onClose]);
  return <div className="lp-auth-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="lp-feature-dialog" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="lp-feature-heading">
      <button type="button" className="lp-auth-close" onClick={onClose} aria-label="Close dialog"><X/></button>
      <div className="lp-feature-icon"><CandlestickChart/></div><span className="lp-kicker">RUSHX PLATFORM</span>
      <h2 id="lp-feature-heading">{title}</h2><p>This section is planned for a future release. It is not available yet.</p>
      <button type="button" className="lp-submit" onClick={onClose}>Got it <Check/></button>
    </section>
  </div>;
}

export default function Landing({ authOpen = false, authMode = 'signin', resetToken, resetEmail, flash }: Props) {
  const shared = usePage().props as { auth?: { user?: HeaderUser | null } };
  const authenticatedUser = shared.auth?.user ?? null;
  const [dark, setDark] = useState(() => {
    try { return typeof localStorage === 'undefined' || localStorage.getItem('rushx-theme') !== 'light'; }
    catch { return true; }
  });
  const [feature, setFeature] = useState('');
  const lastFocusedRef = useRef<HTMLElement | null>(null);
  const mode = authMode;
  const closeFeature = useCallback(() => setFeature(''), []);

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.body.classList.add('landing-page');
    try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* Preference is optional. */ }
    return () => { document.body.classList.remove('landing-page'); };
  }, [dark]);

  useEffect(() => {
    if (!authOpen) {
      document.body.style.overflow = '';
      requestAnimationFrame(() => lastFocusedRef.current?.focus());
      return;
    }
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = oldOverflow; };
  }, [authOpen]);


  const rememberTrigger = () => { lastFocusedRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null; };
  const setAuthMode = useCallback((next: AuthMode) => router.get(`/login?mode=${next}`, {}, { preserveScroll: true }), []);
  const openAuth = (next: AuthMode) => { rememberTrigger(); setAuthMode(next); };
  const closeAuth = useCallback(() => router.get('/', {}, { preserveScroll: true }), []);
  const openFeature = (title: string) => setFeature(title);

  return <>
    <Head title="RushX — Digital asset markets">
      <meta name="description" content="Explore RushX digital asset markets and account tools."/>
      <meta name="theme-color" content={dark ? '#050505' : '#f6f7f4'}/>
    </Head>
    <div className="lp-site">
        <RushXHeader user={authenticatedUser} dark={dark} onToggleTheme={() => setDark(value => !value)}/>
      {flash?.status && <div className="lp-flash" role="status">{flash.status}</div>}

      <main>
        <section className="lp-container lp-hero"><div className="lp-hero-copy"><span className="lp-eyebrow"><i/> LIVE · TRUSTED BY 70M+ TRADERS</span><h1>Trade smarter on the <span>institutional</span> exchange</h1><p>Spot, futures, automated bots, and yield products — both first-time buyers and pros, on one premium terminal.</p><div className="lp-hero-actions"><button type="button" className="lp-button lp-button-primary lp-button-large" onClick={() => openAuth('signup')}>Sign up free <ArrowRight/></button><button type="button" className="lp-button lp-button-quiet lp-button-large" onClick={() => openAuth('signin')}>Sign in</button></div><div className="lp-trust-row"><span><ShieldCheck/> Bank-grade custody</span><span><Zap/> 0.02% fees from</span><span><Globe2/> 180+ countries</span></div></div><div className="lp-hero-visual"><TerminalPreview/></div></section>
        <section className="lp-stats" aria-label="RushX platform areas"><div className="lp-container lp-stats-inner"><div><strong>70M+</strong><span>Registered users</span></div><div><strong>$2.4T</strong><span>Trading volume</span></div><div><strong>800+</strong><span>Trading pairs</span></div><div><strong>180+</strong><span>Countries</span></div></div></section>
        <MarketTable onTrade={() => openAuth('signin')} onAllMarkets={() => openFeature('All markets')}/>
        <section id="products" className="lp-container lp-section lp-products-section"><div className="lp-section-head"><div><h2>One platform.<br/>Every way to grow.</h2><p>From spot trading to automated strategies and yield products — built for first-time buyers and institutional desks alike.</p></div></div><div className="lp-products">{products.map(({icon:Icon,title,copy,cta},index)=><article className="lp-product-card" key={title}><div className="lp-product-icon"><Icon/></div><span className="lp-product-index">0{index+1}</span><h3>{title}</h3><p>{copy}</p><button type="button" onClick={() => openFeature(title)}>{cta} <ArrowRight/></button></article>)}</div></section>
        <section className="lp-container lp-cta-wrap"><div className="lp-cta"><h2>Trade with the pros.<br/>Start in <span>3 minutes.</span></h2><p>No paperwork. No phone trees. Just sign up, fund your wallet, and trade.</p><div className="lp-hero-actions lp-cta-actions"><button type="button" className="lp-button lp-button-primary lp-button-large" onClick={() => openAuth('signup')}>Create free account <ArrowRight/></button><button type="button" className="lp-button lp-button-quiet lp-button-large" onClick={() => openAuth('signin')}>Sign in</button></div></div></section>
      </main>

      <footer id="footer" className="lp-footer"><div className="lp-container"><div className="lp-footer-grid"><div className="lp-footer-brand"><Brand footer/><p>The institutional-grade crypto exchange for spot, futures, options and on-chain. Trusted by 2M+ traders across 180 countries.</p><div className="lp-footer-social" aria-label="Social channels not configured"><span aria-label="X social"><b>𝕏</b></span><span aria-label="Telegram community"><Send/></span><span aria-label="Community chat"><MessageSquare/></span><span aria-label="Website"><Globe2/></span><span aria-label="Help center"><CircleHelp/></span></div></div>{footerColumns.map(column=><div key={column.title}><h4>{column.title}</h4>{column.links.map(label=><button type="button" onClick={() => openFeature(label)} key={label}>{label}</button>)}</div>)}</div><div className="lp-footer-bottom"><span>© 2017 – 2026 <b>RushX Exchange</b>. All rights reserved.</span><div><button type="button" onClick={() => openFeature('Terms of Service')}>Terms of Service</button><button type="button" onClick={() => openFeature('Privacy')}>Privacy</button><button type="button" onClick={() => openFeature('AML / KYC')}>AML / KYC</button><button type="button" onClick={() => openFeature('Fees')}>Fees</button></div><span className="lp-regulated"><i/> REGULATED · 14 JURISDICTIONS</span></div></div></footer>
      {authOpen && <AuthDialog key={`${mode}-${resetToken ?? ''}`} mode={mode} onMode={setAuthMode} onClose={closeAuth} resetToken={resetToken} resetEmail={resetEmail} status={flash?.status}/>} 
      {feature && <ComingSoonDialog title={feature} onClose={closeFeature}/>} 
    </div>
  </>;
}
