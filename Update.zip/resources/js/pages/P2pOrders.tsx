import { useEffect, useState } from 'react';
import { Head } from '@inertiajs/react';
import AccountLayout from '../components/AccountLayout';
import { api } from '../lib/wallet';
import { money, STATUS_LABEL, STATUS_TONE } from '../lib/p2p';
import '../../css/p2p.css';

type Row = { ref: string; role: 'buyer' | 'seller'; coin: string; fiat: string; qty: string; fiatAmount: number; price: number; status: string; other: string; at: string };

export default function P2pOrders() {
  const [rows, setRows] = useState<Row[] | null>(null);
  useEffect(() => { const load = async () => { const r = await api<{ trades: Row[] }>('/api/p2p/trades'); if (r.ok) setRows(r.data.trades); }; void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 8000); return () => window.clearInterval(t); }, []);
  return <AccountLayout active="P2P" title="My P2P orders" showNav={false} phoneBar>
    <Head title="My P2P orders — RushX"/>
    <main className="p2-wrap">
      <div className="p2-top"><h1 className="p2-h1">My orders</h1><div className="p2-links"><a href="/p2p">Marketplace</a><a href="/p2p/ads">My ads</a></div></div>
      {rows === null ? <p className="p2-empty">Loading…</p> : rows.length === 0 ? <div className="p2-empty"><b>No orders yet.</b><span><a href="/p2p">Browse offers</a> to place your first P2P order.</span></div> :
        <div className="p2-list">{rows.map(r => <a key={r.ref} className="p2-ad p2-order" href={`/p2p/orders/${r.ref}`}>
          <header><span className={`p2-role ${r.role}`}>{r.role === 'buyer' ? 'BUY' : 'SELL'}</span><b>{r.qty} {r.coin}</b><em style={{ color: STATUS_TONE[r.status] }}>{STATUS_LABEL[r.status] ?? r.status}</em></header>
          <div className="p2-sub">{money(r.fiatAmount)} {r.fiat} · {money(r.price)} per {r.coin}</div><div className="p2-sub">With {r.other} · {r.at}</div></a>)}</div>}
    </main>
  </AccountLayout>;
}
