import { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronDown, Clock, List, Loader2, Search } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { api, type OrderRow } from '../lib/wallet';

type Tab = 'open' | 'history';
const TYPES: Array<[string, string]> = [['', 'All types'], ['buy', 'Buy'], ['sell', 'Sell']];
const RANGES: Array<[string, string]> = [['7', 'Past 7 days'], ['30', 'Past 30 days'], ['90', 'Past 90 days'], ['', 'All time']];
const stamp = (iso: string | null) => iso ? new Date(iso).toLocaleString('sv-SE').replace('T', ' ') : '';
const num = (v: number, d = 2) => v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });

/** Order center: filled orders from the server. Spot orders fill instantly, so "Open" only lists resting orders (none yet). */
export default function OrderCenter() {
  const [tab, setTab] = useState<Tab>('history');
  const [side, setSide] = useState(''); const [days, setDays] = useState('30'); const [query, setQuery] = useState('');
  const [rows, setRows] = useState<OrderRow[]>([]); const [more, setMore] = useState(false); const [busy, setBusy] = useState(true); const [error, setError] = useState('');
  const [menu, setMenu] = useState<'type' | 'range' | null>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const seq = useRef(0);

  useEffect(() => { const close = (e: PointerEvent) => { if (wrap.current && !wrap.current.contains(e.target as Node)) setMenu(null); }; document.addEventListener('pointerdown', close); return () => document.removeEventListener('pointerdown', close); }, []);

  const load = useCallback(async (before?: number) => {
    const id = ++seq.current;
    const params = new URLSearchParams({ limit: '50' });
    if (side) params.set('side', side); if (days) params.set('days', days); if (query.trim()) params.set('q', query.trim()); if (before) params.set('before', String(before));
    setBusy(true);
    const r = await api<{ orders: OrderRow[]; hasMore: boolean }>(`/api/spot/orders?${params}`);
    if (id !== seq.current) return;
    setBusy(false);
    if (r.status === 401) { window.location.href = '/login'; return; }
    if (!r.ok) { setError('Orders could not be loaded.'); return; }
    setError(''); setMore(r.data.hasMore); setRows(prev => before ? [...prev, ...r.data.orders] : r.data.orders);
  }, [side, days, query]);
  useEffect(() => { const t = window.setTimeout(() => void load(), query ? 250 : 0); return () => window.clearTimeout(t); }, [load, query]);

  const shown = tab === 'open' ? [] : rows;
  const typeLabel = TYPES.find(t => t[0] === side)?.[1]; const rangeLabel = RANGES.find(r => r[0] === days)?.[1];

  return <AccountLayout active="Order center" title="Order center">
    <main className="ap-wrap">
      <h1 className="ap-title">Order center</h1>
      <section className="ap-panel" ref={wrap}>
        <div className="ap-tabs"><button type="button" className={tab === 'open' ? 'active' : ''} onClick={() => setTab('open')}>Open orders</button><button type="button" className={tab === 'history' ? 'active' : ''} onClick={() => setTab('history')}>Order history</button></div>
        <div className="ap-filters">
          <div className="ap-pillwrap"><button type="button" className="ap-pill" aria-expanded={menu === 'type'} onClick={() => setMenu(m => m === 'type' ? null : 'type')}>{typeLabel}<ChevronDown/></button>
            {menu === 'type' && <div className="ap-menu left" role="menu">{TYPES.map(([v, l]) => <button type="button" role="menuitemradio" aria-checked={side === v} key={l} onClick={() => { setSide(v); setMenu(null); }}>{l}</button>)}</div>}</div>
          <div className="ap-pillwrap"><button type="button" className="ap-pill" aria-expanded={menu === 'range'} onClick={() => setMenu(m => m === 'range' ? null : 'range')}>{rangeLabel}<ChevronDown/></button>
            {menu === 'range' && <div className="ap-menu left" role="menu">{RANGES.map(([v, l]) => <button type="button" role="menuitemradio" aria-checked={days === v} key={l} onClick={() => { setDays(v); setMenu(null); }}>{l}</button>)}</div>}</div>
          <label className="ap-searchbox"><Search/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search pair (e.g., BTC/USDT)" aria-label="Search pair"/></label>
        </div>
        <div className="ap-tablewrap"><table className="ap-orders"><thead><tr><th>Time</th><th>Pair</th><th>Type</th><th>Order price</th><th>Amount</th><th>Executed</th><th>Status</th></tr></thead>
          <tbody>{shown.map(o => <tr key={o.id}>
            <td className="t" data-l="Time">{stamp(o.at)}</td><td className="p" data-l="Pair">{o.symbol}</td><td className={o.side === 'buy' ? 'up' : 'down'} data-l="Type">{o.side === 'buy' ? 'Buy' : 'Sell'}</td>
            <td data-l="Order price">{num(o.price, o.price < 1 ? 6 : 2)}</td>
            <td data-l="Amount"><b>{o.side === 'buy' ? num(Number(o.total)) : o.quantity}</b><small>{o.side === 'buy' ? 'USDT' : o.base}</small></td>
            <td data-l="Executed"><b>{o.side === 'buy' ? num(Number(o.total)) : o.quantity}</b><small>100.00%</small></td>
            <td className="s" data-l="Status">{o.status === 'filled' ? 'Filled' : o.status}</td></tr>)}</tbody></table>
          {!busy && shown.length === 0 && <div className="ap-empty">{tab === 'open' ? <List/> : <Clock/>}<b>{error || (tab === 'open' ? 'No open orders' : 'No order history')}</b><p>{tab === 'open' ? 'Spot orders fill instantly at the live price, so nothing stays open. Resting orders will appear here when they are available.' : 'Your filled orders will be listed here. Try a wider date range if you expect more.'}</p></div>}
          {busy && shown.length === 0 && tab === 'history' && <div className="ap-empty"><Loader2 className="spin"/></div>}
        </div>
        {tab === 'history' && more && <div className="ap-more-wrap"><button type="button" className="ap-loadmore" disabled={busy} onClick={() => void load(rows[rows.length - 1]?.id)}>{busy ? <Loader2 className="spin"/> : 'Load more'}</button></div>}
      </section>
    </main>
  </AccountLayout>;
}
