import { useCallback, useEffect, useState } from 'react';
import { Head } from '@inertiajs/react';
import { ArrowLeft, LifeBuoy, Plus } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import { useTheme } from '../lib/hooks';
import { api } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/profile.css';

type T = { id: number; subject: string; category: string; status: string; at: string };
type M = { id: number; staff: boolean; body: string; at: string };
const field = { background: 'var(--ov-input)', color: 'var(--ov-text)', border: '1px solid var(--ov-line)', borderRadius: 10, padding: 12, font: 'inherit', width: '100%' } as const;
const tone: Record<string, string> = { open: '#f5a623', answered: '#2ebd85', closed: '#8e8e93' };

export default function Tickets() {
  useTheme();
  const [list, setList] = useState<T[] | null>(null); const [view, setView] = useState<{ ticket: { id: number; subject: string; status: string }; messages: M[] } | null>(null);
  const [creating, setCreating] = useState(false); const [f, setF] = useState({ subject: '', category: 'other', message: '' }); const [reply, setReply] = useState(''); const [err, setErr] = useState('');
  const load = useCallback(async () => { const r = await api<{ tickets: T[] }>('/api/tickets'); if (r.ok) setList(r.data.tickets); }, []);
  const open = useCallback(async (id: number) => { const r = await api<{ ticket: { id: number; subject: string; status: string }; messages: M[] }>(`/api/tickets/${id}`); if (r.ok) setView(r.data); }, []);
  useEffect(() => { void load(); const q = Number(new URLSearchParams(location.search).get('id')); if (q) void open(q); }, [load, open]);
  useEffect(() => { if (!view) return; const t = window.setInterval(() => { if (!document.hidden) void open(view.ticket.id); }, 12000); return () => window.clearInterval(t); }, [view, open]);
  const create = async () => { setErr(''); const r = await api<{ id: number }>('/api/tickets', f); if (!r.ok) { setErr(r.data.message ?? 'Check the form.'); return; } setCreating(false); setF({ subject: '', category: 'other', message: '' }); void load(); void open(r.data.id); };
  const send = async () => { if (!view || !reply.trim()) return; const r = await api<typeof view>(`/api/tickets/${view.ticket.id}/reply`, { message: reply }); if (r.ok) { setView(r.data); setReply(''); void load(); } else setErr(r.data.message ?? 'Could not send.'); };
  const close = async () => { if (!view) return; const r = await api<typeof view>(`/api/tickets/${view.ticket.id}/close`, {}); if (r.ok) { setView(r.data); void load(); } };
  return <><Head title="Support — RushX"/>
    <div className="ov-shell pf-shell rx-dashboard">
      <header className="pf-top"><button type="button" aria-label="Back" onClick={() => (view || creating ? (setView(null), setCreating(false)) : window.history.length > 1 ? window.history.back() : (window.location.href = '/profile'))}><ArrowLeft/></button><b>{view ? `#${view.ticket.id}` : 'Support tickets'}</b><button type="button" aria-label="New ticket" onClick={() => { setView(null); setCreating(true); }}><Plus/></button></header>
      {creating && <section className="pf-card" style={{ margin: 16, padding: 16, display: 'grid', gap: 10 }}>
        <input style={field} placeholder="Subject" maxLength={140} value={f.subject} onChange={e => setF({ ...f, subject: e.target.value })}/>
        <select style={field} value={f.category} onChange={e => setF({ ...f, category: e.target.value })}><option value="deposit">Deposit</option><option value="withdrawal">Withdrawal</option><option value="trading">Trading</option><option value="account">Account</option><option value="other">Other</option></select>
        <textarea style={{ ...field, minHeight: 130 }} placeholder="Describe the problem. Include amounts, coin, network and transaction IDs where relevant." value={f.message} onChange={e => setF({ ...f, message: e.target.value })}/>
        {err && <small role="alert" style={{ color: '#f6465d' }}>{err}</small>}
        <button type="button" onClick={create} disabled={!f.subject || !f.message} style={{ border: 0, borderRadius: 10, padding: 13, background: '#c1f033', color: '#000', fontWeight: 800, cursor: 'pointer' }}>Send ticket</button>
      </section>}
      {view && <section style={{ margin: 16, display: 'grid', gap: 10 }}>
        <div><b>{view.ticket.subject}</b> <em style={{ fontStyle: 'normal', color: tone[view.ticket.status] }}>· {view.ticket.status}</em></div>
        {view.messages.map(m => <div key={m.id} style={{ justifySelf: m.staff ? 'start' : 'end', maxWidth: '86%', background: m.staff ? 'var(--ov-surface)' : 'rgba(193,240,51,.14)', border: '1px solid var(--ov-line)', borderRadius: 14, padding: '10px 13px' }}><small style={{ opacity: .6 }}>{m.staff ? 'RushX support' : 'You'} · {m.at}</small><div style={{ whiteSpace: 'pre-wrap', marginTop: 3 }}>{m.body}</div></div>)}
        {view.ticket.status !== 'closed' ? <><textarea style={{ ...field, minHeight: 80 }} placeholder="Write a reply…" value={reply} onChange={e => setReply(e.target.value)}/>{err && <small role="alert" style={{ color: '#f6465d' }}>{err}</small>}<div style={{ display: 'flex', gap: 8 }}><button type="button" onClick={send} style={{ flex: 1, border: 0, borderRadius: 10, padding: 12, background: '#c1f033', color: '#000', fontWeight: 800, cursor: 'pointer' }}>Send</button><button type="button" onClick={close} style={{ ...field, width: 'auto', cursor: 'pointer' }}>Close ticket</button></div></> : <small style={{ opacity: .7 }}>This ticket is closed.</small>}
      </section>}
      {!view && !creating && <section className="pf-card flat" style={{ margin: 16 }}>
        {list === null ? <p className="pf-empty">Loading…</p> : list.length === 0 ? <p className="pf-empty"><LifeBuoy style={{ display: 'block', margin: '0 auto 8px' }}/>No tickets yet. Tap + to contact support.</p> : list.map(t => <button type="button" key={t.id} className="pf-row nf" onClick={() => open(t.id)}><span className="pf-txt"><b>{t.subject}</b><small>{t.category} · {t.at}</small></span><em className="nf-t" style={{ color: tone[t.status] }}>{t.status}</em></button>)}
      </section>}
      <MobileNav active="home"/>
    </div></>;
}
