import { useCallback, useEffect, useMemo, useState } from 'react';
import { Bot, Check, Clock, Inbox, Layers, Loader2, Shield, TrendingUp, Users, Wallet, X, Zap } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import CoinImage from '../components/CoinImage';
import { api, newKey, usd } from '../lib/wallet';
import '../../css/earn-bots.css';

type BotRow = { id: number; name: string; pair: string; strategy: string; enabled: boolean; dailyYield: number; profitShare: number; minAmount: string; followers: number; aum: string; runtimeDays: number; following: boolean };
type Mine = { botId: number; name: string; pair: string; capital: string; autoClaim: boolean; claimableCycles: number; remaining: number; pending: string; nextProfit: string; dailyYield: number; profitShare: number };
type Claim = { id: number; bot: string; pair: string; cycles: number; capital: string; gross: string; share: string; net: string; at: string | null };
type Payload = { bots: BotRow[]; mine: Mine[]; history: Claim[]; kpis: { active: number; aum: string; lifetime: string; funding: string; running: number } };
type Sort = 'yield' | 'aum' | 'followers' | 'runtime';
const num = (s: string) => Number(s.replace(/,/g, ''));
const hms = (sec: number) => `${String(Math.floor(sec / 3600)).padStart(2, '0')}:${String(Math.floor((sec % 3600) / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
const base = (pair: string) => pair.replace(/USDT$|USDC$/, '');

/** Yield strategies: a fixed daily yield, set by the platform, is paid per completed 24h cycle. */
export default function Bots() {
  const [data, setData] = useState<Payload | null>(null);
  const [tab, setTab] = useState<'discover' | 'active' | 'history'>('discover');
  const [sort, setSort] = useState<Sort>('yield');
  const [panel, setPanel] = useState<BotRow | null>(null);
  const [toast, setToast] = useState<{ ok: boolean; text: string } | null>(null);
  const [tick, setTick] = useState(0);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const r = await api<Payload>('/api/bots');
    if (r.status === 401) { window.location.href = '/login'; return; }
    if (r.ok) { setData(r.data); setError(''); setTick(0); } else setError('Strategies could not be loaded.');
  }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 30000); return () => window.clearInterval(t); }, [load]);
  useEffect(() => { const t = window.setInterval(() => setTick(v => v + 1), 1000); return () => window.clearInterval(t); }, []);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(null), 4000); return () => window.clearTimeout(t); }, [toast]);

  const act = async (path: string, body: Record<string, unknown> = {}, ok = 'Done') => {
    const r = await api<Payload>(path, body);
    if (r.ok) { setData(r.data); setTick(0); setToast({ ok: true, text: ok }); return true; }
    setToast({ ok: false, text: r.data.message ?? 'Request failed.' }); return false;
  };

  const sorted = useMemo(() => {
    const list = [...(data?.bots ?? [])];
    const key: Record<Sort, (b: BotRow) => number> = { yield: b => b.dailyYield, aum: b => num(b.aum), followers: b => b.followers, runtime: b => b.runtimeDays };
    return list.sort((a, b) => key[sort](b) - key[sort](a));
  }, [data, sort]);
  const totalAum = (data?.bots ?? []).reduce((s, b) => s + num(b.aum), 0);
  const totalFollowers = (data?.bots ?? []).reduce((s, b) => s + b.followers, 0);
  const k = data?.kpis;

  return <AccountLayout active="Bots" title="Trading Bots">
    <main className="bt-wrap">
      <div className="bt-head"><div><span className="bt-eyebrow"><i/> {k ? `${k.running} ${k.running === 1 ? 'strategy' : 'strategies'} open` : 'Strategies'}</span><h1>Trading Bots</h1>
        <p>Allocate capital to a strategy. A fixed daily yield is paid every completed 24-hour cycle to your Funding account, and can be claimed automatically.</p></div></div>
      <div className="bt-kpis">
        <div className="bt-kpi"><span><Bot/></span><small>ACTIVE BOTS</small><b>{k ? k.active : '—'}</b><em>Strategies running</em></div>
        <div className="bt-kpi"><span><Layers/></span><small>TOTAL ALLOCATED</small><b>{k ? `$${k.aum}` : '—'}<u>USDT</u></b><em>Your capital in strategies</em></div>
        <div className="bt-kpi"><span className="g"><TrendingUp/></span><small>LIFETIME PROFIT</small><b>{k ? `+$${k.lifetime}` : '—'}<u>USDT</u></b><em className="up">Paid to your Funding account</em></div>
        <div className="bt-kpi"><span className="y"><Wallet/></span><small>AVAILABLE CAPITAL</small><b>{k ? `$${k.funding}` : '—'}<u>USDT</u></b><em>Funding account</em></div>
      </div>
      <div className="bt-tabs"><button type="button" className={tab === 'discover' ? 'active' : ''} onClick={() => setTab('discover')}>Discover</button><button type="button" className={tab === 'active' ? 'active' : ''} onClick={() => setTab('active')}>My active bots <span>{data?.mine.length ?? 0}</span></button><button type="button" className={tab === 'history' ? 'active' : ''} onClick={() => setTab('history')}>Profits history</button></div>

      {!data ? <div className="bt-empty">{error || <Loader2 className="spin"/>}</div>
        : tab === 'discover' ? (sorted.length === 0 ? <Empty title="No strategies yet" text="New strategies will appear here as soon as they are opened."/> : <>
          <div className="bt-controls"><div className="bt-meta"><b>{sorted.length} {sorted.length === 1 ? 'strategy' : 'strategies'}</b><i/><span>${usd(totalAum)} allocated</span><i/><span>{totalFollowers.toLocaleString('en-US')} followers</span></div>
            <div className="bt-sort" role="tablist" aria-label="Sort strategies">{([['yield', 'Top yield', TrendingUp], ['aum', 'AUM', Layers], ['followers', 'Followers', Users], ['runtime', 'Longest running', Shield]] as const).map(([v, l, I]) => <button type="button" key={v} className={sort === v ? 'active' : ''} onClick={() => setSort(v)}><I/> {l}</button>)}</div></div>
          <div className="bt-cards">{sorted.map((b, i) => <article className={`bt-card${i === 0 && sort === 'yield' ? ' top' : ''}`} key={b.id}>
            <div className="bt-c-top"><div className="bt-logo"><CoinImage symbol={base(b.pair)}/><em className="bt-dot"/></div><div className="bt-c-name"><h3>{b.name}</h3><div className="bt-chips"><span>{b.strategy.toUpperCase()}</span><span className="sh">{b.profitShare > 0 ? `${b.profitShare}% SHARE` : 'NO FEE'}</span></div></div>
              <button type="button" className="bt-follow" disabled={b.following || !b.enabled} onClick={() => setPanel(b)}><Zap/> {b.following ? 'Following' : b.enabled ? 'Follow' : 'Closed'}</button></div>
            <div className="bt-yield"><small>DAILY YIELD</small><b>+{b.dailyYield.toFixed(2)}%</b><em>≈ {(b.dailyYield * 365).toFixed(0)}% yearly, simple</em></div>
            <div className="bt-stats"><div><small>CYCLE</small><b>24 h</b></div><div><small>MIN.</small><b>${b.minAmount}</b></div><div><small>RUNTIME</small><b>{b.runtimeDays}<u>d</u></b></div></div>
            <div className="bt-foot"><span><Users/> {b.followers.toLocaleString('en-US')} followers · AUM <b>${b.aum}</b></span><code>{b.pair}</code></div></article>)}</div></>)
        : tab === 'active' ? (data.mine.length === 0 ? <Empty title="No active bots yet" text="Pick a strategy under Discover and allocate capital to start earning each 24-hour cycle." icon={<Bot/>}/> : <div className="bt-list">{data.mine.map(m => {
          const remaining = Math.max(0, m.remaining - tick); const ready = m.claimableCycles >= 1 || remaining === 0; const pct = Math.min(100, ((86400 - remaining) / 86400) * 100);
          return <div className={`bt-row${ready ? ' ready' : ''}`} key={m.botId}>
            <div className="bt-r-head"><div className="bt-logo sm"><CoinImage symbol={base(m.pair)}/><em className="bt-dot"/></div><div><h3>{m.name}</h3><small>{m.pair} · <b>${m.capital}</b> allocated · {m.dailyYield}% daily</small></div></div>
            <div className="bt-r-timer"><small>{ready ? 'Cycle complete' : 'Next profit in'}</small><b className={ready ? 'ok' : ''}>{ready ? `+${m.nextProfit} USDT` : hms(remaining)}</b><div className="bt-bar"><div style={{ width: `${ready ? 100 : pct}%` }}/></div></div>
            <label className="bt-auto">Auto-claim<span className="bt-switch"><input type="checkbox" checked={m.autoClaim} onChange={e => void act(`/api/bots/${m.botId}/auto`, { auto_claim: e.target.checked }, e.target.checked ? 'Auto-claim on' : 'Auto-claim off')}/><i/></span></label>
            <div className="bt-r-act">{ready ? <button type="button" className="claim" onClick={() => void act(`/api/bots/${m.botId}/claim`, {}, 'Profit claimed')}><Zap/> Claim profit</button> : <button type="button" className="wait" disabled><Clock/> Running…</button>}
              <button type="button" className="stop" onClick={() => { if (window.confirm(`Stop ${m.name}? Your $${m.capital} capital (and any profit already earned) returns to your Funding account.`)) void act(`/api/bots/${m.botId}/unfollow`, {}, 'Stopped — capital returned'); }}>Stop</button></div></div>; })}</div>)
        : (data.history.length === 0 ? <Empty title="No profits yet" text="Once a full 24-hour cycle is claimed, it is listed here." icon={<TrendingUp/>}/> : <div className="bt-hist"><div className="bt-hsum"><div><small>Total claims</small><b>{data.history.length}</b></div><div><small>Realized profit</small><b className="up">+${usd(data.history.reduce((s, c) => s + num(c.net), 0))}</b></div></div>
          <div className="bt-tw"><table><thead><tr><th>Strategy</th><th>Cycles</th><th>Capital</th><th>Gross</th><th>Platform share</th><th>Time</th><th className="r">Profit</th></tr></thead>
            <tbody>{data.history.map(c => <tr key={c.id}><td data-l="Strategy"><b>{c.bot}</b><small>{c.pair}</small></td><td data-l="Cycles">{c.cycles}</td><td data-l="Capital">${c.capital}</td><td data-l="Gross">{c.gross}</td><td data-l="Platform share">{c.share}</td><td data-l="Time" className="t">{c.at ? new Date(c.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}</td><td data-l="Profit" className="r up"><b>+${c.net}</b></td></tr>)}</tbody></table></div></div>)}
    </main>
    {panel && k && <FollowPanel bot={panel} funding={num(k.funding)} onClose={() => setPanel(null)} onConfirm={async (capital, auto, key) => { const ok = await act(`/api/bots/${panel.id}/follow`, { capital, auto_claim: auto, idempotency_key: key }, `Allocated $${capital}`); if (ok) setPanel(null); }}/>}
    {toast && <div className={`ea-toast ${toast.ok ? 'ok' : 'bad'}`} role="status"><Check/>{toast.text}</div>}
  </AccountLayout>;
}

function Empty({ title, text, icon = <Inbox/> }: { title: string; text: string; icon?: React.ReactNode }) {
  return <div className="bt-empty"><span>{icon}</span><b>{title}</b><p>{text}</p></div>;
}

function FollowPanel({ bot, funding, onClose, onConfirm }: { bot: BotRow; funding: number; onClose: () => void; onConfirm: (capital: string, auto: boolean, key: string) => Promise<void> }) {
  const [amount, setAmount] = useState(''); const [auto, setAuto] = useState(true); const [busy, setBusy] = useState(false); const [key] = useState(newKey);
  const v = Number(amount); const min = num(bot.minAmount);
  const valid = /^\d+(\.\d{1,8})?$/.test(amount) && v >= min && v <= funding + 1e-9;
  const daily = v * bot.dailyYield / 100; const net = daily * (1 - bot.profitShare / 100);
  const label = amount === '' || v <= 0 ? 'Enter an amount' : v < min ? `Minimum $${bot.minAmount}` : v > funding ? 'Insufficient balance' : `Allocate $${usd(v)}`;
  return <div className="bt-overlay" onClick={onClose}><aside className="bt-panel" role="dialog" aria-modal="true" aria-label="Allocate to strategy" onClick={e => e.stopPropagation()}>
    <header><b>Allocate to strategy</b><button type="button" aria-label="Close" onClick={onClose}><X/></button></header>
    <div className="bt-pbody">
      <div className="bt-pinfo"><div className="bt-logo"><CoinImage symbol={base(bot.pair)}/><em className="bt-dot"/></div><div><h3>{bot.name}</h3><small>{bot.pair} · <b className="up">+{bot.dailyYield.toFixed(2)}% daily</b></small></div></div>
      <label className="ea-l">CAPITAL AMOUNT <em>Available <b>${usd(funding)}</b> (Funding)</em></label>
      <div className="ea-input"><input inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value.replace(/[^\d.]/g, ''))} placeholder="0.00" aria-label="Capital" autoFocus/><span>USDT</span></div>
      <div className="bt-presets">{[0.25, 0.5, 0.75, 1].map(f => <button type="button" key={f} onClick={() => setAmount(String(Math.floor(funding * f * 100) / 100))}>{f === 1 ? 'Max' : `${f * 100}%`}</button>)}</div>
      <label className="bt-check"><input type="checkbox" checked={auto} onChange={e => setAuto(e.target.checked)}/> Claim profit automatically each cycle</label>
      <div className="bt-sum"><div><span>Cycle length</span><b>24 hours</b></div><div><span>Daily yield</span><b>{bot.dailyYield.toFixed(2)}%</b></div><div><span>Platform share</span><b>{bot.profitShare}%</b></div><div><span>Est. profit per cycle</span><b className="up">{valid ? `+$${usd(net, 4)}` : '—'}</b></div></div>
      <p className="ea-hint">Capital stays yours: stop any time and it returns to your Funding account together with any profit already earned.</p>
    </div>
    <footer><button type="button" className={`ea-submit${valid ? ' ready' : ''}`} disabled={!valid || busy} onClick={async () => { setBusy(true); await onConfirm(amount, auto, key); setBusy(false); }}>{busy ? 'Allocating…' : label}</button></footer>
  </aside></div>;
}
