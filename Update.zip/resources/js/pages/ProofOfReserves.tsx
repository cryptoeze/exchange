import { Head, usePage } from '@inertiajs/react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import { useTheme } from '../lib/hooks';
import '../../css/overview.css';
import '../../css/profile.css';

type Row = { asset: string; liabilities: string; users: number; reserves: string | null; ratio: number | null; wallet: string | null; verified: string | null };

export default function ProofOfReserves({ rows, updated }: { rows: Row[]; updated: string }) {
  const user = ((usePage().props as Record<string, unknown>).auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, toggle] = useTheme();
  return <><Head title="Proof of Reserves — RushX"/>
    <div className="ov-shell pf-shell rx-dashboard" style={{ paddingBottom: 60 }}>
      <RushXHeader user={user} dark={dark} onToggleTheme={toggle}/>
      <main style={{ maxWidth: 900, margin: '0 auto', padding: '24px 16px' }}>
        <h1 style={{ margin: '0 0 8px', fontSize: 28 }}>Proof of Reserves</h1>
        <p style={{ margin: '0 0 18px', color: 'var(--ov-sub)', lineHeight: 1.6 }}>Customer balances below are read live from the RushX ledger. Reserves are the amounts RushX reports holding in its own wallets and are updated by the operator. A ratio of 100% or more means reported reserves cover customer balances for that asset.</p>
        <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
          <thead><tr style={{ textAlign: 'left', color: 'var(--ov-sub)' }}><th style={{ padding: 8 }}>Asset</th><th>Customer balances</th><th>Reported reserves</th><th>Coverage</th><th>Verified</th></tr></thead>
          <tbody>{rows.length === 0 ? <tr><td colSpan={5} style={{ padding: 24, color: 'var(--ov-sub)' }}>No balances yet.</td></tr> : rows.map(r => <tr key={r.asset} style={{ borderTop: '1px solid var(--ov-line)' }}>
            <td style={{ padding: '12px 8px' }}><b>{r.asset}</b><br/><small style={{ color: 'var(--ov-sub)' }}>{r.users} users</small></td><td>{r.liabilities}</td>
            <td>{r.reserves ?? <span style={{ color: 'var(--ov-sub)' }}>Not reported yet</span>}{r.wallet && <><br/><small style={{ color: 'var(--ov-sub)', overflowWrap: 'anywhere' }}>{r.wallet}</small></>}</td>
            <td style={{ fontWeight: 800, color: r.ratio === null ? 'var(--ov-sub)' : r.ratio >= 100 ? '#2ebd85' : '#f6465d' }}>{r.ratio === null ? '—' : `${r.ratio}%`}</td><td>{r.verified ?? '—'}</td></tr>)}</tbody>
        </table></div>
        <p style={{ color: 'var(--ov-sub)', fontSize: 12, marginTop: 14 }}>Generated {new Date(updated).toLocaleString()}. Reserve figures are operator-reported and not an independent audit.</p>
      </main>
    </div></>;
}
