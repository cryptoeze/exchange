import { Head, router, usePage } from '@inertiajs/react';
import { ArrowLeft, BadgeCheck, BellRing, Bot, ChevronRight, Coins, Copy, FileText, Gift, LifeBuoy, LineChart, LogOut, Percent, Shield, UserPlus, Wallet } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import { useTheme } from '../lib/hooks';
import type { HeaderUser } from '../components/RushXHeader';
import '../../css/overview.css';
import '../../css/profile.css';

type Item = { icon: React.ElementType; title: string; sub: string; href?: string; tag?: string };
const initials = (n: string) => n.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'U';
const GROUPS: Array<{ label: string; items: Item[] }> = [
  { label: 'Account', items: [
    { icon: BadgeCheck, title: 'Identity verification', sub: 'Verify your identity', href: '/kyc' },
    { icon: Shield, title: 'Security & settings', sub: 'Password, sign-in protection', href: '/security' },
    { icon: Wallet, title: 'My assets', sub: 'Balances, deposits, withdrawals', href: '/assets' },
  ] },
  { label: 'Trading', items: [
    { icon: LineChart, title: 'Order center', sub: 'Spot and futures history', href: '/orders' },
    { icon: Copy, title: 'Copy trading', sub: 'Follow vetted traders', href: '/copy' },
    { icon: Bot, title: 'Trading bots', sub: 'Automated daily yield', href: '/bots' },
    { icon: Percent, title: 'My trading fees', sub: 'Current fee rates', href: '/fees' },
  ] },
  { label: 'Earn & grow', items: [
    { icon: Gift, title: 'Daily rewards', sub: 'Streak bonus every day', href: '/rewards' },
    { icon: UserPlus, title: 'Refer & earn', sub: 'Referral code and link', href: '/refer' },
    { icon: Coins, title: 'Earn', sub: 'Stake USDT, interest every second', href: '/earn' },
  ] },
  { label: 'Support', items: [
    { icon: LifeBuoy, title: 'Support tickets', sub: 'Contact support, see replies', href: '/tickets' },
    { icon: BellRing, title: 'Price alerts', sub: 'Get notified when a coin hits your price', href: '/alerts' },
    { icon: FileText, title: 'Fees & rules', sub: 'Trading fees and limits', href: '/fees' },
  ] },
];

export default function Profile({ kyc = 'none' }: { kyc?: string }) {
  const user = ((usePage().props as Record<string, unknown>).auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  useTheme();
  return <><Head title="Profile — RushX"/>
    <div className="ov-shell pf-shell rx-dashboard">
      <header className="pf-top"><button type="button" aria-label="Back" onClick={() => (window.history.length > 1 ? window.history.back() : router.visit('/dashboard'))}><ArrowLeft/></button><b>Profile</b><span/></header>
      <section className="pf-user"><span className="pf-big">{initials(user?.name ?? 'User')}</span><h1>{user?.name}</h1><p>{user?.email}</p><small>UID {String(100000 + (user?.id ?? 0))}</small></section>
      {GROUPS.map(g => <section key={g.label}><h2 className="pf-h">{g.label}</h2><div className="pf-card flat">
        {g.items.map(({ icon: Icon, title, sub, href, tag }) => href
          ? <a key={title} href={href} className="pf-row"><span className="pf-ico"><Icon/></span><span className="pf-txt"><b>{title}</b><small>{href === '/kyc' ? ({ approved: 'Verified', pending: 'Under review', rejected: 'Rejected — submit again' } as Record<string, string>)[kyc] ?? sub : sub}</small></span><ChevronRight/></a>
          : <div key={title} className="pf-row static"><span className="pf-ico"><Icon/></span><span className="pf-txt"><b>{title}</b><small>{sub}</small></span><em>{tag}</em></div>)}
      </div></section>)}
      <button type="button" className="pf-out" onClick={() => router.post('/logout')}><LogOut/> Log out</button>
      <MobileNav active="home"/>
    </div></>;
}
