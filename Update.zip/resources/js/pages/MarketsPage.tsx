import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Head, Link, usePage } from '@inertiajs/react';
import { ArrowDownUp, ArrowRight, ChevronDown, Clock3, RefreshCw, Search, Star, TrendingUp, Volume2, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import type { Favorite, Market, MarketCategory, MarketSnapshot, MarketType } from '../types/market';
import '../../css/markets.css';

type Props = { search?: string; auth?: { user: HeaderUser | null } };
const filters: MarketCategory[] = ['All', 'Top', 'New', 'AI', 'Meme', 'DeFi', 'Layer 1'];
const number = new Intl.NumberFormat('en-US', { maximumSignificantDigits: 8 });
function price(value: number) { if (!Number.isFinite(value)) return '—'; return new Intl.NumberFormat('en-US', value >= 1000 ? { minimumFractionDigits: 2, maximumFractionDigits: 2 } : { maximumSignificantDigits: 8 }).format(value); }
function money(value: number) { if (!Number.isFinite(value)) return '—'; return `$${new Intl.NumberFormat('en-US', { notation: value >= 1e6 ? 'compact' : 'standard', maximumFractionDigits: 2 }).format(value)}`; }
function shortTime(value: string) { const date = new Date(value); return Number.isNaN(date.getTime()) ? '—' : new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' }).format(date); }
function marketKey(m: Market) { return `${m.marketType}:${m.symbol}`; }
function tokenFromCookie(name: string) { return document.cookie.split('; ').find(row => row.startsWith(`${name}=`))?.split('=').slice(1).join('=') ?? ''; }

function Coin({ market, size = 'normal' }: { market: Market; size?: string }) {
  const [broken, setBroken] = useState(false);
  return <span className={`mk-coin mk-coin-${size}`}>{market.icon && !broken ? <img src={market.icon} alt="" loading="lazy" onError={() => setBroken(true)}/> : <i>{market.baseAsset.slice(0, 1)}</i>}</span>;
}
function MarketRange({ low, high, current }: { low: number; high: number; current: number }) {
  const valid = [low, high, current].every(Number.isFinite) && low >= 0 && high >= low && current >= 0;
  const position = valid && high > low ? Math.max(0, Math.min(1, (current - low) / (high - low))) : 0.5;
  return <div className="mk-range"><span className="mk-range-values"><small>{price(low)}</small><small>{price(high)}</small></span><span className="mk-range-track"><i style={{ left: `${position * 100}%` }}/></span></div>;
}
function FavoriteButton({ market, active, toggle }: { market: Market; active: boolean; toggle: (market: Market) => void }) {
  return <button type="button" className={`mk-favorite ${active ? 'is-active' : ''}`} aria-label={`${active ? 'Remove' : 'Add'} ${market.baseAsset} ${market.marketType} favorite`} aria-pressed={active} onClick={event => { event.preventDefault(); event.stopPropagation(); toggle(market); }}><Star fill={active ? 'currentColor' : 'none'}/></button>;
}
function MarketName({ market }: { market: Market }) { return <span className="mk-name"><Coin market={market}/><span><b>{market.baseAsset}</b><small>{market.displayName} <i>/ {market.quoteAsset}</i></small></span></span>; }

export default function MarketsPage({ search: initialSearch = '', auth }: Props) {
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [error, setError] = useState(false);
  const [tab, setTab] = useState<'favorites' | 'spot' | 'futures'>('spot');
  const [category, setCategory] = useState<MarketCategory>('All');
  const [query, setQuery] = useState(initialSearch);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<'turnover24h' | 'lastPrice' | 'change24h'>('turnover24h');
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);
  const [flashes, setFlashes] = useState<Record<string, 'up' | 'down'>>({});
  const previousPrices = useRef<Map<string, number>>(new Map());
  const refreshEvery = useRef(20);
  const pageProps = usePage().props as Record<string, unknown>;
  const user = auth?.user ?? ((pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional preference */ } }, [dark]);
  const load = useCallback(async (signal: AbortSignal) => {
    const response = await fetch('/api/markets?type=both', { headers: { Accept: 'application/json' }, signal, credentials: 'same-origin' });
    const data = await response.json().catch(() => null) as MarketSnapshot | null;
    if (!response.ok || !data || !Array.isArray(data.markets)) throw new Error('Market data temporarily unavailable.');
    const next = new Map<string, number>(); const directions: Record<string, 'up' | 'down'> = {};
    for (const item of data.markets) { const key = marketKey(item); const prior = previousPrices.current.get(key); if (prior && item.lastPrice !== prior) directions[key] = item.lastPrice > prior ? 'up' : 'down'; next.set(key, item.lastPrice); }
    previousPrices.current = next; refreshEvery.current = Math.max(15, data.meta.refreshSeconds || 20); setFlashes(directions); window.setTimeout(() => setFlashes({}), 800);
    setSnapshot(data); setError(false); setLoading(false);
  }, []);
  useEffect(() => {
    let active = true; let timer = 0; let inflight = false; const controller = new AbortController();
    const refresh = async () => { if (!active || document.hidden || inflight) return; inflight = true; try { await load(controller.signal); } catch { if (active && !controller.signal.aborted) { setError(true); setLoading(false); } } finally { inflight = false; if (active && !document.hidden) timer = window.setTimeout(refresh, refreshEvery.current * 1000); } };
    const visible = () => { if (document.hidden) window.clearTimeout(timer); else void refresh(); };
    void refresh(); document.addEventListener('visibilitychange', visible);
    return () => { active = false; controller.abort(); window.clearTimeout(timer); document.removeEventListener('visibilitychange', visible); };
  }, [load, refreshKey]);

  const loadFavorites = useCallback(async () => {
    if (user) {
      try { const response = await fetch('/api/market-favorites', { headers: { Accept: 'application/json' }, credentials: 'same-origin' }); const data = await response.json() as { favorites: Favorite[] }; if (response.ok) setFavorites(new Set(data.favorites.map(item => `${item.marketType}:${item.symbol}`))); } catch { /* starred state remains usable locally */ }
    } else {
      try { const list = JSON.parse(localStorage.getItem('rushx-market-favorites') ?? '[]') as Favorite[]; setFavorites(new Set(list.map(item => `${item.marketType}:${item.symbol}`))); } catch { setFavorites(new Set()); }
    }
  }, [user]);
  useEffect(() => { void loadFavorites(); }, [loadFavorites]);
  const toggleFavorite = async (market: Market) => {
    const key = marketKey(market); const wasActive = favorites.has(key); const next = new Set(favorites); wasActive ? next.delete(key) : next.add(key); setFavorites(next);
    if (user) {
      try { const headers = { Accept: 'application/json', 'Content-Type': 'application/json', 'X-CSRF-TOKEN': decodeURIComponent(tokenFromCookie('XSRF-TOKEN')) }; const url = `/api/market-favorites/${market.marketType}/${market.symbol}`; const response = await fetch(wasActive ? url : '/api/market-favorites', { method: wasActive ? 'DELETE' : 'POST', credentials: 'same-origin', headers, ...(wasActive ? {} : { body: JSON.stringify({ symbol: market.symbol, marketType: market.marketType }) }) }); if (!response.ok) throw new Error(); } catch { setFavorites(current => { const restored = new Set(current); wasActive ? restored.add(key) : restored.delete(key); return restored; }); }
    } else { try { localStorage.setItem('rushx-market-favorites', JSON.stringify([...next].map(value => { const [marketType, symbol] = value.split(':'); return { marketType, symbol }; }))); } catch { /* favorites remain in memory for this visit */ } }
  };

  const all = snapshot?.markets ?? [];
  const selectedType: MarketType | 'favorites' = tab === 'spot' ? 'spot' : tab === 'futures' ? 'futures' : 'favorites';
  const rows = useMemo(() => {
    let result = all.filter(item => selectedType === 'favorites' ? favorites.has(marketKey(item)) : item.marketType === selectedType);
    if (category === 'Top') result = result.slice(0, snapshot?.meta.topRankLimit ?? 50);
    else if (category === 'New') result = result.filter(item => item.isNew);
    else if (category !== 'All') result = result.filter(item => item.categories.includes(category));
    const q = query.trim().toLowerCase(); if (q) result = result.filter(item => `${item.symbol} ${item.baseAsset} ${item.displayName}`.toLowerCase().includes(q));
    return [...result].sort((a, b) => b[category === 'Top' ? 'turnover24h' : sort] - a[category === 'Top' ? 'turnover24h' : sort]);
  }, [all, category, favorites, query, selectedType, snapshot?.meta.topRankLimit, sort]);
  useEffect(() => { setPage(1); }, [tab, category, query, sort]);
  const pageSize = 50; const visible = rows.slice((page - 1) * pageSize, page * pageSize); const pages = Math.max(1, Math.ceil(rows.length / pageSize));
  const tabs = [{ id: 'favorites', label: 'Favorites' }, { id: 'spot', label: 'Crypto' }, { id: 'futures', label: 'Futures' }] as const;
  const highlights = snapshot?.highlights;
  const highlightCards: Array<{ title: string; Icon: LucideIcon; items?: Market[] }> = [
    { title: 'Hot Crypto', Icon: TrendingUp, items: highlights?.hotCrypto },
    { title: 'Top Gainers', Icon: ArrowDownUp, items: highlights?.topGainers },
    { title: 'Top Volume 24h', Icon: Volume2, items: highlights?.topVolume24h },
  ];

  return <><Head title="Markets — RushX"><meta name="theme-color" content={dark ? '#050505' : '#f4f6f2'}/></Head><div className="rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(value => !value)}/>
    <main className="mk-page"><div className="mk-breadcrumb"><Link href="/">Home</Link><span>/</span><b>Markets</b></div><header className="mk-page-head"><div><span className="rx-overline">MARKET OVERVIEW</span><h1>Markets</h1><p>Explore live digital asset markets across spot and futures.</p></div><div className={`mk-status ${snapshot?.meta.stale ? 'is-stale' : ''}`}><i/> {snapshot?.meta.stale ? 'Delayed data' : snapshot ? 'Live market data' : 'Connecting'}{snapshot && <span><Clock3/> {shortTime(snapshot.meta.updatedAt)} UTC</span>}</div></header>
    <section className="mk-highlights" aria-label="Market highlights">{highlightCards.map(({title, Icon, items}) => <article className="mk-highlight" key={title}><header><span>{title}</span><Icon size={17}/></header>{!items ? <div className="mk-highlight-loading"><i/><i/><i/></div> : items.length ? items.map(item => <Link href={`/market/${item.symbol}?type=${item.marketType}`} className="mk-highlight-row" key={marketKey(item)}><Coin market={item} size="small"/><b>{item.baseAsset}<small>/{item.quoteAsset}</small></b><span className={item.change24h > 0 ? 'mk-positive' : item.change24h < 0 ? 'mk-negative' : ''}>{item.change24h > 0 ? '+' : ''}{item.change24h.toFixed(2)}%</span><strong>{money(item.turnover24h)}</strong></Link>) : <p className="mk-no-highlight">No market data available</p>}</article>)}</section>
    <section className="mk-board"><div className="mk-toolbar"><div className="mk-tabs" role="tablist">{tabs.map(item => <button key={item.id} role="tab" aria-selected={tab === item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}>{item.label}{item.id === 'favorites' && favorites.size > 0 && <small>{favorites.size}</small>}</button>)}</div><label className="mk-search"><Search/><input aria-label="Search crypto markets" placeholder="Search Crypto" value={query} onChange={event => setQuery(event.target.value)}/>{query && <button aria-label="Clear search" onClick={() => setQuery('')}><X/></button>}<kbd>/</kbd></label></div>
    <div className="mk-filter-row"><div className="mk-filters" role="group" aria-label="Market categories">{filters.map(item => <button key={item} className={category === item ? 'active' : ''} onClick={() => setCategory(item)}>{item}</button>)}</div><button className="mk-refresh" onClick={() => { setLoading(true); setRefreshKey(value => value + 1); }} aria-label="Refresh markets"><RefreshCw className={loading ? 'spinning' : ''}/><span>Refresh</span></button></div>
    {error && !snapshot ? <div className="mk-state mk-error"><b>Market data temporarily unavailable</b><span>Live public prices could not be loaded. Please retry.</span><button onClick={() => { setLoading(true); setRefreshKey(value => value + 1); }}><RefreshCw/> Try again</button></div> : !snapshot ? <div className="mk-skeleton" aria-label="Loading markets">{Array.from({ length: 7 }, (_, i) => <i key={i}/>)}</div> : <>
      {snapshot.meta.stale && <div className="mk-stale-note">Showing a recent cached snapshot. Live provider refresh is temporarily unavailable.</div>}
      {error && <div className="mk-stale-note">Could not refresh markets. Displaying the last successful snapshot.</div>}
      {rows.length === 0 ? <div className="mk-state"><b>{selectedType === 'favorites' && favorites.size === 0 ? 'Your favorites will appear here' : 'No markets found'}</b><span>{selectedType === 'favorites' && favorites.size === 0 ? 'Select the star beside a market to save it.' : 'Try another category or search term.'}</span></div> : <>
      <div className="mk-table-wrap"><table className="mk-table"><thead><tr><th>Name</th><th><button onClick={() => setSort('lastPrice')}>Price <ChevronDown/></button></th><th><button onClick={() => setSort('change24h')}>24h Change <ChevronDown/></button></th><th>24h Range</th><th><button onClick={() => setSort('turnover24h')}>24h Volume <ChevronDown/></button></th><th>Details</th><th>Trade</th></tr></thead><tbody>{visible.map(item => <tr key={marketKey(item)}><td><div className="mk-name-cell"><FavoriteButton market={item} active={favorites.has(marketKey(item))} toggle={toggleFavorite}/><Link href={`/market/${item.symbol}?type=${item.marketType}`}><MarketName market={item}/></Link></div></td><td className={`mk-price ${flashes[marketKey(item)] ? `flash-${flashes[marketKey(item)]}` : ''}`}>${price(item.lastPrice)}</td><td className={item.change24h > 0 ? 'mk-positive' : item.change24h < 0 ? 'mk-negative' : 'mk-neutral'}>{item.change24h > 0 ? '+' : ''}{item.change24h.toFixed(2)}%</td><td><MarketRange low={item.low24h} high={item.high24h} current={item.lastPrice}/></td><td className="mk-volume">{money(item.turnover24h)}<small>{number.format(item.volume24h)} {item.baseAsset}</small></td><td><Link className="mk-details" href={`/market/${item.symbol}?type=${item.marketType}`}>Details <ArrowRight/></Link></td><td><Link className="mk-trade" href={`/${item.marketType === 'spot' ? 'spot' : 'futures'}?pair=${encodeURIComponent(item.symbol)}`}>Trade</Link></td></tr>)}</tbody></table></div>
      <div className="mk-mobile-list">{visible.map(item => <article className="mk-mobile-card" key={marketKey(item)}><div className="mk-mobile-main"><FavoriteButton market={item} active={favorites.has(marketKey(item))} toggle={toggleFavorite}/><Link href={`/market/${item.symbol}?type=${item.marketType}`}><MarketName market={item}/></Link><span className={`mk-mobile-change ${item.change24h > 0 ? 'mk-positive' : item.change24h < 0 ? 'mk-negative' : ''}`}>{item.change24h > 0 ? '+' : ''}{item.change24h.toFixed(2)}%</span></div><div className="mk-mobile-meta"><b>${price(item.lastPrice)}</b><span>Vol {money(item.turnover24h)}</span><Link className="mk-trade" href={`/${item.marketType === 'spot' ? 'spot' : 'futures'}?pair=${encodeURIComponent(item.symbol)}`}>Trade</Link></div></article>)}</div>
      <footer className="mk-pagination"><span>{rows.length.toLocaleString()} markets · Updated {shortTime(snapshot.meta.updatedAt)} UTC</span><div><button disabled={page <= 1} onClick={() => setPage(value => value - 1)}>Previous</button><span>{page} / {pages}</span><button disabled={page >= pages} onClick={() => setPage(value => value + 1)}>Next</button></div></footer>
      </>}
      <p className="mk-disclaimer">Market data provided by Bybit. Spot and futures order execution is not connected in this release.</p>
    </>}
    <footer className="mk-source"><span><i/> Public market feed</span><span>Provider: {snapshot?.meta.provider ?? 'Bybit'} · Refreshes about every {snapshot?.meta.refreshSeconds ?? 20}s</span></footer>
    </section></main></div></>;
}
