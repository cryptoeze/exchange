import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Head, Link, router, usePage } from '@inertiajs/react';
import { ChevronRight, LayoutGrid, Loader2, RefreshCw, Search, Star, TrendingUp, Wallet, UserRound, X } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import type { Favorite, Market, MarketCategory, MarketSnapshot, MarketType } from '../types/market';
import '../../css/markets.css';
import '../../css/markets-reference.css';

type Props = { search?: string; auth?: { user: HeaderUser | null } };
const filters: MarketCategory[] = ['All', 'Top', 'New', 'AI', 'Meme', 'DeFi', 'Layer 1'];
const PAGE_STEP = 20;

function price(value: number) {
  if (!Number.isFinite(value)) return '—';
  const digits = value > 1000 ? 2 : value > 1 ? 4 : 6;
  return value.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
function volume(value: number) {
  if (!Number.isFinite(value)) return '—';
  if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
  if (value >= 1e3) return `$${(value / 1e3).toFixed(2)}K`;
  return `$${value.toFixed(2)}`;
}
function pct(value: number) { return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`; }
function marketKey(m: Market) { return `${m.marketType}:${m.symbol}`; }
function tradeUrl(m: Market) { return `/${m.marketType === 'spot' ? 'spot' : 'futures'}?pair=${encodeURIComponent(m.symbol)}`; }
function detailUrl(m: Market) { return `/market/${m.symbol}?type=${m.marketType}`; }
function tokenFromCookie(name: string) { return document.cookie.split('; ').find(row => row.startsWith(`${name}=`))?.split('=').slice(1).join('=') ?? ''; }

function Coin({ market, size = 36 }: { market: Market; size?: number }) {
  const [broken, setBroken] = useState(false);
  return <span className="mk2-coin" style={{ width: size, height: size }}>{market.icon && !broken ? <img src={market.icon} alt="" loading="lazy" onError={() => setBroken(true)}/> : <i>{market.baseAsset.slice(0, 1)}</i>}</span>;
}
function Range({ low, high, current }: { low: number; high: number; current: number }) {
  const ok = [low, high, current].every(Number.isFinite) && high > low;
  const position = ok ? Math.max(0, Math.min(100, ((current - low) / (high - low)) * 100)) : 50;
  return <div className="mk2-range"><div className="mk2-range-track"><i style={{ left: `${position}%` }}/></div><div className="mk2-range-labels"><span>{price(low)}</span><span>{price(high)}</span></div></div>;
}
function Star_({ active, onToggle, label }: { active: boolean; onToggle: () => void; label: string }) {
  return <button type="button" className={`mk2-fav${active ? ' active' : ''}`} aria-label={label} aria-pressed={active} onClick={event => { event.preventDefault(); event.stopPropagation(); onToggle(); }}><Star/></button>;
}

export default function MarketsPage({ search: initialSearch = '', auth }: Props) {
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [error, setError] = useState(false);
  const [tab, setTab] = useState<'favorites' | 'spot' | 'futures'>('spot');
  const [category, setCategory] = useState<MarketCategory>('All');
  const [query, setQuery] = useState(initialSearch);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [limit, setLimit] = useState(PAGE_STEP);
  const [refreshKey, setRefreshKey] = useState(0);
  const [flashes, setFlashes] = useState<Record<string, 'up' | 'down'>>({});
  const previousPrices = useRef<Map<string, number>>(new Map());
  const refreshEvery = useRef(20);
  const sentinel = useRef<HTMLDivElement>(null);
  const pageProps = usePage().props as Record<string, unknown>;
  const user = auth?.user ?? ((pageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional preference */ } }, [dark]);

  const load = useCallback(async (signal: AbortSignal) => {
    const response = await fetch('/api/markets?type=both', { headers: { Accept: 'application/json' }, signal, credentials: 'same-origin' });
    const data = await response.json().catch(() => null) as MarketSnapshot | null;
    if (!response.ok || !data || !Array.isArray(data.markets)) throw new Error('Market data temporarily unavailable.');
    const next = new Map<string, number>(); const directions: Record<string, 'up' | 'down'> = {};
    for (const item of data.markets) { const key = marketKey(item); const prior = previousPrices.current.get(key); if (prior && item.lastPrice !== prior) directions[key] = item.lastPrice > prior ? 'up' : 'down'; next.set(key, item.lastPrice); }
    previousPrices.current = next; refreshEvery.current = Math.max(15, data.meta.refreshSeconds || 20); setFlashes(directions); window.setTimeout(() => setFlashes({}), 800);
    setSnapshot(data); setError(false);
  }, []);
  useEffect(() => {
    let active = true; let timer = 0; let inflight = false; const controller = new AbortController();
    const refresh = async () => { if (!active || document.hidden || inflight) return; inflight = true; try { await load(controller.signal); } catch { if (active && !controller.signal.aborted) setError(true); } finally { inflight = false; if (active && !document.hidden) timer = window.setTimeout(refresh, refreshEvery.current * 1000); } };
    const visible = () => { if (document.hidden) window.clearTimeout(timer); else void refresh(); };
    void refresh(); document.addEventListener('visibilitychange', visible);
    return () => { active = false; controller.abort(); window.clearTimeout(timer); document.removeEventListener('visibilitychange', visible); };
  }, [load, refreshKey]);

  const loadFavorites = useCallback(async () => {
    if (user) {
      try { const response = await fetch('/api/market-favorites', { headers: { Accept: 'application/json' }, credentials: 'same-origin' }); const data = await response.json() as { favorites: Favorite[] }; if (response.ok) setFavorites(new Set(data.favorites.map(item => `${item.marketType}:${item.symbol}`))); } catch { /* starred state remains usable locally */ }
    } else {
      try { const list = JSON.parse(localStorage.getItem('rushx-market-favorites') ?? '[]') as Favorite[]; setFavorites(new Set(list.map(item => `${item.marketType}:${item.symbol}`))); } catch { setFavorites(new Set()); }
    }
  }, [user]);
  useEffect(() => { void loadFavorites(); }, [loadFavorites]);
  const toggleFavorite = async (market: Market) => {
    const key = marketKey(market); const wasActive = favorites.has(key); const next = new Set(favorites); wasActive ? next.delete(key) : next.add(key); setFavorites(next);
    if (user) {
      try { const headers = { Accept: 'application/json', 'Content-Type': 'application/json', 'X-XSRF-TOKEN': decodeURIComponent(tokenFromCookie('XSRF-TOKEN')) }; const url = `/api/market-favorites/${market.marketType}/${market.symbol}`; const response = await fetch(wasActive ? url : '/api/market-favorites', { method: wasActive ? 'DELETE' : 'POST', credentials: 'same-origin', headers, ...(wasActive ? {} : { body: JSON.stringify({ symbol: market.symbol, marketType: market.marketType }) }) }); if (!response.ok) throw new Error(); } catch { setFavorites(current => { const restored = new Set(current); wasActive ? restored.add(key) : restored.delete(key); return restored; }); }
    } else { try { localStorage.setItem('rushx-market-favorites', JSON.stringify([...next].map(value => { const [marketType, symbol] = value.split(':'); return { marketType, symbol }; }))); } catch { /* favorites remain in memory for this visit */ } }
  };

  const all = snapshot?.markets ?? [];
  const selectedType: MarketType | 'favorites' = tab === 'spot' ? 'spot' : tab === 'futures' ? 'futures' : 'favorites';
  const rows = useMemo(() => {
    let result = all.filter(item => selectedType === 'favorites' ? favorites.has(marketKey(item)) : item.marketType === selectedType);
    if (category === 'Top') result = result.slice(0, snapshot?.meta.topRankLimit ?? 50);
    else if (category === 'New') result = result.filter(item => item.isNew);
    else if (category !== 'All') result = result.filter(item => item.categories.includes(category));
    const q = query.trim().toLowerCase(); if (q) result = result.filter(item => `${item.symbol} ${item.baseAsset} ${item.displayName}`.toLowerCase().includes(q));
    return [...result].sort((a, b) => b.turnover24h - a.turnover24h);
  }, [all, category, favorites, query, selectedType, snapshot?.meta.topRankLimit]);
  useEffect(() => { setLimit(PAGE_STEP); }, [tab, category, query]);
  const visible = rows.slice(0, limit);

  // Infinite scroll: reveal more rows as the sentinel comes into view.
  useEffect(() => {
    const node = sentinel.current; if (!node || !('IntersectionObserver' in window)) return;
    const io = new IntersectionObserver(entries => { if (entries.some(entry => entry.isIntersecting)) setLimit(value => value + PAGE_STEP); }, { rootMargin: '300px' });
    io.observe(node); return () => io.disconnect();
  }, [rows.length, snapshot]);

  const tabs = [{ id: 'favorites', label: 'Favorites' }, { id: 'spot', label: 'Crypto' }, { id: 'futures', label: 'Futures' }] as const;
  const h = snapshot?.highlights;
  const cards: Array<{ title: string; items?: Market[] }> = [
    { title: 'Hot crypto', items: h?.hotCrypto },
    { title: 'Top gainers', items: h?.topGainers },
    { title: 'Top volume 24h', items: h?.topVolume24h },
  ];
  const go = (url: string) => router.visit(url);

  return <><Head title="Markets — RushX"><meta name="theme-color" content={dark ? '#000000' : '#f4f6f2'}/></Head>
    <div className="mk2-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(value => !value)}/>
    <main className="mk2-page">
      <h1 className="mk2-title">Markets</h1>

      <section className="mk2-cards" aria-label="Market highlights">
        {cards.map(({ title, items }) => <article className="mk2-card" key={title}>
          <header><span>{title}</span><ChevronRight/></header>
          {!items ? <div className="mk2-card-loading"><Loader2/></div> : items.length === 0 ? <p className="mk2-card-empty">No data available</p> : items.slice(0, 3).map(item => <a className="mk2-hl-row" key={marketKey(item)} href={tradeUrl(item)} onClick={event => { event.preventDefault(); go(tradeUrl(item)); }}>
            <span className="mk2-hl-coin"><Coin market={item} size={28}/><span><b>{item.baseAsset}</b><small>{item.marketType === 'futures' ? 'Perpetual' : 'Spot'}</small></span></span>
            <span className="mk2-hl-stats"><b className={flashes[marketKey(item)] ? `flash-${flashes[marketKey(item)]}` : ''}>{price(item.lastPrice)}</b><small className={item.change24h >= 0 ? 'up' : 'down'}>{pct(item.change24h)}</small></span>
          </a>)}
        </article>)}
      </section>

      <section className="mk2-board">
        <div className="mk2-tabs" role="tablist">{tabs.map(item => <button key={item.id} type="button" role="tab" aria-selected={tab === item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}>{item.label}</button>)}</div>
        <div className="mk2-filterbar">
          <div className="mk2-chips" role="group" aria-label="Market categories">{filters.map(item => <button key={item} type="button" className={category === item ? 'active' : ''} onClick={() => setCategory(item)}>{item}</button>)}</div>
          <label className="mk2-search"><Search/><input aria-label="Search crypto markets" placeholder="Search crypto" autoComplete="off" spellCheck={false} value={query} onChange={event => setQuery(event.target.value)}/>{query && <button type="button" aria-label="Clear search" onClick={() => setQuery('')}><X/></button>}</label>
        </div>

        {error && !snapshot ? <div className="mk2-state"><b>Market data temporarily unavailable</b><span>Live public prices could not be loaded.</span><button type="button" onClick={() => setRefreshKey(value => value + 1)}><RefreshCw/> Try again</button></div>
        : !snapshot ? <div className="mk2-state"><Loader2 className="mk2-spin"/> Loading markets...</div>
        : rows.length === 0 ? <div className="mk2-state"><b>{selectedType === 'favorites' && favorites.size === 0 ? 'Your favorites will appear here' : 'No markets match your criteria'}</b><span>{selectedType === 'favorites' && favorites.size === 0 ? 'Tap the star beside a market to save it.' : 'Try another category or search term.'}</span></div>
        : <>
          {(snapshot.meta.stale || error) && <div className="mk2-note">Showing the last available prices. Live refresh is temporarily unavailable.</div>}
          <table className="mk2-table"><thead><tr><th>Name</th><th>Price</th><th>Change</th><th className="c">24h range</th><th>24h Volume</th><th>Action</th></tr></thead>
            <tbody>{visible.map(item => { const key = marketKey(item); return <tr key={key} onClick={() => go(tradeUrl(item))}>
              <td><div className="mk2-asset"><Star_ active={favorites.has(key)} onToggle={() => toggleFavorite(item)} label={`${favorites.has(key) ? 'Remove' : 'Add'} ${item.baseAsset} favorite`}/><Coin market={item}/><div><div className="mk2-sym">{item.baseAsset}{item.marketType === 'futures' && <em>Perp</em>}</div><div className="mk2-name">{item.displayName}</div></div></div></td>
              <td className={flashes[key] ? `flash-${flashes[key]}` : ''}>{price(item.lastPrice)}</td>
              <td className={item.change24h >= 0 ? 'up' : 'down'}>{pct(item.change24h)}</td>
              <td><Range low={item.low24h} high={item.high24h} current={item.lastPrice}/></td>
              <td>{volume(item.turnover24h)}</td>
              <td><div className="mk2-actions"><Link href={detailUrl(item)} onClick={event => event.stopPropagation()}>Details</Link><Link className="trade" href={tradeUrl(item)} onClick={event => event.stopPropagation()}>Trade</Link></div></td>
            </tr>; })}</tbody></table>

          <div className="mk2-list">{visible.map(item => { const key = marketKey(item); return <div className="mk2-li" role="link" tabIndex={0} key={key} onClick={() => go(tradeUrl(item))} onKeyDown={event => { if (event.key === 'Enter') go(tradeUrl(item)); }}>
            <Coin market={item} size={38}/>
            <div className="mk2-li-main"><div className="mk2-sym">{item.baseAsset}{item.marketType === 'futures' && <em>Perp</em>}<small>/{item.quoteAsset}</small></div><div className="mk2-name">Vol {volume(item.turnover24h)}</div></div>
            <div className="mk2-li-price"><b className={flashes[key] ? `flash-${flashes[key]}` : ''}>{price(item.lastPrice)}</b></div>
            <span className={`mk2-pill ${item.change24h >= 0 ? 'up' : 'down'}`}>{pct(item.change24h)}</span>
            <Star_ active={favorites.has(key)} onToggle={() => toggleFavorite(item)} label={`${favorites.has(key) ? 'Remove' : 'Add'} ${item.baseAsset} favorite`}/>
          </div>; })}</div>

          {visible.length < rows.length && <div ref={sentinel} className="mk2-more"><Loader2 className="mk2-spin"/></div>}
          <p className="mk2-foot">Prices from Bybit public market data · updated every ~{snapshot.meta.refreshSeconds || 20}s · trading is not connected yet.</p>
        </>}
      </section>
    </main>

    <nav className="mk2-tabbar" aria-label="App navigation">
      <Link href="/" className=""><LayoutGrid/><span>Home</span></Link>
      <Link href="/markets" className="active"><TrendingUp/><span>Markets</span></Link>
      <Link href="/spot"><RefreshCw/><span>Trade</span></Link>
      <Link href={user ? '/assets' : '/login'}><Wallet/><span>Assets</span></Link>
      <Link href={user ? '/dashboard' : '/login'}><UserRound/><span>{user ? 'Account' : 'Sign in'}</span></Link>
    </nav></div></>;
}
