import { useCallback, useEffect, useMemo, useState } from 'react';
import { Check, Clock, Layers, Loader2, TrendingUp, Users, Wallet, Zap } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { api, usd } from '../lib/wallet';
import { Empty, FollowPanel, hms, num, type BotRow, type Claim, type Mine } from './Bots';
import '../../css/earn-bots.css';
import '../../css/copy-trading.css';

type Payload = { bots: BotRow[]; mine: Mine[]; history: Claim[]; kpis: { active: number; aum: string; lifetime: string; funding: string; running: number } };
type Sort = 'roi' | 'followers' | 'aum' | 'runtime';
const hue = (name: string) => [...name].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 7);
const initials = (name: string) => name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
/** What a follower has earned per 100 since launch under this trader's fixed daily return (simple, before the trader's share). */
const roi = (b: BotRow) => b.dailyYield * b.runtimeDays;

function Spark({ b }: { b: BotRow }) {
  const days = Math.max(2, Math.min(60, b.runtimeDays + 1)); const w = 200, h = 56;
  const pts = Array.from({ length: days }, (_, i) => [i * (w / (days - 1)), h - 6 - (i / (days - 1)) * (h - 14)]);
  const path = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const id = `cg${b.id}`;
  return <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id={id} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#17a959" stopOpacity=".22"/><stop offset="1" stopColor="#17a959" stopOpacity="0"/></linearGradient></defs>
    <path d={`${path} L${w},${h} L0,${h} Z`} fill={`url(#${id})`}/><path d={path} fill="none" stroke="#17a959" strokeWidth="1.8" strokeLinecap="round" vectorEffect="non-scaling-stroke"/></svg>;
}

/** Copy trading: copied traders pay the fixed daily return set on the platform, per completed 24h cycle, minus the trader's share. */
export default function CopyTrading() {
  const [data, setData] = useState<Payload | null>(null);
  const [tab, setTab] = useState<'discover' | 'active' | 'history'>('discover');
  const [sort, setSort] = useState<Sort>('roi');
  const [panel, setPanel] = useState<BotRow | null>(null);
  const [toast, setToast] = useState<{ ok: boolean; text: string } | null>(null);
  const [tick, setTick] = useState(0);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const r = await api<Payload>('/api/bots?kind=trader');
    if (r.status === 401) { window.location.href = '/login'; return; }
    if (r.ok) { setData(r.data); setError(''); setTick(0); } else setError('Traders could not be loaded.');
  }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 30000); return () => window.clearInterval(t); }, [load]);
  useEffect(() => { const t = window.setInterval(() => setTick(v => v + 1), 1000); return () => window.clearInterval(t); }, []);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(null), 4000); return () => window.clearTimeout(t); }, [toast]);

  const act = async (path: string, body: Record<string, unknown> = {}, ok = 'Done') => {
    const r = await api<Payload>(path, { ...body, kind: 'trader' });
    if (r.ok) { setData(r.data); setTick(0); setToast({ ok: true, text: ok }); return true; }
    setToast({ ok: false, text: r.data.message ?? 'Request failed.' }); return false;
  };

  const sorted = useMemo(() => {
    const key: Record<Sort, (b: BotRow) => number> = { roi: roi, followers: b => b.followers, aum: b => num(b.aum), runtime: b => b.runtimeDays };
    return [...(data?.bots ?? [])].sort((a, b) => key[sort](b) - key[sort](a));
  }, [data, sort]);
  const k = data?.kpis;

  return <AccountLayout active="Bots" title="Copy Trading">
    <main className="bt-wrap cp-wrap">
      <div className="bt-head"><div><span className="bt-eyebrow"><i/> {k ? `Live · ${k.running} ${k.running === 1 ? 'trader' : 'traders'}` : 'Traders'}</span><h1>Copy Trading</h1>
        <p>Pick a trader and allocate capital. You earn the trader’s fixed daily return every completed 24-hour cycle, paid to your Funding account — pause or stop any time and your capital comes straight back.</p></div></div>
      <div className="bt-kpis">
        <div className="bt-kpi"><span><Users/></span><small>ACTIVE FOLLOWS</small><b>{k ? k.active : '—'}</b><em>Traders you copy</em></div>
        <div className="bt-kpi"><span><Layers/></span><small>CAPITAL DEPLOYED</small><b>{k ? `$${k.aum}` : '—'}<u>USDT</u></b><em>Allocated to copy trading</em></div>
        <div className="bt-kpi"><span className="g"><TrendingUp/></span><small>LIFETIME PNL</small><b>{k ? `+$${k.lifetime}` : '—'}<u>USDT</u></b><em className="up">From your follows</em></div>
        <div className="bt-kpi"><span className="y"><Wallet/></span><small>AVAILABLE CAPITAL</small><b>{k ? `$${k.funding}` : '—'}<u>USDT</u></b><em>Funding wallet</em></div>
      </div>
      <div className="bt-tabs"><button type="button" className={tab === 'discover' ? 'active' : ''} onClick={() => setTab('discover')}>Discover traders</button><button type="button" className={tab === 'active' ? 'active' : ''} onClick={() => setTab('active')}>My copy connections <span>{data?.mine.length ?? 0}</span></button><button type="button" className={tab === 'history' ? 'active' : ''} onClick={() => setTab('history')}>Profit history</button></div>

      {!data ? <div className="bt-empty">{error || <Loader2 className="spin"/>}</div>
        : tab === 'discover' ? (sorted.length === 0 ? <Empty title="No traders yet" text="Verified traders will appear here as soon as they are opened."/> : <>
          <div className="cp-sort" role="tablist" aria-label="Sort traders">{([['roi', 'Top ROI'], ['followers', 'Most followed'], ['aum', 'Highest AUM'], ['runtime', 'Longest running']] as const).map(([v, l]) => <button type="button" key={v} className={sort === v ? 'on' : ''} onClick={() => setSort(v)}>{l}</button>)}</div>
          <div className="cp-grid">{sorted.map(b => <article className="cp-card" key={b.id}>
            <div className="cp-head"><span className="cp-av" style={{ background: `hsl(${hue(b.name)} 70% 45%)` }}>{initials(b.name)}<em/></span>
              <div><h3>{b.name}</h3><div className="cp-meta"><span className={`cp-chip ${(b.direction ?? 'LONG').toLowerCase()}`}>{b.direction ?? 'LONG'}</span><span>{b.leverage ?? 1}x avg leverage</span><i/><span>{b.profitShare}% share</span></div></div></div>
            <p className="cp-bio">{b.bio}</p>
            <div className="cp-spark"><Spark b={b}/></div>
            <div className="cp-stats"><div><small>ROI</small><b className="up">+{roi(b).toFixed(1)}%</b></div><div><small>Daily</small><b>+{b.dailyYield.toFixed(2)}%</b></div><div><small>Days</small><b>{b.runtimeDays}</b></div></div>
            <div className="cp-foot"><span><Users/> {b.followers.toLocaleString('en-US')} followers · AUM <b>${b.aum}</b></span>
              <button type="button" className="cp-copy" disabled={b.following || !b.enabled} onClick={() => setPanel(b)}><Zap/> {b.following ? 'Copying' : b.enabled ? 'Copy' : 'Closed'}</button></div></article>)}</div></>)
        : tab === 'active' ? (data.mine.length === 0 ? <Empty title="No active copies yet" text="Find a trader you like and start copying — the daily return is paid to your Funding account every cycle." icon={<Users/>}/> : <div className="bt-list">{data.mine.map(m => {
          const t = data.bots.find(x => x.id === m.botId);
          const remaining = Math.max(0, m.remaining - tick); const ready = m.claimableCycles >= 1 || remaining === 0; const pct = Math.min(100, ((86400 - remaining) / 86400) * 100);
          return <div className={`bt-row${ready ? ' ready' : ''}`} key={m.botId}>
            <div className="bt-r-head"><span className="cp-av sm" style={{ background: `hsl(${hue(m.name)} 70% 45%)` }}>{initials(m.name)}</span><div><h3>{m.name}</h3><small>{t?.direction ?? 'LONG'} · <b>${m.capital}</b> allocated · {m.dailyYield}% daily</small></div></div>
            <div className="bt-r-timer"><small>{ready ? 'Cycle complete' : 'Next profit in'}</small><b className={ready ? 'ok' : ''}>{ready ? `+${m.nextProfit} USDT` : hms(remaining)}</b><div className="bt-bar"><div style={{ width: `${ready ? 100 : pct}%` }}/></div></div>
            <label className="bt-auto">Auto-claim<span className="bt-switch"><input type="checkbox" checked={m.autoClaim} onChange={e => void act(`/api/bots/${m.botId}/auto`, { auto_claim: e.target.checked }, e.target.checked ? 'Auto-claim on' : 'Auto-claim off')}/><i/></span></label>
            <div className="bt-r-act">{ready ? <button type="button" className="claim" onClick={() => void act(`/api/bots/${m.botId}/claim`, {}, 'Profit claimed')}><Zap/> Claim profit</button> : <button type="button" className="wait" disabled><Clock/> Running…</button>}
              <button type="button" className="stop" onClick={() => { if (window.confirm(`Stop copying ${m.name}? Your $${m.capital} (and any profit already earned) returns to your Funding account.`)) void act(`/api/bots/${m.botId}/unfollow`, {}, 'Stopped — capital returned'); }}>Stop copying</button></div></div>; })}</div>)
        : (data.history.length === 0 ? <Empty title="No profits yet" text="Once a full 24-hour cycle is claimed, it is listed here." icon={<TrendingUp/>}/> : <div className="bt-hist"><div className="bt-hsum"><div><small>Total claims</small><b>{data.history.length}</b></div><div><small>Realized profit</small><b className="up">+${usd(data.history.reduce((s, c) => s + num(c.net), 0))}</b></div></div>
          <div className="bt-tw"><table><thead><tr><th>Trader</th><th>Cycles</th><th>Capital</th><th>Gross</th><th>Trader share</th><th>Time</th><th className="r">Profit</th></tr></thead>
            <tbody>{data.history.map(c => <tr key={c.id}><td data-l="Trader"><b>{c.bot}</b></td><td data-l="Cycles">{c.cycles}</td><td data-l="Capital">${c.capital}</td><td data-l="Gross">{c.gross}</td><td data-l="Trader share">{c.share}</td><td data-l="Time" className="t">{c.at ? new Date(c.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}</td><td data-l="Profit" className="r up"><b>+${c.net}</b></td></tr>)}</tbody></table></div></div>)}
    </main>
    {panel && k && <FollowPanel bot={panel} funding={num(k.funding)} onClose={() => setPanel(null)} onConfirm={async (capital, auto, key) => { const ok = await act(`/api/bots/${panel.id}/follow`, { capital, auto_claim: auto, idempotency_key: key }, `Now copying ${panel.name}`); if (ok) setPanel(null); }}/>}
    {toast && <div className={`ea-toast ${toast.ok ? 'ok' : 'bad'}`} role="status"><Check/>{toast.text}</div>}
  </AccountLayout>;
}
