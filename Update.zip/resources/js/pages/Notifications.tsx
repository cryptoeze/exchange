import { useCallback, useEffect, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import { AlertTriangle, ArrowLeft, Bell, CheckCircle2, Info, Megaphone } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import { useTheme } from '../lib/hooks';
import { api } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/profile.css';

type Item = { id: number; type: string; title: string; body: string | null; url: string | null; read: boolean; at: string };
const ago = (iso: string) => { const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000); return s < 60 ? 'now' : s < 3600 ? `${Math.floor(s / 60)}m` : s < 86400 ? `${Math.floor(s / 3600)}h` : `${Math.floor(s / 86400)}d`; };
const icon = (t: string) => t === 'success' ? <CheckCircle2/> : t === 'warn' ? <AlertTriangle/> : t === 'broadcast' ? <Megaphone/> : <Info/>;

export default function Notifications() {
  const brandName = (usePage().props as { siteName?: string }).siteName || 'RushX';
  useTheme();
  const [items, setItems] = useState<Item[] | null>(null); const [unread, setUnread] = useState(0);
  const load = useCallback(async () => { try { const r = await fetch('/api/notifications', { headers: { Accept: 'application/json' }, credentials: 'same-origin' }); if (r.ok) { const d = await r.json() as { items: Item[]; unread: number }; setItems(d.items); setUnread(d.unread); } } catch { setItems([]); } }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 15000); return () => window.clearInterval(t); }, [load]);
  const readAll = async () => { await api('/api/notifications/read', {}); void load(); };
  const open = async (n: Item) => { if (!n.read) await api('/api/notifications/read', { id: n.id }); if (n.url) window.location.href = n.url; else void load(); };
  return <><Head title={`Notifications — ${brandName}`}/>
    <div className="ov-shell pf-shell rx-dashboard">
      <header className="pf-top"><button type="button" aria-label="Back" onClick={() => (window.history.length > 1 ? window.history.back() : (window.location.href = '/dashboard'))}><ArrowLeft/></button><b>Notifications</b><button type="button" aria-label="Mark all read" onClick={readAll} disabled={unread === 0} style={{ fontSize: 12, width: 'auto', padding: '0 6px', opacity: unread ? 1 : .4 }}>Read all</button></header>
      <section className="pf-card flat" style={{ marginTop: 14 }}>
        {items === null ? <p className="pf-empty">Loading…</p> : items.length === 0 ? <p className="pf-empty"><Bell style={{ display: 'block', margin: '0 auto 8px' }}/>No notifications yet.</p> : items.map(n => <button type="button" key={n.id} className={`pf-row nf${n.read ? '' : ' unread'}`} onClick={() => open(n)}>
          <span className={`pf-ico nf-${n.type}`}>{icon(n.type)}</span><span className="pf-txt"><b>{n.title}</b>{n.body && <small>{n.body}</small>}</span><em className="nf-t">{ago(n.at)}</em></button>)}
      </section>
      <MobileNav active="home"/>
    </div></>;
}
