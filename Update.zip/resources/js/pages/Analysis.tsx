import { useEffect, useMemo, useState } from 'react';
import { Eye, EyeOff, Activity, Info } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import CoinImage from '../components/CoinImage';
import { COIN_NAMES, useSpotPrices, useWallet } from '../lib/hooks';
import { api, usd, usdValue } from '../lib/wallet';

type Summary = { deposits: string; withdrawals: string; volume30d: string; fees30d: string; trades30d: number; tradesTotal: number; winRate: number | null; feeRate: number };
const COLORS = ['#c1f033', '#2ebd85', '#5b8def', '#f5a623', '#f6465d', '#a06cf0', '#727a8a'];

/** Portfolio analysis derived entirely from the ledger, live prices and the user's own orders. */
export default function Analysis() {
  const { wallet } = useWallet('funding');
  const prices = useSpotPrices();
  const [summary, setSummary] = useState<Summary | null>(null);
  const [visible, setVisible] = useState(true);
  useEffect(() => { let on = true; const load = async () => { const r = await api<Summary>('/api/account/summary'); if (on && r.ok) setSummary(r.data); }; void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 30000); return () => { on = false; window.clearInterval(t); }; }, []);

  const assets = useMemo(() => {
    const merged = new Map<string, number>();
    for (const b of wallet?.balances ?? []) merged.set(b.asset, (merged.get(b.asset) ?? 0) + b.units / 1e8);
    return [...merged].map(([asset, amount]) => ({ asset, amount, value: usdValue(asset, amount, prices) })).filter(a => a.value > 0).sort((a, b) => b.value - a.value);
  }, [wallet, prices]);
  const total = assets.reduce((sum, a) => sum + a.value, 0);
  const mask = (text: string) => visible ? text : '******';

  // Donut: one arc per asset (stroke-dasharray on a circle), coloured from the palette.
  const R = 70; const C = 2 * Math.PI * R;
  let offset = 0;
  const arcs = assets.map((a, i) => { const len = total > 0 ? (a.value / total) * C : 0; const arc = { ...a, len, offset, color: COLORS[i % COLORS.length] }; offset += len; return arc; });

  return <AccountLayout active="Analysis" title="Portfolio Analysis">
    <main className="ap-wrap">
      <h1 className="ap-title">Portfolio Analysis</h1>
      <div className="ap-grid-top">
        <section className="ov-card ap-balance">
          <div>
            <div className="ov-lbl ap-lbl-big"><b>Estimated Total Balance</b><button type="button" aria-label={visible ? 'Hide balances' : 'Show balances'} onClick={() => setVisible(v => !v)}>{visible ? <Eye/> : <EyeOff/>}</button></div>
            <div className="ap-big">{wallet ? mask(`$${usd(total)}`) : '—'}</div>
            <div className="ap-live"><Activity/> Live market valuation</div>
          </div>
          <div className="ap-two">
            <div><small>Total Deposits (USDT)</small><b>{summary ? mask(`$${usd(Number(summary.deposits))}`) : '—'}</b></div>
            <div><small>Total Withdrawals (USDT)</small><b>{summary ? mask(`$${usd(Number(summary.withdrawals))}`) : '—'}</b></div>
          </div>
        </section>

        <section className="ov-card ap-alloc">
          <h2>Asset Allocation</h2>
          <div className="ap-donut" role="img" aria-label="Asset allocation chart">
            <svg viewBox="0 0 200 200"><circle cx="100" cy="100" r={R} fill="none" stroke="var(--ov-input)" strokeWidth="22"/>
              {arcs.map(a => <circle key={a.asset} cx="100" cy="100" r={R} fill="none" stroke={a.color} strokeWidth="22" strokeDasharray={`${a.len} ${C - a.len}`} strokeDashoffset={-a.offset} transform="rotate(-90 100 100)"/>)}</svg>
            <div><small>Assets</small><b>{assets.length}</b></div>
          </div>
          <div className="ap-legend">{assets.length === 0 ? <p className="ov-empty">No assets hold value yet.</p> : arcs.slice(0, 6).map(a => <div key={a.asset}>
            <i style={{ background: a.color }}/><span className="ov-coin sm"><CoinImage symbol={a.asset} icon={prices.get(`${a.asset}USDT`)?.icon}/></span>
            <span className="nm"><b>{a.asset}</b><small>{COIN_NAMES[a.asset] ?? a.asset}</small></span>
            <span className="vl"><b>{mask(`${total > 0 ? ((a.value / total) * 100).toFixed(2) : '0.00'}%`)}</b><small>{mask(`$${usd(a.value)}`)}</small></span></div>)}</div>
        </section>
      </div>

      <div className="ap-grid-3">
        <section className="ov-card"><small className="ap-k">30-Day Trading Volume <Info/></small><b className="ap-v">{summary ? mask(`$${usd(Number(summary.volume30d))}`) : '—'}</b></section>
        <section className="ov-card"><small className="ap-k">Total Trades Executed</small><b className="ap-v">{summary ? summary.tradesTotal.toLocaleString('en-US') : '—'}</b></section>
        <section className="ov-card"><small className="ap-k">Win Rate / Profitability</small><b className="ap-v">{summary ? (summary.winRate === null ? '—' : `${summary.winRate}%`) : '—'}</b>{summary && summary.winRate === null && <small className="ap-hint">Shown after your first closed (sell) trade.</small>}</section>
      </div>
    </main>
  </AccountLayout>;
}
