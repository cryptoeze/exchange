import { useCallback, useEffect, useState } from 'react';
import { ArrowRight, Check, CheckCheck, Copy, Gift, Loader2, PiggyBank, Sparkles, Zap, BadgePercent } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { api } from '../lib/wallet';
import '../../css/rewards.css';

type Day = { day: number; amount: string; claimed: boolean; today: boolean };
type State = { enabled: boolean; asset: string; claimedToday: boolean; nextDay: number; streak: number; lifetime: string; lastAmount: string | null; days: Day[]; nextReset: string };

const CARDS = [
  { tone: 'stake', Icon: PiggyBank, tag: 'Flexible savings', title: 'Earn on idle USDT', text: 'Put your balance to work in flexible savings — withdraw any time.', cta: 'Start earning', href: '/earn' },
  { tone: 'bonus', Icon: BadgePercent, tag: 'Deposit bonus', title: '+12% on every deposit', text: 'The bonus is added to your Funding balance as real, tradable money.', cta: 'Deposit now', href: '/deposit' },
  { tone: 'bot', Icon: Zap, tag: 'Auto-trading', title: 'Trading bots', text: 'Put capital in a strategy and earn a fixed daily yield.', cta: 'Browse bots', href: '/bots' },
  { tone: 'copy', Icon: Copy, tag: 'Auto-copy', title: 'Copy top traders', text: 'Follow a trader and earn their daily return — hands-free.', cta: 'Browse traders', href: '/copy' },
];

/** Daily check-in rewards: one claim per UTC day, bigger reward each consecutive day, paid into Funding. */
export default function Rewards() {
  const [s, setS] = useState<State | null>(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ ok: boolean; text: string } | null>(null);
  const [left, setLeft] = useState('');

  const load = useCallback(async () => { const r = await api<State>('/api/rewards'); if (r.status === 401) { window.location.href = '/login'; return; } if (r.ok) setS(r.data); }, []);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(null), 3200); return () => window.clearTimeout(t); }, [toast]);
  useEffect(() => { // countdown to the next UTC day
    if (!s) return; const f = () => { const ms = Math.max(0, new Date(s.nextReset).getTime() - Date.now()); const h = Math.floor(ms / 3.6e6); const m = Math.floor((ms % 3.6e6) / 6e4); setLeft(`${h}h ${String(m).padStart(2, '0')}m`); if (ms === 0) void load(); };
    f(); const t = window.setInterval(f, 30000); return () => window.clearInterval(t);
  }, [s, load]);

  const claim = async () => {
    if (!s || busy || s.claimedToday) return; setBusy(true);
    const r = await api<State>('/api/rewards/claim', {}); setBusy(false);
    if (r.ok) { setS(r.data); setToast({ ok: true, text: `+$${r.data.lastAmount} added to Funding · Day ${r.data.days.filter(d => d.claimed).length}` }); } else setToast({ ok: false, text: r.data.message ?? 'Could not claim.' });
  };

  const today = s?.days.find(d => d.today);
  const shown = s ? (s.claimedToday ? s.lastAmount : today?.amount) : null;

  return <AccountLayout active="Rewards" title="Rewards" showNav={false} phoneBar>
    <main className="rw-wrap">
      <section className="rw-hero">
        <span className="rw-eyebrow">{s?.claimedToday ? <><CheckCheck/> Already claimed today</> : <><Gift/> Daily reward ready</>}</span>
        <div className="rw-amount">{s ? `$${shown}` : '—'}<em>{s?.asset ?? 'USDT'}</em></div>
        <p className="rw-label">{!s ? 'Loading…' : s.claimedToday ? <>Come back in {left} to claim day <b>{s.nextDay}</b></> : <>Claim day <b>{s.nextDay}</b> — paid straight to your Funding account</>}</p>
        <div className="rw-pill"><CheckCheck/> Lifetime <b>${s?.lifetime ?? '0.00'}</b> · Streak <b>{s?.streak ?? 0} {s?.streak === 1 ? 'day' : 'days'}</b></div>
      </section>

      <section className="rw-days" aria-label="7-day reward cycle">{(s?.days ?? Array.from({ length: 7 }, (_, i) => ({ day: i + 1, amount: '…', claimed: false, today: false }))).map(d =>
        <div key={d.day} className={`rw-day${d.claimed ? ' claimed' : ''}${d.today ? ' today' : ''}${d.day === 7 ? ' bonus' : ''}`}>
          <small>D{d.day}</small><span>{d.claimed ? <Check/> : d.day === 7 ? <Sparkles/> : <Gift/>}</span><b>${d.amount}</b></div>)}</section>

      <h2 className="rw-h">More ways to earn</h2>
      <section className="rw-cards">{CARDS.map(({ tone, Icon, tag, title, text, cta, href }) => <a key={title} href={href} className={`rw-card ${tone}`}>
        <span className="ic"><Icon/></span><em>{tag}</em><h3>{title}</h3><p>{text}</p><b>{cta} <ArrowRight/></b></a>)}</section>

      <div className="rw-claimbar"><button type="button" className="rw-claim" disabled={!s || !s.enabled || s.claimedToday || busy} onClick={claim}>
        {busy ? <Loader2 className="spin"/> : s?.claimedToday ? <CheckCheck/> : <Gift/>}<span>{!s ? 'Loading…' : !s.enabled ? 'Rewards paused' : s.claimedToday ? 'Already claimed today' : `Claim $${today?.amount ?? ''} USDT`}</span></button></div>
    </main>
    {toast && <div className={`rw-toast ${toast.ok ? 'ok' : 'bad'}`} role="status">{toast.text}</div>}
  </AccountLayout>;
}
