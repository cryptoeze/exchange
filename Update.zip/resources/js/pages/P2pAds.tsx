import { useCallback, useEffect, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import AccountLayout from '../components/AccountLayout';
import { api } from '../lib/wallet';
import { money, type P2pAd, type P2pConfig } from '../lib/p2p';
import '../../css/p2p.css';

export default function P2pAds() {
  const brandName = (usePage().props as { siteName?: string }).siteName || 'RushX';
  const [cfg, setCfg] = useState<P2pConfig | null>(null); const [ads, setAds] = useState<P2pAd[] | null>(null); const [err, setErr] = useState(''); const [ok, setOk] = useState('');
  const [f, setF] = useState({ side: 'sell' as 'buy' | 'sell', coin: 'USDT', fiat: 'PKR', price: '', amount: '', min_fiat: '', max_fiat: '', terms: '', window_min: '15' });
  const [methods, setMethods] = useState<string[]>([]); const [details, setDetails] = useState<Record<string, string>>({});
  const load = useCallback(async () => { const r = await api<{ ads: P2pAd[] }>('/api/p2p/my-ads'); if (r.ok) setAds(r.data.ads); }, []);
  useEffect(() => { void api<P2pConfig>('/api/p2p/config').then(r => { if (r.ok) setCfg(r.data); }); void load(); }, [load]);
  const toggle = (m: string) => setMethods(v => v.includes(m) ? v.filter(x => x !== m) : v.length >= 5 ? v : [...v, m]);
  const create = async () => { setErr(''); setOk(''); const r = await api<{ id: number }>('/api/p2p/ads', { ...f, methods, details, window_min: Number(f.window_min) }); if (r.ok) { setOk('Ad published.'); setF({ ...f, price: '', amount: '', min_fiat: '', max_fiat: '' }); void load(); } else setErr(r.data.message ?? 'Check the form.'); };
  const status = async (id: number, s: string) => { const r = await api<{ ads: P2pAd[] }>(`/api/p2p/ads/${id}/status`, { status: s }); if (r.ok) setAds(r.data.ads); else setErr(r.data.message ?? 'Failed.'); };
  return <AccountLayout active="P2P" title="My P2P ads" showNav={false} phoneBar>
    <Head title={`My P2P ads — ${brandName}`}/>
    <main className="p2-wrap">
      <div className="p2-top"><h1 className="p2-h1">My ads</h1><div className="p2-links"><a href="/p2p">Marketplace</a><a href="/p2p/orders">My orders</a></div></div>
      <section className="p2-card">
        <h2>Post an ad</h2>
        <div className="p2-seg"><button type="button" className={f.side === 'sell' ? 'on sell' : ''} onClick={() => setF({ ...f, side: 'sell' })}>I sell coins</button><button type="button" className={f.side === 'buy' ? 'on buy' : ''} onClick={() => setF({ ...f, side: 'buy' })}>I buy coins</button></div>
        <p className="p2-sub">{f.side === 'sell' ? 'Your coins are locked in escrow when the ad goes live and returned if you close it.' : 'Your coins are not locked. Sellers lock theirs when they accept your ad.'}</p>
        <div className="p2-grid">
          <label>Coin<select value={f.coin} onChange={e => setF({ ...f, coin: e.target.value })}>{cfg && Object.keys(cfg.coins).map(c => <option key={c}>{c}</option>)}</select></label>
          <label>Currency<select value={f.fiat} onChange={e => setF({ ...f, fiat: e.target.value })}>{cfg && Object.keys(cfg.fiats).map(c => <option key={c}>{c}</option>)}</select></label>
          <label>Price per {f.coin} ({f.fiat})<input inputMode="decimal" value={f.price} onChange={e => setF({ ...f, price: e.target.value })}/></label>
          <label>Amount ({f.coin})<input inputMode="decimal" value={f.amount} onChange={e => setF({ ...f, amount: e.target.value })}/></label>
          <label>Min order ({f.fiat})<input inputMode="decimal" value={f.min_fiat} onChange={e => setF({ ...f, min_fiat: e.target.value })}/></label>
          <label>Max order ({f.fiat})<input inputMode="decimal" value={f.max_fiat} onChange={e => setF({ ...f, max_fiat: e.target.value })}/></label>
          <label>Payment window (min)<select value={f.window_min} onChange={e => setF({ ...f, window_min: e.target.value })}>{[10, 15, 20, 30, 45, 60].map(n => <option key={n}>{n}</option>)}</select></label>
        </div>
        <label>Payment methods (up to 5)</label>
        <div className="p2-methods pick">{cfg?.methods.map(m => <button type="button" key={m} className={methods.includes(m) ? 'on' : ''} onClick={() => toggle(m)}>{m}</button>)}</div>
        {f.side === 'sell' && methods.map(m => <label key={m}>{m} — where buyers should pay<input value={details[m] ?? ''} onChange={e => setDetails({ ...details, [m]: e.target.value })} placeholder="Account number, name, phone…" maxLength={300}/></label>)}
        <label>Terms (optional)<textarea value={f.terms} onChange={e => setF({ ...f, terms: e.target.value })} maxLength={600}/></label>
        {err && <p className="p2-err" role="alert">{err}</p>}{ok && <p className="p2-ok">{ok}</p>}
        <button type="button" className={`p2-cta ${f.side === 'sell' ? 'sell' : 'buy'}`} onClick={create}>Publish ad</button>
      </section>
      <h2 className="p2-h2">Live ads</h2>
      {ads === null ? <p className="p2-empty">Loading…</p> : ads.length === 0 ? <p className="p2-empty">You have no active ads.</p> : <div className="p2-list">{ads.map(a => <article key={a.id} className="p2-ad">
        <header><b>{a.side === 'sell' ? 'Selling' : 'Buying'} {a.coin}</b><em style={{ color: a.status === 'online' ? '#2ebd85' : '#8e8e93' }}>{a.status}</em></header>
        <div className="p2-price"><b>{money(a.price)}</b> <em>{a.fiat}</em></div>
        <div className="p2-sub">Open: {a.available} of {a.total} {a.coin} · limits {money(a.min, 0)}–{money(a.max, 0)} {a.fiat}</div>
        <div className="p2-methods">{a.methods.map(m => <span key={m}>{m}</span>)}</div>
        <div className="p2-actions"><button type="button" className="p2-ghost" onClick={() => status(a.id, a.status === 'online' ? 'offline' : 'online')}>{a.status === 'online' ? 'Go offline' : 'Go online'}</button><button type="button" className="p2-ghost danger" onClick={() => window.confirm('Close this ad? Unused coins return to your Funding account.') && status(a.id, 'closed')}>Close ad</button></div>
      </article>)}</div>}
    </main>
  </AccountLayout>;
}
