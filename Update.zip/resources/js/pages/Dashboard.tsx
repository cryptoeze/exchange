import { useEffect, useState } from 'react';
import { Head } from '@inertiajs/react';
import { Activity, ArrowDownToLine, ArrowLeftRight, ArrowUpFromLine, CandlestickChart, CircleHelp, LockKeyhole, ShieldCheck, Wallet } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';

type Props = { user: HeaderUser };
const themeValue = () => { try { return typeof localStorage === 'undefined' || localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } };

export default function Dashboard({ user }: Props) {
  const [dark, setDark] = useState(themeValue);
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* Theme preference is optional. */ }
  }, [dark]);
  return <>
    <Head title="Dashboard"><meta name="theme-color" content={dark ? '#050505' : '#f6f7f4'}/></Head>
    <div className="rx-dashboard" data-theme={dark ? 'dark' : 'light'}>
      <RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(value => !value)}/>
      <main className="rx-dashboard-main">
        <div className="rx-dashboard-welcome"><div><span className="rx-overline">RUSHX ACCOUNT</span><h1>Welcome, {user.name || 'back'}</h1><p>Your account overview and platform access.</p></div><a className="rx-account-link" href="/security"><ShieldCheck/> Account settings</a></div>
        <section className="rx-account-grid" aria-label="Account overview">
          <article className="rx-account-card rx-account-primary"><span className="rx-card-icon"><Wallet/></span><span className="rx-card-label">Estimated total value</span><strong>Not available</strong><p>Wallet balances are not configured for this account yet.</p><a href="/assets">Open assets <ArrowLeftRight/></a></article>
          <article className="rx-account-card"><span className="rx-card-icon"><ShieldCheck/></span><span className="rx-card-label">Email verification</span><strong className="rx-card-small">{user.emailVerified ? 'Verified' : 'Not verified'}</strong><p>{user.email}</p><a href="/security">Security &amp; settings <ArrowLeftRight/></a></article>
          <article className="rx-account-card"><span className="rx-card-icon"><Activity/></span><span className="rx-card-label">Market data</span><strong className="rx-card-small">Public market preview</strong><p>Prices are for information only; trading is not connected.</p><a href="/markets">View markets <ArrowLeftRight/></a></article>
        </section>
        <section className="rx-wallet-panel">
          <div className="rx-panel-heading"><div><span className="rx-overline">ACCOUNT TOOLS</span><h2>Wallet &amp; activity</h2><p>Funding operations will show here once RushX wallet services are configured.</p></div><span className="rx-not-configured">Not configured</span></div>
          <div className="rx-wallet-actions"><a href="/deposit"><ArrowDownToLine/> Deposit</a><a href="/withdraw"><ArrowUpFromLine/> Withdraw</a><a href="/transfer"><ArrowLeftRight/> Transfer</a><a href="/orders"><CandlestickChart/> Order center</a></div>
          <div className="rx-wallet-empty"><span><LockKeyhole/></span><div><b>No wallet activity yet</b><p>This app release has no wallet balance or transaction ledger. Your funds are not changed by these account tools.</p></div><a href="/support"><CircleHelp/> Get help</a></div>
        </section>
        <p className="rx-dashboard-note"><ShieldCheck/> RushX account access is active. Financial services will appear after their secure wallet and approval workflows are implemented.</p>
      </main>
    </div>
  </>;
}
