import { useCallback, useEffect, useMemo, useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import { Check, Copy, Loader2, ShieldCheck, Undo2, Zap } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import AccountSubNav from '../components/AccountSubNav';
import CoinImage from '../components/CoinImage';
import { api, newKey } from '../lib/wallet';
import '../../css/overview.css';
import '../../css/deposit.css';
import '../../css/treasury.css';

type Net = { code: string; label: string; fee: number; arrival: string };
type Asset = { ticker: string; name: string; logo: string; min: number; networks: Net[] };
type Row = { id: number; asset: string; network: string; address: string; amount: string; net: string; fee: string; status: string; txHash: string | null; reason: string | null; at: string | null };
type Payload = { enabled: boolean; balances: Record<string, string>; assets: Asset[]; rows: Row[] };

const fmt = (n: number, d = 4) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: d });
const PATTERNS: Record<string, RegExp> = { TRC20: /^T[1-9A-HJ-NP-Za-km-z]{33}$/, BTC: /^(bc1[a-z0-9]{25,62}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/ };
const EVM = /^0x[a-fA-F0-9]{40}$/;
const addressOk = (asset: string, net: string, a: string) => net === 'TRC20' ? PATTERNS.TRC20.test(a) : asset === 'BTC' ? PATTERNS.BTC.test(a) : EVM.test(a);
const STATUS: Record<string, string> = { pending: 'Pending review', completed: 'Completed', rejected: 'Rejected', cancelled: 'Cancelled' };
const FAQ = ['How do I make a withdrawal?', 'Why is my withdrawal pending?', 'How long does a withdrawal take?', 'What happens if I enter a wrong address?'];

function CoinLogo({ asset }: { asset: Asset }) {
  return <span style={{ width: 28, height: 28, borderRadius: '50%', overflow: 'hidden', display: 'inline-grid', placeItems: 'center', flex: '0 0 auto', background: 'var(--ov-input)', fontWeight: 700 }}><CoinImage symbol={asset.ticker}/></span>;
}

export default function Withdraw() {
  const withdrawPageProps = usePage().props as Record<string, unknown>;
  const user = (withdrawPageProps.auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const brandName = (withdrawPageProps.siteName as string | undefined) || 'RushX';
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  const [data, setData] = useState<Payload | null>(null);
  const [ticker, setTicker] = useState('USDT');
  const [netCode, setNetCode] = useState('');
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [copied, setCopied] = useState(0);
  const [key, setKey] = useState(newKey);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* optional */ } }, [dark]);
  const load = useCallback(async () => { const r = await api<Payload>('/api/withdrawals'); if (r.ok) setData(r.data); }, []);
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 4000); return () => window.clearInterval(t); }, [load]);

  const asset = data?.assets.find(a => a.ticker === ticker);
  const net = asset?.networks.find(n => n.code === netCode) ?? asset?.networks[0];
  useEffect(() => { if (asset && !asset.networks.some(n => n.code === netCode)) setNetCode(asset.networks[0].code); }, [asset, netCode]);

  const balance = Number((data?.balances[ticker] ?? '0').replace(/,/g, ''));
  const amt = Number(amount) || 0;
  const fee = net?.fee ?? 0;
  const receive = Math.max(0, amt - fee);
  const addr = address.trim();
  const problem = useMemo(() => {
    if (!asset || !net) return 'Loading…';
    if (!amount || amt <= 0) return 'Enter an amount';
    if (amt < asset.min) return `Minimum ${fmt(asset.min, 8)} ${ticker}`;
    if (amt > balance) return 'Insufficient balance';
    if (amt <= fee) return 'Amount must exceed the fee';
    if (!addr) return 'Enter destination address';
    if (!addressOk(ticker, net.code, addr)) return `Invalid ${net.label} address`;
    return '';
  }, [asset, net, amount, amt, balance, fee, addr, ticker]);

  const submit = async () => {
    setConfirm(false); setBusy(true); setError(''); setOk('');
    const r = await api<Payload>('/api/withdrawals', { asset: ticker, network: net!.code, address: addr, amount, idempotency_key: key });
    setBusy(false);
    if (r.ok) { setData(r.data); setAmount(''); setAddress(''); setKey(newKey()); setOk('Withdrawal submitted. It will be reviewed and sent shortly.'); } else setError(r.data.message ?? 'Could not submit the withdrawal.');
  };
  const cancel = async (id: number) => { const r = await api<Payload>(`/api/withdrawals/${id}/cancel`, {}); if (r.ok) setData(r.data); else setError(r.data.message ?? 'Could not cancel.'); };
  const copy = async (t: string, id: number) => { try { await navigator.clipboard.writeText(t); setCopied(id); window.setTimeout(() => setCopied(0), 1800); } catch { /* blocked */ } };

  return <><Head title={`Withdraw — ${brandName}`}/>
    <div className="ov-shell dp-shell rx-dashboard"><RushXHeader user={user} dark={dark} onToggleTheme={() => setDark(v => !v)}/>
    <AccountSubNav active="Funding"/>
    <main className="dp-main">
      <h1 className="dp-title">Withdraw</h1>
      <div className="dp-grid">
        <div>
          {data && !data.enabled && <div className="dp-note" role="status" style={{ marginLeft: 0 }}>Withdrawals are temporarily paused.</div>}
          <div className="tw-field"><label htmlFor="w-asset">Asset</label>
            <div className="tw-coin" style={{ marginBottom: 0 }}>{asset ? <CoinLogo asset={asset}/> : null}
              <select id="w-asset" value={ticker} onChange={e => { setTicker(e.target.value); setAmount(''); setError(''); }} style={{ flex: 1, background: 'transparent', color: 'inherit', border: 0, font: 'inherit', fontWeight: 700, fontSize: 16, outline: 0 }}>
                {data?.assets.map(a => <option key={a.ticker} value={a.ticker}>{a.name}</option>)}
              </select></div></div>
          <div style={{ height: 20 }}/>
          <div className="tw-lbl">Network</div>
          <div className="tw-nets" role="radiogroup" aria-label="Network">{asset?.networks.map(n => <button key={n.code} type="button" role="radio" aria-checked={net?.code === n.code} className={`tw-net${net?.code === n.code ? ' on' : ''}`} onClick={() => setNetCode(n.code)}><b>{n.code}</b><small>Fee {fmt(n.fee, 8)} · {n.arrival}</small></button>)}</div>
          <div className="tw-field"><label htmlFor="w-addr">Destination address</label><div className="tw-in"><input id="w-addr" placeholder={`Paste the ${net?.label ?? ''} address`} value={address} onChange={e => setAddress(e.target.value)} autoComplete="off" spellCheck={false}/></div></div>
          <div className="tw-field"><label htmlFor="w-amt">Amount</label>
            <div className="tw-in"><input id="w-amt" inputMode="decimal" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ''))}/><span>{ticker}</span><button type="button" className="tw-max" onClick={() => setAmount(String(Math.floor(balance * 1e8) / 1e8))}>Max</button></div>
            <div className="tw-hint"><span>Available</span><b>{fmt(balance, 8)} {ticker}</b></div></div>
          <div className="tw-sum"><div><span>You will send</span><b>{fmt(amt, 8)} {ticker}</b></div><div><span>Network fee</span><b>{fmt(fee, 8)} {ticker}</b></div><div className="total"><span>Recipient gets</span><b>{fmt(receive, 8)} {ticker}</b></div></div>
          {error && <div className="tw-err" role="alert">{error}</div>}{ok && <div className="tw-ok" role="status">{ok}</div>}
          <p className="tw-warn">Double-check the address and network. Withdrawals are reviewed manually and cannot be recovered once sent to a wrong address.</p>
          <button type="button" className="tw-cta" disabled={!!problem || busy || data?.enabled === false} onClick={() => setConfirm(true)}>{busy ? <Loader2 className="dp-spin"/> : problem || 'Submit withdrawal'}</button>
        </div>
        <aside className="dp-faq"><h2>Quick guide</h2>{FAQ.map(q => <a key={q} href="/faq">{q}</a>)}
          <div className="tw-tips">
            <div><ShieldCheck/><span><b>Manual compliance review</b><small>Every withdrawal is checked before it is sent.</small></span></div>
            <div><Undo2/><span><b>Cancellable while pending</b><small>Cancel any time before review and the funds return at once.</small></span></div>
            <div><Zap/><span><b>Cheapest network</b><small>BEP20 has the lowest fee for USDT and USDC.</small></span></div>
          </div></aside>
      </div>
      <section className="dp-table"><header><div className="dp-tab">Withdrawal history</div></header>
        <div className="dp-scroll"><table><thead><tr><th>Time</th><th>Asset</th><th>Address</th><th>Amount</th><th>Net</th><th>Status</th><th/></tr></thead><tbody>
          {!data || data.rows.length === 0 ? <tr><td colSpan={7}><div className="dp-empty"><b>No withdrawals yet</b><small>Your withdrawal history will be shown here.</small></div></td></tr> : data.rows.map(w => <tr key={w.id}>
            <td>{w.at ? new Date(w.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}</td>
            <td>{w.asset}<small> {w.network}</small></td>
            <td><span className="tw-addr"><code>{w.address.slice(0, 6)}…{w.address.slice(-5)}</code><button type="button" aria-label="Copy address" onClick={() => copy(w.address, w.id)}>{copied === w.id ? <Check/> : <Copy/>}</button></span></td>
            <td>{w.amount}</td><td>{w.net}</td>
            <td><span className={`tw-pill ${w.status}`} title={w.reason ?? w.txHash ?? ''}>{STATUS[w.status] ?? w.status}</span></td>
            <td>{w.status === 'pending' && <button type="button" className="tw-ghost" onClick={() => cancel(w.id)}>Cancel</button>}</td></tr>)}
        </tbody></table></div></section>
    </main>
    {confirm && net && <div className="tw-dlg" role="dialog" aria-modal="true" onClick={() => setConfirm(false)}><div onClick={e => e.stopPropagation()}>
      <h3>Confirm withdrawal</h3>
      <div className="tw-sum"><div><span>Asset</span><b>{ticker} · {net.code}</b></div><div><span>Amount</span><b>{fmt(amt, 8)}</b></div><div><span>Fee</span><b>{fmt(fee, 8)}</b></div><div className="total"><span>Recipient gets</span><b>{fmt(receive, 8)} {ticker}</b></div><div><span>To</span><b className="tw-wrap" style={{ textAlign: 'right' }}>{addr}</b></div></div>
      <div className="row"><button type="button" className="tw-ghost" style={{ padding: 12 }} onClick={() => setConfirm(false)}>Back</button><button type="button" className="tw-cta" onClick={submit}>Confirm</button></div>
    </div></div>}
    <MobileNav active="assets"/>
    </div></>;
}
