import { useEffect, useState } from 'react';
import { Link, usePage } from '@inertiajs/react';
import { ChevronRight, Info } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { useSpotPrices, useWallet } from '../lib/hooks';
import { api, usd, usdValue } from '../lib/wallet';

type Summary = { volume30d: string; fees30d: string; trades30d: number; feeRate: number };

/** Fee schedule. RushX has a single flat spot fee (from server config) — no invented VIP tiers. */
export default function Fees({ feeRate, futuresFeeRate, maxLeverage }: { feeRate: number; futuresFeeRate: number; maxLeverage: number }) {
  const signedIn = !!(usePage().props as { auth?: { user?: unknown } }).auth?.user;
  const pct = (feeRate * 100).toFixed(4) + '%';
  const { wallet } = useWallet('funding', signedIn);
  const prices = useSpotPrices();
  const [summary, setSummary] = useState<Summary | null>(null);
  useEffect(() => { if (!signedIn) return; void api<Summary>('/api/account/summary').then(r => { if (r.ok) setSummary(r.data); }); }, [signedIn]);
  const holdings = (wallet?.balances ?? []).reduce((sum, b) => sum + usdValue(b.asset, b.units / 1e8, prices), 0);

  return <AccountLayout active="Fees" title="Fees" showNav={signedIn}>
    <main className="ap-wrap">
      <div className="ap-feehead"><div><small>{signedIn ? 'My fee tier' : 'Trading fees'}</small><h1>Standard</h1></div><Link href="/spot" className="ap-link">Start trading</Link></div>
      <div className="ap-feegrid">
        <section className="ap-fee"><h3>Spot <Info/></h3><div><div><small>Trading fee</small><b>{pct}</b></div><div><small>Charged on</small><b className="sm">USDT side of each fill</b></div></div></section>
        <section className="ap-fee"><h3>Deposits</h3><div><div><small>RushX deposit fee</small><b>0.0000%</b></div><div><small>Network fee</small><b className="sm">Paid on the sending side</b></div></div></section>
        <section className="ap-fee"><h3>Withdrawals</h3><div><div><small>Status</small><b className="sm">Not available yet</b></div></div></section>
        <section className="ap-fee"><h3>Futures</h3><div><div><small>Fee (open and close)</small><b>{(futuresFeeRate * 100).toFixed(4)}%</b></div><div><small>Charged on</small><b className="sm">Position size · up to {maxLeverage}x</b></div></div></section>
      </div>

      {signedIn && <section className="ap-vip"><h2>Your activity</h2><p>Your fees are the same on every trade. These figures show what you have traded and paid over the last 30 days.</p>
        <div className="ap-grid-3">
          <div className="ap-mini"><small>Current total holdings</small><b>{wallet ? `${usd(holdings, 0)} USD` : '—'}</b></div>
          <div className="ap-mini"><small>30-day spot trading volume</small><b>{summary ? `${usd(Number(summary.volume30d), 0)} USD` : '—'}</b></div>
          <div className="ap-mini"><small>Fees paid (30 days)</small><b>{summary ? `${usd(Number(summary.fees30d), 4)} USDT` : '—'}</b></div>
        </div></section>}

      <h2 className="ap-h2">Fee table</h2>
      <div className="ap-tablewrap"><table className="ap-orders ap-fees"><thead><tr><th>Market</th><th>Order type</th><th>Fee</th><th>Charged in</th></tr></thead>
        <tbody><tr><td className="p">Spot — all pairs</td><td>Market order</td><td>{pct}</td><td>USDT</td></tr>
          <tr><td className="p">Futures — all contracts</td><td>Market order</td><td>{(futuresFeeRate * 100).toFixed(4)}%</td><td>USDT (Trading account)</td></tr>
          <tr><td className="p">Deposit</td><td>—</td><td>0.0000%</td><td>—</td></tr></tbody></table></div>
      <div className="ap-about"><h3>About fees</h3><p>The spot fee is taken from the USDT side of every fill: when you buy, it is deducted from the amount you spend; when you sell, it is deducted from the proceeds. Fees are shown in your order history and on every order confirmation.</p>
        {!signedIn && <p><Link href="/login" className="ap-link">Sign in <ChevronRight/></Link> to see your own trading activity.</p>}</div>
    </main>
  </AccountLayout>;
}
