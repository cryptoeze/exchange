import { useEffect, useState } from 'react';
import { Head } from '@inertiajs/react';
import { ArrowLeft, ArrowRight, CircleHelp, ShieldCheck } from 'lucide-react';
import RushXHeader, { type HeaderUser } from '../components/RushXHeader';
import MarketTable from '../components/landing/MarketTable';

type Props = { page: string; title: string; description: string; search?: string; pair?: string; auth?: { user: HeaderUser | null } };
export default function PlatformPage({ page, title, description, search = '', auth }: Props) {
  const [dark, setDark] = useState(() => { try { return typeof localStorage === 'undefined' || localStorage.getItem('rushx-theme') !== 'light'; } catch { return true; } });
  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; try { localStorage.setItem('rushx-theme', dark ? 'dark' : 'light'); } catch { /* Preference is optional. */ } }, [dark]);
  return <>
    <Head title={`${title} — RushX`}><meta name="theme-color" content={dark ? '#050505' : '#f6f7f4'}/></Head>
    <div className="rx-dashboard"><RushXHeader user={auth?.user} dark={dark} onToggleTheme={() => setDark(value => !value)}/>
      {page === 'markets' ? <><div className="rx-feature-intro"><a href="/" className="rx-back-link"><ArrowLeft/> Home</a><span className="rx-overline">PUBLIC MARKET DATA</span><h1>Markets</h1><p>{search ? `Showing live spot pairs matching “${search}”.` : description}</p></div><MarketTable onTrade={() => { window.location.href = auth?.user ? '/spot' : '/login'; }} onAllMarkets={() => window.location.assign('/markets')} initialQuery={search}/></> :
        <main className="rx-feature-main"><a href="/" className="rx-back-link"><ArrowLeft/> Back to RushX</a><section className="rx-feature-card"><span className="rx-feature-icon"><CircleHelp/></span><span className="rx-overline">RUSHX PLATFORM</span><h1>{title}</h1><p>{description}</p><div className="rx-feature-status"><ShieldCheck/> This page does not change account balances or place orders.</div><a className="rx-feature-home" href="/">Return to homepage <ArrowRight/></a></section></main>}
    </div>
  </>;
}
