import { useEffect, useMemo, useRef, useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import { Bot, MessageCircle, ChevronDown, ChevronRight, Coins, Copy, Eye, EyeOff, Gift, LineChart, LogOut, Moon, Search, Shield, Sun, TrendingUp, Wallet, X } from 'lucide-react';
import CoinImage from '../components/CoinImage';
import MobileNav from '../components/MobileNav';
import { COIN_NAMES, useSpotPrices, useTheme, useWallet } from '../lib/hooks';
import { change24hUsd, usd, usdValue } from '../lib/wallet';
import type { HeaderUser } from '../components/RushXHeader';
import '../../css/overview.css';
import '../../css/mobile-home.css';

type Tab = 'Top 10' | 'Gainers' | 'Losers' | 'New';
const initials = (n: string) => n.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase() || 'U';
const vol = (v: number) => v >= 1e9 ? `$${(v / 1e9).toFixed(2)}B` : v >= 1e6 ? `$${(v / 1e6).toFixed(2)}M` : v >= 1e3 ? `$${(v / 1e3).toFixed(2)}K` : `$${v.toFixed(2)}`;
const price = (p: number) => p >= 1000 ? p.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : p >= 1 ? p.toFixed(4) : p >= 0.001 ? p.toFixed(6) : p.toFixed(8);

const BANNERS = [
  { title: 'Daily Rewards', text: 'Check in every day — the reward grows each day.', cta: 'Claim', href: '/rewards', Icon: Gift },
  { title: 'Trading Bots', text: 'Put capital to work and earn a daily yield.', cta: 'Start', href: '/bots', Icon: Bot },
  { title: 'Copy Trading', text: 'Follow vetted traders and earn every cycle.', cta: 'Copy', href: '/copy', Icon: Copy },
  { title: 'Earn', text: 'Stake USDT and earn interest every second.', cta: 'Earn', href: '/earn', Icon: Coins },
  { title: 'Futures', text: 'Trade perpetual contracts with leverage.', cta: 'Trade', href: '/futures', Icon: TrendingUp },
];

function Row({ m, prev }: { m: { symbol: string; baseAsset: string; lastPrice: number; change24h: number; turnover24h: number }; prev: number | undefined }) {
  const flash = prev !== undefined && prev !== m.lastPrice ? (m.lastPrice > prev ? 'f-up' : 'f-down') : '';
  return <a className="mh-row" href={`/spot?pair=${m.symbol}`}>
    <span className="mh-coin"><span className="mh-ico"><CoinImage symbol={m.baseAsset}/></span><span><b>{m.baseAsset}</b><small>{COIN_NAMES[m.baseAsset] ?? m.baseAsset} · Vol {vol(m.turnover24h)}</small></span></span>
    <span className="mh-px"><b key={m.lastPrice} className={flash}>${price(m.lastPrice)}</b><small className={m.change24h >= 0 ? 'up' : 'down'}>{m.change24h >= 0 ? '+' : ''}{m.change24h.toFixed(2)}%</small></span>
  </a>;
}

/** Phone home: balance, quick actions, promo cards and a live market list. On desktop it forwards to the assets overview. */
export default function Home({ pkrRate = 278 }: { pkrRate?: number }) {
  const user = ((usePage().props as Record<string, unknown>).auth as { user?: HeaderUser | null } | undefined)?.user ?? null;
  const [dark, toggleTheme] = useTheme();
  const prices = useSpotPrices();
  const { wallet } = useWallet('funding');
  const [hidden, setHidden] = useState(() => { try { return localStorage.getItem('rushx-hide-total') === '1'; } catch { return false; } });
  const [tab, setTab] = useState<Tab>('Top 10');
  const [menu, setMenu] = useState(false);
  const [cur, setCur] = useState<'USD' | 'PKR'>(() => { try { return localStorage.getItem('rushx-home-cur') === 'PKR' ? 'PKR' : 'USD'; } catch { return 'USD'; } });
  const [curOpen, setCurOpen] = useState(false);
  const [q, setQ] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const prevPrices = useRef<Map<string, number>>(new Map());
  const carousel = useRef<HTMLDivElement>(null);

  useEffect(() => { if (window.matchMedia('(min-width: 821px)').matches) router.visit('/assets', { replace: true }); }, []);
  useEffect(() => { const f = () => setScrolled(window.scrollY > 10); window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f); }, []);
  useEffect(() => { // gentle auto-advance of the promo cards
    const el = carousel.current; if (!el) return; let i = 0;
    const t = window.setInterval(() => { const cards = el.children; if (!cards.length || document.hidden) return; i = (i + 1) % cards.length; el.scrollTo({ left: (cards[i] as HTMLElement).offsetLeft - 20, behavior: 'smooth' }); }, 4500);
    const stop = () => window.clearInterval(t); el.addEventListener('touchstart', stop, { passive: true }); return stop;
  }, []);

  const totals = useMemo(() => {
    let total = 0; let pnl = 0;
    for (const b of wallet?.balances ?? []) { const amt = b.units / 1e8; total += usdValue(b.asset, amt, prices); pnl += change24hUsd(b.asset, amt, prices); }
    const base = total - pnl; return { total, pnl, pct: base > 0 ? (pnl / base) * 100 : 0 };
  }, [wallet, prices]);

  const list = useMemo(() => {
    const all = [...prices.values()].filter(m => m.quoteAsset === 'USDT' && m.isTradable && m.lastPrice > 0 && !/\d[LS]$/.test(m.baseAsset));
    const top = [...all].sort((a, b) => b.turnover24h - a.turnover24h);
    if (tab === 'Top 10') { const pin = ['BTC', 'ETH', 'BNB', 'SOL'].map(s => top.find(m => m.baseAsset === s)).filter(Boolean) as typeof top; return [...pin, ...top.filter(m => !pin.includes(m)).slice(0, 10 - pin.length)]; }
    if (tab === 'Gainers') return [...top.slice(0, 150)].sort((a, b) => b.change24h - a.change24h).slice(0, 10);
    if (tab === 'Losers') return [...top.slice(0, 150)].sort((a, b) => a.change24h - b.change24h).slice(0, 10);
    return all.filter(m => m.isNew).sort((a, b) => b.turnover24h - a.turnover24h).slice(0, 10);
  }, [prices, tab]);
  const found = useMemo(() => {
    const t = q.trim().toLowerCase(); if (!t) return [];
    return [...prices.values()].filter(m => m.quoteAsset === 'USDT' && m.isTradable && m.lastPrice > 0 && (m.baseAsset.toLowerCase().includes(t) || (COIN_NAMES[m.baseAsset] ?? '').toLowerCase().includes(t)))
      .sort((a, b) => (a.baseAsset.toLowerCase() === t ? -1 : 0) - (b.baseAsset.toLowerCase() === t ? -1 : 0) || b.turnover24h - a.turnover24h).slice(0, 12);
  }, [prices, q]);
  const seen = prevPrices.current; const snapshot = new Map(seen);
  useEffect(() => { list.forEach(m => seen.set(m.symbol, m.lastPrice)); });

  const toggleHide = () => setHidden(h => { const n = !h; try { localStorage.setItem('rushx-hide-total', n ? '1' : '0'); } catch { /* optional */ } return n; });
  const rate = cur === 'PKR' ? pkrRate : 1; const sym = cur === 'PKR' ? 'Rs' : '';
  const pickCur = (c: 'USD' | 'PKR') => { setCur(c); setCurOpen(false); try { localStorage.setItem('rushx-home-cur', c); } catch { /* optional */ } };
  const up = totals.pnl >= 0; const mask = (s: string) => hidden ? '••••••' : s;

  const shown = hidden ? '••••••' : `${sym}${usd(totals.total * rate)}`;
  return <><Head title="Home — RushX"/>
    <div className="ov-shell mh-shell rx-dashboard">
      <header className={`mh-head${scrolled ? ' scrolled' : ''}`}>
        <button type="button" className="mh-avatar" aria-label="Account" onClick={() => setMenu(true)}>{initials(user?.name ?? 'User')}</button>
        <a className="mh-logo" href="/dashboard" aria-label="RushX home"><svg viewBox="0 0 100 100" fill="none" aria-hidden="true"><rect width="100" height="100" rx="24" fill="#c1f033" fillOpacity=".12"/><path d="M25 25 L45 25 L75 60 L75 75 L55 75 L25 40 Z" fill="currentColor"/><path d="M25 75 L25 60 L55 25 L75 25 L75 40 L45 75 Z" fill="#c1f033"/></svg><b>Rush<i>X</i></b></a>
        <span className="mh-hicons"><button type="button" aria-label="Live chat" onClick={() => (window as unknown as { rushxChat?: () => void }).rushxChat?.()}><MessageCircle/></button><button type="button" aria-label="Toggle theme" onClick={toggleTheme}>{dark ? <Sun/> : <Moon/>}</button></span>
      </header>

      <main className="mh-main">
        <section className="mh-overview">
          <div className={`mh-glow ${up ? '' : 'neg'}`} aria-hidden="true"/>
          <label className="mh-search"><Search/><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search coins — BTC, ETH, SOL…" inputMode="search" autoComplete="off" enterKeyHint="search"/>{q && <button type="button" aria-label="Clear" onClick={() => setQ('')}><X/></button>}</label>
          <div className="mh-label">Est. total value <button type="button" aria-label={hidden ? 'Show balance' : 'Hide balance'} onClick={toggleHide}>{hidden ? <EyeOff/> : <Eye/>}</button><em className="mh-cur"><button type="button" onClick={() => setCurOpen(v => !v)} aria-expanded={curOpen}>{cur} <ChevronDown/></button>
              {curOpen && <i className="mh-curmenu">{(['USD', 'PKR'] as const).map(c => <button type="button" key={c} className={c === cur ? 'on' : ''} onClick={() => pickCur(c)}>{c}</button>)}</i>}</em></div>
          <div className="mh-balance"><span><b style={{ fontSize: `min(${shown.length > 12 ? 26 : shown.length > 10 ? 32 : 38}px, 9.5vw)` }}>{shown}</b>
            </span>
            <a className="mh-add" href="/deposit">Add Funds</a></div>
          <div className="mh-sub">≈ {mask(cur === 'USD' ? `Rs ${usd(totals.total * pkrRate)}` : `$${usd(totals.total)}`)}{cur === 'USD' && <small> · 1 USD ≈ Rs {pkrRate}</small>}</div>
          <a className="mh-pnl" href="/analysis"><span>Today’s PnL</span><b className={up ? 'up' : 'down'}>{mask(`${up ? '+' : '-'}${sym}${usd(Math.abs(totals.pnl) * rate)} (${up ? '+' : '-'}${Math.abs(totals.pct).toFixed(2)}%)`)}</b><ChevronRight/></a>
        </section>

        {q.trim() && <section className="mh-market"><div className="mh-tabs"><button type="button" className="on">Results</button></div>
          {found.length === 0 ? <p className="mh-empty">No coin matches “{q}”.</p> : found.map(m => <Row key={m.symbol} m={m} prev={undefined}/>)}</section>}

        <section className="mh-banners" ref={carousel} hidden={!!q.trim()}>{BANNERS.map(({ title, text, cta, href, Icon }) => <a key={title} className="mh-banner" href={href}><span><h4>{title}</h4><p>{text}</p><em>{cta}</em></span><i><Icon/></i></a>)}</section>

        <section className="mh-market" hidden={!!q.trim()}>
          <div className="mh-tabs" role="tablist">{(['Top 10', 'Gainers', 'New', 'Losers'] as Tab[]).map(t => <button type="button" role="tab" aria-selected={tab === t} key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>)}</div>
          {list.length === 0 ? <p className="mh-empty">{prices.size === 0 ? 'Loading markets…' : 'Nothing to show here right now.'}</p> : list.map(m => <Row key={m.symbol} m={m} prev={snapshot.get(m.symbol)}/>)}
        </section>
      </main>

      {menu && <div className="mh-sheet-bd" onClick={() => setMenu(false)}><div className="mh-sheet" role="dialog" aria-label="Account" onClick={e => e.stopPropagation()}>
        <header><span className="mh-avatar lg">{initials(user?.name ?? 'User')}</span><span><b>{user?.name}</b><small>{user?.email}</small></span><button type="button" aria-label="Close" onClick={() => setMenu(false)}><X/></button></header>
        <a href="/assets"><Wallet/> My Assets</a><a href="/orders"><LineChart/> Order center</a><a href="/fees"><Coins/> My trading fees</a><a href="/security"><Shield/> Security &amp; Settings</a>
        <button type="button" className="out" onClick={() => router.post('/logout')}><LogOut/> Log out</button>
      </div></div>}
      <MobileNav active="home"/>
    </div></>;
}
