import { Link, router, useForm, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Addr = { id: number; asset: string; network: string; label: string; address: string; min: string; note: string | null; enabled: boolean };
type Row = { id: number; user: string; asset: string; network: string; claimed: string; credited: string | null; txid: string; status: string; reason: string | null; at: string };
const field = { style: { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '9px 10px', font: 'inherit', width: '100%' } } as const;

function AddrForm({ a }: { a: Addr }) {
  const f = useForm({ id: a.id, asset: a.asset, network: a.network, label: a.label, address: a.address, min: a.min, note: a.note ?? '', enabled: a.enabled });
  return <form onSubmit={e => { e.preventDefault(); f.post('/admin/deposits/address', { preserveScroll: true }); }} style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', alignItems: 'end', padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)' }}>
    <label>Label<input {...field} value={f.data.label} onChange={e => f.setData('label', e.target.value)} required/></label>
    <label>Network<input {...field} value={f.data.network} disabled/></label>
    <label style={{ gridColumn: 'span 2' }}>Receiving address ({a.network})<input {...field} value={f.data.address} onChange={e => f.setData('address', e.target.value)} spellCheck={false}/></label>
    <label>Minimum (USDT)<input {...field} inputMode="decimal" value={f.data.min} onChange={e => f.setData('min', e.target.value)} required/></label>
    <label>Note shown to users<input {...field} value={f.data.note} onChange={e => f.setData('note', e.target.value)}/></label>
    <label style={{ display: 'flex', gap: 8, alignItems: 'center', paddingBottom: 10 }}><input type="checkbox" checked={f.data.enabled} onChange={e => f.setData('enabled', e.target.checked)}/> Show to users</label>
    <button type="submit" disabled={f.processing} style={{ padding: '10px 16px', borderRadius: 8, border: 0, fontWeight: 700, background: '#c1f033', color: '#000', cursor: 'pointer' }}>Save</button>
    {Object.values(f.errors).map(m => <small key={m} role="alert" style={{ color: '#f6465d', gridColumn: '1 / -1' }}>{m}</small>)}
  </form>;
}

function Line({ d }: { d: Row }) {
  const [amt, setAmt] = useState(d.claimed); const [why, setWhy] = useState('');
  const act = (decision: 'approve' | 'reject') => { if (decision === 'approve' && !window.confirm(`Credit ${amt} ${d.asset} to ${d.user}? Confirm the TXID arrived in your wallet.`)) return; router.post(`/admin/deposits/${d.id}`, { decision, amount: amt, reason: why }, { preserveScroll: true }); };
  return <div style={{ padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)', display: 'grid', gap: 8 }}>
    <div><b>#{d.id}</b> · {d.user} · {d.at} · {d.network} · claims <b>{d.claimed} {d.asset}</b> · <b>{d.status}</b>{d.credited && ` (credited ${d.credited})`}</div>
    <div style={{ overflowWrap: 'anywhere', fontFamily: 'monospace' }}>{d.txid}</div>
    {d.status === 'pending' ? <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      <input {...field} style={{ ...field.style, width: 130 }} value={amt} onChange={e => setAmt(e.target.value)} aria-label="Amount received"/>
      <button type="button" onClick={() => act('approve')} style={{ padding: '8px 14px', borderRadius: 8, border: 0, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer' }}>Credit</button>
      <input {...field} style={{ ...field.style, flex: '1 1 160px', width: 'auto' }} placeholder="Reject reason" value={why} onChange={e => setWhy(e.target.value)}/>
      <button type="button" onClick={() => act('reject')} style={{ padding: '8px 14px', borderRadius: 8, border: '1px solid rgba(128,128,128,.35)', background: 'none', color: '#f6465d', cursor: 'pointer' }}>Reject</button></div> : d.reason && <small style={{ opacity: .75 }}>{d.reason}</small>}
  </div>;
}

export default function ManualDeposits({ admin, addresses, rows, status, pendingCount }: { admin: AdminUser; addresses: Addr[]; rows: Row[]; status: string; pendingCount: number }) {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  return <AdminLayout admin={admin} active="/admin/deposits"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Manual deposits</h1><p>{pendingCount} waiting for review. Check the TXID in your wallet, then credit.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Receiving addresses</h2></header><div style={{ padding: '0 22px 18px' }}>
      <p style={{ opacity: .75, fontSize: 13 }}>Users see the address and QR code of each method that is switched on. Double-check every character — funds sent to a wrong address are lost. Changes are audit-logged.</p>
      {addresses.map(a => <AddrForm key={a.id} a={a}/>)}</div></section>
    <section className="admin-panel"><header><h2>Requests</h2></header><div style={{ padding: '0 22px 18px' }}>
      <div style={{ display: 'flex', gap: 8, padding: '8px 0' }}>{['pending', 'approved', 'rejected'].map(s => <Link key={s} href={`/admin/deposits?status=${s}`} style={{ ...field.style, width: 'auto', textDecoration: 'none', fontWeight: s === status ? 700 : 400 }}>{s}</Link>)}</div>
      {rows.length === 0 ? <p style={{ opacity: .7 }}>Nothing here.</p> : rows.map(d => <Line key={d.id} d={d}/>)}</div></section>
  </div></AdminLayout>;
}
