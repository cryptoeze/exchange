import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link, router } from '@inertiajs/react';
import {
  ArrowDownToLine, ArrowUpFromLine, Bot, CandlestickChart, ClipboardList,
  FileCheck2, Handshake, LayoutDashboard, LogOut, Menu, Megaphone, Moon,
  PiggyBank, Settings2, Sun, Wallet, Users, X,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type AdminUser = { name: string; email: string };
const groups: Array<{ title: string; items: Array<{ label: string; href: string; icon: LucideIcon }> }> = [
  { title: 'Overview', items: [{ label: 'Dashboard', href: '/admin', icon: LayoutDashboard }] },
  { title: 'Compliance', items: [{ label: 'Users', href: '/admin/users', icon: Users }, { label: 'KYC review', href: '/admin/kyc', icon: FileCheck2 }] },
  { title: 'Treasury', items: [{ label: 'Deposits', href: '/admin/deposits', icon: ArrowDownToLine }, { label: 'Withdrawals', href: '/admin/withdrawals', icon: ArrowUpFromLine }, { label: 'Wallet log', href: '/admin/transactions', icon: Wallet }] },
  { title: 'Trading', items: [{ label: 'Trades', href: '/admin/trades', icon: CandlestickChart }, { label: 'Futures', href: '/admin/futures', icon: CandlestickChart }, { label: 'Earn', href: '/admin/earn', icon: PiggyBank }, { label: 'Bots', href: '/admin/bots', icon: Bot }, { label: 'Copy traders', href: '/admin/traders', icon: Bot }, { label: 'P2P Desk', href: '/admin/p2pdesk', icon: Handshake }] },
  { title: 'System', items: [{ label: 'Notifications', href: '/admin/notifications', icon: Megaphone }, { label: 'Audit log', href: '/admin/audit', icon: ClipboardList }, { label: 'Settings', href: '/admin/settings', icon: Settings2 }] },
];

export function AdminLayout({ admin, active, children, userCount }: { admin: AdminUser; active: string; children: ReactNode; userCount?: number | null }) {
  const [drawer, setDrawer] = useState(false);
  const [light, setLight] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);
  const drawerPanel = useRef<HTMLElement>(null);
  useEffect(() => {
    let value = 'dark';
    try { value = localStorage.getItem('rushx-theme') || 'dark'; } catch { /* Theme storage is optional. */ }
    setLight(value === 'light');
    document.documentElement.dataset.theme = value;
  }, []);
  useEffect(() => {
    if (!drawer) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setDrawer(false); return; }
      if (event.key !== 'Tab' || !drawerPanel.current) return;
      const controls = drawerPanel.current.querySelectorAll<HTMLElement>('a[href],button:not([disabled])');
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', close);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => drawerPanel.current?.querySelector<HTMLElement>('.admin-drawer-head button')?.focus());
    return () => { document.removeEventListener('keydown', close); document.body.style.overflow = ''; menuButton.current?.focus(); };
  }, [drawer]);
  const toggleTheme = () => {
    const next = light ? 'dark' : 'light';
    setLight(next === 'light');
    try { localStorage.setItem('rushx-theme', next); } catch { /* Theme storage is optional. */ }
    document.documentElement.dataset.theme = next;
  };
  const logout = () => router.post('/admin/logout');
  const nav = <nav className="admin-nav" aria-label="Admin navigation">
    {groups.map(group => <section className="admin-nav-group" key={group.title}>
      <p>{group.title}</p>
      {group.items.map(({ label, href, icon: Icon }) => {
        const selected = active === href;
        return <Link key={href} href={href} className={`admin-nav-link${selected ? ' active' : ''}`} aria-current={selected ? 'page' : undefined} onClick={() => setDrawer(false)}>
          <Icon aria-hidden="true"/><span>{label}</span>
        </Link>;
      })}
    </section>)}
  </nav>;
  const initials = admin.name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase() || 'AD';

  return <main className="admin-shell">
    <aside className="admin-sidebar">
      <Link className="admin-brand" href="/admin"><span className="admin-brand-mark">R</span><span><b>Rushpay</b><small>ADMIN CONSOLE</small></span></Link>
      {nav}
      <div className="admin-side-bottom"><span className="admin-avatar">{initials}</span><span className="admin-profile"><b>{admin.name}</b><small>Administrator</small></span><button onClick={logout} aria-label="Log out"><LogOut/></button></div>
    </aside>
    <section className="admin-main">
      <header className="admin-topbar">
        <div className="admin-topbar-title"><button ref={menuButton} className="admin-menu-button" onClick={() => setDrawer(true)} aria-label="Open admin navigation" aria-expanded={drawer} aria-controls="admin-mobile-drawer"><Menu/></button><span className="admin-prompt-mark" aria-hidden="true">›_</span><b>Dashboard</b></div>
        <div className="admin-topbar-actions"><span className="admin-live"><i/> {userCount == null ? 'Admin access' : `Users · ${userCount.toLocaleString()}`}</span><button className="admin-theme-button" onClick={toggleTheme} aria-label={`Switch to ${light ? 'dark' : 'light'} theme`}>{light ? <Moon/> : <Sun/>}</button><button className="admin-logout" onClick={logout}>Logout</button></div>
      </header>
      {children}
    </section>
    {drawer && <div className="admin-drawer-layer">
      <button className="admin-drawer-scrim" onClick={() => setDrawer(false)} aria-label="Close navigation"/>
      <aside ref={drawerPanel} id="admin-mobile-drawer" className="admin-drawer" role="dialog" aria-modal="true" aria-label="Admin navigation"><div className="admin-drawer-head"><Link className="admin-brand" href="/admin"><span className="admin-brand-mark">R</span><span><b>Rushpay</b><small>ADMIN CONSOLE</small></span></Link><button onClick={() => setDrawer(false)} aria-label="Close navigation"><X/></button></div>{nav}<button className="admin-drawer-logout" onClick={logout}><LogOut/> Log out</button></aside>
    </div>}
  </main>;
}
