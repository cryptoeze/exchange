import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link, router, usePage } from '@inertiajs/react';
import { Bell, LogOut, Menu, Moon, Search, Sun, X } from 'lucide-react';
import { ADMIN_NAV, canSee, groupOf } from '../../admin/nav';
import '../../../css/admin-ui.css';

export type AdminUser = { name: string; email: string };
type BellItem = { id: number; title: string; body: string | null; url: string | null; read: boolean; at: string };
function AdminBell() {
  const [data, setData] = useState<{ unread: number; items: BellItem[]; queues: { withdrawals: number; deposits: number; kyc: number } } | null>(null);
  const [open, setOpen] = useState(false); const [ring, setRing] = useState(false); const prev = useRef(0);
  const load = async () => { try { const r = await fetch('/admin/api/bell', { headers: { Accept: 'application/json' }, credentials: 'same-origin' }); if (!r.ok) return; const d = await r.json(); if (d.unread > prev.current) { setRing(true); window.setTimeout(() => setRing(false), 3000); } prev.current = d.unread; setData(d); } catch { /* retry */ } };
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 15000); return () => window.clearInterval(t); }, []);
  const readAll = async () => { await fetch('/admin/api/bell/read', { method: 'POST', credentials: 'same-origin', headers: { 'X-XSRF-TOKEN': decodeURIComponent(document.cookie.match(/XSRF-TOKEN=([^;]+)/)?.[1] ?? ''), Accept: 'application/json' } }); void load(); };
  const unread = data?.unread ?? 0; const q = data?.queues;
  return <div className="abell">
    <button type="button" className={`abell-btn${unread > 0 ? ' has' : ''}${ring ? ' ring' : ''}`} aria-label={`Notifications${unread ? ` (${unread} new)` : ''}`} onClick={() => setOpen(v => !v)}><Bell size={17}/>{unread > 0 && <i>{unread > 9 ? '9+' : unread}</i>}</button>
    {open && <><button type="button" className="abell-scrim" aria-label="Close" onClick={() => setOpen(false)}/><div className="abell-pop" role="dialog" aria-label="Admin notifications">
      <header><b>Notifications</b><button type="button" onClick={readAll} disabled={!unread}>Mark all read</button></header>
      {q && (q.withdrawals + q.deposits + q.kyc > 0) && <div className="abell-q">{q.withdrawals > 0 && <Link href="/admin/withdrawals">{q.withdrawals} withdrawals</Link>}{q.deposits > 0 && <Link href="/admin/deposits">{q.deposits} deposits</Link>}{q.kyc > 0 && <Link href="/admin/kyc">{q.kyc} KYC</Link>}</div>}
      <div className="abell-list">{!data || data.items.length === 0 ? <p>No events yet.</p> : data.items.map(n => <a key={n.id} href={n.url ?? '#'} className={n.read ? '' : 'new'} onClick={() => { void fetch('/admin/api/bell/read', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-XSRF-TOKEN': decodeURIComponent(document.cookie.match(/XSRF-TOKEN=([^;]+)/)?.[1] ?? '') }, body: JSON.stringify({ id: n.id }) }); }}><b>{n.title}</b>{n.body && <small>{n.body}</small>}<em>{new Date(n.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</em></a>)}</div>
    </div></>}
  </div>;
}

export function AdminLayout({ admin, active, children, userCount }: { admin: AdminUser; active: string; children: ReactNode; userCount?: number | null }) {
  const [drawer, setDrawer] = useState(false);
  const [light, setLight] = useState(false);
  const [liveOn, setLiveOn] = useState(true);
  const liveList = ['/admin/withdrawals', '/admin/deposits', '/admin/kyc', '/admin/tickets', '/admin/p2p', '/admin/users', '/admin/futures', '/admin/audit', '/admin/referrals'].includes(active);
  useEffect(() => {
    if (!liveList || !liveOn) return;
    const id = window.setInterval(() => {
      const el = document.activeElement as HTMLElement | null;
      const typing = !!el && ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName);
      if (!document.hidden && !typing) router.reload();
    }, 20000);
    return () => window.clearInterval(id);
  }, [liveList, liveOn]);
  const menuButton = useRef<HTMLButtonElement>(null);
  const drawerPanel = useRef<HTMLElement>(null);
  useEffect(() => {
    let value = 'dark';
    try { value = localStorage.getItem('rushx-theme') || 'dark'; } catch { /* Theme storage is optional. */ }
    setLight(value === 'light');
    document.documentElement.dataset.theme = value;
  }, []);
  useEffect(() => {
    if (!drawer) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setDrawer(false); return; }
      if (event.key !== 'Tab' || !drawerPanel.current) return;
      const controls = drawerPanel.current.querySelectorAll<HTMLElement>('a[href],button:not([disabled])');
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', close);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => drawerPanel.current?.querySelector<HTMLElement>('.admin-drawer-head button')?.focus());
    return () => { document.removeEventListener('keydown', close); document.body.style.overflow = ''; menuButton.current?.focus(); };
  }, [drawer]);
  const toggleTheme = () => {
    const next = light ? 'dark' : 'light';
    setLight(next === 'light');
    try { localStorage.setItem('rushx-theme', next); } catch { /* Theme storage is optional. */ }
    document.documentElement.dataset.theme = next;
  };
  const logout = () => router.post('/admin/logout');
  const role = (usePage().props as { adminRole?: string | null }).adminRole ?? 'super';
  const badges = (usePage().props as { adminBadges?: Record<string, number> }).adminBadges ?? {};
  const visibleGroups = ADMIN_NAV.map(g => ({ ...g, items: g.items.filter(i => canSee(i, role)) })).filter(g => g.items.length > 0);
  const siblings = (groupOf(active)?.items ?? []).filter(i => canSee(i, role));
  const [find, setFind] = useState('');
  const nav = <nav className="admin-nav" aria-label="Admin navigation">
    {visibleGroups.map(group => <section className="admin-nav-group" key={group.title}>
      <p>{group.title}</p>
      {group.items.map(({ label, href, icon: Icon, badge }) => {
        const selected = active === href;
        const n = badge ? badges[badge] ?? 0 : 0;
        return <Link key={href} href={href} className={`admin-nav-link${selected ? ' active' : ''}`} aria-current={selected ? 'page' : undefined} onClick={() => setDrawer(false)}>
          <Icon aria-hidden="true"/><span>{label}</span>{n > 0 && <i className="au-badge-n">{n > 99 ? '99+' : n}</i>}
        </Link>;
      })}
    </section>)}
  </nav>;
  const initials = admin.name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase() || 'AD';

  return <main className="admin-shell">
    <aside className="admin-sidebar">
      <Link className="admin-brand" href="/admin"><span className="admin-brand-mark">R</span><span><b>RushX</b><small>ADMIN CONSOLE</small></span></Link>
      {nav}
      <div className="admin-side-bottom"><span className="admin-avatar">{initials}</span><span className="admin-profile"><b>{admin.name}</b><small>Administrator</small></span><button onClick={logout} aria-label="Log out"><LogOut/></button></div>
    </aside>
    <section className="admin-main">
      <header className="admin-topbar">
        <div className="admin-topbar-title"><button ref={menuButton} className="admin-menu-button" onClick={() => setDrawer(true)} aria-label="Open admin navigation" aria-expanded={drawer} aria-controls="admin-mobile-drawer"><Menu/></button><span className="admin-prompt-mark" aria-hidden="true">›_</span><b>{ADMIN_NAV.flatMap(g => g.items).find(i => i.href === active)?.label ?? 'Dashboard'}</b></div>
        <form className="au-find" role="search" onSubmit={e => { e.preventDefault(); if (find.trim()) router.get('/admin/users', { q: find.trim() }); }}><Search size={15} aria-hidden="true"/><input value={find} onChange={e => setFind(e.target.value)} placeholder="Find user — email, name, ID or UID" aria-label="Find a user"/></form>
        <div className="admin-topbar-actions"><AdminBell/><span className="admin-live"><i/> {userCount == null ? 'Admin access' : `Users · ${userCount.toLocaleString()}`}</span><button className="admin-theme-button" onClick={toggleTheme} aria-label={`Switch to ${light ? 'dark' : 'light'} theme`}>{light ? <Moon/> : <Sun/>}</button><button className="admin-logout" onClick={logout} aria-label="Log out"><LogOut size={16}/><span>Logout</span></button></div>
      </header>
      {siblings.length > 1 && <nav className="au-section-nav" aria-label="Section pages">{siblings.map(i => <Link key={i.href} href={i.href} className={i.href === active ? 'on' : ''}><i.icon aria-hidden="true"/>{i.label}{i.badge && (badges[i.badge] ?? 0) > 0 && <i>{badges[i.badge]}</i>}</Link>)}{liveList && <button type="button" className="admin-live-btn au-live" onClick={() => setLiveOn(v => !v)} title="Auto-refresh every 20 seconds">{liveOn ? '● Live' : '○ Paused'}</button>}</nav>}
      {children}
    </section>
    {drawer && <div className="admin-drawer-layer">
      <button className="admin-drawer-scrim" onClick={() => setDrawer(false)} aria-label="Close navigation"/>
      <aside ref={drawerPanel} id="admin-mobile-drawer" className="admin-drawer" role="dialog" aria-modal="true" aria-label="Admin navigation"><div className="admin-drawer-head"><Link className="admin-brand" href="/admin"><span className="admin-brand-mark">R</span><span><b>RushX</b><small>ADMIN CONSOLE</small></span></Link><button onClick={() => setDrawer(false)} aria-label="Close navigation"><X/></button></div>{nav}<button className="admin-drawer-logout" onClick={logout}><LogOut/> Log out</button></aside>
    </div>}
  </main>;
}
