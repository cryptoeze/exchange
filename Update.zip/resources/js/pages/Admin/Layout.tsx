import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link, router, usePage } from '@inertiajs/react';
import {
  ArrowDownToLine, ArrowUpFromLine, Bot, CandlestickChart, ClipboardList,
  Bell, FileCheck2, Handshake, LifeBuoy, ShieldCheck, Landmark, Mail, LayoutDashboard, LogOut, Menu, Megaphone, Moon,
  PiggyBank, Settings2, Sun, Wallet, Users, X,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type AdminUser = { name: string; email: string };
const ROLE_PREFIXES: Record<string, string[]> = { finance: ['/admin', '/admin/deposits', '/admin/withdrawals', '/admin/gateways', '/admin/transactions', '/admin/users', '/admin/referrals', '/admin/security', '/admin/futures', '/admin/earn', '/admin/por'], support: ['/admin', '/admin/users', '/admin/kyc', '/admin/notifications', '/admin/tickets', '/admin/p2p', '/admin/referrals', '/admin/security', '/admin/trades'] };
const groups: Array<{ title: string; items: Array<{ label: string; href: string; icon: LucideIcon }> }> = [
  { title: 'Overview', items: [{ label: 'Dashboard', href: '/admin', icon: LayoutDashboard }] },
  { title: 'Compliance', items: [{ label: 'Users', href: '/admin/users', icon: Users }, { label: 'KYC review', href: '/admin/kyc', icon: FileCheck2 }, { label: 'Referrals', href: '/admin/referrals', icon: Handshake }] },
  { title: 'Gateways', items: [{ label: 'Gateways', href: '/admin/gateways', icon: Landmark }] },
  { title: 'Treasury', items: [{ label: 'Deposits', href: '/admin/deposits', icon: ArrowDownToLine }, { label: 'Withdrawals', href: '/admin/withdrawals', icon: ArrowUpFromLine }, { label: 'Wallet log', href: '/admin/transactions', icon: Wallet }, { label: 'Proof of Reserves', href: '/admin/por', icon: FileCheck2 }] },
  { title: 'Trading', items: [{ label: 'Trades', href: '/admin/trades', icon: CandlestickChart }, { label: 'Futures', href: '/admin/futures', icon: CandlestickChart }, { label: 'Earn', href: '/admin/earn', icon: PiggyBank }, { label: 'Bots', href: '/admin/bots', icon: Bot }, { label: 'Copy traders', href: '/admin/traders', icon: Bot }, { label: 'P2P Desk', href: '/admin/p2pdesk', icon: Handshake }] },
  { title: 'System', items: [{ label: 'Admin team', href: '/admin/team', icon: Users }, { label: 'My security', href: '/admin/security', icon: ShieldCheck }, { label: 'P2P desk', href: '/admin/p2p', icon: Handshake }, { label: 'Support tickets', href: '/admin/tickets', icon: LifeBuoy }, { label: 'Notifications', href: '/admin/notifications', icon: Megaphone }, { label: 'Email templates', href: '/admin/emails', icon: Mail }, { label: 'Audit log', href: '/admin/audit', icon: ClipboardList }, { label: 'Settings', href: '/admin/settings', icon: Settings2 }] },
];

type BellItem = { id: number; title: string; body: string | null; url: string | null; read: boolean; at: string };
function AdminBell() {
  const [data, setData] = useState<{ unread: number; items: BellItem[]; queues: { withdrawals: number; deposits: number; kyc: number } } | null>(null);
  const [open, setOpen] = useState(false); const [ring, setRing] = useState(false); const prev = useRef(0);
  const load = async () => { try { const r = await fetch('/admin/api/bell', { headers: { Accept: 'application/json' }, credentials: 'same-origin' }); if (!r.ok) return; const d = await r.json(); if (d.unread > prev.current) { setRing(true); window.setTimeout(() => setRing(false), 3000); } prev.current = d.unread; setData(d); } catch { /* retry */ } };
  useEffect(() => { void load(); const t = window.setInterval(() => { if (!document.hidden) void load(); }, 15000); return () => window.clearInterval(t); }, []);
  const readAll = async () => { await fetch('/admin/api/bell/read', { method: 'POST', credentials: 'same-origin', headers: { 'X-XSRF-TOKEN': decodeURIComponent(document.cookie.match(/XSRF-TOKEN=([^;]+)/)?.[1] ?? ''), Accept: 'application/json' } }); void load(); };
  const unread = data?.unread ?? 0; const q = data?.queues;
  return <div className="abell">
    <button type="button" className={`abell-btn${unread > 0 ? ' has' : ''}${ring ? ' ring' : ''}`} aria-label={`Notifications${unread ? ` (${unread} new)` : ''}`} onClick={() => setOpen(v => !v)}><Bell size={17}/>{unread > 0 && <i>{unread > 9 ? '9+' : unread}</i>}</button>
    {open && <><button type="button" className="abell-scrim" aria-label="Close" onClick={() => setOpen(false)}/><div className="abell-pop" role="dialog" aria-label="Admin notifications">
      <header><b>Notifications</b><button type="button" onClick={readAll} disabled={!unread}>Mark all read</button></header>
      {q && (q.withdrawals + q.deposits + q.kyc > 0) && <div className="abell-q">{q.withdrawals > 0 && <Link href="/admin/withdrawals">{q.withdrawals} withdrawals</Link>}{q.deposits > 0 && <Link href="/admin/deposits">{q.deposits} deposits</Link>}{q.kyc > 0 && <Link href="/admin/kyc">{q.kyc} KYC</Link>}</div>}
      <div className="abell-list">{!data || data.items.length === 0 ? <p>No events yet.</p> : data.items.map(n => <a key={n.id} href={n.url ?? '#'} className={n.read ? '' : 'new'} onClick={() => { void fetch('/admin/api/bell/read', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-XSRF-TOKEN': decodeURIComponent(document.cookie.match(/XSRF-TOKEN=([^;]+)/)?.[1] ?? '') }, body: JSON.stringify({ id: n.id }) }); }}><b>{n.title}</b>{n.body && <small>{n.body}</small>}<em>{new Date(n.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</em></a>)}</div>
    </div></>}
  </div>;
}

export function AdminLayout({ admin, active, children, userCount }: { admin: AdminUser; active: string; children: ReactNode; userCount?: number | null }) {
  const [drawer, setDrawer] = useState(false);
  const [light, setLight] = useState(false);
  const [liveOn, setLiveOn] = useState(true);
  const liveList = ['/admin/withdrawals', '/admin/deposits', '/admin/kyc', '/admin/tickets', '/admin/p2p', '/admin/users', '/admin/futures', '/admin/audit', '/admin/referrals'].includes(active);
  useEffect(() => {
    if (!liveList || !liveOn) return;
    const id = window.setInterval(() => {
      const el = document.activeElement as HTMLElement | null;
      const typing = !!el && ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName);
      if (!document.hidden && !typing) router.reload();
    }, 20000);
    return () => window.clearInterval(id);
  }, [liveList, liveOn]);
  const menuButton = useRef<HTMLButtonElement>(null);
  const drawerPanel = useRef<HTMLElement>(null);
  useEffect(() => {
    let value = 'dark';
    try { value = localStorage.getItem('rushx-theme') || 'dark'; } catch { /* Theme storage is optional. */ }
    setLight(value === 'light');
    document.documentElement.dataset.theme = value;
  }, []);
  useEffect(() => {
    if (!drawer) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setDrawer(false); return; }
      if (event.key !== 'Tab' || !drawerPanel.current) return;
      const controls = drawerPanel.current.querySelectorAll<HTMLElement>('a[href],button:not([disabled])');
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', close);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => drawerPanel.current?.querySelector<HTMLElement>('.admin-drawer-head button')?.focus());
    return () => { document.removeEventListener('keydown', close); document.body.style.overflow = ''; menuButton.current?.focus(); };
  }, [drawer]);
  const toggleTheme = () => {
    const next = light ? 'dark' : 'light';
    setLight(next === 'light');
    try { localStorage.setItem('rushx-theme', next); } catch { /* Theme storage is optional. */ }
    document.documentElement.dataset.theme = next;
  };
  const logout = () => router.post('/admin/logout');
  const role = (usePage().props as { adminRole?: string | null }).adminRole ?? 'super';
  const visibleGroups = groups.map(g => ({ ...g, items: g.items.filter(i => role === 'super' || (ROLE_PREFIXES[role] ?? ['/admin']).includes(i.href)) })).filter(g => g.items.length > 0);
  const nav = <nav className="admin-nav" aria-label="Admin navigation">
    {visibleGroups.map(group => <section className="admin-nav-group" key={group.title}>
      <p>{group.title}</p>
      {group.items.map(({ label, href, icon: Icon }) => {
        const selected = active === href;
        return <Link key={href} href={href} className={`admin-nav-link${selected ? ' active' : ''}`} aria-current={selected ? 'page' : undefined} onClick={() => setDrawer(false)}>
          <Icon aria-hidden="true"/><span>{label}</span>
        </Link>;
      })}
    </section>)}
  </nav>;
  const initials = admin.name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase() || 'AD';

  return <main className="admin-shell">
    <aside className="admin-sidebar">
      <Link className="admin-brand" href="/admin"><span className="admin-brand-mark">R</span><span><b>RushX</b><small>ADMIN CONSOLE</small></span></Link>
      {nav}
      <div className="admin-side-bottom"><span className="admin-avatar">{initials}</span><span className="admin-profile"><b>{admin.name}</b><small>Administrator</small></span><button onClick={logout} aria-label="Log out"><LogOut/></button></div>
    </aside>
    <section className="admin-main">
      <header className="admin-topbar">
        <div className="admin-topbar-title"><button ref={menuButton} className="admin-menu-button" onClick={() => setDrawer(true)} aria-label="Open admin navigation" aria-expanded={drawer} aria-controls="admin-mobile-drawer"><Menu/></button><span className="admin-prompt-mark" aria-hidden="true">›_</span><b>Dashboard</b></div>
        <div className="admin-topbar-actions"><AdminBell/><span className="admin-live"><i/> {userCount == null ? 'Admin access' : `Users · ${userCount.toLocaleString()}`}</span><button className="admin-theme-button" onClick={toggleTheme} aria-label={`Switch to ${light ? 'dark' : 'light'} theme`}>{light ? <Moon/> : <Sun/>}</button><button className="admin-logout" onClick={logout}>Logout</button></div>
      </header>
      {liveList && <button type="button" className="admin-live-btn admin-live-float" onClick={() => setLiveOn(v => !v)} title="Auto-refresh every 20 seconds">{liveOn ? '● Live' : '○ Paused'}</button>}
      {children}
    </section>
    {drawer && <div className="admin-drawer-layer">
      <button className="admin-drawer-scrim" onClick={() => setDrawer(false)} aria-label="Close navigation"/>
      <aside ref={drawerPanel} id="admin-mobile-drawer" className="admin-drawer" role="dialog" aria-modal="true" aria-label="Admin navigation"><div className="admin-drawer-head"><Link className="admin-brand" href="/admin"><span className="admin-brand-mark">R</span><span><b>RushX</b><small>ADMIN CONSOLE</small></span></Link><button onClick={() => setDrawer(false)} aria-label="Close navigation"><X/></button></div>{nav}<button className="admin-drawer-logout" onClick={logout}><LogOut/> Log out</button></aside>
    </div>}
  </main>;
}
