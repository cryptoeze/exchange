import { useMemo } from 'react';
import { useForm, usePage } from '@inertiajs/react';

export type Activity = {
  deposits: Array<{ kind: string; asset: string; network: string; status: string; amount: string; at: string }>;
  withdrawals: Array<{ asset: string; network: string; status: string; amount: string; at: string }>;
  orders: Array<{ symbol: string; side: string; total: string; at: string }>;
  futures: Array<{ symbol: string; side: string; leverage: number; margin: string; status: string; pnl: string | null; at: string }>;
  kycLast: { id: number; status: string; doc_type: string; created_at: string } | null;
};
export type WalletData = {
  balances: Array<{ account: string; asset: string; balance: string }>;
  activity?: Activity;
  ledger: Array<{ id: number; type: string; account: string; asset: string; amount: string; note: string | null; at: string | null }>;
};

export default function AdminWallet({ userId, wallet }: { userId: number; wallet: WalletData }) {
  const flash = (usePage().props as { flash?: { status?: string } }).flash?.status;
  const key = useMemo(() => (globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`), []);
  const form = useForm({ action: 'credit', account: 'funding', asset: 'USDT', amount: '', note: '', idempotency_key: key });
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!window.confirm(`${form.data.action === 'credit' ? 'Credit' : 'Debit'} ${form.data.amount} ${form.data.asset} (${form.data.account}) — this is recorded in the audit log. Continue?`)) return;
    form.post(`/admin/users/${userId}/wallet`, { preserveScroll: true, onSuccess: () => form.setData(d => ({ ...d, amount: '', note: '', idempotency_key: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}` })) });
  };
  const field = { style: { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '9px 10px', font: 'inherit' } } as const;
  return <section className="admin-panel">
    <header><h2>Wallet</h2></header>
    {flash && <p role="status" style={{ color: '#2ebd85' }}>{flash}</p>}
    <div style={{ display: 'grid', gap: 6, margin: '8px 0 18px' }}>
      {wallet.balances.length === 0 ? <span>No balances yet.</span> : wallet.balances.map(b => <div key={`${b.account}-${b.asset}`} style={{ display: 'flex', justifyContent: 'space-between' }}><span>{b.account} · {b.asset}</span><b>{b.balance}</b></div>)}
    </div>
    <form onSubmit={submit} style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(140px,1fr))', alignItems: 'end' }}>
      <label>Action<select {...field} value={form.data.action} onChange={e => form.setData('action', e.target.value)}><option value="credit">Credit</option><option value="debit">Debit</option></select></label>
      <label>Account<select {...field} value={form.data.account} onChange={e => form.setData('account', e.target.value)}><option value="funding">Funding</option><option value="trading">Trading</option><option value="copy">Copy trading</option></select></label>
      <label>Asset<input {...field} value={form.data.asset} onChange={e => form.setData('asset', e.target.value.toUpperCase())} maxLength={16} required/></label>
      <label>Amount<input {...field} inputMode="decimal" value={form.data.amount} onChange={e => form.setData('amount', e.target.value)} placeholder="0.00" required/></label>
      <label style={{ gridColumn: '1 / -1' }}>Reason (required, audited)<input {...field} style={{ ...field.style, width: '100%' }} value={form.data.note} onChange={e => form.setData('note', e.target.value)} maxLength={200} required/></label>
      <button type="submit" disabled={form.processing} style={{ padding: '10px 16px', borderRadius: 8, border: 0, fontWeight: 700, background: '#c1f033', color: '#000', cursor: 'pointer' }}>{form.processing ? 'Applying…' : 'Apply'}</button>
    </form>
    {Object.values(form.errors).map(message => <p key={message} role="alert" style={{ color: '#f6465d' }}>{message}</p>)}
    <h3 style={{ marginTop: 22 }}>Recent ledger</h3>
    <div style={{ display: 'grid', gap: 6, fontSize: 13 }}>
      {wallet.ledger.map(l => <div key={l.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><span>{l.at} · {l.type} · {l.account}{l.note ? ` · ${l.note}` : ''}</span><b style={{ color: l.amount.startsWith('-') ? '#f6465d' : '#2ebd85' }}>{l.amount} {l.asset}</b></div>)}
    </div>
  </section>;
}
