import { Link } from '@inertiajs/react';
import { AdminLayout, type AdminUser } from './Layout';
import { Badge, DataTable, FilterBar, Page, Pager, Panel, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; admin: string; action: string; userId: number | null; target: string | null; details: string | null; ip: string | null; at: string };
const pretty = (d: string | null) => { if (!d) return '—'; try { return Object.entries(JSON.parse(d) as Record<string, unknown>).map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : String(v)}`).join(' · '); } catch { return d; } };

export default function AdminAudit({ admin, rows, pager, filters, actions }: { admin: AdminUser; rows: Row[]; pager: Paged; filters: Record<string, string>; actions: string[] }) {
  const cols: Col<Row>[] = [
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'admin', label: 'Admin', primary: true }, { key: 'action', label: 'Action', render: r => <Badge tone="info">{r.action}</Badge> },
    { key: 'target', label: 'User', render: r => r.userId ? <Link href={`/admin/users/${r.userId}`}>{r.target ?? `#${r.userId}`}</Link> : '—' },
    { key: 'details', label: 'Details', wide: true, render: r => <small style={{ overflowWrap: 'anywhere' }}>{pretty(r.details)}</small> }, { key: 'ip', label: 'IP', hideOnPhone: true, render: r => r.ip ?? '—' },
  ];
  return <AdminLayout admin={admin} active="/admin/audit">
    <Page title="Audit log" subtitle="Every sensitive action an admin takes — who, what, on which user, from which IP. Cannot be edited.">
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}><FilterBar url="/admin/audit" values={filters} defs={[
          { name: 'q', type: 'search', placeholder: 'Admin / user email, IP or text in details' },
          { name: 'action', type: 'select', options: [['', 'All actions'], ...actions.map(a => [a, a] as [string, string])] }, { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
        ]}/></div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty="Nothing logged yet."/>
        <Pager p={pager} url="/admin/audit"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
