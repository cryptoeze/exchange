import { Link } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; admin: string; action: string; userId: number | null; details: string | null; ip: string | null; at: string };
export default function AdminAudit({ admin, rows }: { admin: AdminUser; rows: Row[] }) {
  return <AdminLayout admin={admin} active="/admin/audit"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Audit log</h1><p>Every admin money, KYC, settings and account action. Latest 200.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '8px 22px 22px', overflowX: 'auto' }}>
      {rows.length === 0 ? <p style={{ opacity: .7 }}>No admin actions recorded yet.</p> : <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}><thead><tr style={{ textAlign: 'left', opacity: .7 }}><th>Time</th><th>Admin</th><th>Action</th><th>User</th><th>Details</th><th>IP</th></tr></thead>
        <tbody>{rows.map(r => <tr key={r.id} style={{ borderTop: '1px solid rgba(128,128,128,.2)', verticalAlign: 'top' }}><td style={{ padding: '8px 6px', whiteSpace: 'nowrap' }}>{r.at}</td><td>{r.admin}</td><td><b>{r.action}</b></td><td>{r.userId ? <Link href={`/admin/users/${r.userId}`}>#{r.userId}</Link> : '—'}</td><td style={{ fontFamily: 'monospace', fontSize: 11, maxWidth: 360, overflowWrap: 'anywhere' }}>{r.details}</td><td>{r.ip}</td></tr>)}</tbody></table>}
    </div></section>
  </div></AdminLayout>;
}
