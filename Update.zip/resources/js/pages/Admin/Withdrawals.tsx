import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; user: string; userId: number; asset: string; network: string; address: string; amount: string; fee: string; net: string; status: string; txHash: string | null; reason: string | null; at: string };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;

function Line({ w }: { w: Row }) {
  const [tx, setTx] = useState(''); const [why, setWhy] = useState('');
  const act = (decision: 'complete' | 'reject') => { if (decision === 'complete' && !window.confirm(`Confirm you have SENT ${w.net} ${w.asset} (${w.network}) to ${w.address}?`)) return; router.post(`/admin/withdrawals/${w.id}`, { decision, tx_hash: tx, reason: why }, { preserveScroll: true }); };
  return <div style={{ padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)', display: 'grid', gap: 8 }}>
    <div><b>#{w.id}</b> · <Link href={`/admin/users/${w.userId}`}>{w.user}</Link> · {w.at} · <b>{w.status}</b></div>
    <div>Send <b>{w.net} {w.asset}</b> on <b>{w.network}</b> (requested {w.amount}, fee {w.fee})</div>
    <div style={{ overflowWrap: 'anywhere', fontFamily: 'monospace' }}>{w.address}</div>
    {w.status === 'pending' ? <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      <input style={{ ...input, flex: '1 1 200px' }} placeholder="TX hash (optional)" value={tx} onChange={e => setTx(e.target.value)}/>
      <button type="button" onClick={() => act('complete')} style={{ ...input, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer', border: 0 }}>Mark sent</button>
      <input style={{ ...input, flex: '1 1 160px' }} placeholder="Reject reason" value={why} onChange={e => setWhy(e.target.value)}/>
      <button type="button" onClick={() => act('reject')} style={{ ...input, color: '#f6465d', cursor: 'pointer' }}>Reject &amp; refund</button></div>
      : <small style={{ opacity: .75 }}>{w.txHash ? `TX ${w.txHash}` : w.reason}</small>}
  </div>;
}

export default function AdminWithdrawals({ admin, rows, status, pendingCount }: { admin: AdminUser; rows: Row[]; status: string; pendingCount: number }) {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  return <AdminLayout admin={admin} active="/admin/withdrawals"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Withdrawals</h1><p>{pendingCount} waiting for review. Send the funds from your wallet, then mark as sent.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>
      <div style={{ display: 'flex', gap: 8, padding: '14px 0' }}>{['pending', 'completed', 'rejected', 'cancelled'].map(s => <Link key={s} href={`/admin/withdrawals?status=${s}`} style={{ ...input, textDecoration: 'none', fontWeight: s === status ? 700 : 400 }}>{s}</Link>)}</div>
      {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}
      {rows.length === 0 ? <p style={{ opacity: .7 }}>Nothing here.</p> : rows.map(w => <Line key={w.id} w={w}/>)}
    </div></section>
  </div></AdminLayout>;
}
