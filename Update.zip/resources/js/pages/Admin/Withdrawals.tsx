import { Download } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';
import { ActionButton, Badge, Copy, DataTable, FilterBar, Page, Pager, Panel, Stats, usd, Tabs, UserLink, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; name: string; kyc: string; asset: string; network: string; address: string; amount: string; fee: string; net: string; status: string; txHash: string | null; reason: string | null; by: string | null; at: string; doneAt: string | null };
type Props = {
  admin: AdminUser; tab: string; rows: Row[]; pager: Paged; filters: Record<string, string>; assets: string[]; networks: string[];
  counts: { pending: number; completed: number; rejected: number; cancelled: number; all: number };
  stats: { pendingValue: string; sent30: string; sentToday: number; fees30: string };
};
const short = (v: string) => v.length > 24 ? `${v.slice(0, 10)}…${v.slice(-8)}` : v;

export default function AdminWithdrawals({ admin, tab, rows, pager, filters, assets, networks, counts, stats }: Props) {
  const cols: Col<Row>[] = [
    { key: 'id', label: '#', hideOnPhone: true },
    { key: 'at', label: 'Requested', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'user', label: 'User', primary: true, render: r => <><UserLink id={r.userId} name={r.name} email={r.email}/><Badge tone={r.kyc === 'approved' ? 'ok' : 'muted'}>{r.kyc === 'approved' ? 'KYC ✓' : `KYC ${r.kyc}`}</Badge></> },
    { key: 'asset', label: 'Coin / network', render: r => <><b>{r.asset}</b> <small style={{ opacity: .7 }}>{r.network}</small></> },
    { key: 'net', label: 'Send (net)', align: 'right', render: r => <><b>{r.net}</b><small style={{ display: 'block', opacity: .65 }}>amount {r.amount} · fee {r.fee}</small></> },
    { key: 'address', label: 'To address', wide: true, render: r => <Copy text={r.address}>{short(r.address)}</Copy> },
    { key: 'status', label: 'Status', render: r => <><Badge>{r.status}</Badge>{r.doneAt && <small style={{ display: 'block', opacity: .65 }}>{r.doneAt}{r.by ? ` · ${r.by}` : ''}</small>}{r.txHash && <small style={{ display: 'block' }}><Copy text={r.txHash}>TX {short(r.txHash)}</Copy></small>}{r.reason && <small style={{ display: 'block', opacity: .65 }}>{r.reason}</small>}</> },
    { key: 'act', label: 'Action', align: 'right', render: r => r.status !== 'pending' ? null : <span style={{ display: 'inline-flex', gap: 6 }}>
      <ActionButton label="Mark sent" title={`Mark ${r.net} ${r.asset} as sent`} variant="ok" url={`/admin/withdrawals/${r.id}`} data={{ decision: 'complete' }}
        note={<>Send <b>{r.net} {r.asset}</b> on <b>{r.network}</b> to <b style={{ overflowWrap: 'anywhere' }}>{r.address}</b> from your wallet first, then confirm here. The user is notified.</>}
        fields={[{ name: 'tx_hash', label: 'Transaction hash (optional)', placeholder: 'Paste the TXID' }]}/>
      <ActionButton label="Reject" title="Reject and refund" variant="danger" url={`/admin/withdrawals/${r.id}`} data={{ decision: 'reject' }}
        note="The full amount (including the fee) goes back to the user's Funding wallet." fields={[{ name: 'reason', label: 'Reason shown to the user', placeholder: 'e.g. Address not supported', type: 'textarea' }]}/>
    </span> },
  ];
  const exportUrl = `/admin/withdrawals?${new URLSearchParams({ ...Object.fromEntries(Object.entries({ ...filters, status: tab }).filter(([, v]) => v)), export: '1' }).toString()}`;
  return <AdminLayout admin={admin} active="/admin/withdrawals">
    <Page title="Withdrawals" subtitle="Users request, you send from your wallet and mark it sent — or reject and the money returns to them. Fees and networks are set in Gateways."
      actions={<><a className="au-btn" href="/admin/gateways?tab=withdraw">Fees & networks</a><a className="au-btn" href={exportUrl}><Download size={15}/> Export CSV</a></>}>
      <Stats items={[
        { label: 'Waiting to be sent', value: counts.pending, hint: `≈ ${usd(stats.pendingValue)}`, tone: counts.pending ? 'warn' : undefined },
        { label: 'Sent today', value: stats.sentToday },
        { label: 'Sent (30d)', value: usd(stats.sent30), tone: 'ok' },
        { label: 'Fees kept (30d)', value: usd(stats.fees30) },
      ]}/>
      <Tabs base="/admin/withdrawals" param="status" active={tab} tabs={[
        { key: 'pending', label: 'Pending', count: counts.pending, tone: 'warn' }, { key: 'completed', label: 'Sent' }, { key: 'rejected', label: 'Rejected' }, { key: 'cancelled', label: 'Cancelled' }, { key: 'all', label: 'All' },
      ]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}>
          <FilterBar url="/admin/withdrawals" hidden={{ status: tab }} values={filters} defs={[
            { name: 'q', type: 'search', placeholder: 'User email / name / ID, address or TX hash' },
            { name: 'asset', type: 'select', options: [['', 'All coins'], ...assets.map(a => [a, a] as [string, string])] },
            { name: 'network', type: 'select', options: [['', 'All networks'], ...networks.map(a => [a, a] as [string, string])] },
            { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
          ]}/>
        </div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty={tab === 'pending' ? 'No withdrawals are waiting. 🎉' : 'No withdrawals match these filters.'}/>
        <Pager p={pager} url="/admin/withdrawals"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
