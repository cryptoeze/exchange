import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState, type ChangeEvent } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const btn = { ...input, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer', border: 0 } as const;
function Flash() { const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> }; return <>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}</>; }

type Field = { key: string; type: string; label: string; hint: string; group: string };
type License = { authority: boolean; status?: 'none' | 'active' | 'locked'; key?: string };
function LicenseCard({ license }: { license: License }) {
  const row = (color: string, bg: string, label: string, note: string) => <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', borderRadius: 10, background: bg }}>
    <span style={{ width: 10, height: 10, borderRadius: '50%', background: color, flex: 'none' }}/>
    <span><b style={{ color }}>{label}</b><br/><small style={{ opacity: .7 }}>{note}</small></span>
  </div>;
  return <div style={{ display: 'grid', gap: 14, paddingTop: 10 }}>
    <h3 style={{ margin: '8px 0 0', fontSize: 15, borderBottom: '1px solid rgba(128,128,128,.25)', paddingBottom: 6 }}>Licensing</h3>
    {license.authority
      ? row('#c1f033', 'rgba(193,240,51,.12)', 'Authority mode', 'This install issues and manages license keys for sold copies (LICENSE_AUTHORITY=true). It never needs a license itself.')
      : license.status === 'active'
        ? row('#2ebd85', 'rgba(46,189,133,.12)', 'Activated', `License key ${license.key} is active.`)
        : license.status === 'locked'
          ? row('#f6465d', 'rgba(246,70,93,.12)', 'Locked', `License key ${license.key} was revoked, or this site could not check in for too long.`)
          : row('#9a9aa0', 'rgba(128,128,128,.12)', 'Not activated', 'Run php artisan license:activate <key> on the server to activate.')}
  </div>;
}
function LogoCard({ logoUrl }: { logoUrl: string | null }) {
  const [busy, setBusy] = useState(false);
  const pick = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; e.target.value = '';
    if (!file) return;
    const data = new FormData(); data.append('logo', file);
    setBusy(true);
    router.post('/admin/settings/logo', data, { preserveScroll: true, forceFormData: true, onFinish: () => setBusy(false) });
  };
  const remove = () => { setBusy(true); router.post('/admin/settings/logo/remove', {}, { preserveScroll: true, onFinish: () => setBusy(false) }); };
  return <div style={{ display: 'grid', gap: 14, paddingTop: 10 }}>
    <h3 style={{ margin: '8px 0 0', fontSize: 15, borderBottom: '1px solid rgba(128,128,128,.25)', paddingBottom: 6 }}>Site logo</h3>
    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <span style={{ display: 'grid', placeItems: 'center', width: 56, height: 56, borderRadius: 10, border: '1px solid rgba(128,128,128,.35)', overflow: 'hidden', background: 'rgba(128,128,128,.08)' }}>
        {logoUrl ? <img src={logoUrl} alt="Current logo" style={{ maxWidth: '100%', maxHeight: '100%' }}/> : <small style={{ opacity: .6 }}>Default</small>}
      </span>
      <span style={{ display: 'grid', gap: 6 }}>
        <small style={{ opacity: .65 }}>Shown in the site header. PNG, JPG, WEBP or SVG, up to 1&nbsp;MB.</small>
        <span style={{ display: 'flex', gap: 10 }}>
          <label style={{ ...btn, padding: '8px 14px', opacity: busy ? .6 : 1 }}>{busy ? 'Uploading…' : 'Upload logo'}<input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={pick} disabled={busy} style={{ display: 'none' }}/></label>
          {logoUrl && <button type="button" style={{ ...input, cursor: 'pointer' }} onClick={remove} disabled={busy}>Reset to default</button>}
        </span>
      </span>
    </div>
  </div>;
}
export default function AdminSettings({ admin, fields, values, logoUrl, license }: { admin: AdminUser; fields: Field[]; values: Record<string, string | boolean>; logoUrl: string | null; license: License }) {
  const [v, setV] = useState(values);
  const save = () => router.post('/admin/settings', v as never, { preserveScroll: true });
  return <AdminLayout admin={admin} active="/admin/settings"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Settings</h1><p>Changes apply immediately. Money rates are paid by the platform — review before switching on.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '8px 22px 22px', display: 'grid', gap: 14 }}><Flash/>
      <LicenseCard license={license}/>
      <LogoCard logoUrl={logoUrl}/>
      {[...new Set(fields.map(f => f.group))].map(g => <div key={g} style={{ display: 'grid', gap: 14, paddingTop: 10 }}>
        <h3 style={{ margin: '8px 0 0', fontSize: 15, borderBottom: '1px solid rgba(128,128,128,.25)', paddingBottom: 6 }}>{g}</h3>
        {fields.filter(f => f.group === g).map(f => <label key={f.key} style={{ display: 'grid', gap: 6 }}>
          <span><b>{f.label}</b>{f.hint && <small style={{ opacity: .65 }}> — {f.hint}</small>}</span>
          {f.type === 'bool' ? <input type="checkbox" checked={!!v[f.key]} onChange={e => setV({ ...v, [f.key]: e.target.checked })} style={{ width: 20, height: 20 }}/> : <input style={input} type={f.type === 'secret' ? 'password' : 'text'} autoComplete="off" value={String(v[f.key] ?? '')} onChange={e => setV({ ...v, [f.key]: e.target.value })}/>}
        </label>)}
      </div>)}
      <button type="button" style={{ ...btn, padding: '12px 18px', justifySelf: 'start' }} onClick={save}>Save settings</button>
    </div></section>
  </div></AdminLayout>;
}
