import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const btn = { ...input, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer', border: 0 } as const;
function Flash() { const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> }; return <>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}</>; }

type Field = { key: string; type: string; label: string; hint: string };
export default function AdminSettings({ admin, fields, values }: { admin: AdminUser; fields: Field[]; values: Record<string, string | boolean> }) {
  const [v, setV] = useState(values);
  const save = () => router.post('/admin/settings', v as never, { preserveScroll: true });
  return <AdminLayout admin={admin} active="/admin/settings"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Settings</h1><p>Changes apply immediately. Money rates are paid by the platform — review before switching on.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '8px 22px 22px', display: 'grid', gap: 14 }}><Flash/>
      {fields.map(f => <label key={f.key} style={{ display: 'grid', gap: 6 }}>
        <span><b>{f.label}</b>{f.hint && <small style={{ opacity: .65 }}> — {f.hint}</small>}</span>
        {f.type === 'bool' ? <input type="checkbox" checked={!!v[f.key]} onChange={e => setV({ ...v, [f.key]: e.target.checked })} style={{ width: 20, height: 20 }}/> : <input style={input} value={String(v[f.key] ?? '')} onChange={e => setV({ ...v, [f.key]: e.target.value })}/>}
      </label>)}
      <button type="button" style={{ ...btn, padding: '12px 18px', justifySelf: 'start' }} onClick={save}>Save settings</button>
    </div></section>
  </div></AdminLayout>;
}
