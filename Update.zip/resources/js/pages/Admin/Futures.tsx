import { Link } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; user: string; symbol: string; side: string; leverage: number; margin: string; entry: number; mark: number | null; liq: number; pnl: string; at: string | null };
type Totals = { open: number; margin: string; long: string; short: string; unrealized: string; feesEarned: string; closedCount: number; liquidations: number };

export default function AdminFutures({ admin, positions, totals, config }: { admin: AdminUser; positions: Row[]; totals: Totals; config: { enabled: boolean; feeRate: number; maxLeverage: number; maxMargin: number } }) {
  const pad = { padding: '4px 22px 18px' } as const;
  return <AdminLayout admin={admin} active="/admin/futures"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Futures</h1><p>Open positions and the platform's exposure.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Exposure</h2></header><div style={pad}>
      <p>Open positions: <b>{totals.open}</b> · Margin locked: <b>{totals.margin}</b> USDT</p>
      <p>Long size: <b>{totals.long}</b> · Short size: <b>{totals.short}</b> USDT</p>
      <p>Unrealized PnL owed to users if all closed now: <b style={{ color: totals.unrealized.startsWith('-') ? '#f6465d' : '#2ebd85' }}>{totals.unrealized}</b> USDT <small style={{ opacity: .7 }}>(negative means users are losing and the platform is ahead)</small></p>
      <p>Fees earned: <b>{totals.feesEarned}</b> USDT · Closed: <b>{totals.closedCount}</b> · Liquidations: <b>{totals.liquidations}</b></p>
      <p style={{ opacity: .75, fontSize: 13 }}>Trades are matched by the platform at the live Bybit price, so user profits are paid by the platform. Settings come from the server's <code>.env</code>: status <b>{config.enabled ? 'ON' : 'OFF'}</b>, fee <b>{(config.feeRate * 100).toFixed(3)}%</b>, max leverage <b>{config.maxLeverage}x</b>, max margin <b>{config.maxMargin.toLocaleString()}</b> per position (TRADING_FUTURES_*). Take-profit, stop-loss and liquidation run on every user request and by <code>php artisan futures:sweep</code> (cron every minute recommended).</p></div></section>
    <section className="admin-panel"><header><h2>Open positions</h2></header><div style={{ ...pad, overflowX: 'auto' }}>
      {positions.length === 0 ? <p>No open positions.</p> : <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, whiteSpace: 'nowrap' }}><thead><tr style={{ textAlign: 'left', opacity: .7 }}><th>User</th><th>Contract</th><th>Margin</th><th>Entry</th><th>Mark</th><th>Liq</th><th>PnL</th><th>Opened</th></tr></thead>
        <tbody>{positions.map(p => <tr key={p.id} style={{ borderTop: '1px solid rgba(128,128,128,.2)' }}><td style={{ padding: '8px 12px 8px 0' }}>{p.user}</td><td>{p.symbol} <b style={{ color: p.side === 'long' ? '#2ebd85' : '#f6465d' }}>{p.side.toUpperCase()} {p.leverage}x</b></td><td>{p.margin}</td><td>{p.entry}</td><td>{p.mark ?? '—'}</td><td>{p.liq.toFixed(4)}</td><td style={{ color: p.pnl.startsWith('-') ? '#f6465d' : '#2ebd85' }}>{p.pnl}</td><td>{p.at}</td></tr>)}</tbody></table>}
    </div></section>
  </div></AdminLayout>;
}
