import { AdminLayout, type AdminUser } from './Layout';
import { Badge, DataTable, FilterBar, Page, Pager, Panel, Stats, Tabs, UserLink, group, usd, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; name: string; symbol: string; side: string; leverage: number; margin: string; entry: number; mark: number | null; close: number | null; liq: number; pnl: string; status: string; reason: string | null; at: string | null; closedAt: string | null };
type Totals = { open: number; margin: string; long: string; short: string; unrealized: string; feesEarned: string; closedCount: number; liquidations: number };
type Props = { admin: AdminUser; tab: string; rows: Row[]; pager: Paged; filters: Record<string, string>; counts: { open: number; closed: number }; totals: Totals; config: { enabled: boolean; feeRate: number; maxLeverage: number; maxMargin: number } };
const px = (n: number | null) => n == null ? '—' : n.toLocaleString('en-US', { maximumFractionDigits: 6 });

export default function AdminFutures({ admin, tab, rows, pager, filters, counts, totals, config }: Props) {
  const cols: Col<Row>[] = [
    { key: 'at', label: 'Opened', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'user', label: 'User', primary: true, render: r => <UserLink id={r.userId} name={r.name} email={r.email}/> },
    { key: 'symbol', label: 'Contract', render: r => <><b>{r.symbol}</b> <b className={r.side === 'long' ? 'pos' : 'neg'}>{r.side.toUpperCase()} {r.leverage}x</b></> },
    { key: 'margin', label: 'Margin', align: 'right', render: r => group(r.margin) },
    { key: 'entry', label: 'Entry', align: 'right', render: r => px(r.entry) },
    { key: 'mark', label: 'Mark / close', align: 'right', render: r => px(r.status === 'open' ? r.mark : r.close) },
    { key: 'liq', label: 'Liq.', align: 'right', hideOnPhone: true, render: r => px(r.liq) },
    { key: 'pnl', label: 'PnL', align: 'right', render: r => <b className={r.pnl.startsWith('-') ? 'neg' : 'pos'}>{group(r.pnl)}</b> },
    { key: 'status', label: 'Status', render: r => <><Badge>{r.status}</Badge>{r.reason && <small style={{ display: 'block', opacity: .65 }}>{r.reason}{r.closedAt ? ` · ${r.closedAt}` : ''}</small>}</> },
  ];
  return <AdminLayout admin={admin} active="/admin/futures">
    <Page title="Futures" subtitle="Platform exposure and every position. Trades are matched by the platform at the live Bybit price, so user profits are paid by the platform.">
      <Stats items={[
        { label: 'Open positions', value: totals.open, hint: `Margin locked ${usd(totals.margin)}` },
        { label: 'Long / short size', value: `${usd(totals.long)} / ${usd(totals.short)}` },
        { label: 'Unrealized PnL (users)', value: usd(totals.unrealized), tone: totals.unrealized.startsWith('-') ? 'ok' : 'warn', hint: totals.unrealized.startsWith('-') ? 'users are losing — platform ahead' : 'platform owes this if all closed now' },
        { label: 'Fees earned', value: usd(totals.feesEarned), tone: 'ok', hint: `${totals.closedCount} closed · ${totals.liquidations} liquidations` },
      ]}/>
      <Panel title="Futures settings" hint="Change these in Settings → Fees & trading limits." actions={<a className="au-btn sm" href="/admin/settings">Open settings</a>}>
        <small>Status <Badge tone={config.enabled ? 'ok' : 'bad'}>{config.enabled ? 'on' : 'off'}</Badge> · fee {(config.feeRate * 100).toFixed(3)}% · max leverage {config.maxLeverage}x · max margin {config.maxMargin.toLocaleString()} per position</small>
      </Panel>
      <Tabs base="/admin/futures" active={tab} tabs={[{ key: 'open', label: 'Open', count: counts.open }, { key: 'closed', label: 'Closed' }, { key: 'all', label: 'All' }].map(t => t.key === 'open' ? t : { ...t, count: undefined })}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}><FilterBar url="/admin/futures" hidden={{ tab }} values={filters} defs={[
          { name: 'q', type: 'search', placeholder: 'User — email, name or ID' }, { name: 'symbol', type: 'search', placeholder: 'Contract, e.g. BTC' },
          { name: 'side', type: 'select', options: [['', 'Long & short'], ['long', 'Long'], ['short', 'Short']] },
          { name: 'reason', type: 'select', options: [['', 'Any close reason'], ['manual', 'Closed by user'], ['tp', 'Take profit'], ['sl', 'Stop loss'], ['liquidation', 'Liquidated']] },
          { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
        ]}/></div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty="No positions match."/>
        <Pager p={pager} url="/admin/futures"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
