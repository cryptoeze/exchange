import { Download } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';
import { Badge, DataTable, FilterBar, Page, Pager, Panel, Stats, usd, UserLink, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; name: string; symbol: string; side: string; price: string; qty: string; total: string; fee: string; status: string; at: string };
type Props = { admin: AdminUser; rows: Row[]; pager: Paged; filters: Record<string, string>; stats: { dayOrders: number; dayVolume: string; dayFees: string; dayTraders: number; matchCount: number; matchVolume: string; matchFees: string } };

export default function AdminTrades({ admin, rows, pager, filters, stats }: Props) {
  const cols: Col<Row>[] = [
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'user', label: 'User', primary: true, render: r => <UserLink id={r.userId} name={r.name} email={r.email}/> },
    { key: 'symbol', label: 'Pair', render: r => <b>{r.symbol}</b> },
    { key: 'side', label: 'Side', render: r => <Badge tone={r.side === 'buy' ? 'ok' : 'bad'}>{r.side}</Badge> },
    { key: 'price', label: 'Price', align: 'right' },
    { key: 'qty', label: 'Amount', align: 'right', hideOnPhone: true },
    { key: 'total', label: 'Total (USDT)', align: 'right', render: r => <b>{r.total}</b> },
    { key: 'fee', label: 'Fee', align: 'right', hideOnPhone: true },
    { key: 'status', label: 'Status', render: r => <Badge>{r.status}</Badge> },
  ];
  const exportUrl = `/admin/trades?${new URLSearchParams({ ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)), export: '1' }).toString()}`;
  return <AdminLayout admin={admin} active="/admin/trades">
    <Page title="Spot trades" subtitle="Every filled spot order — market, limit, take-profit and stop-loss."
      actions={<a className="au-btn" href={exportUrl}><Download size={15}/> Export CSV</a>}>
      <Stats items={[
        { label: 'Orders (24h)', value: stats.dayOrders.toLocaleString(), hint: `${stats.dayTraders} traders` },
        { label: 'Volume (24h)', value: usd(stats.dayVolume) },
        { label: 'Fees earned (24h)', value: usd(stats.dayFees), tone: 'ok' },
        { label: 'Matching filters', value: stats.matchCount.toLocaleString(), hint: `${usd(stats.matchVolume)} volume · ${usd(stats.matchFees)} fees` },
      ]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}>
          <FilterBar url="/admin/trades" values={filters} defs={[
            { name: 'q', type: 'search', placeholder: 'User — email, name or ID' },
            { name: 'symbol', type: 'search', placeholder: 'Pair, e.g. BTC' },
            { name: 'side', type: 'select', options: [['', 'Buy & sell'], ['buy', 'Buy'], ['sell', 'Sell']] },
            { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
          ]}/>
        </div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty="No trades match these filters."/>
        <Pager p={pager} url="/admin/trades"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
