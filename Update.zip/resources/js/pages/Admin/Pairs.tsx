import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useMemo, useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const btn = { ...input, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer', border: 0 } as const;
function Flash() { const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> }; return <>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}</>; }

type Row = { symbol: string; base: string; spot: boolean; futures: boolean; price: number; paused: boolean };
export default function AdminPairs({ admin, rows, paused }: { admin: AdminUser; rows: Row[]; paused: string[] }) {
  const [off, setOff] = useState<Set<string>>(new Set(paused));
  const [q, setQ] = useState('');
  const list = useMemo(() => rows.filter(r => r.symbol.includes(q.trim().toUpperCase())), [rows, q]);
  const toggle = (s: string) => setOff(prev => { const n = new Set(prev); if (n.has(s)) n.delete(s); else n.add(s); return n; });
  const save = () => router.post('/admin/markets', { paused: [...off] } as never, { preserveScroll: true });
  return <AdminLayout admin={admin} active="/admin/markets"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Markets on/off</h1><p>Paused pairs cannot be opened, bought or sold by users (spot and futures). Open futures positions and resting orders keep working. {off.size} paused.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '14px 22px 22px', display: 'grid', gap: 12 }}>
      <Flash/>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><input style={{ ...input, flex: '1 1 220px' }} placeholder="Search pair, e.g. BTC" value={q} onChange={e => setQ(e.target.value)}/><button type="button" style={{ ...btn, padding: '8px 18px' }} onClick={save}>Save changes</button></div>
      {rows.length === 0 && <p style={{ opacity: .7 }}>Market list is unavailable right now (price feed offline). Try again in a moment.</p>}
      <div style={{ display: 'grid', gap: 0 }}>{list.map(r => <label key={r.symbol} style={{ display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 12, alignItems: 'center', padding: '10px 0', borderTop: '1px solid rgba(128,128,128,.18)' }}>
        <span><b>{r.symbol}</b> <small style={{ opacity: .6 }}>{r.spot ? 'Spot' : ''}{r.spot && r.futures ? ' · ' : ''}{r.futures ? 'Futures' : ''}</small></span>
        <small style={{ opacity: .7 }}>{r.price ? r.price.toLocaleString('en-US', { maximumFractionDigits: 6 }) : '—'}</small>
        <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}><input type="checkbox" checked={!off.has(r.symbol)} onChange={() => toggle(r.symbol)} style={{ width: 20, height: 20 }}/><small>{off.has(r.symbol) ? 'Paused' : 'Trading'}</small></span>
      </label>)}</div>
    </div></section>
  </div></AdminLayout>;
}
