import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Ev = { key: string; label: string; vars: string[]; subject: string; heading: string; body: string; enabled: boolean };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit', width: '100%' } as const;
const btn = { ...input, width: 'auto', cursor: 'pointer', fontWeight: 700 } as const;

function Card({ e }: { e: Ev }) {
  const [f, setF] = useState({ subject: e.subject, heading: e.heading, body: e.body, enabled: e.enabled });
  return <div style={{ borderTop: '1px solid rgba(128,128,128,.2)', padding: '16px 0', display: 'grid', gap: 8 }}>
    <label style={{ display: 'flex', gap: 10, alignItems: 'center' }}><input type="checkbox" checked={f.enabled} onChange={x => setF({ ...f, enabled: x.target.checked })} style={{ width: 18, height: 18 }}/><b>{e.label}</b><small style={{ opacity: .6 }}>placeholders: {e.vars.map(v => `{${v}}`).join(' ')}</small></label>
    <input style={input} value={f.subject} onChange={x => setF({ ...f, subject: x.target.value })} placeholder="Subject"/>
    <input style={input} value={f.heading} onChange={x => setF({ ...f, heading: x.target.value })} placeholder="Heading"/>
    <textarea style={{ ...input, minHeight: 120, fontFamily: 'inherit' }} value={f.body} onChange={x => setF({ ...f, body: x.target.value })}/>
    <div style={{ display: 'flex', gap: 8 }}>
      <button type="button" style={{ ...btn, background: '#c1f033', color: '#000', border: 0 }} onClick={() => router.post(`/admin/emails/${e.key}`, f as never, { preserveScroll: true })}>Save</button>
      <button type="button" style={btn} onClick={() => router.post(`/admin/emails/${e.key}/test`, {}, { preserveScroll: true })}>Send test to me</button>
    </div>
  </div>;
}

export default function AdminEmailTemplates({ admin, events, master, mailer, from }: { admin: AdminUser; events: Ev[]; master: boolean; mailer: string; from: string }) {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  return <AdminLayout admin={admin} active="/admin/emails"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Email templates</h1><p>Every event also shows in the user's notification bell. Switch an event off to stop both.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '8px 22px 22px' }}>
      <p style={{ fontSize: 13 }}>Mail driver: <b>{mailer}</b> · From: <b>{from || 'not set'}</b> · Sending is <b style={{ color: master ? '#2ebd85' : '#f6465d' }}>{master ? 'ON' : 'OFF'}</b> (Settings → Display &amp; email).{mailer === 'log' && <span style={{ color: '#f5a623' }}> Mail driver is “log”: emails are only written to the log. Set MAIL_MAILER=smtp and the MAIL_* values in .env.</span>}</p>
      {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}
      {events.map(e => <Card key={e.key} e={e}/>)}
    </div></section>
  </div></AdminLayout>;
}
