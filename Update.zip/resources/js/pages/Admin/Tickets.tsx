import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; subject: string; category: string; user: string; at: string };
type Msg = { id: number; staff: boolean; body: string; at: string };
type Sel = { id: number; subject: string; status: string; category: string; userId: number; user: string };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit', width: '100%' } as const;

export default function AdminTickets({ admin, rows, status, counts, selected, messages }: { admin: AdminUser; rows: Row[]; status: string; counts: Record<string, number>; selected: Sel | null; messages: Msg[] }) {
  const page = usePage().props as { flash?: { status?: string } };
  const [text, setText] = useState('');
  return <AdminLayout admin={admin} active="/admin/tickets"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Support tickets</h1><p>{counts.open} waiting for a reply.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.4fr)', gap: 16 }} className="adm-tk">
      <section className="admin-panel"><div style={{ padding: '10px 18px 18px' }}>
        <div style={{ display: 'flex', gap: 8, paddingBottom: 10 }}>{['open', 'answered', 'closed'].map(s => <Link key={s} href={`/admin/tickets?status=${s}`} style={{ ...input, width: 'auto', textDecoration: 'none', fontWeight: s === status ? 800 : 400 }}>{s} ({counts[s]})</Link>)}</div>
        {rows.length === 0 ? <p style={{ opacity: .7 }}>Nothing here.</p> : rows.map(r => <Link key={r.id} href={`/admin/tickets?status=${status}&id=${r.id}`} style={{ display: 'block', padding: '10px 0', borderTop: '1px solid rgba(128,128,128,.2)', textDecoration: 'none', color: 'inherit', fontWeight: selected?.id === r.id ? 800 : 500 }}>#{r.id} {r.subject}<br/><small style={{ opacity: .65 }}>{r.user} · {r.category} · {r.at}</small></Link>)}
      </div></section>
      <section className="admin-panel"><div style={{ padding: '10px 18px 18px', display: 'grid', gap: 10 }}>
        {!selected ? <p style={{ opacity: .7 }}>Pick a ticket.</p> : <>
          <div><b>#{selected.id} {selected.subject}</b><br/><small><Link href={`/admin/users/${selected.userId}`}>{selected.user}</Link> · {selected.category} · {selected.status}</small></div>
          {messages.map(m => <div key={m.id} style={{ justifySelf: m.staff ? 'end' : 'start', maxWidth: '88%', background: m.staff ? 'rgba(193,240,51,.12)' : 'rgba(128,128,128,.14)', borderRadius: 12, padding: '9px 12px' }}><small style={{ opacity: .6 }}>{m.staff ? 'Staff' : 'User'} · {m.at}</small><div style={{ whiteSpace: 'pre-wrap' }}>{m.body}</div></div>)}
          <textarea style={{ ...input, minHeight: 90 }} placeholder="Reply to the user…" value={text} onChange={e => setText(e.target.value)}/>
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" style={{ ...input, width: 'auto', background: '#c1f033', color: '#000', fontWeight: 800, border: 0, cursor: 'pointer' }} onClick={() => text.trim() && router.post(`/admin/tickets/${selected.id}/reply`, { message: text } as never, { preserveScroll: true, onSuccess: () => setText('') })}>Send reply</button>
            <button type="button" style={{ ...input, width: 'auto', cursor: 'pointer' }} onClick={() => router.post(`/admin/tickets/${selected.id}/status`, { status: selected.status === 'closed' ? 'open' : 'closed' } as never, { preserveScroll: true })}>{selected.status === 'closed' ? 'Reopen' : 'Close ticket'}</button>
          </div></>}
      </div></section>
    </div>
    <style>{`@media(max-width:900px){.adm-tk{grid-template-columns:1fr!important}}`}</style>
  </div></AdminLayout>;
}
