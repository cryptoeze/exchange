import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const btn = { ...input, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer', border: 0 } as const;
function Flash() { const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> }; return <>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}</>; }

type Recent = { title: string; body: string | null; created_at: string; total: number };
export default function AdminNotifications({ admin, recent, users }: { admin: AdminUser; recent: Recent[]; users: number }) {
  const [f, setF] = useState({ title: '', body: '', email: '' });
  const send = () => { if (!f.title.trim()) return; if (!f.email && !window.confirm(`Send to ALL ${users} users?`)) return; router.post('/admin/notifications', f as never, { preserveScroll: true, onSuccess: () => setF({ title: '', body: '', email: '' }) }); };
  return <AdminLayout admin={admin} active="/admin/notifications"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Notifications</h1><p>Message everyone, or one user by email. It shows under the bell in the app.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '8px 22px 22px', display: 'grid', gap: 12 }}><Flash/>
      <input style={input} placeholder="Title" maxLength={140} value={f.title} onChange={e => setF({ ...f, title: e.target.value })}/>
      <textarea style={{ ...input, minHeight: 90 }} placeholder="Message (optional)" maxLength={1000} value={f.body} onChange={e => setF({ ...f, body: e.target.value })}/>
      <input style={input} placeholder="User email (leave empty to send to everyone)" value={f.email} onChange={e => setF({ ...f, email: e.target.value })}/>
      <button type="button" style={{ ...btn, padding: '12px 18px', justifySelf: 'start' }} onClick={send}>Send</button>
      <h3 style={{ margin: '14px 0 0' }}>Recent</h3>
      {recent.length === 0 ? <p style={{ opacity: .7 }}>Nothing sent yet.</p> : recent.map((r, i) => <div key={i} style={{ borderTop: '1px solid rgba(128,128,128,.2)', padding: '10px 0' }}><b>{r.title}</b> <small style={{ opacity: .65 }}>· {r.total} recipient(s) · {r.created_at}</small>{r.body && <div style={{ opacity: .8 }}>{r.body}</div>}</div>)}
    </div></section>
  </div></AdminLayout>;
}
