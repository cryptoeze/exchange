import { Link, router, useForm, usePage } from '@inertiajs/react';
import { useState } from 'react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type BotRow = { bio?: string | null; direction?: string; leverage?: number; id: number; name: string; pair: string; strategy: string; daily: number; share: number; min: string; maxPerUser?: string; capacity?: string; enabled: boolean; followers: number; aum: string; paid: string; kept: string };
const field = { style: { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '9px 10px', font: 'inherit', width: '100%' } } as const;

function Tools({ bot }: { bot: BotRow }) {
  const [list, setList] = useState<Array<{ userId: number; email: string; capital: string; since: string | null; auto: boolean }> | null>(null);
  const load = async () => { const r = await fetch(`/admin/bots/${bot.id}/followers`, { headers: { Accept: 'application/json' } }); if (r.ok) setList(await r.json()); };
  const btn = { ...field.style, width: 'auto', cursor: 'pointer', fontSize: 12.5 } as const;
  return <div style={{ gridColumn: '1 / -1', display: 'grid', gap: 8 }}>
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      <button type="button" style={btn} onClick={() => (list ? setList(null) : load())}>{list ? 'Hide followers' : `Followers (${bot.followers})`}</button>
      <button type="button" style={btn} onClick={() => window.confirm(`Pay all completed cycles for ${bot.name} now?`) && router.post(`/admin/bots/${bot.id}/settle`, {}, { preserveScroll: true })}>Settle now</button>
      {bot.followers === 0 && <button type="button" style={{ ...btn, color: '#f6465d' }} onClick={() => window.confirm(`Delete ${bot.name}? Only possible if nobody ever used it.`) && router.post(`/admin/bots/${bot.id}/delete`, {}, { preserveScroll: true })}>Delete</button>}
    </div>
    {list && (list.length === 0 ? <small>No active followers.</small> : <div style={{ display: 'grid', gap: 4 }}>{list.map(f => <div key={f.userId} style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: 13 }}>
      <Link href={`/admin/users/${f.userId}`}>{f.email}</Link><b>{f.capital} USDT</b><small style={{ opacity: .65 }}>since {f.since}{f.auto ? ' · auto-claim' : ''}</small>
      <button type="button" style={{ ...btn, color: '#f6465d', marginLeft: 'auto' }} onClick={() => window.confirm(`Stop ${f.email} and return ${f.capital} USDT to Funding?`) && router.post(`/admin/bots/${bot.id}/followers/${f.userId}/stop`, {}, { preserveScroll: true, onSuccess: load })}>Stop &amp; refund</button></div>)}</div>)}
  </div>;
}

function Row({ bot, kind }: { bot?: BotRow; kind: string }) {
  const trader = kind === 'trader';
  const form = useForm({ kind, bio: bot?.bio ?? '', direction: bot?.direction ?? 'LONG', leverage: String(bot?.leverage ?? 1), id: bot?.id ?? null, name: bot?.name ?? '', pair: bot?.pair ?? 'BTCUSDT', strategy: bot?.strategy ?? 'Futures grid', daily: String(bot?.daily ?? '1'), share: String(bot?.share ?? '0'), min: (bot?.min ?? '10').replace(/,/g, ''), max_per_user: (bot?.maxPerUser ?? '').replace(/,/g, ''), capacity: (bot?.capacity ?? '').replace(/,/g, ''), enabled: bot?.enabled ?? false });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.data.enabled && !window.confirm(`${form.data.name} will pay followers ${form.data.daily}% of their capital every 24h from the platform. ${bot ? 'Completed cycles are paid at the old terms first.' : ''} Continue?`)) return;
    form.post('/admin/bots', { preserveScroll: true, onSuccess: () => { if (!bot) form.reset(); } });
  };
  return <form onSubmit={submit} style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', alignItems: 'end', padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)' }}>
    <label>Name<input {...field} value={form.data.name} onChange={e => form.setData('name', e.target.value)} required maxLength={60}/></label>
    <label>Pair label<input {...field} value={form.data.pair} onChange={e => form.setData('pair', e.target.value.toUpperCase())} required maxLength={24}/></label>
    <label>Strategy<input {...field} value={form.data.strategy} onChange={e => form.setData('strategy', e.target.value)} required maxLength={40}/></label>
    {trader && <><label>Direction label<select {...field} value={form.data.direction} onChange={e => form.setData('direction', e.target.value)}><option>LONG</option><option>SHORT</option></select></label><label>Leverage label<input {...field} inputMode="numeric" value={form.data.leverage} onChange={e => form.setData('leverage', e.target.value)}/></label><label style={{ gridColumn: 'span 2' }}>Bio<input {...field} value={form.data.bio} onChange={e => form.setData('bio', e.target.value)} maxLength={255}/></label></>}
    <label>Daily yield %<input {...field} inputMode="decimal" value={form.data.daily} onChange={e => form.setData('daily', e.target.value)} required/></label>
    <label>Platform share %<input {...field} inputMode="decimal" value={form.data.share} onChange={e => form.setData('share', e.target.value)} required/></label>
    <label>Min. capital<input {...field} inputMode="decimal" value={form.data.min} onChange={e => form.setData('min', e.target.value)} required/></label>
    <label>Max per user<input {...field} inputMode="decimal" placeholder="no limit" value={form.data.max_per_user} onChange={e => form.setData('max_per_user', e.target.value)}/></label>
    <label>Total capacity<input {...field} inputMode="decimal" placeholder="no limit" value={form.data.capacity} onChange={e => form.setData('capacity', e.target.value)}/></label>
    <label style={{ display: 'flex', gap: 8, alignItems: 'center', paddingBottom: 10 }}><input type="checkbox" checked={form.data.enabled} onChange={e => form.setData('enabled', e.target.checked)}/> Open for new followers</label>
    <button type="submit" disabled={form.processing} style={{ padding: '10px 16px', borderRadius: 8, border: 0, fontWeight: 700, background: '#c1f033', color: '#000', cursor: 'pointer' }}>{bot ? 'Save' : trader ? 'Add trader' : 'Add strategy'}</button>
    {bot && <small style={{ gridColumn: '1 / -1', opacity: .75 }}>{bot.followers} followers · {bot.aum} USDT allocated · paid to followers {bot.paid} · kept by platform {bot.kept}</small>}
    {bot && <Tools bot={bot}/>}
    {Object.values(form.errors).map(m => <small key={m} role="alert" style={{ color: '#f6465d', gridColumn: '1 / -1' }}>{m}</small>)}
  </form>;
}

export default function AdminBots({ admin, bots, totals, kind = 'bot' }: { admin: AdminUser; bots: BotRow[]; totals: { aum: string; paid: string }; kind?: string }) {
  const trader = kind === 'trader';
  const flash = (usePage().props as { flash?: { status?: string } }).flash?.status;
  return <AdminLayout admin={admin} active={trader ? '/admin/traders' : '/admin/bots'}><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>{trader ? 'Copy traders' : 'Trading bots'}</h1><p>{trader ? 'Traders users can copy. Their daily return is fixed by you here; direction and leverage are labels only.' : 'Yield strategies users can allocate capital to.'}</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Overview</h2></header><div style={{ padding: '4px 22px 18px' }}><p>Allocated by users: <b>{totals.aum}</b> USDT · Paid to followers so far: <b>{totals.paid}</b> USDT</p>
      <p style={{ opacity: .75, fontSize: 13 }}>Each completed 24h cycle pays capital × daily yield, minus the platform share, into the follower's Funding account. The profit is paid from the platform, so keep a reserve. The numbers users see (yield, followers, allocated, runtime) are exactly these — nothing is simulated. Changing yield or share first pays completed cycles at the old terms. Strategies are created switched off.</p></div></section>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>{flash && <p role="status" style={{ color: '#2ebd85' }}>{flash}</p>}<header><h2>Strategies</h2></header>
      {bots.length === 0 && <p>No strategies yet. Add the first one below.</p>}
      {bots.map(b => <Row key={b.id} bot={b} kind={kind}/>)}
      <h3 style={{ marginTop: 20 }}>{trader ? 'Add a trader' : 'Add a strategy'}</h3><Row kind={kind}/></div></section>
  </div></AdminLayout>;
}
