import { Link, useForm, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type BotRow = { bio?: string | null; direction?: string; leverage?: number; id: number; name: string; pair: string; strategy: string; daily: number; share: number; min: string; enabled: boolean; followers: number; aum: string; paid: string; kept: string };
const field = { style: { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '9px 10px', font: 'inherit', width: '100%' } } as const;

function Row({ bot, kind }: { bot?: BotRow; kind: string }) {
  const trader = kind === 'trader';
  const form = useForm({ kind, bio: bot?.bio ?? '', direction: bot?.direction ?? 'LONG', leverage: String(bot?.leverage ?? 1), id: bot?.id ?? null, name: bot?.name ?? '', pair: bot?.pair ?? 'BTCUSDT', strategy: bot?.strategy ?? 'Futures grid', daily: String(bot?.daily ?? '1'), share: String(bot?.share ?? '0'), min: (bot?.min ?? '10').replace(/,/g, ''), enabled: bot?.enabled ?? false });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.data.enabled && !window.confirm(`${form.data.name} will pay followers ${form.data.daily}% of their capital every 24h from the platform. ${bot ? 'Completed cycles are paid at the old terms first.' : ''} Continue?`)) return;
    form.post('/admin/bots', { preserveScroll: true, onSuccess: () => { if (!bot) form.reset(); } });
  };
  return <form onSubmit={submit} style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', alignItems: 'end', padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)' }}>
    <label>Name<input {...field} value={form.data.name} onChange={e => form.setData('name', e.target.value)} required maxLength={60}/></label>
    <label>Pair label<input {...field} value={form.data.pair} onChange={e => form.setData('pair', e.target.value.toUpperCase())} required maxLength={24}/></label>
    <label>Strategy<input {...field} value={form.data.strategy} onChange={e => form.setData('strategy', e.target.value)} required maxLength={40}/></label>
    {trader && <><label>Direction label<select {...field} value={form.data.direction} onChange={e => form.setData('direction', e.target.value)}><option>LONG</option><option>SHORT</option></select></label><label>Leverage label<input {...field} inputMode="numeric" value={form.data.leverage} onChange={e => form.setData('leverage', e.target.value)}/></label><label style={{ gridColumn: 'span 2' }}>Bio<input {...field} value={form.data.bio} onChange={e => form.setData('bio', e.target.value)} maxLength={255}/></label></>}
    <label>Daily yield %<input {...field} inputMode="decimal" value={form.data.daily} onChange={e => form.setData('daily', e.target.value)} required/></label>
    <label>Platform share %<input {...field} inputMode="decimal" value={form.data.share} onChange={e => form.setData('share', e.target.value)} required/></label>
    <label>Min. capital<input {...field} inputMode="decimal" value={form.data.min} onChange={e => form.setData('min', e.target.value)} required/></label>
    <label style={{ display: 'flex', gap: 8, alignItems: 'center', paddingBottom: 10 }}><input type="checkbox" checked={form.data.enabled} onChange={e => form.setData('enabled', e.target.checked)}/> Open for new followers</label>
    <button type="submit" disabled={form.processing} style={{ padding: '10px 16px', borderRadius: 8, border: 0, fontWeight: 700, background: '#c1f033', color: '#000', cursor: 'pointer' }}>{bot ? 'Save' : trader ? 'Add trader' : 'Add strategy'}</button>
    {bot && <small style={{ gridColumn: '1 / -1', opacity: .75 }}>{bot.followers} followers · {bot.aum} USDT allocated · paid to followers {bot.paid} · kept by platform {bot.kept}</small>}
    {Object.values(form.errors).map(m => <small key={m} role="alert" style={{ color: '#f6465d', gridColumn: '1 / -1' }}>{m}</small>)}
  </form>;
}

export default function AdminBots({ admin, bots, totals, kind = 'bot' }: { admin: AdminUser; bots: BotRow[]; totals: { aum: string; paid: string }; kind?: string }) {
  const trader = kind === 'trader';
  const flash = (usePage().props as { flash?: { status?: string } }).flash?.status;
  return <AdminLayout admin={admin} active={trader ? '/admin/traders' : '/admin/bots'}><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>{trader ? 'Copy traders' : 'Trading bots'}</h1><p>{trader ? 'Traders users can copy. Their daily return is fixed by you here; direction and leverage are labels only.' : 'Yield strategies users can allocate capital to.'}</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Overview</h2></header><div style={{ padding: '4px 22px 18px' }}><p>Allocated by users: <b>{totals.aum}</b> USDT · Paid to followers so far: <b>{totals.paid}</b> USDT</p>
      <p style={{ opacity: .75, fontSize: 13 }}>Each completed 24h cycle pays capital × daily yield, minus the platform share, into the follower's Funding account. The profit is paid from the platform, so keep a reserve. The numbers users see (yield, followers, allocated, runtime) are exactly these — nothing is simulated. Changing yield or share first pays completed cycles at the old terms. Strategies are created switched off.</p></div></section>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>{flash && <p role="status" style={{ color: '#2ebd85' }}>{flash}</p>}<header><h2>Strategies</h2></header>
      {bots.length === 0 && <p>No strategies yet. Add the first one below.</p>}
      {bots.map(b => <Row key={b.id} bot={b} kind={kind}/>)}
      <h3 style={{ marginTop: 20 }}>{trader ? 'Add a trader' : 'Add a strategy'}</h3><Row kind={kind}/></div></section>
  </div></AdminLayout>;
}
