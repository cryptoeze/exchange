import { Link } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import TwoFactorPanel from '../../components/TwoFactorPanel';
import { AdminLayout, type AdminUser } from './Layout';

type Ev = { ok: boolean; note: string | null; ip: string | null; agent: string | null; at: string };
export default function AdminSecurity({ admin, twoFactor, history }: { admin: AdminUser; twoFactor: boolean; history: Ev[] }) {
  return <AdminLayout admin={admin} active="/admin/security"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>My security</h1><p>Protect this admin account with an authenticator app.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Two-factor authentication</h2></header><div style={{ padding: '0 22px 22px' }}><TwoFactorPanel enabled={twoFactor} admin/></div></section>
    <section className="admin-panel"><header><h2>Recent admin sign-ins</h2></header><div style={{ padding: '0 22px 18px' }}>
      {history.length === 0 ? <p style={{ opacity: .7 }}>Nothing recorded yet.</p> : history.map((e, i) => <div key={i} style={{ borderTop: '1px solid rgba(128,128,128,.2)', padding: '9px 0', fontSize: 13 }}><b style={{ color: e.ok ? undefined : '#f6465d' }}>{e.ok ? 'Signed in' : 'Failed attempt'}{e.note ? ` · ${e.note}` : ''}</b> · {e.ip} · {e.at}<br/><small style={{ opacity: .6 }}>{e.agent}</small></div>)}
    </div></section>
  </div></AdminLayout>;
}
