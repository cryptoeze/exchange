import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Dis = { ref: string; status: string; outcome: string | null; reason: string; coin: string; qty: string; fiat: string; fiatAmount: number; method: string; buyer: string; seller: string; openedBy: string; at: string; note: string | null };
type Ord = { ref: string; status: string; coin: string; qty: string; fiat: string; fiatAmount: number; method: string; buyer: string; seller: string; at: string };
type Ad = { id: number; user: string; userId: number; side: string; coin: string; fiat: string; price: number; available: string; status: string };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;

function Dispute({ d }: { d: Dis }) {
  const [note, setNote] = useState('');
  const go = (outcome: 'release' | 'refund') => window.confirm(outcome === 'release' ? `Release ${d.qty} ${d.coin} to the BUYER (${d.buyer})?` : `Return ${d.qty} ${d.coin} to the SELLER (${d.seller})?`) && router.post(`/admin/p2p/${d.ref}/resolve`, { outcome, note } as never, { preserveScroll: true });
  return <div style={{ borderTop: '1px solid rgba(128,128,128,.2)', padding: '14px 0', display: 'grid', gap: 6 }}>
    <div><b>{d.ref}</b> · {d.status === 'open' ? <b style={{ color: '#f6465d' }}>OPEN</b> : <span>resolved ({d.outcome})</span>} · {d.at}</div>
    <div>{d.qty} {d.coin} for {d.fiatAmount} {d.fiat} via {d.method}</div><div>Buyer: {d.buyer} · Seller: {d.seller} · opened by the {d.openedBy}</div>
    <div style={{ opacity: .85 }}>Reason: “{d.reason}”</div>
    {d.status === 'open' ? <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><input style={{ ...input, flex: '1 1 220px' }} placeholder="Note (shown in the chat)" value={note} onChange={e => setNote(e.target.value)}/><button type="button" style={{ ...input, background: '#0ecb81', color: '#fff', border: 0, fontWeight: 700, cursor: 'pointer' }} onClick={() => go('release')}>Release to buyer</button><button type="button" style={{ ...input, background: '#f6465d', color: '#fff', border: 0, fontWeight: 700, cursor: 'pointer' }} onClick={() => go('refund')}>Refund seller</button></div> : d.note && <small>{d.note}</small>}
  </div>;
}

export default function AdminP2p({ admin, tab, rows, counts }: { admin: AdminUser; tab: string; rows: Array<Dis | Ord | Ad>; counts: { disputes: number; active: number } }) {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  return <AdminLayout admin={admin} active="/admin/p2p"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>P2P desk</h1><p>{counts.disputes} open disputes · {counts.active} active orders. Coins in an order stay locked until released, refunded or decided here.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>
      <div style={{ display: 'flex', gap: 8, padding: '14px 0' }}>{['disputes', 'orders', 'ads'].map(t => <Link key={t} href={`/admin/p2p?tab=${t}`} style={{ ...input, textDecoration: 'none', fontWeight: t === tab ? 800 : 400 }}>{t}</Link>)}</div>
      {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}
      {rows.length === 0 && <p style={{ opacity: .7 }}>Nothing here.</p>}
      {tab === 'disputes' && (rows as Dis[]).map(d => <Dispute key={d.ref} d={d}/>)}
      {tab === 'orders' && (rows as Ord[]).map(o => <div key={o.ref} style={{ borderTop: '1px solid rgba(128,128,128,.2)', padding: '10px 0', fontSize: 13 }}><b>{o.ref}</b> · {o.status} · {o.qty} {o.coin} ↔ {o.fiatAmount} {o.fiat} ({o.method})<br/><small style={{ opacity: .7 }}>buyer {o.buyer} · seller {o.seller} · {o.at}</small></div>)}
      {tab === 'ads' && (rows as Ad[]).map(a => <div key={a.id} style={{ borderTop: '1px solid rgba(128,128,128,.2)', padding: '10px 0', fontSize: 13, display: 'flex', gap: 10, alignItems: 'center' }}><span>#{a.id} · <Link href={`/admin/users/${a.userId}`}>{a.user}</Link> · {a.side} {a.coin} @ {a.price} {a.fiat} · open {a.available} · {a.status}</span><button type="button" style={{ ...input, marginLeft: 'auto', color: '#f6465d', cursor: 'pointer' }} onClick={() => window.confirm('Force-close this ad and return unused coins?') && router.post(`/admin/p2p/ads/${a.id}/close`, {}, { preserveScroll: true })}>Close</button></div>)}
    </div></section>
  </div></AdminLayout>;
}
