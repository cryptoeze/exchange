import { router } from '@inertiajs/react';
import { useEffect, useState } from 'react';
import {
  Activity, ArrowDownToLine, ArrowUpFromLine, Bot, CandlestickChart,
  Leaf, ShieldCheck, Users, Wallet,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type Signup = { id: number; name: string; email: string; verified: boolean; kyc?: string; joined: string | null };
type Trade = { user: string; pair: string; side: string; value: string; kind: string; at: string };
type DashboardData = {
  users: { available: boolean; total: number | null; today: number | null; latest: Signup[] };
  kyc: { available: boolean; pending: number | null; verified: number | null };
  funding: { available: boolean; total_usdt: string | null };
  trading_wallet: { available: boolean; total_usdt: string | null };
  staking: { available: boolean; total_usdt: string | null };
  deposits: { available: boolean; volume_30d: string | null; pending_count: number | null };
  withdrawals: { available: boolean; pending_count: number | null };
  trades: { available: boolean; count_30d: number | null; latest: Trade[] };
  queues?: { tickets: number; disputes: number; positions: number; limit_orders: number };
  generated_at?: string;
  bots: { available: boolean; active_follows: number | null; aum: string | null };
};
type Props = { admin: AdminUser; data: DashboardData | null; loadError: string | null };
type Metric = { label: string; value: string; note: string; icon: LucideIcon; tone: string };

function number(value: number | null | undefined) { return value == null ? '—' : value.toLocaleString(); }
function money(value: string | null | undefined) {
  const match = value?.match(/^(-?)(\d+)(?:\.(\d{1,8}))?$/);
  if (!match) return '—';
  const [, sign, wholeInput, fractionInput = ''] = match;
  let whole = wholeInput;
  let cents = (fractionInput + '00').slice(0, 2);
  if ((fractionInput[2] ?? '0') >= '5') {
    const combined = `${whole}${cents}`.split('').map(Number);
    for (let index = combined.length - 1; index >= 0; index--) {
      combined[index] += 1;
      if (combined[index] < 10) break;
      combined[index] = 0;
      if (index === 0) combined.unshift(1);
    }
    const rounded = combined.join('').padStart(3, '0');
    whole = rounded.slice(0, -2);
    cents = rounded.slice(-2);
  }
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${sign === '-' ? '-$' : '$'}${grouped}.${cents}`;
}

function MetricCard({ label, value, note, icon: Icon, tone }: Metric) {
  return <article className="admin-metric"><div className={`admin-metric-icon ${tone}`}><Icon aria-hidden="true"/></div><span className="admin-metric-label">{label}</span><b title={value}>{value}</b><small>{note}</small></article>;
}

export default function AdminDashboard({ admin, data, loadError }: Props) {
  const metrics: Metric[] = [
    { label: 'Total users', value: data?.users.available ? number(data.users.total) : '—', note: data?.users.available ? `${number(data.users.today)} today` : 'User data unavailable', icon: Users, tone: 'violet' },
    { label: 'KYC pending', value: data?.kyc.available ? number(data.kyc.pending) : '—', note: data?.kyc.available ? `${number(data.kyc.verified)} verified` : 'KYC is not configured', icon: ShieldCheck, tone: 'yellow' },
    { label: 'Total funding (USDT)', value: data?.funding.available ? money(data.funding.total_usdt) : '—', note: 'Sum of user balances', icon: Wallet, tone: 'green' },
    { label: 'Trading wallet', value: data?.trading_wallet.available ? money(data.trading_wallet.total_usdt) : '—', note: 'Capital allocated to trading', icon: Activity, tone: 'green' },
    { label: 'Total staked', value: data?.staking.available ? money(data.staking.total_usdt) : '—', note: 'Locked in earn products', icon: Leaf, tone: 'lime' },
    { label: 'Deposits 30d', value: data?.deposits.available ? money(data.deposits.volume_30d) : '—', note: data?.deposits.available ? `${number(data.deposits.pending_count)} pending` : 'Deposit records not configured', icon: ArrowDownToLine, tone: 'blue' },
    { label: 'Withdrawals queue', value: data?.withdrawals.available ? number(data.withdrawals.pending_count) : '—', note: data?.withdrawals.available ? 'Pending admin review' : 'Withdrawal records not configured', icon: ArrowUpFromLine, tone: 'yellow' },
    { label: 'Trades 30d', value: data?.trades.available ? number(data.trades.count_30d) : '—', note: 'Spot + futures activity', icon: CandlestickChart, tone: 'blue' },
    { label: 'Active bot follows', value: data?.bots.available ? number(data.bots.active_follows) : '—', note: data?.bots.available ? `Bot AUM ${money(data.bots.aum)}` : 'Bot data not configured', icon: Bot, tone: 'lime' },
  ];
  const [live, setLive] = useState(true);
  useEffect(() => {
    if (!live) return;
    const id = window.setInterval(() => { if (!document.hidden) router.reload({ only: ['data', 'loadError'] }); }, 15000);
    return () => window.clearInterval(id);
  }, [live]);
  const q = data?.queues;
  const retry = () => router.reload({ only: ['data', 'loadError'] });

  return <AdminLayout admin={admin} active="/admin" userCount={data?.users.total}>
    <div className="admin-content">
      <div className="admin-heading"><div><h1>Operations Dashboard</h1><p>High-level state of the platform. Live data, refreshed every 15 seconds{data?.generated_at ? ` · last update ${data.generated_at}` : ''}.</p></div><button className="admin-live-btn" onClick={() => setLive(v => !v)}>{live ? '● Live' : '○ Paused'}</button></div>
      {q && <div className="admin-queues">
        <a href="/admin/withdrawals"><b>{number(data?.withdrawals.pending_count)}</b><span>Withdrawals pending</span></a>
        <a href="/admin/kyc"><b>{number(data?.kyc.pending)}</b><span>KYC to review</span></a>
        <a href="/admin/tickets"><b>{q.tickets}</b><span>Open tickets</span></a>
        <a href="/admin/p2p"><b>{q.disputes}</b><span>P2P disputes</span></a>
        <a href="/admin/futures"><b>{q.positions}</b><span>Open positions</span></a>
        <a href="/admin/trades"><b>{q.limit_orders}</b><span>Limit orders</span></a>
      </div>}
      {loadError && <div className="admin-error" role="alert"><div><b>Dashboard data unavailable</b><p>{loadError}</p></div><button onClick={retry}>Retry</button></div>}
      <div className="admin-metrics">{metrics.map(metric => <MetricCard key={metric.label} {...metric}/>)}</div>
      <div className="admin-panels">
        <section className="admin-panel" aria-labelledby="signups-heading"><header><h2 id="signups-heading">Latest signups</h2><a href="/admin/users">View all <span aria-hidden="true">→</span></a></header>
          <div className="admin-table-wrap" role="table" aria-label="Latest user signups"><div className="admin-table-head admin-signup-cols" role="row"><span role="columnheader">EMAIL</span><span role="columnheader">KYC</span><span role="columnheader">JOINED</span></div>
            {!data?.users.available ? <div className="admin-empty" role="row">User records could not be loaded.</div> : data.users.latest.length === 0 ? <div className="admin-empty" role="row">No users have registered yet.</div> : <div className="admin-table-body">{data.users.latest.map(user => <div className="admin-table-row admin-signup-cols" role="row" key={user.id}><a role="cell" className="admin-email" href={`/admin/users/${user.id}`} title={user.email}>{user.email}</a><span role="cell"><span className={`admin-status ${user.kyc === 'approved' ? 'ok' : 'neutral'}`}>{user.kyc === 'approved' ? 'Verified' : user.kyc === 'pending' ? 'Pending' : 'None'}</span></span><time role="cell" dateTime={user.joined ?? undefined}>{user.joined ?? '—'}</time></div>)}</div>}
          </div>
        </section>
        <section className="admin-panel" aria-labelledby="trades-heading"><header><h2 id="trades-heading">Latest trades</h2><a href="/admin/trades">View all <span aria-hidden="true">→</span></a></header>
          <div className="admin-table-wrap" role="table" aria-label="Latest trades"><div className="admin-table-head admin-trade-cols" role="row"><span role="columnheader">USER</span><span role="columnheader">PAIR</span><span role="columnheader">SIDE</span><span role="columnheader">PNL</span></div>{data?.trades.latest.length ? <div className="admin-table-body">{data.trades.latest.map((t, i) => <div className="admin-table-row admin-trade-cols" role="row" key={i}><span role="cell" title={t.user}>{t.user}</span><span role="cell">{t.pair}</span><span role="cell">{t.side}</span><span role="cell">{t.value}</span></div>)}</div> : <div className="admin-empty" role="row">No trades have been recorded yet.</div>}</div>
        </section>
      </div>
      <footer className="admin-footnote"><span>Signed in as {admin.email}</span><span className="admin-data-note">All figures are live from your database.</span></footer>
    </div>
  </AdminLayout>;
}
