import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const btn = { ...input, background: '#c1f033', color: '#000', fontWeight: 700, cursor: 'pointer', border: 0 } as const;
function Flash() { const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> }; return <>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}</>; }

type Row = { id: number; userId: number; user: string; name: string; country: string; docType: string; docNumber: string; status: string; reason: string | null; at: string };
function Line({ k }: { k: Row }) {
  const [why, setWhy] = useState('');
  const act = (decision: 'approve' | 'reject') => router.post(`/admin/kyc/${k.id}`, { decision, reason: why } as never, { preserveScroll: true });
  return <div style={{ padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)', display: 'grid', gap: 8 }}>
    <div><b>#{k.id}</b> · <Link href={`/admin/users/${k.userId}`}>{k.user}</Link> · {k.at} · <b>{k.status}</b></div>
    <div>{k.name} · {k.country} · {k.docType.replace('_', ' ')} · <code>{k.docNumber}</code></div>
    <div style={{ display: 'flex', gap: 10 }}>{['front', 'selfie'].map(w => <a key={w} href={`/admin/kyc/${k.id}/${w}`} target="_blank" rel="noreferrer"><img src={`/admin/kyc/${k.id}/${w}`} alt={w} style={{ width: 150, height: 110, objectFit: 'cover', borderRadius: 8, border: '1px solid rgba(128,128,128,.3)' }}/></a>)}</div>
    {k.status === 'pending' ? <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><button type="button" style={btn} onClick={() => act('approve')}>Approve</button><input style={{ ...input, flex: '1 1 180px' }} placeholder="Reject reason" value={why} onChange={e => setWhy(e.target.value)}/><button type="button" style={{ ...input, color: '#f6465d', cursor: 'pointer' }} onClick={() => act('reject')}>Reject</button></div> : k.reason && <small style={{ opacity: .75 }}>{k.reason}</small>}
  </div>;
}
export default function AdminKyc({ admin, rows, status, pending }: { admin: AdminUser; rows: Row[]; status: string; pending: number }) {
  return <AdminLayout admin={admin} active="/admin/kyc"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>KYC review</h1><p>{pending} waiting for review.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>
      <div style={{ display: 'flex', gap: 8, padding: '14px 0' }}>{['pending', 'approved', 'rejected'].map(s => <Link key={s} href={`/admin/kyc?status=${s}`} style={{ ...input, textDecoration: 'none', fontWeight: s === status ? 800 : 400 }}>{s}</Link>)}</div>
      <Flash/>{rows.length === 0 ? <p style={{ opacity: .7 }}>Nothing here.</p> : rows.map(k => <Line key={k.id} k={k}/>)}
    </div></section>
  </div></AdminLayout>;
}
