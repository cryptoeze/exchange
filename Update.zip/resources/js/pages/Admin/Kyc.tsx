import { AdminLayout, type AdminUser } from './Layout';
import { ActionButton, Badge, FilterBar, KV, Page, Pager, Panel, Stats, Tabs, UserLink, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; account: string; name: string; country: string; phone: string | null; hasBack: boolean; docType: string; docNumber: string; status: string; reason: string | null; at: string };
type Props = { admin: AdminUser; rows: Row[]; status: string; pager: Paged; filters: Record<string, string>; counts: { pending: number; approved: number; rejected: number } };

export default function AdminKyc({ admin, rows, status, pager, filters, counts }: Props) {
  return <AdminLayout admin={admin} active="/admin/kyc">
    <Page title="KYC review" subtitle="Check the documents against the details, then approve or reject. The user is notified by bell and email, and gets a verified tick when approved.">
      <Stats items={[{ label: 'Waiting for review', value: counts.pending, tone: counts.pending ? 'warn' : undefined }, { label: 'Approved', value: counts.approved, tone: 'ok' }, { label: 'Rejected', value: counts.rejected }]}/>
      <Tabs base="/admin/kyc" param="status" active={status} tabs={[{ key: 'pending', label: 'Pending', count: counts.pending, tone: 'warn' }, { key: 'approved', label: 'Approved' }, { key: 'rejected', label: 'Rejected' }, { key: 'all', label: 'All' }]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}><FilterBar url="/admin/kyc" hidden={{ status }} values={filters} defs={[
          { name: 'q', type: 'search', placeholder: 'Email, name on document, document number or phone' }, { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
        ]}/></div>
        {rows.length === 0 ? <div className="au-empty">{status === 'pending' ? 'No identity checks are waiting. 🎉' : 'Nothing here.'}</div> : rows.map(k => <div key={k.id} style={{ padding: '18px 20px', borderTop: '1px solid var(--ad-line)', display: 'grid', gap: 12 }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}><b>#{k.id}</b><Badge>{k.status}</Badge><UserLink id={k.userId} name={k.account} email={k.email}/><span style={{ color: 'var(--ad-muted)', fontSize: 13, marginLeft: 'auto' }}>{k.at}</span></div>
          <KV items={[['Name on document', k.name], ['Country', k.country], ['Phone', k.phone], ['Reject reason', k.reason]]}/>
          <div className="au-img-row">{['front', 'back'].map(w => <a key={w} href={`/admin/kyc/${k.id}/${w}`} target="_blank" rel="noreferrer" title={`Open ${w} photo`}><img src={`/admin/kyc/${k.id}/${w}`} alt={w}/></a>)}</div>
          {k.status === 'pending' && <div style={{ display: 'flex', gap: 8 }}>
            <ActionButton label="Approve" variant="ok" url={`/admin/kyc/${k.id}`} data={{ decision: 'approve' }} confirmText="Approve this identity verification?"/>
            <ActionButton label="Reject" variant="danger" url={`/admin/kyc/${k.id}`} data={{ decision: 'reject' }} title="Reject KYC" fields={[{ name: 'reason', label: 'Reason shown to the user', placeholder: 'e.g. Photo is blurry', required: true, type: 'textarea' }]}/></div>}
        </div>)}
        <Pager p={pager} url="/admin/kyc"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
