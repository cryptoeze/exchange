import { Link } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; email: string; code: string; invited: number; earned: string };
export default function AdminReferrals({ admin, rows, percent }: { admin: AdminUser; rows: Row[]; percent: number }) {
  return <AdminLayout admin={admin} active="/admin/referrals"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Referrals</h1><p>Commission is {percent > 0 ? percent + '% of every credited deposit' : 'OFF'} — change it in Settings.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '8px 22px 22px', overflowX: 'auto' }}>
      {rows.length === 0 ? <p style={{ opacity: .7 }}>Nobody has used a referral code yet.</p> : <table style={{ width: '100%', borderCollapse: 'collapse' }}><thead><tr style={{ textAlign: 'left', opacity: .7 }}><th>User</th><th>Code</th><th>Invited</th><th>Commission earned</th></tr></thead>
        <tbody>{rows.map(r => <tr key={r.id} style={{ borderTop: '1px solid rgba(128,128,128,.2)' }}><td style={{ padding: '10px 6px' }}><Link href={`/admin/users/${r.id}`}>{r.email}</Link></td><td><code>{r.code}</code></td><td>{r.invited}</td><td>{r.earned}</td></tr>)}</tbody></table>}
    </div></section>
  </div></AdminLayout>;
}
