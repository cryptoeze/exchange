import { AdminLayout, type AdminUser } from './Layout';
import { Badge, DataTable, FilterBar, Page, Pager, Panel, Stats, UserLink, group, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; name: string; email: string; code: string | null; invited: number; earned: string };
export default function AdminReferrals({ admin, rows, percent, pager, filters, stats }: { admin: AdminUser; rows: Row[]; percent: number; pager: Paged; filters: Record<string, string>; stats: { referrers: number; referred: number; paid: string } }) {
  const cols: Col<Row>[] = [
    { key: 'u', label: 'Referrer', primary: true, render: r => <UserLink id={r.id} name={r.name} email={r.email}/> }, { key: 'code', label: 'Code', render: r => r.code ?? '—' },
    { key: 'invited', label: 'Friends invited', align: 'right', render: r => <b>{r.invited}</b> }, { key: 'earned', label: 'Earned', align: 'right', render: r => group(r.earned) },
  ];
  return <AdminLayout admin={admin} active="/admin/referrals">
    <Page title="Referrals" subtitle={<>Commission is <Badge tone={percent > 0 ? 'ok' : 'muted'}>{percent > 0 ? `${percent}% of each credited deposit` : 'off (0%)'}</Badge> — change it in Settings → Bonuses &amp; rewards.</>}>
      <Stats items={[{ label: 'Active referrers', value: stats.referrers }, { label: 'Users referred', value: stats.referred }, { label: 'Commission paid', value: `$${group(stats.paid)}`, tone: 'ok' }]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}><FilterBar url="/admin/referrals" values={filters} defs={[{ name: 'q', type: 'search', placeholder: 'Referrer email, name or code' }]}/></div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} rowHref={r => `/admin/users/${r.id}?tab=referrals`} empty="Nobody has invited a friend yet."/>
        <Pager p={pager} url="/admin/referrals"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
