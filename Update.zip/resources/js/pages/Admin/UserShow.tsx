import { Link, router, useForm } from '@inertiajs/react';
import { useMemo, useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
import { ActionButton, Badge, Copy, DataTable, Field, FilterBar, Flash, Input, KV, Pager, Panel, Select, Stats, Tabs, group, signed, usd, type Col, type Paged } from '../../admin/kit';

/* ───────── types (mirror App\Http\Controllers\Admin\UsersController) ───────── */
type U = { id: number; uid: number; name: string; email: string; role: string; status: string; kyc: string; verified: boolean; phone: string | null; country: string | null; twoFactor: boolean; joined: string | null; referralCode: string | null; referredBy: { id: number; label: string } | null };
type Summary = { totalUsdt: string; funding: string; trading: string; futures: string; deposited: string; withdrawn: string; spotTrades: number; futuresTrades: number; openPositions: number; invited: number; lastLogin: string | null; lastIp: string | null };
type Ledger = { id: number; type: string; account: string; asset: string; amount: string; after: string; note: string | null; at: string };
type Login = { id: number; ok: boolean; area: string; note: string | null; ip: string | null; agent: string | null; at: string };
type Props = { admin: AdminUser; tab: string; counts: { deposits: number; withdrawals: number; kyc: number; support: number }; user: U; summary: Summary; data: any }; // eslint-disable-line @typescript-eslint/no-explicit-any
const nice = (t: string) => t.replace(/_/g, ' ');
const initials = (n: string) => n.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || 'U';
const short = (v: string) => v.length > 24 ? `${v.slice(0, 10)}…${v.slice(-8)}` : v;
const BASE = (u: U) => `/admin/users/${u.id}`;

/* ───────── tabs ───────── */
function Overview({ u, s, d }: { u: U; s: Summary; d: { ledger: Ledger[]; logins: Login[]; kyc: { id: number; status: string; name: string; country: string; at: string } | null } }) {
  const ledgerCols: Col<Ledger>[] = [
    { key: 'at', label: 'Time' }, { key: 'type', label: 'Type', render: r => nice(r.type) }, { key: 'account', label: 'Account', hideOnPhone: true },
    { key: 'amount', label: 'Amount', align: 'right', render: r => <>{signed(r.amount)} <small>{r.asset}</small></> },
  ];
  return <>
    <div className="au-grid-2">
      <Panel title="Account details"><KV items={[
        ['User ID / UID', `${u.id} / ${u.uid}`], ['Email', <>{u.email} <Badge tone={u.verified ? 'ok' : 'muted'}>{u.verified ? 'verified' : 'not verified'}</Badge></>], ['Mobile', u.phone ?? '—'], ['Country', u.country ?? '—'], ['Joined', u.joined], ['Role', u.role],
        ['Referral code', u.referralCode ? <Copy text={u.referralCode}/> : '—'], ['Referred by', u.referredBy ? <Link href={`/admin/users/${u.referredBy.id}`}>{u.referredBy.label}</Link> : '—'],
        ['Friends invited', s.invited], ['Two-factor', <Badge tone={u.twoFactor ? 'ok' : 'muted'}>{u.twoFactor ? 'on' : 'off'}</Badge>], ['Last login', s.lastLogin ? `${s.lastLogin} · ${s.lastIp ?? ''}` : 'never'],
      ]}/></Panel>
      <Panel title="Identity (KYC)" actions={<Link className="au-btn sm" href={`${BASE(u)}?tab=kyc`}>Open KYC tab</Link>}>
        {d.kyc ? <KV items={[['Status', <Badge>{d.kyc.status}</Badge>], ['Name on document', d.kyc.name], ['Country', d.kyc.country], ['Submitted', d.kyc.at]]}/> : <p style={{ margin: 0, color: 'var(--ad-muted)' }}>This user has not submitted identity documents.</p>}
      </Panel>
    </div>
    <Panel title="Latest wallet activity" flush actions={<Link className="au-btn sm" href={`${BASE(u)}?tab=wallet`}>Full wallet & ledger</Link>}><DataTable cols={ledgerCols} rows={d.ledger} rowKey={r => r.id} empty="No wallet activity yet."/></Panel>
    <Panel title="Recent sign-ins" flush actions={<Link className="au-btn sm" href={`${BASE(u)}?tab=security`}>All sign-ins</Link>}><LoginTable rows={d.logins}/></Panel>
  </>;
}

function LoginTable({ rows }: { rows: Login[] }) {
  const cols: Col<Login>[] = [
    { key: 'at', label: 'Time' }, { key: 'ok', label: 'Result', render: r => <Badge tone={r.ok ? 'ok' : 'bad'}>{r.ok ? 'success' : 'failed'}</Badge> },
    { key: 'ip', label: 'IP', render: r => r.ip ?? '—' }, { key: 'agent', label: 'Device', hideOnPhone: true, wide: true, render: r => <small>{r.agent ?? '—'}</small> }, { key: 'note', label: 'Note', render: r => r.note ?? '' },
  ];
  return <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty="No sign-ins recorded."/>;
}

function AdjustForm({ u }: { u: U }) {
  const key = useMemo(() => globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`, []);
  const f = useForm({ action: 'credit', account: 'funding', asset: 'USDT', amount: '', note: '', idempotency_key: key });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.confirm(`${f.data.action === 'credit' ? 'CREDIT' : 'DEBIT'} ${f.data.amount} ${f.data.asset} (${f.data.account}) ${f.data.action === 'credit' ? 'to' : 'from'} ${u.email}?\n\nThis is recorded in the audit log.`)) return;
    f.post(`/admin/users/${u.id}/wallet`, { preserveScroll: true, onSuccess: () => f.setData(d => ({ ...d, amount: '', note: '', idempotency_key: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}` })) });
  };
  return <form onSubmit={submit} className="au-form" style={{ gridTemplateColumns: 'repeat(4,minmax(0,1fr))' }}>
    <Field label="Action"><Select value={f.data.action} onChange={e => f.setData('action', e.target.value)}><option value="credit">Credit (add)</option><option value="debit">Debit (deduct)</option></Select></Field>
    <Field label="Wallet"><Select value={f.data.account} onChange={e => f.setData('account', e.target.value)}><option value="funding">Funding</option><option value="trading">Trading</option><option value="copy">Copy trading</option></Select></Field>
    <Field label="Coin"><Input value={f.data.asset} maxLength={16} required onChange={e => f.setData('asset', e.target.value.toUpperCase())}/></Field>
    <Field label="Amount"><Input inputMode="decimal" placeholder="0.00" required value={f.data.amount} onChange={e => f.setData('amount', e.target.value)}/></Field>
    <Field label="Reason (required — kept in the audit log)" wide><Input maxLength={200} required value={f.data.note} onChange={e => f.setData('note', e.target.value)} placeholder="e.g. Promotion bonus / correction for ticket #12"/></Field>
    <div className="au-form-actions"><button type="submit" className={`au-btn ${f.data.action === 'credit' ? 'primary' : 'danger'}`} disabled={f.processing}>{f.processing ? 'Applying…' : f.data.action === 'credit' ? 'Credit wallet' : 'Debit wallet'}</button></div>
  </form>;
}

function Wallet({ u, d }: { u: U; d: { balances: Array<{ account: string; asset: string; balance: string }>; ledger: Ledger[]; pager: Paged; filters: Record<string, string>; assets: string[]; categories: Array<[string, string]> } }) {
  const cols: Col<Ledger>[] = [
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> }, { key: 'type', label: 'Type', primary: true, render: r => nice(r.type) }, { key: 'account', label: 'Wallet', hideOnPhone: true },
    { key: 'amount', label: 'Amount', align: 'right', render: r => <>{signed(r.amount)} <small>{r.asset}</small></> }, { key: 'after', label: 'Balance after', align: 'right', hideOnPhone: true },
    { key: 'note', label: 'Note', wide: true, render: r => r.note ?? '—' },
  ];
  return <>
    <Panel title="Balances" hint="Every wallet this user holds. Funding is the main wallet; Trading/Copy are for trading; Hold = reserved by open orders.">
      {d.balances.length === 0 ? <p style={{ margin: 0, color: 'var(--ad-muted)' }}>This user has no balance yet.</p> : <div className="au-wallet-grid">{d.balances.map(b => <div className="au-wallet-card" key={b.account + b.asset}><small>{b.account} · {b.asset}</small><b>{group(b.balance)}</b></div>)}</div>}
    </Panel>
    <Panel title="Add or remove balance" hint="Manual credit / debit. Always journaled in the ledger and the audit log."><AdjustForm u={u}/></Panel>
    <Panel title="Wallet ledger" flush>
      <div style={{ padding: '16px 16px 2px' }}><FilterBar url={BASE(u)} hidden={{ tab: 'wallet' }} values={d.filters} defs={[
        { name: 'cat', type: 'select', options: [['', 'All categories'], ...d.categories] }, { name: 'asset', type: 'select', options: [['', 'All coins'], ...d.assets.map(a => [a, a] as [string, string])] },
        { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
      ]}/></div>
      <DataTable cols={cols} rows={d.ledger} rowKey={r => r.id} empty="No ledger entries match."/>
      <Pager p={d.pager} url={BASE(u)}/>
    </Panel>
  </>;
}

type Dep = { id: number; asset: string; network: string; amount: string; credited: string | null; status: string; ref: string | null; at: string; reason?: string | null };
function Deposits({ u, d }: { u: U; d: { sub: string; rows: Dep[]; pager: Paged } }) {
  const cols: Col<Dep>[] = [
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> }, { key: 'asset', label: 'Coin', render: r => <><b>{r.asset}</b> <small>{r.network}</small></> },
    { key: 'amount', label: d.sub === 'auto' ? 'Paid / expected' : 'Claimed', align: 'right' }, { key: 'credited', label: 'Credited', align: 'right', render: r => r.credited ?? '—' },
    { key: 'ref', label: 'TX', wide: true, render: r => r.ref ? <Copy text={r.ref}>{short(r.ref)}</Copy> : '—' },
    { key: 'status', label: 'Status', render: r => <><Badge>{r.status}</Badge>{r.reason && <small style={{ display: 'block', opacity: .65 }}>{r.reason}</small>}</> },
    { key: 'act', label: '', align: 'right', render: r => d.sub === 'manual' && r.status === 'pending' ? <span style={{ display: 'inline-flex', gap: 6 }}>
      <ActionButton label="Credit" variant="ok" title="Credit deposit" url={`/admin/deposits/${r.id}`} data={{ decision: 'approve' }} fields={[{ name: 'amount', label: `Amount received (${r.asset})`, defaultValue: r.amount, required: true, type: 'number' }]}/>
      <ActionButton label="Reject" variant="danger" title="Reject deposit" url={`/admin/deposits/${r.id}`} data={{ decision: 'reject' }} fields={[{ name: 'reason', label: 'Reason', type: 'textarea' }]}/></span> : null },
  ];
  return <Panel flush title="Deposits" actions={<div className="au-chips" style={{ margin: 0 }}>{['manual', 'auto'].map(k => <Link key={k} preserveScroll className={d.sub === k ? 'on' : ''} href={`${BASE(u)}?tab=deposits&sub=${k}`}>{k === 'manual' ? 'Manual' : 'Automatic'}</Link>)}</div>}>
    <DataTable cols={cols} rows={d.rows} rowKey={r => r.id} empty="No deposits yet."/><Pager p={d.pager} url={BASE(u)}/></Panel>;
}

type Wd = { id: number; asset: string; network: string; address: string; amount: string; fee: string; net: string; status: string; tx: string | null; reason: string | null; at: string };
function Withdrawals({ u, d }: { u: U; d: { rows: Wd[]; pager: Paged } }) {
  const cols: Col<Wd>[] = [
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> }, { key: 'asset', label: 'Coin', render: r => <><b>{r.asset}</b> <small>{r.network}</small></> },
    { key: 'net', label: 'Net', align: 'right', render: r => <><b>{r.net}</b><small style={{ display: 'block', opacity: .65 }}>{r.amount} − fee {r.fee}</small></> },
    { key: 'address', label: 'Address', wide: true, render: r => <Copy text={r.address}>{short(r.address)}</Copy> },
    { key: 'status', label: 'Status', render: r => <><Badge>{r.status}</Badge>{r.tx && <small style={{ display: 'block' }}><Copy text={r.tx}>TX {short(r.tx)}</Copy></small>}{r.reason && <small style={{ display: 'block', opacity: .65 }}>{r.reason}</small>}</> },
    { key: 'act', label: '', align: 'right', render: r => r.status === 'pending' ? <span style={{ display: 'inline-flex', gap: 6 }}>
      <ActionButton label="Mark sent" variant="ok" title="Mark as sent" url={`/admin/withdrawals/${r.id}`} data={{ decision: 'complete' }} note={`Send ${r.net} ${r.asset} (${r.network}) to ${r.address} first.`} fields={[{ name: 'tx_hash', label: 'TX hash (optional)' }]}/>
      <ActionButton label="Reject" variant="danger" title="Reject & refund" url={`/admin/withdrawals/${r.id}`} data={{ decision: 'reject' }} fields={[{ name: 'reason', label: 'Reason', type: 'textarea' }]}/></span> : null },
  ];
  return <Panel flush title="Withdrawals"><DataTable cols={cols} rows={d.rows} rowKey={r => r.id} empty="No withdrawals yet."/><Pager p={d.pager} url={BASE(u)}/></Panel>;
}

type TRow = { id: number; a: string; b: string; c: string; d: string; e: string; at: string };
function Trading({ u, d }: { u: U; d: { sub: string; head: string[]; rows: TRow[]; pager: Paged } }) {
  const keys: Array<keyof TRow> = ['a', 'b', 'c', 'd', 'e', 'at'];
  const cols: Col<TRow>[] = keys.map((k, i) => ({ key: k, label: d.head[i] ?? '', align: i === 2 || i === 4 ? 'right' as const : undefined, primary: i === 0, render: (r: TRow) => i === 3 ? <Badge>{r[k]}</Badge> : r[k] })).filter(c => c.label !== '');
  const subs: Array<[string, string]> = [['spot', 'Spot orders'], ['futures', 'Futures'], ['limit', 'Limit & TP/SL'], ['earn', 'Earn'], ['bots', 'Bots']];
  return <Panel flush title="Trading & products" actions={<div className="au-chips" style={{ margin: 0 }}>{subs.map(([k, l]) => <Link key={k} preserveScroll className={d.sub === k ? 'on' : ''} href={`${BASE(u)}?tab=trading&sub=${k}`}>{l}</Link>)}</div>}>
    <DataTable cols={cols} rows={d.rows} rowKey={r => r.id} empty="Nothing here yet."/><Pager p={d.pager} url={BASE(u)}/></Panel>;
}

function P2p({ u, d }: { u: U; d: { rows: Array<{ ref: string; role: string; coin: string; qty: string; fiat: string; method: string; status: string; at: string }>; pager: Paged; ads: Array<{ id: number; side: string; coin: string; fiat: string; price: string; available: string; status: string }> } }) {
  type R = typeof d.rows[number];
  const cols: Col<R>[] = [{ key: 'at', label: 'Time' }, { key: 'ref', label: 'Order', primary: true, render: r => <b>{r.ref}</b> }, { key: 'role', label: 'Role' }, { key: 'qty', label: 'Amount', align: 'right', render: r => `${r.qty} ${r.coin}` }, { key: 'fiat', label: 'Fiat', align: 'right' }, { key: 'method', label: 'Method', hideOnPhone: true }, { key: 'status', label: 'Status', render: r => <Badge>{r.status}</Badge> }];
  return <><Panel flush title="P2P orders" actions={<Link className="au-btn sm" href="/admin/p2p">P2P desk</Link>}><DataTable cols={cols} rows={d.rows} rowKey={r => r.ref} empty="No P2P orders."/><Pager p={d.pager} url={BASE(u)}/></Panel>
    <Panel title="P2P ads">{d.ads.length === 0 ? <p style={{ margin: 0, color: 'var(--ad-muted)' }}>No ads.</p> : <div className="au-rows">{d.ads.map(a => <div className="au-row" key={a.id}><div><b>{a.side.toUpperCase()} {a.coin} @ {a.price} {a.fiat}</b><small>{a.available} {a.coin} available</small></div><Badge>{a.status}</Badge></div>)}</div>}</Panel></>;
}

type K = { id: number; status: string; name: string; country: string; phone: string | null; docType: string; docNumber: string; hasBack: boolean; reason: string | null; at: string };
function Kyc({ d }: { d: { rows: K[] } }) {
  return <Panel title="Identity submissions" hint="Approve or reject here — the user is notified by bell and email.">
    {d.rows.length === 0 ? <p style={{ margin: 0, color: 'var(--ad-muted)' }}>No submissions.</p> : <div className="au-rows">{d.rows.map(k => <div key={k.id} style={{ padding: '14px 0', borderBottom: '1px solid var(--ad-line)', display: 'grid', gap: 10 }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}><b>#{k.id}</b><Badge>{k.status}</Badge><span style={{ color: 'var(--ad-muted)', fontSize: 13 }}>{k.at}</span></div>
      <KV items={[['Name', k.name], ['Country', k.country], ['Phone', k.phone], ['Document', `${nice(k.docType)} · ${k.docNumber}`], ['Reason', k.reason]]}/>
      <div className="au-img-row">{(k.hasBack ? ['front', 'back', 'selfie'] : ['front', 'selfie']).map(w => <a key={w} href={`/admin/kyc/${k.id}/${w}`} target="_blank" rel="noreferrer"><img src={`/admin/kyc/${k.id}/${w}`} alt={w}/></a>)}</div>
      {k.status === 'pending' && <div style={{ display: 'flex', gap: 8 }}><ActionButton label="Approve" variant="ok" size="sm" url={`/admin/kyc/${k.id}`} data={{ decision: 'approve' }} confirmText="Approve this identity verification?"/>
        <ActionButton label="Reject" variant="danger" url={`/admin/kyc/${k.id}`} data={{ decision: 'reject' }} title="Reject KYC" fields={[{ name: 'reason', label: 'Reason shown to the user', placeholder: 'e.g. Photo is blurry', required: true, type: 'textarea' }]}/></div>}
    </div>)}</div>}
  </Panel>;
}

function Security({ u, d }: { u: U; d: { rows: Login[]; pager: Paged; twoFactor: boolean; sessions: number } }) {
  return <>
    <Panel title="Account security"><div style={{ display: 'flex', gap: 22, flexWrap: 'wrap', alignItems: 'center' }}>
      <KV items={[['Two-factor', <Badge tone={d.twoFactor ? 'ok' : 'muted'}>{d.twoFactor ? 'on' : 'off'}</Badge>], ['Active sessions', d.sessions]]}/>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginLeft: 'auto' }}>
        {d.twoFactor && <ActionButton label="Switch off 2FA" variant="danger" size="sm" url={`${BASE(u)}/2fa-reset`} confirmText="Switch off two-factor for this user? Do this only after verifying their identity."/>}
        <ActionButton label="Sign out everywhere" size="sm" url={`${BASE(u)}/signout`} confirmText="Sign this user out of every device?"/>
      </div></div></Panel>
    <Panel title="Sign-in history" flush><LoginTable rows={d.rows}/><Pager p={d.pager} url={BASE(u)}/></Panel>
  </>;
}

function Referrals({ u, d }: { u: U; d: { rows: Array<{ id: number; name: string; email: string; kyc: string; joined: string | null }>; pager: Paged; earned: Array<{ asset: string; total: string; n: number }>; code: string | null } }) {
  type R = typeof d.rows[number];
  const cols: Col<R>[] = [{ key: 'u', label: 'Invited user', primary: true, render: r => <Link href={`/admin/users/${r.id}`}><b>{r.name}</b><small style={{ display: 'block', opacity: .65 }}>{r.email}</small></Link> }, { key: 'kyc', label: 'KYC', render: r => <Badge>{r.kyc}</Badge> }, { key: 'joined', label: 'Joined' }];
  return <><Stats items={[{ label: 'Referral code', value: d.code ?? '—' }, { label: 'Friends invited', value: d.pager.total }, ...d.earned.map(e => ({ label: `Earned (${e.asset})`, value: e.total, hint: `${e.n} rewards`, tone: 'ok' as const }))]}/>
    <Panel flush title="Invited friends"><DataTable cols={cols} rows={d.rows} rowKey={r => r.id} empty="This user has not invited anyone."/><Pager p={d.pager} url={BASE(u)}/></Panel></>;
}

function Support({ d }: { d: { rows: Array<{ id: number; subject: string; category: string; status: string; at: string }>; pager: Paged; notifications: Array<{ id: number; title: string; read: boolean; at: string }> } }) {
  type R = typeof d.rows[number];
  const cols: Col<R>[] = [{ key: 'id', label: '#' }, { key: 'subject', label: 'Subject', primary: true, render: r => <Link href="/admin/tickets">{r.subject}</Link> }, { key: 'category', label: 'Category' }, { key: 'status', label: 'Status', render: r => <Badge>{r.status}</Badge> }, { key: 'at', label: 'Opened' }];
  return <><Panel flush title="Support tickets" actions={<Link className="au-btn sm" href="/admin/tickets">Open tickets</Link>}><DataTable cols={cols} rows={d.rows} rowKey={r => r.id} empty="No tickets."/></Panel>
    <Panel title="Recent messages sent to this user">{d.notifications.length === 0 ? <p style={{ margin: 0, color: 'var(--ad-muted)' }}>None.</p> : <div className="au-rows">{d.notifications.map(n => <div className="au-row" key={n.id}><div><b>{n.title}</b><small>{n.at}</small></div><Badge tone={n.read ? 'muted' : 'info'}>{n.read ? 'read' : 'unread'}</Badge></div>)}</div>}</Panel></>;
}

function Manage({ u }: { u: U }) {
  const [f, setF] = useState({ name: u.name, email: u.email, password: '' });
  const save = (e: React.FormEvent) => { e.preventDefault(); router.post(`${BASE(u)}/profile`, f as never, { preserveScroll: true, onSuccess: () => setF(x => ({ ...x, password: '' })) }); };
  if (u.role === 'admin') return <Panel title="Admin account"><p style={{ margin: 0 }}>Admin accounts are managed from <Link href="/admin/team">Admin team</Link>.</p></Panel>;
  return <div className="au-grid-2">
    <Panel title="Edit profile" hint="Changing the password signs the user out of every device."><form onSubmit={save} className="au-form">
      <Field label="Name" wide><Input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} required/></Field>
      <Field label="Email" wide><Input type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} required/></Field>
      <Field label="New password" wide hint="Leave empty to keep the current one. Minimum 10 characters."><Input autoComplete="off" value={f.password} onChange={e => setF({ ...f, password: e.target.value })}/></Field>
      <div className="au-form-actions"><button type="submit" className="au-btn primary">Save changes</button></div></form></Panel>
    <div>
      <Panel title="Account status" hint={u.status === 'frozen' ? 'This account is frozen: the user cannot sign in or trade.' : 'Freezing blocks sign-in and trading immediately.'}>
        <ActionButton label={u.status === 'frozen' ? 'Unfreeze account' : 'Freeze account'} variant={u.status === 'frozen' ? 'ok' : 'danger'} size="sm" url={`${BASE(u)}/status`} data={{ status: u.status === 'frozen' ? 'active' : 'frozen' }} confirmText={u.status === 'frozen' ? 'Unfreeze this account?' : 'Freeze this account? They will be signed out.'}/></Panel>
      <Panel title="Send a message" hint="Appears in the user's notification bell (and the notification centre)."><ActionButton label="Write a message…" variant="primary" size="sm" url={`${BASE(u)}/notify`} title={`Message ${u.email}`} fields={[{ name: 'title', label: 'Title', required: true, placeholder: 'Short headline' }, { name: 'body', label: 'Message', type: 'textarea' }]}/></Panel>
    </div>
  </div>;
}

/* ───────── page ───────── */
export default function UserShow({ admin, tab, counts, user: u, summary: s, data }: Props) {
  return <AdminLayout admin={admin} active="/admin/users">
    <div className="admin-content au-page">
      <Link className="au-back" href="/admin/users">← All users</Link>
      <div className="au-hero">
        <span className="au-avatar">{initials(u.name)}</span>
        <div>
          <h2>{u.name} <Badge>{u.status}</Badge><Badge>{`KYC ${u.kyc}`}</Badge>{u.twoFactor && <Badge tone="ok">2FA</Badge>}{u.role === 'admin' && <Badge tone="info">admin</Badge>}</h2>
          <p><span>{u.email}</span><span>UID {u.uid}</span><span>Joined {u.joined?.slice(0, 10)}</span><span>Last login {s.lastLogin ?? 'never'}</span></p>
        </div>
        <div className="au-hero-actions">
          <Link className="au-btn primary" href={`${BASE(u)}?tab=wallet`}>Credit / debit</Link>
          <ActionButton label="Message" size="sm" url={`${BASE(u)}/notify`} title={`Message ${u.email}`} fields={[{ name: 'title', label: 'Title', required: true }, { name: 'body', label: 'Message', type: 'textarea' }]}/>
          {u.role !== 'admin' && <ActionButton label={u.status === 'frozen' ? 'Unfreeze' : 'Freeze'} variant={u.status === 'frozen' ? 'ok' : 'danger'} size="sm" url={`${BASE(u)}/status`} data={{ status: u.status === 'frozen' ? 'active' : 'frozen' }} confirmText={u.status === 'frozen' ? 'Unfreeze this account?' : 'Freeze this account?'}/>}
        </div>
      </div>
      <Flash/>
      <Stats items={[
        { label: 'Total balance (USDT)', value: usd(s.totalUsdt), hint: `Funding ${usd(s.funding)} · Trading ${usd(s.trading)}` },
        { label: 'Deposited', value: usd(s.deposited), tone: 'ok' }, { label: 'Withdrawn', value: usd(s.withdrawn) },
        { label: 'Trades', value: s.spotTrades + s.futuresTrades, hint: `${s.spotTrades} spot · ${s.futuresTrades} futures · ${s.openPositions} open` },
        { label: 'Friends invited', value: s.invited },
      ]}/>
      <Tabs base={BASE(u)} active={tab} tabs={[
        { key: 'overview', label: 'Overview' }, { key: 'wallet', label: 'Wallet' }, { key: 'deposits', label: 'Deposits', count: counts.deposits, tone: 'warn' }, { key: 'withdrawals', label: 'Withdrawals', count: counts.withdrawals, tone: 'warn' },
        { key: 'trading', label: 'Trading' }, { key: 'p2p', label: 'P2P' }, { key: 'kyc', label: 'KYC', count: counts.kyc, tone: 'warn' }, { key: 'security', label: 'Security' },
        { key: 'referrals', label: 'Referrals' }, { key: 'support', label: 'Support', count: counts.support, tone: 'warn' }, { key: 'manage', label: 'Manage' },
      ]}/>
      {tab === 'overview' && <Overview u={u} s={s} d={data}/>}
      {tab === 'wallet' && <Wallet u={u} d={data}/>}
      {tab === 'deposits' && <Deposits u={u} d={data}/>}
      {tab === 'withdrawals' && <Withdrawals u={u} d={data}/>}
      {tab === 'trading' && <Trading u={u} d={data}/>}
      {tab === 'p2p' && <P2p u={u} d={data}/>}
      {tab === 'kyc' && <Kyc d={data}/>}
      {tab === 'security' && <Security u={u} d={data}/>}
      {tab === 'referrals' && <Referrals u={u} d={data}/>}
      {tab === 'support' && <Support d={data}/>}
      {tab === 'manage' && <Manage u={u}/>}
    </div>
  </AdminLayout>;
}
