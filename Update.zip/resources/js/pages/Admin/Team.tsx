import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; name: string; email: string; role: string; twoFactor: boolean; since: string };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const ROLES: Record<string, string> = { super: 'Super admin — everything', finance: 'Finance — deposits, withdrawals, gateways, wallets, users', support: 'Support — users, KYC, tickets, P2P, notifications' };

export default function AdminTeam({ admin, rows, me }: { admin: AdminUser; rows: Row[]; me: number }) {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  const [f, setF] = useState({ email: '', name: '', password: '', role: 'support' });
  return <AdminLayout admin={admin} active="/admin/team"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Admin team</h1><p>Who can sign in to the admin console, and what each role can open.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Admins</h2></header><div style={{ padding: '0 22px 18px', overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}><thead><tr style={{ textAlign: 'left', opacity: .65 }}><th>Name</th><th>Role</th><th>2FA</th><th>Since</th><th/></tr></thead>
        <tbody>{rows.map(r => <tr key={r.id} style={{ borderTop: '1px solid rgba(128,128,128,.2)' }}><td style={{ padding: '9px 6px' }}><b>{r.name}</b><br/><small style={{ opacity: .7 }}>{r.email}</small></td>
          <td><select style={input} value={r.role} onChange={e => router.post('/admin/team', { email: r.email, role: e.target.value } as never, { preserveScroll: true })}>{Object.keys(ROLES).map(k => <option key={k} value={k}>{k}</option>)}</select></td>
          <td style={{ color: r.twoFactor ? '#2ebd85' : '#f5a623' }}>{r.twoFactor ? 'ON' : 'OFF'}</td><td>{r.since}</td>
          <td>{r.id !== me && <button type="button" style={{ ...input, color: '#f6465d', cursor: 'pointer' }} onClick={() => window.confirm(`Remove admin access for ${r.email}?`) && router.post(`/admin/team/${r.id}/remove`, {}, { preserveScroll: true })}>Remove</button>}</td></tr>)}</tbody></table>
    </div></section>
    <section className="admin-panel"><header><h2>Add an admin</h2></header><div style={{ padding: '0 22px 22px', display: 'grid', gap: 10 }}>
      <small style={{ opacity: .7 }}>Enter the email of an existing user to promote them, or a new email with a name and a strong password to create the account.</small>
      <input style={input} placeholder="Email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })}/>
      <input style={input} placeholder="Name (new accounts only)" value={f.name} onChange={e => setF({ ...f, name: e.target.value })}/>
      <input style={input} type="password" placeholder="Password (new accounts only, 12+ chars with letters and numbers)" value={f.password} onChange={e => setF({ ...f, password: e.target.value })}/>
      <select style={input} value={f.role} onChange={e => setF({ ...f, role: e.target.value })}>{Object.entries(ROLES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      <button type="button" style={{ ...input, background: '#c1f033', color: '#000', fontWeight: 800, border: 0, cursor: 'pointer', justifySelf: 'start', padding: '11px 20px' }} onClick={() => router.post('/admin/team', f as never, { preserveScroll: true, onSuccess: () => setF({ email: '', name: '', password: '', role: 'support' }) })}>Save admin</button>
    </div></section>
  </div></AdminLayout>;
}
