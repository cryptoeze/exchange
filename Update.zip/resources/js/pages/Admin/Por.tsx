import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { asset: string; liabilities: string; reserves: string | null; ratio: number | null; wallet: string | null; verified: string | null };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;

function Line({ r }: { r: Row }) {
  const [amt, setAmt] = useState(r.reserves ?? ''); const [wallet, setWallet] = useState(r.wallet ?? '');
  return <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '80px 1fr 1fr 2fr auto', alignItems: 'center', padding: '10px 0', borderTop: '1px solid rgba(128,128,128,.2)' }} className="por-row">
    <b>{r.asset}</b><span>Owed: {r.liabilities}</span><input style={input} placeholder="Reserves held" value={amt} onChange={e => setAmt(e.target.value)}/><input style={input} placeholder="Wallet address / explorer link (public)" value={wallet} onChange={e => setWallet(e.target.value)}/>
    <button type="button" style={{ ...input, background: '#c1f033', color: '#000', fontWeight: 800, border: 0, cursor: 'pointer' }} onClick={() => router.post('/admin/por', { asset: r.asset, amount: amt || '0', wallet } as never, { preserveScroll: true })}>Save</button>
    <small style={{ gridColumn: '1 / -1', opacity: .65 }}>{r.ratio === null ? 'Not reported' : `Coverage ${r.ratio}%`} · verified {r.verified ?? 'never'}</small></div>;
}

export default function AdminPor({ admin, rows }: { admin: AdminUser; rows: Row[] }) {
  const page = usePage().props as { flash?: { status?: string } };
  const [asset, setAsset] = useState('');
  return <AdminLayout admin={admin} active="/admin/por"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Proof of Reserves</h1><p>Customer balances come from the ledger. Enter what you actually hold in your wallets; it is published on the public page.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '4px 22px 22px' }}>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}
      {rows.map(r => <Line key={r.asset} r={r}/>)}
      <div style={{ display: 'flex', gap: 8, paddingTop: 16 }}><input style={input} placeholder="Add another asset (e.g. SOL)" value={asset} onChange={e => setAsset(e.target.value.toUpperCase())}/><button type="button" style={{ ...input, cursor: 'pointer' }} onClick={() => asset && router.post('/admin/por', { asset, amount: '0' } as never, { preserveScroll: true, onSuccess: () => setAsset('') })}>Add</button></div>
      <p style={{ opacity: .65, fontSize: 12 }}>Publishing false reserve numbers misleads customers. Only enter figures you can prove.</p>
    </div></section>
    <style>{`@media(max-width:900px){.por-row{grid-template-columns:1fr!important}}`}</style>
  </div></AdminLayout>;
}
