import { Link, useForm, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';

type Product = { id: number; asset: string; name: string; apr: number; min: string; enabled: boolean; holders: number; staked: string };
const field = { style: { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '9px 10px', font: 'inherit', width: '100%' } } as const;

function Row({ product }: { product?: Product }) {
  const form = useForm({ id: product?.id ?? null, name: product?.name ?? '', asset: product?.asset ?? 'USDT', apr: String(product?.apr ?? '3.5'), min: (product?.min ?? '1').replace(/,/g, ''), enabled: product?.enabled ?? false });
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const rateChanged = product && Number(form.data.apr) !== product.apr;
    if (form.data.enabled && !window.confirm(`${rateChanged ? 'Everyone currently staked is paid at the old rate first, then ' : ''}${form.data.apr}% APR will be paid from the platform to stakers of ${form.data.name}. Continue?`)) return;
    form.post('/admin/earn', { preserveScroll: true, onSuccess: () => { if (!product) form.reset(); } });
  };
  return <form onSubmit={submit} style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))', alignItems: 'end', padding: '14px 0', borderTop: '1px solid rgba(128,128,128,.2)' }}>
    <label>Name<input {...field} value={form.data.name} onChange={e => form.setData('name', e.target.value)} required maxLength={60}/></label>
    <label>Asset<select {...field} value={form.data.asset} disabled={!!product} onChange={e => form.setData('asset', e.target.value)}><option>USDT</option><option>USDC</option></select></label>
    <label>APR % (yearly)<input {...field} inputMode="decimal" value={form.data.apr} onChange={e => form.setData('apr', e.target.value)} required/></label>
    <label>Minimum stake<input {...field} inputMode="decimal" value={form.data.min} onChange={e => form.setData('min', e.target.value)} required/></label>
    <label style={{ display: 'flex', gap: 8, alignItems: 'center', paddingBottom: 10 }}><input type="checkbox" checked={form.data.enabled} onChange={e => form.setData('enabled', e.target.checked)}/> Open for new stakes</label>
    <button type="submit" disabled={form.processing} style={{ padding: '10px 16px', borderRadius: 8, border: 0, fontWeight: 700, background: '#c1f033', color: '#000', cursor: 'pointer' }}>{product ? 'Save' : 'Add product'}</button>
    {product && <small style={{ gridColumn: '1 / -1', opacity: .75 }}>{product.holders} holders · {product.staked} {product.asset} staked</small>}
    {Object.values(form.errors).map(m => <small key={m} role="alert" style={{ color: '#f6465d', gridColumn: '1 / -1' }}>{m}</small>)}
  </form>;
}

export default function AdminEarn({ admin, products, totals }: { admin: AdminUser; products: Product[]; totals: { staked: string; interestPaid: string } }) {
  const flash = (usePage().props as { flash?: { status?: string } }).flash?.status;
  return <AdminLayout admin={admin} active="/admin/earn"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Earn (staking)</h1><p>Set the yearly rate paid on staked balances.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel" style={{ marginBottom: 16 }}><header><h2>Overview</h2></header><div style={{ padding: '4px 22px 18px' }}><p>Currently staked: <b>{totals.staked}</b> · Interest paid so far: <b>{totals.interestPaid}</b></p>
      <p style={{ opacity: .75, fontSize: 13 }}>Interest is simple interest, paid every second of holding into the user's Funding account. It is paid from the platform, so keep a reserve. Changing the APR first pays everyone at the old rate up to that moment. Every change is written to the audit log. Products are created switched off.</p></div></section>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>{flash && <p role="status" style={{ color: '#2ebd85' }}>{flash}</p>}<header><h2>Products</h2></header>
      {products.map(p => <Row key={p.id} product={p}/>)}
      <h3 style={{ marginTop: 20 }}>Add a product</h3><Row/></div></section>
  </div></AdminLayout>;
}
