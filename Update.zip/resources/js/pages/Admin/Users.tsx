import { Link, router } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Row = { id: number; name: string; email: string; status: string; kyc: string; verified: boolean; usdt: string; joined: string | null };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;

export default function AdminUsers({ admin, rows, filters, total, page, last }: { admin: AdminUser; rows: Row[]; filters: { q: string; status: string; kyc: string }; total: number; page: number; last: number }) {
  const [f, setF] = useState(filters);
  const go = (extra: Record<string, string | number> = {}) => router.get('/admin/users', { ...f, ...extra } as never, { preserveState: true });
  return <AdminLayout admin={admin} active="/admin/users"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Users</h1><p>{total.toLocaleString()} accounts. Search by email, name, ID or referral code.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '0 22px 20px' }}>
      <form onSubmit={e => { e.preventDefault(); go({ page: 1 }); }} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', padding: '14px 0' }}>
        <input style={{ ...input, flex: '1 1 220px' }} placeholder="Search…" value={f.q} onChange={e => setF({ ...f, q: e.target.value })}/>
        <select style={input} value={f.status} onChange={e => setF({ ...f, status: e.target.value })}><option value="">All status</option><option value="active">Active</option><option value="frozen">Frozen</option></select>
        <select style={input} value={f.kyc} onChange={e => setF({ ...f, kyc: e.target.value })}><option value="">All KYC</option><option value="none">No KYC</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select>
        <button style={{ ...input, background: '#c1f033', color: '#000', fontWeight: 700, border: 0, cursor: 'pointer' }}>Search</button>
      </form>
      <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}><thead><tr style={{ textAlign: 'left', opacity: .65 }}><th>ID</th><th>User</th><th>USDT</th><th>KYC</th><th>Status</th><th>Joined</th></tr></thead>
        <tbody>{rows.map(r => <tr key={r.id} style={{ borderTop: '1px solid rgba(128,128,128,.2)' }}><td style={{ padding: '9px 6px' }}>{r.id}</td><td><Link href={`/admin/users/${r.id}`}><b>{r.name}</b></Link><br/><small style={{ opacity: .7 }}>{r.email}{r.verified ? '' : ' · unverified'}</small></td><td>{r.usdt}</td><td>{r.kyc}</td><td style={{ color: r.status === 'frozen' ? '#f6465d' : undefined }}>{r.status}</td><td>{r.joined}</td></tr>)}</tbody></table>
        {rows.length === 0 && <p style={{ opacity: .7 }}>No users match.</p>}</div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', paddingTop: 14 }}><button style={input} disabled={page <= 1} onClick={() => go({ page: page - 1 })}>Previous</button><span>Page {page} / {last}</span><button style={input} disabled={page >= last} onClick={() => go({ page: page + 1 })}>Next</button></div>
    </div></section>
  </div></AdminLayout>;
}
