import { Download } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';
import { Badge, DataTable, FilterBar, Page, Pager, Panel, Stats, UserLink, group, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; uid: number; name: string; email: string; status: string; kyc: string; verified: boolean; funding: string; total: string; lastLogin: string | null; joined: string | null };
type Props = {
  admin: AdminUser; rows: Row[]; pager: Paged;
  filters: { q: string; status: string; kyc: string; verified: string; sort: string; from: string; to: string };
  stats: { total: number; today: number; week: number; frozen: number; kycPending: number; kycApproved: number; unverified: number };
};

export default function AdminUsers({ admin, rows, pager, filters, stats }: Props) {
  const cols: Col<Row>[] = [
    { key: 'user', label: 'User', primary: true, wide: true, render: r => <UserLink id={r.id} name={r.name} email={r.email}/> },
    { key: 'uid', label: 'UID', hideOnPhone: true, render: r => <span style={{ opacity: .7 }}>{r.uid}</span> },
    { key: 'status', label: 'Status', render: r => <Badge>{r.status}</Badge> },
    { key: 'kyc', label: 'KYC', render: r => <Badge>{r.kyc}</Badge> },
    { key: 'verified', label: 'Email', hideOnPhone: true, render: r => <Badge tone={r.verified ? 'ok' : 'muted'}>{r.verified ? 'verified' : 'unverified'}</Badge> },
    { key: 'funding', label: 'Funding USDT', align: 'right', render: r => group(r.funding) },
    { key: 'total', label: 'Total USDT', align: 'right', render: r => <b>{group(r.total)}</b> },
    { key: 'lastLogin', label: 'Last login', hideOnPhone: true, render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.lastLogin ?? '—'}</span> },
    { key: 'joined', label: 'Joined', hideOnPhone: true, render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.joined}</span> },
  ];
  const exportUrl = `/admin/users?${new URLSearchParams({ ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)), export: '1' }).toString()}`;
  return <AdminLayout admin={admin} active="/admin/users">
    <Page title="Users" subtitle="Everyone who signed up. Click a user to open their full account — wallet, activity, KYC, security and controls."
      actions={<a className="au-btn" href={exportUrl}><Download size={15}/> Export CSV</a>}>
      <Stats items={[
        { label: 'Total users', value: stats.total.toLocaleString(), hint: `${stats.today} today · ${stats.week} this week` },
        { label: 'KYC pending', value: stats.kycPending, hint: `${stats.kycApproved} verified`, href: '/admin/kyc', tone: stats.kycPending ? 'warn' : undefined },
        { label: 'Frozen', value: stats.frozen, tone: stats.frozen ? 'bad' : undefined },
        { label: 'Email not verified', value: stats.unverified },
      ]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}>
          <FilterBar url="/admin/users" values={filters} defs={[
            { name: 'q', type: 'search', placeholder: 'Search email, name, user ID, UID or referral code' },
            { name: 'status', type: 'select', options: [['', 'All status'], ['active', 'Active'], ['frozen', 'Frozen']] },
            { name: 'kyc', type: 'select', options: [['', 'All KYC'], ['none', 'No KYC'], ['pending', 'Pending'], ['approved', 'Approved'], ['rejected', 'Rejected']] },
            { name: 'verified', type: 'select', options: [['', 'Any email'], ['yes', 'Verified'], ['no', 'Not verified']] },
            { name: 'sort', type: 'select', options: [['newest', 'Newest first'], ['oldest', 'Oldest first'], ['balance', 'Highest balance'], ['name', 'Name A–Z']] },
            { name: 'from', type: 'date', label: 'Joined from' }, { name: 'to', type: 'date', label: 'to' },
          ]}/>
        </div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} rowHref={r => `/admin/users/${r.id}`} empty="No users match these filters."/>
        <Pager p={pager} url="/admin/users"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
