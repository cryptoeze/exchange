import { Link } from '@inertiajs/react';
import { Download } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';
import { Badge, DataTable, FilterBar, Page, Pager, Panel, Stats, UserLink, group, signed, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; name: string; category: string; type: string; account: string; asset: string; amount: string; after: string; note: string | null; by: string | null; ref: string | null; at: string };
type Props = {
  admin: AdminUser; rows: Row[]; pager: Paged; types: string[]; assets: string[]; categories: Array<[string, string]>; accounts: string[];
  filters: Record<string, string>; summary: { asset: string; in: string; out: string; net: string };
};
const nice = (t: string) => t.replace(/_/g, ' ');

export default function AdminTransactions({ admin, rows, pager, types, assets, categories, accounts, filters, summary }: Props) {
  const cols: Col<Row>[] = [
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'user', label: 'User', primary: true, render: r => <UserLink id={r.userId} name={r.name} email={r.email}/> },
    { key: 'type', label: 'Type', render: r => <><Badge tone="info">{r.category}</Badge> {nice(r.type) !== r.category && <small style={{ opacity: .7 }}>{nice(r.type)}</small>}</> },
    { key: 'account', label: 'Account', hideOnPhone: true },
    { key: 'amount', label: 'Amount', align: 'right', render: r => <span style={{ whiteSpace: 'nowrap' }}>{signed(group(r.amount))} <small>{r.asset}</small></span> },
    { key: 'after', label: 'Balance after', align: 'right', hideOnPhone: true, render: r => group(r.after) },
    { key: 'note', label: 'Note / reference', wide: true, render: r => <>{r.ref ? <Link href={r.ref}>{r.note || 'open record'}</Link> : (r.note ?? '—')}{r.by && <small style={{ display: 'block', opacity: .65 }}>by {r.by}</small>}</> },
  ];
  const exportUrl = `/admin/transactions?${new URLSearchParams({ ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)), export: '1' }).toString()}`;
  return <AdminLayout admin={admin} active="/admin/transactions">
    <Page title="Transactions" subtitle="Every balance movement on the platform in one place — deposits, withdrawals, transfers, trades, bonuses and admin adjustments. Filter by category, asset, user or date."
      actions={<a className="au-btn" href={exportUrl}><Download size={15}/> Export CSV</a>}>
      <Stats items={[
        { label: `Money in (${summary.asset})`, value: group(summary.in), tone: 'ok', hint: 'for the filters below' },
        { label: `Money out (${summary.asset})`, value: group(summary.out), tone: 'bad' },
        { label: 'Net', value: group(summary.net) },
        { label: 'Matching entries', value: pager.total.toLocaleString() },
      ]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}>
          <FilterBar url="/admin/transactions" values={filters} defs={[
            { name: 'q', type: 'search', placeholder: 'User — email, name or ID' },
            { name: 'cat', type: 'select', options: [['', 'All categories'], ...categories] },
            { name: 'type', type: 'select', options: [['', 'Any type'], ...types.map(t => [t, nice(t)] as [string, string])] },
            { name: 'asset', type: 'select', options: [['', 'All assets'], ...assets.map(a => [a, a] as [string, string])] },
            { name: 'account', type: 'select', options: [['', 'All accounts'], ...accounts.map(a => [a, a] as [string, string])] },
            { name: 'dir', type: 'select', options: [['', 'In & out'], ['in', 'Money in'], ['out', 'Money out']] },
            { name: 'min', type: 'search', placeholder: 'Min amount' },
            { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
          ]}/>
        </div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty="No transactions match these filters."/>
        <Pager p={pager} url="/admin/transactions"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
