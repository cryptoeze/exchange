import { AdminLayout, type AdminUser } from './Layout';
import { ActionButton, Badge, DataTable, FilterBar, Page, Pager, Panel, Stats, Tabs, UserLink, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; name: string; symbol: string; side: string; kind: string; price: string; qty: string; at: string };
type Props = { admin: AdminUser; rows: Row[]; status: string; pager: Paged; filters: Record<string, string>; counts: { open: number; filled: number; cancelled: number } };
const label = (k: string) => k === 'tp' ? 'Take profit' : k === 'sl' ? 'Stop loss' : 'Limit';

export default function AdminOrders({ admin, rows, status, pager, filters, counts }: Props) {
  const cols: Col<Row>[] = [
    { key: 'id', label: '#', hideOnPhone: true }, { key: 'at', label: 'Placed', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'user', label: 'User', primary: true, render: r => <UserLink id={r.userId} name={r.name} email={r.email}/> },
    { key: 'symbol', label: 'Pair', render: r => <b>{r.symbol}</b> }, { key: 'kind', label: 'Type', render: r => <Badge tone="info">{label(r.kind)}</Badge> },
    { key: 'side', label: 'Side', render: r => <Badge tone={r.side === 'buy' ? 'ok' : 'bad'}>{r.side}</Badge> },
    { key: 'price', label: 'Trigger / price', align: 'right', render: r => `${r.kind === 'tp' ? '≥ ' : r.kind === 'sl' ? '≤ ' : ''}${r.price}` }, { key: 'qty', label: 'Amount', align: 'right' },
    { key: 'act', label: '', align: 'right', render: r => status === 'open' ? <ActionButton label="Cancel" variant="danger" url={`/admin/orders/${r.id}/cancel`} confirmText={`Cancel order #${r.id} and return the reserved funds to the user?`}/> : null },
  ];
  return <AdminLayout admin={admin} active="/admin/orders">
    <Page title="Limit & TP/SL orders" subtitle="Resting spot orders. Funds are held until the price is reached or the order is cancelled. Cancelling returns the reserved funds to the user.">
      <Stats items={[{ label: 'Resting now', value: counts.open, tone: counts.open ? 'info' : undefined }, { label: 'Filled', value: counts.filled, tone: 'ok' }, { label: 'Cancelled', value: counts.cancelled }]}/>
      <Tabs base="/admin/orders" param="status" active={status} tabs={[{ key: 'open', label: 'Resting' }, { key: 'filled', label: 'Filled' }, { key: 'cancelled', label: 'Cancelled' }]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}><FilterBar url="/admin/orders" hidden={{ status }} values={filters} defs={[
          { name: 'q', type: 'search', placeholder: 'User — email, name or ID' }, { name: 'symbol', type: 'search', placeholder: 'Pair, e.g. BTC' },
          { name: 'kind', type: 'select', options: [['', 'All types'], ['limit', 'Limit'], ['tp', 'Take profit'], ['sl', 'Stop loss']] }, { name: 'side', type: 'select', options: [['', 'Buy & sell'], ['buy', 'Buy'], ['sell', 'Sell']] },
          { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
        ]}/></div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty="No orders here."/>
        <Pager p={pager} url="/admin/orders"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
