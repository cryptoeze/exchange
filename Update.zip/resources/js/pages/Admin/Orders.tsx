import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
function Flash() { const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> }; return <>{page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}</>; }

type Row = { id: number; userId: number; user: string; symbol: string; side: string; kind: string; price: string; qty: string; at: string };
const label = (k: string) => k === 'tp' ? 'Take profit' : k === 'sl' ? 'Stop loss' : 'Limit';
export default function AdminOrders({ admin, rows, status, counts }: { admin: AdminUser; rows: Row[]; status: string; counts: Record<string, number> }) {
  const cancel = (id: number) => { if (window.confirm(`Cancel order #${id} and return the reserved funds to the user?`)) router.post(`/admin/orders/${id}/cancel`, {} as never, { preserveScroll: true }); };
  return <AdminLayout admin={admin} active="/admin/orders"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Limit &amp; TP/SL orders</h1><p>Resting spot orders. Funds are held until the price is reached or the order is cancelled.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    <section className="admin-panel"><div style={{ padding: '0 22px 18px' }}>
      <div style={{ display: 'flex', gap: 8, padding: '14px 0' }}>{['open', 'filled', 'cancelled'].map(s => <Link key={s} href={`/admin/orders?status=${s}`} style={{ ...input, textDecoration: 'none', fontWeight: s === status ? 800 : 400 }}>{s} ({counts[s] ?? 0})</Link>)}</div>
      <Flash/>
      {rows.length === 0 ? <p style={{ opacity: .7 }}>Nothing here.</p> : <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead><tr style={{ textAlign: 'left', opacity: .6 }}><th>#</th><th>User</th><th>Pair</th><th>Type</th><th>Side</th><th>Trigger / price</th><th>Amount</th><th>Placed</th><th/></tr></thead>
        <tbody>{rows.map(o => <tr key={o.id} style={{ borderTop: '1px solid rgba(128,128,128,.18)' }}>
          <td>{o.id}</td><td><Link href={`/admin/users/${o.userId}`}>{o.user}</Link></td><td>{o.symbol}</td><td>{label(o.kind)}</td><td style={{ color: o.side === 'buy' ? '#2ebd85' : '#f6465d' }}>{o.side}</td><td>{o.kind === 'tp' ? '≥ ' : o.kind === 'sl' ? '≤ ' : ''}{o.price}</td><td>{o.qty}</td><td>{o.at}</td>
          <td>{status === 'open' && <button type="button" style={{ ...input, cursor: 'pointer' }} onClick={() => cancel(o.id)}>Cancel</button>}</td>
        </tr>)}</tbody>
      </table></div>}
    </div></section>
  </div></AdminLayout>;
}
