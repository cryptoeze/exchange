import { Download } from 'lucide-react';
import { AdminLayout, type AdminUser } from './Layout';
import { ActionButton, Badge, Copy, DataTable, FilterBar, Page, Pager, Panel, Stats, usd, Tabs, UserLink, type Col, type Paged } from '../../admin/kit';

type Row = { id: number; userId: number; email: string; name: string; asset: string; network: string; claimed: string; credited: string | null; txid: string; status: string; reason: string | null; by: string | null; at: string };
type Props = {
  admin: AdminUser; tab: string; rows: Row[]; pager: Paged; filters: Record<string, string>; assets: string[]; networks: string[];
  counts: { pending: number; approved: number; rejected: number; all: number; auto: number };
  stats: { pendingValue: string; manual30: string; auto30: string; waitingAuto: number };
};

export default function AdminDeposits({ admin, tab, rows, pager, filters, assets, networks, counts, stats }: Props) {
  const auto = tab === 'auto';
  const cols: Col<Row>[] = [
    { key: 'id', label: '#', hideOnPhone: true },
    { key: 'at', label: 'Time', render: r => <span style={{ whiteSpace: 'nowrap' }}>{r.at}</span> },
    { key: 'user', label: 'User', primary: true, render: r => <UserLink id={r.userId} name={r.name} email={r.email}/> },
    { key: 'asset', label: 'Coin / network', render: r => <><b>{r.asset}</b> <small style={{ opacity: .7 }}>{r.network}</small></> },
    { key: 'claimed', label: auto ? 'Paid / expected' : 'Claimed', align: 'right' },
    { key: 'credited', label: 'Credited', align: 'right', render: r => r.credited ?? '—' },
    { key: 'txid', label: auto ? 'TX / address' : 'TXID', wide: true, render: r => r.txid ? <Copy text={r.txid}>{r.txid.length > 26 ? `${r.txid.slice(0, 12)}…${r.txid.slice(-10)}` : r.txid}</Copy> : '—' },
    { key: 'status', label: 'Status', render: r => <><Badge>{r.status}</Badge>{r.reason && <small style={{ display: 'block', opacity: .65 }}>{r.reason}</small>}{r.by && <small style={{ display: 'block', opacity: .65 }}>by {r.by}</small>}</> },
  ];
  if (!auto) {
    cols.push({ key: 'act', label: 'Action', align: 'right', render: r => r.status !== 'pending' ? null : <span style={{ display: 'inline-flex', gap: 6 }}>
      <ActionButton label="Credit" title={`Credit ${r.asset} to ${r.email}`} variant="ok" url={`/admin/deposits/${r.id}`} data={{ decision: 'approve' }}
        note={<>Check that the transaction <b>{r.txid.slice(0, 18)}…</b> really arrived in your wallet. The user will be credited and notified.</>}
        fields={[{ name: 'amount', label: `Amount actually received (${r.asset})`, defaultValue: r.claimed, required: true, type: 'number' }]}/>
      <ActionButton label="Reject" title="Reject deposit" variant="danger" url={`/admin/deposits/${r.id}`} data={{ decision: 'reject' }} fields={[{ name: 'reason', label: 'Reason shown to the user', placeholder: 'e.g. Transaction not found', type: 'textarea' }]}/>
    </span> });
  }
  const exportUrl = `/admin/deposits?${new URLSearchParams({ ...Object.fromEntries(Object.entries({ ...filters, tab }).filter(([, v]) => v)), export: '1' }).toString()}`;
  return <AdminLayout admin={admin} active="/admin/deposits">
    <Page title="Deposits" subtitle="Review manual deposits (credit or reject) and follow automatic NOWPayments deposits. Addresses and on/off switches are in Gateways."
      actions={<><a className="au-btn" href="/admin/gateways?tab=deposit-manual">Manage addresses</a><a className="au-btn" href={exportUrl}><Download size={15}/> Export CSV</a></>}>
      <Stats items={[
        { label: 'Waiting for review', value: counts.pending, hint: `≈ ${usd(stats.pendingValue)} claimed`, tone: counts.pending ? 'warn' : undefined },
        { label: 'Manual credited (30d)', value: usd(stats.manual30), tone: 'ok' },
        { label: 'Auto credited (30d)', value: usd(stats.auto30), tone: 'ok' },
        { label: 'Auto in progress', value: stats.waitingAuto, hint: 'waiting / confirming' },
      ]}/>
      <Tabs base="/admin/deposits" active={tab} tabs={[
        { key: 'pending', label: 'Pending review', count: counts.pending, tone: 'warn' }, { key: 'approved', label: 'Credited' }, { key: 'rejected', label: 'Rejected' },
        { key: 'all', label: 'All manual' }, { key: 'auto', label: 'Automatic (NOWPayments)' },
      ]}/>
      <Panel flush>
        <div style={{ padding: '16px 16px 2px' }}>
          <FilterBar url="/admin/deposits" hidden={{ tab }} values={filters} defs={[
            { name: 'q', type: 'search', placeholder: 'User email / name / ID, or TXID' },
            { name: 'asset', type: 'select', options: [['', 'All coins'], ...assets.map(a => [a, a] as [string, string])] },
            { name: 'network', type: 'select', options: [['', 'All networks'], ...networks.map(a => [a, a] as [string, string])] },
            { name: 'from', type: 'date', label: 'From' }, { name: 'to', type: 'date', label: 'To' },
          ]}/>
        </div>
        <DataTable cols={cols} rows={rows} rowKey={r => r.id} empty={tab === 'pending' ? 'No deposits are waiting for review. 🎉' : 'No deposits match these filters.'}/>
        <Pager p={pager} url="/admin/deposits"/>
      </Panel>
    </Page>
  </AdminLayout>;
}
