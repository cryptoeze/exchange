import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';

type Net = { ticker: string; code: string; label: string; min: number; fee: number; off: boolean };
type Props = { admin: AdminUser; switches: Record<string, boolean>; nowpayments: { apiKey: boolean; ipnSecret: boolean; sandbox: boolean; ipnUrl: string }; stats: Record<string, number>; networks: Net[] };
const input = { background: 'transparent', color: 'inherit', border: '1px solid rgba(128,128,128,.35)', borderRadius: 8, padding: '8px 10px', font: 'inherit' } as const;
const ok = (v: boolean) => <b style={{ color: v ? '#2ebd85' : '#f6465d' }}>{v ? 'Ready' : 'Missing'}</b>;
const SW: Array<[string, string, string]> = [['auto_deposit', 'Auto deposits (NOWPayments)', 'Users get a generated address and balance is credited automatically.'], ['manual_deposit', 'Manual deposits', 'Users send to your own addresses and you approve each one.'], ['withdraw_enabled', 'Withdrawals', 'Users can request withdrawals (you send them manually).'], ['kyc_required', 'Require KYC to withdraw', 'Only users with approved identity verification can withdraw.']];

export default function AdminGateways({ admin, switches, nowpayments, stats, networks }: Props) {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  const [sw, setSw] = useState(switches); const [nets, setNets] = useState(networks);
  const edit = (i: number, patch: Partial<Net>) => setNets(nets.map((n, j) => j === i ? { ...n, ...patch } : n));
  const save = () => router.post('/admin/gateways', { switches: sw, networks: nets } as never, { preserveScroll: true });
  const card = (t: string, body: React.ReactNode) => <section className="admin-panel" style={{ marginBottom: 18 }}><header><h2>{t}</h2></header><div style={{ padding: '0 22px 20px', display: 'grid', gap: 10 }}>{body}</div></section>;
  return <AdminLayout admin={admin} active="/admin/gateways"><div className="admin-content admin-section-content">
    <Link className="admin-section-back" href="/admin"><ArrowLeft/> Dashboard</Link>
    <div className="admin-heading"><div><h1>Gateways</h1><p>Deposit and withdrawal control in one place.</p></div><span className="admin-secure"><ShieldCheck/> Secure session</span></div>
    {page.flash?.status && <p role="status" style={{ color: '#2ebd85' }}>{page.flash.status}</p>}{Object.values(page.errors ?? {}).map(m => <p key={m} role="alert" style={{ color: '#f6465d' }}>{m}</p>)}
    {card('Switches', <>{SW.map(([k, t, d]) => <label key={k} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}><input type="checkbox" checked={!!sw[k]} onChange={e => setSw({ ...sw, [k]: e.target.checked })} style={{ width: 20, height: 20, marginTop: 2 }}/><span><b>{t}</b><br/><small style={{ opacity: .7 }}>{d}</small></span></label>)}</>)}
    {card('Auto deposit gateway — NOWPayments', <>
      <div>API key: {ok(nowpayments.apiKey)} · IPN secret: {ok(nowpayments.ipnSecret)} · Mode: <b>{nowpayments.sandbox ? 'Sandbox (test)' : 'Live'}</b></div>
      <div>IPN callback URL (set this in your NOWPayments dashboard): <code style={{ overflowWrap: 'anywhere' }}>{nowpayments.ipnUrl}</code></div>
      <small style={{ opacity: .7 }}>Keys are kept in the server .env (NOWPAYMENTS_API_KEY, NOWPAYMENTS_IPN_SECRET) for safety; they are not editable here.</small>
      <div>Last 30 days: <b>{stats.autoDeposits30d}</b> addresses created · <b>{stats.autoCredited30d}</b> credited</div></>)}
    {card('Manual deposit gateway', <><div>Enabled addresses: <b>{stats.manualAddresses}</b> · Waiting for approval: <b>{stats.manualPending}</b></div><div><Link href="/admin/deposits">Manage addresses &amp; approve deposits →</Link></div></>)}
    {card('Withdrawal gateway', <>
      <div>Waiting to be sent: <b>{stats.withdrawPending}</b> · Sent in last 30 days: <b>{stats.withdrawDone30d}</b> · <Link href="/admin/withdrawals">Open queue →</Link></div>
      <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}><thead><tr style={{ textAlign: 'left', opacity: .65 }}><th>Asset</th><th>Network</th><th>Min amount</th><th>Fee</th><th>Disabled</th></tr></thead>
        <tbody>{nets.map((n, i) => <tr key={n.ticker + n.code} style={{ borderTop: '1px solid rgba(128,128,128,.2)' }}><td style={{ padding: '7px 6px' }}><b>{n.ticker}</b></td><td>{n.label}</td>
          <td><input style={{ ...input, width: 90 }} value={n.min} onChange={e => edit(i, { min: Number(e.target.value) || 0 })}/></td><td><input style={{ ...input, width: 90 }} value={n.fee} onChange={e => edit(i, { fee: Number(e.target.value) || 0 })}/></td>
          <td><input type="checkbox" checked={n.off} onChange={e => edit(i, { off: e.target.checked })}/></td></tr>)}</tbody></table></div>
      <small style={{ opacity: .7 }}>Minimum is per asset (the same value applies to all networks of that asset). The fee is kept by the platform.</small></>)}
    <button type="button" onClick={save} style={{ ...input, background: '#c1f033', color: '#000', fontWeight: 800, border: 0, padding: '12px 20px', cursor: 'pointer' }}>Save gateway settings</button>
  </div></AdminLayout>;
}
