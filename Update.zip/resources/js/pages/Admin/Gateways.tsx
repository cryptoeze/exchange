import { Link, router, useForm } from '@inertiajs/react';
import { useMemo, useState } from 'react';
import { AdminLayout, type AdminUser } from './Layout';
import { Badge, Btn, Field, Input, Page, Panel, Stat, Switch, Tabs } from '../../admin/kit';

type Net = { ticker: string; code: string; label: string; min: number; fee: number; off: boolean };
type Coin = { ticker: string; coin: string; code: string; network: string; off: boolean };
type Addr = { id: number | null; asset: string; network: string; label: string; address: string; min: string; note: string | null; enabled: boolean };
type Props = {
  admin: AdminUser; tab: string; switches: Record<string, boolean>; nowpayments: { apiKey: boolean; ipnSecret: boolean; sandbox: boolean; ipnUrl: string };
  stats: Record<string, number>; networks: Net[]; depositCoins: Coin[]; addresses: Addr[];
};
const SW: Array<[string, string, string]> = [
  ['auto_deposit', 'Automatic deposits (NOWPayments)', 'Users get a generated address and are credited automatically.'],
  ['manual_deposit', 'Manual deposits', 'Users send to your own addresses; you check and credit each one.'],
  ['withdraw_enabled', 'Withdrawals', 'Users can request withdrawals. You send them manually and mark them sent.'],
  ['kyc_required', 'Require KYC to withdraw', 'Only users with approved identity verification can withdraw.'],
];

function AddressForm({ a }: { a: Addr }) {
  const f = useForm({ id: a.id, asset: a.asset, network: a.network, label: a.label, address: a.address, min: a.min, note: a.note ?? '', enabled: a.enabled });
  const isNew = a.id === null;
  return <form onSubmit={e => { e.preventDefault(); f.post('/admin/deposits/address', { preserveScroll: true, onSuccess: () => isNew && f.reset() }); }} className="au-form" style={{ padding: '16px 0', borderTop: '1px solid var(--ad-line)' }}>
    <Field label="Label shown to users"><Input value={f.data.label} onChange={e => f.setData('label', e.target.value)} required placeholder="USDT · TRON (TRC20)"/></Field>
    <div className="au-form" style={{ gridColumn: 'auto', gridTemplateColumns: '1fr 1fr' }}>
      <Field label="Coin"><Input value={f.data.asset} disabled={!isNew} onChange={e => f.setData('asset', e.target.value.toUpperCase())} required placeholder="USDT"/></Field>
      <Field label="Network"><Input value={f.data.network} disabled={!isNew} onChange={e => f.setData('network', e.target.value.toUpperCase())} required placeholder="TRC20"/></Field>
    </div>
    <Field label="Receiving address" wide hint="Double-check every character — funds sent to a wrong address are lost. Changes are audit-logged."><Input value={f.data.address} onChange={e => f.setData('address', e.target.value)} spellCheck={false} placeholder="Paste your wallet address"/></Field>
    <Field label="Minimum deposit"><Input inputMode="decimal" value={f.data.min} onChange={e => f.setData('min', e.target.value)} required/></Field>
    <Field label="Note shown to users"><Input value={f.data.note} onChange={e => f.setData('note', e.target.value)} placeholder="Optional"/></Field>
    <div style={{ gridColumn: '1/-1', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
      <Switch checked={f.data.enabled} onChange={v => f.setData('enabled', v)} label="Show to users"/>
      <button type="submit" className="au-btn primary" disabled={f.processing}>{isNew ? 'Add method' : 'Save'}</button>
    </div>
    {Object.values(f.errors).map(m => <small key={m} role="alert" className="neg" style={{ gridColumn: '1/-1' }}>{m}</small>)}
  </form>;
}

export default function AdminGateways({ admin, tab, switches, nowpayments, stats, networks, depositCoins, addresses }: Props) {
  const [sw, setSw] = useState(switches);
  const [nets, setNets] = useState(networks);
  const [off, setOff] = useState<string[]>(depositCoins.filter(c => c.off).map(c => c.code));
  const dirty = useMemo(() => JSON.stringify({ sw, nets, off: [...off].sort() }) !== JSON.stringify({ sw: switches, nets: networks, off: depositCoins.filter(c => c.off).map(c => c.code).sort() }), [sw, nets, off, switches, networks, depositCoins]);
  const save = () => router.post('/admin/gateways', { switches: sw, networks: nets, depositOff: off } as never, { preserveScroll: true });
  const editNet = (i: number, patch: Partial<Net>) => setNets(nets.map((n, j) => j === i ? { ...n, ...patch } : n));
  const toggleCoin = (code: string, on: boolean) => setOff(on ? off.filter(c => c !== code) : [...off, code]);
  const coins = useMemo(() => depositCoins.reduce<Record<string, Coin[]>>((a, c) => { (a[c.ticker] ||= []).push(c); return a; }, {}), [depositCoins]);

  return <AdminLayout admin={admin} active="/admin/gateways">
    <Page title="Gateways" subtitle="Everything about moving money in and out, in one place: master switches, automatic and manual deposits, and withdrawal fees & networks.">
      <Tabs base="/admin/gateways" active={tab} tabs={[
        { key: 'overview', label: 'Overview' }, { key: 'deposit-auto', label: 'Deposits · Automatic' }, { key: 'deposit-manual', label: 'Deposits · Manual', count: stats.manualPending, tone: 'warn' }, { key: 'withdraw', label: 'Withdrawals', count: stats.withdrawPending, tone: 'warn' },
      ]}/>

      {tab === 'overview' && <>
        <div className="au-stats">
          <Stat label="Auto deposits (30d)" value={stats.autoCredited30d} hint={`${stats.autoDeposits30d} addresses created`} href="/admin/deposits?tab=auto"/>
          <Stat label="Manual waiting" value={stats.manualPending} tone={stats.manualPending ? 'warn' : undefined} href="/admin/deposits"/>
          <Stat label="Withdrawals waiting" value={stats.withdrawPending} tone={stats.withdrawPending ? 'warn' : undefined} href="/admin/withdrawals"/>
          <Stat label="Sent (30d)" value={stats.withdrawDone30d} href="/admin/withdrawals?status=completed"/>
        </div>
        <Panel title="Master switches" hint="Turn a whole gateway on or off. Changes apply as soon as you save.">
          <div style={{ display: 'grid', gap: 18 }}>{SW.map(([k, t, d]) => <Switch key={k} checked={!!sw[k]} onChange={v => setSw({ ...sw, [k]: v })} label={t} hint={d}/>)}</div>
        </Panel>
      </>}

      {tab === 'deposit-auto' && <>
        <Panel title="NOWPayments connection" hint="Keys stay in the server .env (NOWPAYMENTS_API_KEY, NOWPAYMENTS_IPN_SECRET) for safety.">
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', alignItems: 'center', marginBottom: 12 }}>
            <span>API key <Badge tone={nowpayments.apiKey ? 'ok' : 'bad'}>{nowpayments.apiKey ? 'ready' : 'missing'}</Badge></span>
            <span>IPN secret <Badge tone={nowpayments.ipnSecret ? 'ok' : 'bad'}>{nowpayments.ipnSecret ? 'ready' : 'missing'}</Badge></span>
            <span>Mode <Badge tone={nowpayments.sandbox ? 'warn' : 'ok'}>{nowpayments.sandbox ? 'sandbox (test)' : 'live'}</Badge></span>
          </div>
          <small style={{ color: 'var(--ad-muted)' }}>IPN callback URL — set this in your NOWPayments dashboard:</small>
          <div style={{ marginTop: 4 }}><code style={{ overflowWrap: 'anywhere' }}>{nowpayments.ipnUrl}</code></div>
        </Panel>
        <Panel title="Coins & networks users can deposit" hint="Switch off a network to hide it from the Deposit page (existing deposits still complete).">
          <div style={{ display: 'grid', gap: 18 }}>{Object.entries(coins).map(([ticker, list]) => <div key={ticker}>
            <b style={{ display: 'block', marginBottom: 8 }}>{ticker} <small style={{ opacity: .6, fontWeight: 400 }}>{list[0].coin}</small></b>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(230px,1fr))', gap: 10 }}>{list.map(c => <div key={c.code} className="au-wallet-card"><Switch checked={!off.includes(c.code)} onChange={v => toggleCoin(c.code, v)} label={c.network} hint={c.code}/></div>)}</div>
          </div>)}</div>
        </Panel>
      </>}

      {tab === 'deposit-manual' && <Panel title="Manual deposit methods" hint="Users send to these addresses and submit the TXID. Review requests in Deposits."
        actions={<Link className="au-btn" href="/admin/deposits">Open pending deposits{stats.manualPending ? ` (${stats.manualPending})` : ''}</Link>}>
        {addresses.map(a => <AddressForm key={a.id} a={a}/>)}
        <details style={{ borderTop: '1px solid var(--ad-line)', paddingTop: 12 }}><summary style={{ cursor: 'pointer', fontWeight: 700 }}>+ Add a new method</summary>
          <AddressForm a={{ id: null, asset: 'USDT', network: '', label: '', address: '', min: '10', note: '', enabled: false }}/></details>
      </Panel>}

      {tab === 'withdraw' && <Panel title="Withdrawal networks, fees & minimums" hint="The fee is kept by the platform. The minimum is per coin (same for all its networks). Switch a network off to hide it."
        actions={<Link className="au-btn" href="/admin/withdrawals">Open queue{stats.withdrawPending ? ` (${stats.withdrawPending})` : ''}</Link>}>
        <div className="au-table-wrap"><table className="au-table">
          <thead><tr><th>Coin</th><th>Network</th><th>Min amount</th><th>Fee</th><th className="center">Enabled</th></tr></thead>
          <tbody>{nets.map((n, i) => <tr key={n.ticker + n.code}>
            <td data-label="Coin" className="primary"><b>{n.ticker}</b></td><td data-label="Network">{n.label}</td>
            <td data-label="Min amount"><Input style={{ width: 110 }} inputMode="decimal" value={n.min} onChange={e => editNet(i, { min: Number(e.target.value) || 0 })}/></td>
            <td data-label="Fee"><Input style={{ width: 110 }} inputMode="decimal" value={n.fee} onChange={e => editNet(i, { fee: Number(e.target.value) || 0 })}/></td>
            <td data-label="Enabled" className="center"><Switch checked={!n.off} onChange={v => editNet(i, { off: !v })}/></td>
          </tr>)}</tbody></table></div>
      </Panel>}

      {dirty && (tab === 'overview' || tab === 'deposit-auto' || tab === 'withdraw') && <div className="au-savebar"><span>You have unsaved gateway changes.</span><Btn onClick={() => { setSw(switches); setNets(networks); setOff(depositCoins.filter(c => c.off).map(c => c.code)); }}>Discard</Btn><button type="button" className="au-btn primary" onClick={save}>Save changes</button></div>}
    </Page>
  </AdminLayout>;
}
