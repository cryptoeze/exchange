import { useCallback, useEffect, useRef, useState } from 'react';
import { Head } from '@inertiajs/react';
import { Copy, Send } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import { api } from '../lib/wallet';
import { initials, money, STATUS_LABEL, STATUS_TONE } from '../lib/p2p';
import '../../css/p2p.css';

type Trade = { ref: string; role: 'buyer' | 'seller'; coin: string; fiat: string; price: number; qty: string; fiatAmount: number; method: string; status: string; resolution: string | null; payDetails: string | null; secondsLeft: number; terms: string | null; other: { name: string; completed: number; rate: number | null } };
type Msg = { id: number; mine: boolean; system: boolean; body: string; at: string };

export default function P2pOrder({ ref: orderRef }: { ref: string }) {
  const [t, setT] = useState<Trade | null>(null); const [msgs, setMsgs] = useState<Msg[]>([]); const [text, setText] = useState(''); const [err, setErr] = useState(''); const [left, setLeft] = useState(0);
  const [dispute, setDispute] = useState(false); const [reason, setReason] = useState(''); const [copied, setCopied] = useState(false); const end = useRef<HTMLDivElement>(null);
  const apply = (d: { trade: Trade; messages: Msg[] }) => { setT(d.trade); setMsgs(d.messages); setLeft(d.trade.secondsLeft); };
  const load = useCallback(async () => { const r = await api<{ trade: Trade; messages: Msg[] }>(`/api/p2p/trades/${orderRef}`); if (r.ok) apply(r.data); else setErr(r.data.message ?? 'Order not found.'); }, [orderRef]);
  useEffect(() => { void load(); const i = window.setInterval(() => { if (!document.hidden) void load(); }, 4000); return () => window.clearInterval(i); }, [load]);
  useEffect(() => { const i = window.setInterval(() => setLeft(v => Math.max(0, v - 1)), 1000); return () => window.clearInterval(i); }, []);
  useEffect(() => { end.current?.scrollIntoView({ block: 'nearest' }); }, [msgs.length]);
  const act = async (path: string, body: Record<string, unknown> = {}, confirmText?: string) => {
    if (confirmText && !window.confirm(confirmText)) return; setErr('');
    const r = await api<{ trade: Trade; messages: Msg[] }>(`/api/p2p/trades/${orderRef}/${path}`, body);
    if (r.ok) apply(r.data); else setErr(r.data.message ?? 'Action failed.');
  };
  const send = async () => { if (!text.trim()) return; const body = text; setText(''); await act('message', { body }); };
  if (!t) return <AccountLayout active="P2P" title="P2P order" showNav={false} phoneBar><main className="p2-wrap"><p className="p2-empty">{err || 'Loading order…'}</p></main></AccountLayout>;
  const buyer = t.role === 'buyer'; const mm = String(Math.floor(left / 60)).padStart(2, '0'); const ss = String(left % 60).padStart(2, '0');
  const active = ['pending', 'paid', 'disputed'].includes(t.status);
  return <AccountLayout active="P2P" title={`Order ${t.ref}`} showNav={false} phoneBar>
    <Head title={`Order ${t.ref} — RushX`}/>
    <main className="p2-wrap p2-room">
      <section className="p2-card">
        <div className="p2-status" style={{ color: STATUS_TONE[t.status] }}>{STATUS_LABEL[t.status] ?? t.status}{t.status === 'pending' && <span> · {mm}:{ss}</span>}</div>
        <h1 className="p2-h1">{buyer ? 'Buy' : 'Sell'} {t.qty} {t.coin}</h1>
        <dl className="p2-dl"><div><dt>{buyer ? 'You pay' : 'You receive'}</dt><dd><b>{money(t.fiatAmount)} {t.fiat}</b></dd></div><div><dt>Price</dt><dd>{money(t.price)} {t.fiat}</dd></div><div><dt>Payment method</dt><dd>{t.method}</dd></div><div><dt>Order</dt><dd>{t.ref}</dd></div></dl>
        <div className="p2-who2"><span className="p2-av">{initials(t.other.name)}</span><span><b>{t.other.name}</b><small>{t.other.completed} orders · {t.other.rate === null ? 'new trader' : `${t.other.rate}% completion`}</small></span></div>
        {t.payDetails && (buyer ? <div className="p2-pay"><small>Send {money(t.fiatAmount)} {t.fiat} to</small><pre>{t.payDetails}</pre><button type="button" onClick={() => { void navigator.clipboard?.writeText(t.payDetails ?? ''); setCopied(true); window.setTimeout(() => setCopied(false), 1500); }}><Copy size={14}/> {copied ? 'Copied' : 'Copy details'}</button></div> : <div className="p2-pay"><small>Your receiving details</small><pre>{t.payDetails}</pre></div>)}
        {t.terms && <details className="p2-terms"><summary>Advertiser terms</summary><p>{t.terms}</p></details>}
        {t.resolution && <p className="p2-note">{t.resolution}</p>}
        {err && <p className="p2-err" role="alert">{err}</p>}
        <div className="p2-actions">
          {t.status === 'pending' && buyer && <><button type="button" className="p2-cta buy" onClick={() => act('paid', {}, 'Confirm only after you have really sent the payment. False confirmations can get your account restricted.')}>I have paid</button><button type="button" className="p2-ghost" onClick={() => act('cancel', {}, 'Cancel this order? Do not cancel if you have already paid.')}>Cancel order</button></>}
          {t.status === 'pending' && !buyer && <p className="p2-sub">Waiting for the buyer to pay. Your coins are safe in escrow.</p>}
          {t.status === 'paid' && !buyer && <><button type="button" className="p2-cta sell" onClick={() => act('release', {}, `Release ${t.qty} ${t.coin} to the buyer? Only do this after the money is in your account.`)}>Release coins</button></>}
          {t.status === 'paid' && buyer && <p className="p2-sub">Waiting for the seller to check the payment and release the coins.</p>}
          {t.status === 'paid' && <button type="button" className="p2-ghost danger" onClick={() => setDispute(v => !v)}>Open a dispute</button>}
          {t.status === 'disputed' && <p className="p2-sub">RushX support is reviewing this order. Add anything useful to the chat below.</p>}
          {t.status === 'completed' && <p className="p2-ok">{buyer ? `${t.qty} ${t.coin} was added to your Funding account.` : 'Order complete.'}</p>}
        </div>
        {dispute && <div className="p2-dispute"><textarea placeholder="Tell support what went wrong (min. 5 characters)" value={reason} onChange={e => setReason(e.target.value)} maxLength={300}/><button type="button" className="p2-cta sell" disabled={reason.trim().length < 5} onClick={() => { void act('dispute', { reason }); setDispute(false); }}>Send dispute</button></div>}
      </section>
      <section className="p2-card p2-chat">
        <h2>Chat</h2>
        <div className="p2-msgs">{msgs.map(m => <div key={m.id} className={`p2-msg${m.system ? ' sys' : m.mine ? ' me' : ''}`}>{m.body}<small>{m.at.slice(11, 16)}</small></div>)}<div ref={end}/></div>
        {active || t.status === 'completed' ? <div className="p2-send"><input value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Write a message…" maxLength={500}/><button type="button" aria-label="Send" onClick={send}><Send size={18}/></button></div> : null}
      </section>
    </main>
  </AccountLayout>;
}
