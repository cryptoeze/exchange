import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from '@inertiajs/react';
import { ArrowLeftRight, ChevronDown, ChevronRight, Eye, EyeOff, MoreHorizontal, RefreshCw, Search, X } from 'lucide-react';
import AccountLayout from '../components/AccountLayout';
import CoinImage from '../components/CoinImage';
import { COIN_NAMES, useSpotPrices, useWallet } from '../lib/hooks';
import { api, newKey, usd, usdValue, type WalletPayload } from '../lib/wallet';

type Kind = 'funding' | 'trading';
const SMALL_USD = 1;
const isFundingKind = (k: Kind) => k === 'funding';

/** Funding and Trading account pages: live valuation, assets with a row menu, recent activity. */
export default function AccountPage({ kind }: { kind: Kind }) {
  const { wallet, setWallet, error } = useWallet(kind);
  const other = useWallet(kind === 'funding' ? 'trading' : 'funding');
  const prices = useSpotPrices();
  const [visible, setVisible] = useState(true);
  const [query, setQuery] = useState('');
  const [hideSmall, setHideSmall] = useState(false);
  const [menu, setMenu] = useState<string | null>(null);
  const [modal, setModal] = useState(() => typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('transfer') === '1');
  const wrap = useRef<HTMLDivElement>(null);
  const mask = (text: string) => visible ? text : '******';

  useEffect(() => { const close = (e: PointerEvent) => { if (wrap.current && !wrap.current.contains(e.target as Node)) setMenu(null); }; document.addEventListener('pointerdown', close); return () => document.removeEventListener('pointerdown', close); }, []);

  // The Trading account also counts margin locked in open futures positions.
  const rows = useMemo(() => {
    const merged = new Map<string, number>();
    for (const b of wallet?.balances ?? []) if (b.account === kind || (kind === 'trading' && b.account === 'futures')) merged.set(b.asset, (merged.get(b.asset) ?? 0) + b.units / 1e8);
    return [...merged].map(([asset, amount]) => ({ asset, balance: '', units: amount * 1e8, account: kind, amount, value: usdValue(asset, amount, prices) })).filter(r => r.amount > 0);
  }, [wallet, kind, prices]);
  const lockedMargin = kind === 'trading' ? (wallet?.balances.find(b => b.account === 'futures' && b.asset === 'USDT')?.units ?? 0) / 1e8 : 0;
  const total = rows.reduce((sum, r) => sum + r.value, 0);
  const usdt = (wallet?.balances.find(b => b.account === kind && b.asset === 'USDT')?.units ?? 0) / 1e8;
  const list = rows.filter(r => (!query || r.asset.toLowerCase().includes(query.toLowerCase())) && (!hideSmall || r.value >= SMALL_USD)).sort((a, b) => b.value - a.value);
  const usdtIn = (p: WalletPayload | null, account: Kind) => (p?.balances.find(x => x.account === account && x.asset === 'USDT')?.units ?? 0) / 1e8;
  const funding = usdtIn(isFundingKind(kind) ? wallet : other.wallet, 'funding'); const trading = usdtIn(kind === 'trading' ? wallet : other.wallet, 'trading');
  const isFunding = kind === 'funding';
  const title = isFunding ? 'Funding' : 'Trading';

  return <AccountLayout active={title} title={title}>
    <main className="ov-main">
      <div className="ov-left">
        <section className="ov-card">
          <div className="ov-lbl">{isFunding ? 'Estimated value' : 'Estimated total value'} <button type="button" aria-label={visible ? 'Hide balances' : 'Show balances'} onClick={() => setVisible(v => !v)}>{visible ? <Eye/> : <EyeOff/>}</button></div>
          <div className="ov-total"><span>{wallet ? mask(usd(total)) : '—'}</span><small>USD <ChevronDown/></small></div>
          <div className="ov-actions">
            {isFunding ? <><Link href="/deposit" className="primary">Deposit</Link><Link href="/withdraw">Withdraw</Link><button type="button" onClick={() => setModal(true)}>Transfer</button><Link href="/convert">Convert</Link></>
              : <><Link href="/spot" className="primary">Spot Trading</Link><Link href="/convert">Convert</Link><button type="button" onClick={() => setModal(true)}>Transfer</button></>}
          </div>
          {!isFunding && <><h3 className="ap-sub">Trading account status</h3>
            <div className="ap-status"><div><small>Total equity</small><b>{wallet ? mask(`$${usd(total)}`) : '—'}</b></div><div><small>Available balance</small><b className="up">{wallet ? mask(`${usd(usdt, 4)} USDT`) : '—'}</b></div><div><small>In open positions</small><b>{wallet ? mask(`${usd(lockedMargin, 2)} USDT`) : '—'}</b></div></div>
            <p className="ap-note">Funds in this account are the margin for futures trading. Spot trades use your Funding account.</p></>}
        </section>

        <section className="ov-card" ref={wrap}>
          <h2>Assets</h2>
          <div className="ov-search"><label><Search/><input placeholder="Search" value={query} onChange={e => setQuery(e.target.value)} aria-label="Search assets"/></label>
            <div className="ap-tools"><label><input type="checkbox" checked={hideSmall} onChange={e => setHideSmall(e.target.checked)}/> Hide small assets</label><Link href="/convert"><RefreshCw/> Easy convert</Link></div></div>
          <table className="ov-table ap-assets"><thead><tr><th>Name</th><th>Balance</th><th>Equity (USD)</th><th aria-label="Actions"/></tr></thead>
            <tbody>{!wallet ? <tr><td colSpan={4} className="ov-empty">{error || 'Loading balances…'}</td></tr> : list.length === 0 ? <tr><td colSpan={4} className="ov-empty">{rows.length ? 'No assets match.' : `No assets in your ${title} account yet.`}</td></tr> : list.map(r => <tr key={r.asset} onClick={() => window.location.assign(r.asset === 'USDT' ? '/spot' : `/spot?pair=${r.asset}USDT`)}>
              <td><div className="ov-name"><span className="ov-coin"><CoinImage symbol={r.asset} icon={prices.get(`${r.asset}USDT`)?.icon}/></span><div><b>{r.asset} <ChevronRight className="ap-chev"/></b><small>{COIN_NAMES[r.asset] ?? r.asset}</small></div></div></td>
              <td>{mask(r.amount >= 1 ? r.amount.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 }) : r.amount.toFixed(8).replace(/0+$/, '').replace(/\.$/, ''))}</td>
              <td>{mask(r.value < 0.01 ? '<$0.01' : `$${usd(r.value)}`)}</td>
              <td className="ap-more" onClick={e => e.stopPropagation()}><button type="button" aria-label={`${r.asset} actions`} aria-expanded={menu === r.asset} onClick={() => setMenu(m => m === r.asset ? null : r.asset)}><MoreHorizontal/></button>
                {menu === r.asset && <div className="ap-menu" role="menu"><Link href="/deposit" role="menuitem">Deposit</Link><button type="button" role="menuitem" onClick={() => { setMenu(null); setModal(true); }}>Transfer</button><Link href={r.asset === 'USDT' ? '/spot' : `/spot?pair=${r.asset}USDT`} role="menuitem">Trade</Link></div>}</td>
            </tr>)}</tbody></table>
        </section>
      </div>

      <aside className="ov-right"><section className="ov-card">
        <header><h2>{isFunding ? 'Recent funding history' : 'Recent transactions'}</h2><Link href="/orders">View more <ChevronRight/></Link></header>
        {!wallet ? <p className="ov-empty">Loading…</p> : wallet.history.length === 0 ? <p className="ov-empty">No activity yet.</p> : wallet.history.map(h => <div className="ov-hist" key={h.id}>
          <div><b>{h.title}</b><small>{h.at ? new Date(h.at).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : ''}</small></div>
          <span className={h.positive ? 'up' : 'down'}>{mask(`${h.positive ? '+' : ''}${h.amount} ${h.asset}`)}</span></div>)}
      </section></aside>
    </main>
    {modal && <TransferModal initial={kind} funding={funding} trading={trading} onClose={() => setModal(false)} onDone={(p: WalletPayload) => { setWallet(p); void other.reload(); setModal(false); }}/>}
  </AccountLayout>;
}

function TransferModal({ initial, funding, trading, onClose, onDone }: { initial: Kind; funding: number; trading: number; onClose: () => void; onDone: (payload: WalletPayload) => void }) {
  const [from, setFrom] = useState<Kind>(initial);
  const [amount, setAmount] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [key] = useState(newKey);
  const to: Kind = from === 'funding' ? 'trading' : 'funding'; const max = from === 'funding' ? funding : trading;
  const submit = async () => {
    setErr(''); if (!/^\d+(\.\d{1,8})?$/.test(amount) || Number(amount) <= 0) { setErr('Enter a valid amount.'); return; }
    setBusy(true); const r = await api<WalletPayload>('/api/wallet/transfer', { from, to, amount, idempotency_key: key }); setBusy(false);
    if (r.ok) onDone(r.data); else setErr(r.data.message ?? 'Transfer failed.');
  };
  const name = (k: Kind) => k === 'funding' ? 'Funding' : 'Trading';
  return <div className="ov-modal" role="dialog" aria-modal="true" aria-label="Transfer" onClick={onClose}><div onClick={e => e.stopPropagation()}>
    <header><b>Transfer</b><button type="button" aria-label="Close" onClick={onClose}><X/></button></header>
    <div className="ov-tr"><div><small>From {name(from)} Account</small><b>${usd(max)}</b></div><button type="button" aria-label="Swap direction" onClick={() => setFrom(to)}><ArrowLeftRight/></button><div><small>To {name(to)} Account</small></div></div>
    <label>Amount (USDT)<div className="ov-amt"><input inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00"/><button type="button" onClick={() => setAmount(String(Math.floor(max * 1e8) / 1e8))}>Max</button></div></label>
    {err && <p className="ov-err" role="alert">{err}</p>}
    <button type="button" className="ov-confirm" disabled={busy} onClick={submit}>{busy ? 'Please wait…' : 'Confirm'}</button>
  </div></div>;
}
