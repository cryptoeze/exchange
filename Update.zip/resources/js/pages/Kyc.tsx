import { useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import { ArrowLeft, BadgeCheck, Clock, ShieldAlert } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import { COUNTRIES } from '../lib/countries';
import { useTheme } from '../lib/hooks';
import '../../css/overview.css';
import '../../css/profile.css';

type Props = { status: string; required: boolean; profile: { country: string | null; phone: string | null }; last: { status: string; reason: string | null; at: string } | null };

export default function Kyc({ status, required, profile, last }: Props) {
  useTheme();
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  const [busy, setBusy] = useState(false);
  const [country, setCountry] = useState(profile.country ?? 'Pakistan');
  const locked = !!(profile.country && profile.phone);
  const [dial, setDial] = useState('+92');
  const pick = (name: string) => { setCountry(name); const c = COUNTRIES.find(x => x.name === name); if (c) setDial(c.dial); };
  const submit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault(); setBusy(true); router.post('/kyc', new FormData(e.currentTarget), { forceFormData: true, onFinish: () => setBusy(false) }); };
  const state = status === 'approved' ? ['Verified', <BadgeCheck key="i"/>, 'ok'] : status === 'pending' ? ['Under review', <Clock key="i"/>, 'wait'] : status === 'rejected' ? ['Rejected — submit again', <ShieldAlert key="i"/>, 'bad'] : ['Not verified', <ShieldAlert key="i"/>, 'wait'];
  return <><Head title="Identity verification — RushX"/>
    <div className="ov-shell pf-shell rx-dashboard">
      <header className="pf-top"><button type="button" aria-label="Back" onClick={() => (window.history.length > 1 ? window.history.back() : (window.location.href = '/profile'))}><ArrowLeft/></button><b>Identity verification</b><span/></header>
      <section className="pf-card" style={{ margin: '16px' }}><div className={`pf-row static kyc-${state[2]}`}><span className="pf-ico">{state[1]}</span><span className="pf-txt"><b>{state[0] as string}</b><small>{required ? 'Required before withdrawing.' : 'Optional right now, but may be required for withdrawals.'}{last?.reason ? ` Reason: ${last.reason}` : ''}</small></span></div></section>
      {page.flash?.status && <p className="kyc-msg ok" role="status">{page.flash.status}</p>}
      {Object.values(page.errors ?? {}).map(m => <p key={m} className="kyc-msg bad" role="alert">{m}</p>)}
      {(status === 'none' || status === 'rejected') && <form className="kyc-form" onSubmit={submit}>
        <label>Full name (as on document)<input name="full_name" required maxLength={120}/></label>
        {locked ? <>
          <label>Country<input value={profile.country ?? ''} readOnly aria-readonly="true"/><small>Taken from your account.</small></label>
          <label>Mobile number<input value={profile.phone ?? ''} readOnly aria-readonly="true"/><small>Taken from your account.</small></label>
        </> : <>
          <label>Country<select name="country" required value={country} onChange={e => pick(e.target.value)}>{COUNTRIES.map(c => <option key={c.name} value={c.name}>{c.name} ({c.dial})</option>)}</select></label>
          <label>Mobile number<span className="kyc-phone"><select name="dial" value={dial} onChange={e => setDial(e.target.value)} aria-label="Country code">{Array.from(new Set(COUNTRIES.map(c => c.dial))).sort((x, y) => Number(x.slice(1)) - Number(y.slice(1))).map(d => <option key={d} value={d}>{d}</option>)}</select><input name="phone" type="tel" inputMode="numeric" pattern="[0-9]{5,14}" placeholder="3001234567" required maxLength={14}/></span></label>
        </>}
        <label>Document photo (front)<input type="file" name="front" accept="image/jpeg,image/png" required/></label>
        <label>Document photo (back)<input type="file" name="back" accept="image/jpeg,image/png" required/></label>
        <button type="submit" disabled={busy}>{busy ? 'Uploading…' : 'Submit for review'}</button>
        <small>JPG or PNG, up to 5 MB each — front and back of your ID card. Files are stored privately and only reviewed by RushX staff.</small>
      </form>}
      <MobileNav active="home"/>
    </div></>;
}
