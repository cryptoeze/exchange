import { useState } from 'react';
import { Head, router, usePage } from '@inertiajs/react';
import { ArrowLeft, BadgeCheck, Clock, ShieldAlert } from 'lucide-react';
import MobileNav from '../components/MobileNav';
import { useTheme } from '../lib/hooks';
import '../../css/overview.css';
import '../../css/profile.css';

type Props = { status: string; required: boolean; last: { status: string; reason: string | null; at: string } | null };

export default function Kyc({ status, required, last }: Props) {
  useTheme();
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  const [busy, setBusy] = useState(false);
  const submit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault(); setBusy(true); router.post('/kyc', new FormData(e.currentTarget), { forceFormData: true, onFinish: () => setBusy(false) }); };
  const state = status === 'approved' ? ['Verified', <BadgeCheck key="i"/>, 'ok'] : status === 'pending' ? ['Under review', <Clock key="i"/>, 'wait'] : status === 'rejected' ? ['Rejected — submit again', <ShieldAlert key="i"/>, 'bad'] : ['Not verified', <ShieldAlert key="i"/>, 'wait'];
  return <><Head title="Identity verification — RushX"/>
    <div className="ov-shell pf-shell rx-dashboard">
      <header className="pf-top"><button type="button" aria-label="Back" onClick={() => (window.history.length > 1 ? window.history.back() : (window.location.href = '/profile'))}><ArrowLeft/></button><b>Identity verification</b><span/></header>
      <section className="pf-card" style={{ margin: '16px' }}><div className={`pf-row static kyc-${state[2]}`}><span className="pf-ico">{state[1]}</span><span className="pf-txt"><b>{state[0] as string}</b><small>{required ? 'Required before withdrawing.' : 'Optional right now, but may be required for withdrawals.'}{last?.reason ? ` Reason: ${last.reason}` : ''}</small></span></div></section>
      {page.flash?.status && <p className="kyc-msg ok" role="status">{page.flash.status}</p>}
      {Object.values(page.errors ?? {}).map(m => <p key={m} className="kyc-msg bad" role="alert">{m}</p>)}
      {(status === 'none' || status === 'rejected') && <form className="kyc-form" onSubmit={submit}>
        <label>Full name (as on document)<input name="full_name" required maxLength={120}/></label>
        <label>Country<input name="country" required maxLength={80}/></label>
        <label>Document type<select name="doc_type" defaultValue="national_id"><option value="national_id">National ID</option><option value="passport">Passport</option><option value="driving_license">Driving licence</option></select></label>
        <label>Document number<input name="doc_number" required maxLength={64}/></label>
        <label>Document photo (front)<input type="file" name="front" accept="image/jpeg,image/png" required/></label>
        <label>Selfie holding the document<input type="file" name="selfie" accept="image/jpeg,image/png" required/></label>
        <button type="submit" disabled={busy}>{busy ? 'Uploading…' : 'Submit for review'}</button>
        <small>JPG or PNG, up to 5 MB each. Files are stored privately and only reviewed by RushX staff.</small>
      </form>}
      <MobileNav active="home"/>
    </div></>;
}
