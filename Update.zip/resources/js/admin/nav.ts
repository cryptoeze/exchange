import {
  ArrowDownToLine, ArrowUpFromLine, Bot, CandlestickChart, ClipboardList, FileCheck2, Handshake, Landmark, LayoutDashboard,
  LifeBuoy, Mail, Megaphone, PiggyBank, Receipt, ScrollText, Settings2, ShieldCheck, Store, TrendingUp, Users, UsersRound, Wallet,
  Gift, Network, type LucideIcon,
} from 'lucide-react';

/**
 * SINGLE SOURCE OF TRUTH for the admin sitemap.
 * - The sidebar, the section tabs shown at the top of every page and the role filter all read this list.
 * - To add a page: add one item here (+ the route, controller and page component). Nothing else to touch on the frontend.
 * - `roles`: which NON-super admin roles may see/open it (super admins see everything). Keep in sync with
 *   App\Http\Middleware\EnsureAdmin::ROLE_PATHS (the server is the real gatekeeper).
 * - `badge`: key of a live count in the shared `adminBadges` prop (see HandleInertiaRequests).
 */
export type AdminRole = 'finance' | 'support';
export type NavItem = { label: string; href: string; icon: LucideIcon; roles?: AdminRole[]; badge?: string; match?: string[] };
export type NavGroup = { title: string; items: NavItem[] };

export const ADMIN_NAV: NavGroup[] = [
  { title: 'Overview', items: [
    { label: 'Dashboard', href: '/admin', icon: LayoutDashboard, roles: ['finance', 'support'] },
  ] },
  { title: 'Users & compliance', items: [
    { label: 'Users', href: '/admin/users', icon: Users, roles: ['finance', 'support'] },
    { label: 'KYC review', href: '/admin/kyc', icon: FileCheck2, roles: ['support'], badge: 'kyc' },
    { label: 'Referrals', href: '/admin/referrals', icon: Handshake, roles: ['finance', 'support'] },
    { label: 'Support tickets', href: '/admin/tickets', icon: LifeBuoy, roles: ['support'], badge: 'tickets' },
  ] },
  { title: 'Money', items: [
    { label: 'Transactions', href: '/admin/transactions', icon: Receipt, roles: ['finance'] },
    { label: 'Deposits', href: '/admin/deposits', icon: ArrowDownToLine, roles: ['finance'], badge: 'deposits' },
    { label: 'Withdrawals', href: '/admin/withdrawals', icon: ArrowUpFromLine, roles: ['finance'], badge: 'withdrawals' },
    { label: 'Gateways', href: '/admin/gateways', icon: Landmark, roles: ['finance'] },
    { label: 'Proof of Reserves', href: '/admin/por', icon: ShieldCheck, roles: ['finance'] },
  ] },
  { title: 'Trading', items: [
    { label: 'Spot trades', href: '/admin/trades', icon: CandlestickChart, roles: ['finance', 'support'] },
    { label: 'Futures', href: '/admin/futures', icon: TrendingUp, roles: ['finance'] },
    { label: 'Limit & TP/SL', href: '/admin/orders', icon: ClipboardList, roles: ['finance'] },
    { label: 'Markets on/off', href: '/admin/markets', icon: Store },
    { label: 'P2P desk', href: '/admin/p2p', icon: Network, roles: ['support'], badge: 'disputes' },
  ] },
  { title: 'Products', items: [
    { label: 'Earn', href: '/admin/earn', icon: PiggyBank, roles: ['finance'] },
    { label: 'Bots', href: '/admin/bots', icon: Bot },
    { label: 'Copy traders', href: '/admin/traders', icon: UsersRound },
  ] },
  { title: 'Communication', items: [
    { label: 'Notifications', href: '/admin/notifications', icon: Megaphone, roles: ['support'] },
    { label: 'Email templates', href: '/admin/emails', icon: Mail },
  ] },
  { title: 'System', items: [
    { label: 'Settings', href: '/admin/settings', icon: Settings2 },
    { label: 'Admin team', href: '/admin/team', icon: Gift },
    { label: 'Audit log', href: '/admin/audit', icon: ScrollText },
    { label: 'My security', href: '/admin/security', icon: Wallet, roles: ['finance', 'support'] },
  ] },
];

export const canSee = (item: NavItem, role: string) => role === 'super' || (item.roles ?? []).includes(role as AdminRole);

/** The group an active href belongs to (used for the section tabs). */
export function groupOf(active: string): NavGroup | undefined {
  return ADMIN_NAV.find(g => g.items.some(i => i.href === active));
}
