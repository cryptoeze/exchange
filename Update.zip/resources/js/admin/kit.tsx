import { Link, router, usePage } from '@inertiajs/react';
import { ArrowLeft, Check, ChevronLeft, ChevronRight, Copy as CopyIcon, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import '../../css/admin-ui.css';

/* ───────────────────────── Page chrome ───────────────────────── */

export function Flash() {
  const page = usePage().props as { flash?: { status?: string }; errors?: Record<string, string> };
  const errors = Object.values(page.errors ?? {});
  return <>
    {page.flash?.status && <div className="au-flash ok" role="status"><Check size={16}/>{page.flash.status}</div>}
    {errors.map(m => <div key={m} className="au-flash bad" role="alert">{m}</div>)}
  </>;
}

/** Standard page: heading + optional actions + flash + content. Every admin page should use this. */
export function Page({ title, subtitle, back, actions, children }: { title: ReactNode; subtitle?: ReactNode; back?: { href: string; label: string }; actions?: ReactNode; children: ReactNode }) {
  return <div className="admin-content au-page">
    {back && <Link className="au-back" href={back.href}><ArrowLeft size={15}/> {back.label}</Link>}
    <div className="au-head"><div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{actions && <div className="au-head-actions">{actions}</div>}</div>
    <Flash/>
    {children}
  </div>;
}

export function Panel({ title, hint, actions, children, flush }: { title?: ReactNode; hint?: ReactNode; actions?: ReactNode; children: ReactNode; flush?: boolean }) {
  return <section className="au-panel">
    {(title || actions) && <header><div><h2>{title}</h2>{hint && <small>{hint}</small>}</div>{actions && <div className="au-panel-actions">{actions}</div>}</header>}
    <div className={flush ? 'au-flush' : 'au-body'}>{children}</div>
  </section>;
}

/* ───────────────────────── Stats ───────────────────────── */

export type StatProps = { label: string; value: ReactNode; hint?: ReactNode; href?: string; tone?: 'ok' | 'warn' | 'bad' | 'info' };
export function Stat({ label, value, hint, href, tone }: StatProps) {
  const body = <><span className="au-stat-label">{label}</span><b className={tone ? `t-${tone}` : ''}>{value}</b>{hint && <small>{hint}</small>}</>;
  return href ? <Link href={href} className="au-stat link">{body}</Link> : <div className="au-stat">{body}</div>;
}
export function Stats({ items }: { items: StatProps[] }) {
  return <div className="au-stats">{items.map(s => <Stat key={s.label} {...s}/>)}</div>;
}

/* ───────────────────────── Tabs ───────────────────────── */

export type TabDef = { key: string; label: string; count?: number | null; tone?: 'warn' | 'bad' };
/** Tabs driven by a query parameter, e.g. ?tab=wallet. Keeps other query params unless listed in `reset`. */
export function Tabs({ tabs, active, param = 'tab', base, keep = [] }: { tabs: TabDef[]; active: string; param?: string; base: string; keep?: string[] }) {
  const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const href = (key: string) => {
    const q = new URLSearchParams();
    keep.forEach(k => { const v = params.get(k); if (v) q.set(k, v); });
    q.set(param, key);
    return `${base}?${q.toString()}`;
  };
  return <nav className="au-tabs" aria-label="Sections">{tabs.map(t => <Link key={t.key} href={href(t.key)} preserveScroll className={`au-tab${t.key === active ? ' on' : ''}`} aria-current={t.key === active ? 'page' : undefined}>
    {t.label}{t.count != null && t.count > 0 && <i className={t.tone ?? ''}>{t.count > 99 ? '99+' : t.count}</i>}
  </Link>)}</nav>;
}

/* ───────────────────────── Badges ───────────────────────── */

const TONES: Record<string, string> = {
  pending: 'warn', waiting: 'warn', confirming: 'warn', paid: 'warn', open: 'warn', answered: 'info', online: 'ok',
  completed: 'ok', approved: 'ok', confirmed: 'ok', finished: 'ok', sent: 'ok', filled: 'ok', closed: 'muted', active: 'ok', verified: 'ok', credited: 'ok', released: 'ok',
  rejected: 'bad', failed: 'bad', cancelled: 'muted', canceled: 'muted', expired: 'muted', frozen: 'bad', liquidation: 'bad', disputed: 'bad', refunded: 'muted', offline: 'muted', none: 'muted',
};
export function Badge({ children, tone }: { children: ReactNode; tone?: string }) {
  const text = String(children ?? '');
  return <span className={`au-badge ${tone ?? TONES[text.toLowerCase()] ?? 'muted'}`}>{text}</span>;
}

/* ───────────────────────── Buttons & fields ───────────────────────── */

export function Btn({ children, variant = 'ghost', size, ...rest }: { children: ReactNode; variant?: 'primary' | 'ghost' | 'danger' | 'ok'; size?: 'sm' } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type="button" {...rest} className={`au-btn ${variant}${size === 'sm' ? ' sm' : ''} ${rest.className ?? ''}`}>{children}</button>;
}
export function Field({ label, hint, children, wide }: { label: string; hint?: ReactNode; children: ReactNode; wide?: boolean }) {
  return <label className={`au-field${wide ? ' wide' : ''}`}><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>;
}
export const Input = (p: React.InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={`au-input ${p.className ?? ''}`}/>;
export const Select = (p: React.SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={`au-input ${p.className ?? ''}`}/>;
export function Switch({ checked, onChange, label, hint, disabled }: { checked: boolean; onChange: (v: boolean) => void; label?: ReactNode; hint?: ReactNode; disabled?: boolean }) {
  return <label className={`au-switch${disabled ? ' off' : ''}`}><input type="checkbox" checked={checked} disabled={disabled} onChange={e => onChange(e.target.checked)}/><i aria-hidden="true"/>{(label || hint) && <span>{label && <b>{label}</b>}{hint && <small>{hint}</small>}</span>}</label>;
}

export function Copy({ text, children }: { text: string; children?: ReactNode }) {
  const [done, setDone] = useState(false);
  return <button type="button" className="au-copy" title="Copy" onClick={() => { void navigator.clipboard?.writeText(text); setDone(true); window.setTimeout(() => setDone(false), 1200); }}>{children ?? text}{done ? <Check size={13}/> : <CopyIcon size={13}/>}</button>;
}

/** One-click link to a user's 360° page. */
export function UserLink({ id, name, email }: { id: number; name?: string | null; email?: string | null }) {
  return <Link className="au-user" href={`/admin/users/${id}`}><b>{name || email || `#${id}`}</b>{name && email && <small>{email}</small>}</Link>;
}

/* ───────────────────────── Modal / confirm with fields ───────────────────────── */

export function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', k);
    document.body.style.overflow = 'hidden';
    ref.current?.querySelector<HTMLElement>('input,textarea,select,button.primary,button.danger')?.focus();
    return () => { document.removeEventListener('keydown', k); document.body.style.overflow = ''; };
  }, [onClose]);
  return <div className="au-modal-layer" role="dialog" aria-modal="true" aria-label={title}>
    <button type="button" className="au-modal-scrim" aria-label="Close" onClick={onClose}/>
    <div className="au-modal" ref={ref}><header><h3>{title}</h3><button type="button" onClick={onClose} aria-label="Close"><X size={18}/></button></header><div className="au-modal-body">{children}</div>{footer && <footer>{footer}</footer>}</div>
  </div>;
}

/** Action button that opens a small form (reason, amount, tx hash…) and posts to `url`. */
export type ActionField = { name: string; label: string; placeholder?: string; required?: boolean; defaultValue?: string; type?: 'text' | 'textarea' | 'number' };
export function ActionButton({ label, title, url, fields = [], variant = 'ghost', size = 'sm', note, data = {}, confirmText, method = 'post' }: {
  label: ReactNode; title?: string; url: string; fields?: ActionField[]; variant?: 'primary' | 'ghost' | 'danger' | 'ok'; size?: 'sm'; note?: ReactNode; data?: Record<string, unknown>; confirmText?: string; method?: 'post' | 'delete';
}) {
  const [open, setOpen] = useState(false);
  const [vals, setVals] = useState<Record<string, string>>(() => Object.fromEntries(fields.map(f => [f.name, f.defaultValue ?? ''])));
  const [busy, setBusy] = useState(false);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    router[method](url, { ...data, ...vals } as never, { preserveScroll: true, onSuccess: () => setOpen(false), onFinish: () => setBusy(false) });
  };
  if (fields.length === 0) {
    return <Btn variant={variant} size={size} onClick={() => { if (!confirmText || window.confirm(confirmText)) router[method](url, data as never, { preserveScroll: true }); }}>{label}</Btn>;
  }
  return <>
    <Btn variant={variant} size={size} onClick={() => setOpen(true)}>{label}</Btn>
    {open && <Modal title={title ?? String(label)} onClose={() => setOpen(false)}>
      <form onSubmit={submit} className="au-form">
        {note && <p className="au-note">{note}</p>}
        {fields.map(f => <Field key={f.name} label={f.label} wide>
          {f.type === 'textarea' ? <textarea className="au-input" rows={3} placeholder={f.placeholder} required={f.required} value={vals[f.name]} onChange={e => setVals({ ...vals, [f.name]: e.target.value })}/>
            : <Input type={f.type === 'number' ? 'text' : 'text'} inputMode={f.type === 'number' ? 'decimal' : undefined} placeholder={f.placeholder} required={f.required} value={vals[f.name]} onChange={e => setVals({ ...vals, [f.name]: e.target.value })}/>}
        </Field>)}
        <div className="au-form-actions"><Btn onClick={() => setOpen(false)}>Cancel</Btn><button type="submit" className={`au-btn ${variant === 'ghost' ? 'primary' : variant}`} disabled={busy}>{busy ? 'Working…' : (typeof label === 'string' ? label : 'Confirm')}</button></div>
      </form>
    </Modal>}
  </>;
}

/* ───────────────────────── Filters ───────────────────────── */

export type FilterDef =
  | { name: string; type: 'search'; placeholder?: string }
  | { name: string; type: 'select'; label?: string; options: Array<[string, string]> }
  | { name: string; type: 'date'; label?: string };

/** GET-driven filter bar: values live in the URL, so every filtered view is shareable and survives refresh. */
export function FilterBar({ url, defs, values, extra, hidden = {} }: { url: string; defs: FilterDef[]; values: Record<string, string>; extra?: ReactNode; hidden?: Record<string, string> }) {
  const [v, setV] = useState<Record<string, string>>(values);
  useEffect(() => setV(values), [values]);
  const run = (next: Record<string, string>) => {
    const clean = Object.fromEntries(Object.entries({ ...hidden, ...next }).filter(([, x]) => x !== '' && x != null));
    router.get(url, clean as never, { preserveState: true, preserveScroll: true, replace: true });
  };
  const active = defs.some(d => (values[d.name] ?? '') !== '');
  return <form className="au-filters" onSubmit={e => { e.preventDefault(); run({ ...v, page: '' }); }}>
    {defs.map((d, i) => d.type === 'search'
      ? <Input key={d.name} className={defs.findIndex(x => x.type === 'search') === i ? 'grow' : ''} type="search" placeholder={d.placeholder ?? 'Search…'} value={v[d.name] ?? ''} onChange={e => setV({ ...v, [d.name]: e.target.value })}/>
      : d.type === 'select'
        ? <Select key={d.name} aria-label={d.label ?? d.name} value={v[d.name] ?? ''} onChange={e => { const n = { ...v, [d.name]: e.target.value, page: '' }; setV(n); run(n); }}>{d.options.map(([val, text]) => <option key={val} value={val}>{text}</option>)}</Select>
        : <label key={d.name} className="au-date"><small>{d.label ?? d.name}</small><Input type="date" value={v[d.name] ?? ''} onChange={e => { const n = { ...v, [d.name]: e.target.value, page: '' }; setV(n); run(n); }}/></label>)}
    <button type="submit" className="au-btn primary">Apply</button>
    {active && <Btn onClick={() => run({})}>Reset</Btn>}
    {extra}
  </form>;
}

/* ───────────────────────── Table (cards on phones) ───────────────────────── */

export type Col<T> = { key: string; label: string; render?: (row: T) => ReactNode; align?: 'right' | 'center'; primary?: boolean; hideOnPhone?: boolean; wide?: boolean };
export function DataTable<T>({ cols, rows, rowKey, empty = 'Nothing here yet.', footer, rowHref }: { cols: Col<T>[]; rows: T[]; rowKey: (r: T) => string | number; empty?: ReactNode; footer?: ReactNode; rowHref?: (r: T) => string }) {
  if (rows.length === 0) return <div className="au-empty">{empty}</div>;
  return <div className="au-table-wrap">
    <table className="au-table">
      <thead><tr>{cols.map(c => <th key={c.key} className={c.align ?? ''}>{c.label}</th>)}</tr></thead>
      <tbody>{rows.map(r => <tr key={rowKey(r)} className={rowHref ? 'click' : undefined} onClick={rowHref ? e => { if ((e.target as HTMLElement).closest('a,button,input,select,textarea,label')) return; router.visit(rowHref(r)); } : undefined}>{cols.map(c => <td key={c.key} data-label={c.label} className={`${c.align ?? ''}${c.primary ? ' primary' : ''}${c.hideOnPhone ? ' hide-phone' : ''}${c.wide ? ' wide' : ''}`}>{c.render ? c.render(r) : String((r as Record<string, unknown>)[c.key] ?? '—')}</td>)}</tr>)}</tbody>
    </table>
    {footer}
  </div>;
}

export type Paged = { page: number; last: number; total: number; per: number };
export function Pager({ p, url }: { p: Paged; url: string }) {
  const go = (page: number) => {
    const q = Object.fromEntries(new URLSearchParams(window.location.search).entries());
    router.get(url, { ...q, page } as never, { preserveScroll: false, preserveState: true });
  };
  if (p.last <= 1) return <div className="au-pager"><small>{p.total.toLocaleString()} {p.total === 1 ? 'result' : 'results'}</small></div>;
  const from = (p.page - 1) * p.per + 1; const to = Math.min(p.total, p.page * p.per);
  return <div className="au-pager"><small>{from.toLocaleString()}–{to.toLocaleString()} of {p.total.toLocaleString()}</small>
    <div><button type="button" disabled={p.page <= 1} onClick={() => go(p.page - 1)} aria-label="Previous page"><ChevronLeft size={16}/></button><span>{p.page} / {p.last}</span><button type="button" disabled={p.page >= p.last} onClick={() => go(p.page + 1)} aria-label="Next page"><ChevronRight size={16}/></button></div></div>;
}

/* ───────────────────────── Key/value grid ───────────────────────── */
export function KV({ items }: { items: Array<[string, ReactNode]> }) {
  return <dl className="au-kv">{items.map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v ?? '—'}</dd></div>)}</dl>;
}

/* ───────────────────────── helpers ───────────────────────── */
/** "1234567.5" → "1,234,567.5" (display only; the server already formats the decimals). */
export const group = (v: string | number | null | undefined) => {
  const s = String(v ?? '');
  const m = s.match(/^(-?)(\d+)(\.\d+)?$/);
  return m ? `${m[1]}${m[2].replace(/\B(?=(\d{3})+(?!\d))/g, ',')}${m[3] ?? ''}` : s;
};
export const usd = (v: string | number | null | undefined) => { const g = group(v); return g.startsWith('-') ? `-$${g.slice(1)}` : `$${g}`; };
export const signed = (s: string) => <b className={s.startsWith('-') ? 'neg' : 'pos'}>{s.startsWith('-') ? '' : '+'}{s}</b>;
export function useQueryValues(keys: string[]): Record<string, string> {
  const url = usePage().url;
  return useMemo(() => {
    const q = new URLSearchParams(url.split('?')[1] ?? '');
    return Object.fromEntries(keys.map(k => [k, q.get(k) ?? '']));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url]);
}
