<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Install RushX</title><meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--bg:#07080a;--card:#101214;--line:#23262b;--ink:#f2f2f3;--sub:#9a9aa0;--go:#c1f033;--bad:#f6465d;--ok:#2ebd85}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:"DM Sans",system-ui,sans-serif;min-height:100vh;display:grid;place-items:center;padding:28px 16px}
main{width:100%;max-width:560px}
.brand{display:flex;align-items:center;gap:8px;font-weight:800;font-size:20px;margin-bottom:18px;justify-content:center}.brand-mark{width:30px;height:30px;border-radius:9px;background:var(--go);color:#000;display:grid;place-items:center;font-weight:900}.brand-accent{color:var(--go)}
.steps{display:flex;gap:6px;justify-content:center;margin-bottom:22px}.steps span{width:28px;height:4px;border-radius:3px;background:var(--line)}.steps span.on{background:var(--go)}.steps span.done{background:var(--ok)}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:26px}
h1{font-size:19px;margin:0 0 4px}p.sub{color:var(--sub);font-size:13px;margin:0 0 18px;line-height:1.5}
label{display:block;font-size:13px;color:var(--sub);margin:12px 0 6px}
input[type=text],input[type=email],input[type=password],input[type=url],input[type=number]{width:100%;background:#0b0c0e;border:1px solid var(--line);border-radius:9px;padding:11px 12px;color:var(--ink);font:inherit}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.chk{display:flex;align-items:center;gap:8px;color:var(--ink);font-size:14px;margin-top:14px}.chk input{width:18px;height:18px}
.req-item{display:flex;align-items:center;gap:10px;padding:8px 0;font-size:13.5px;border-bottom:1px solid var(--line)}.req-item:last-child{border:0}
.req-item b{width:18px;height:18px;border-radius:50%;display:grid;place-items:center;font-size:11px;color:#000;flex:none}
.req-item.ok b{background:var(--ok)}.req-item.bad b{background:var(--bad);color:#fff}
.actions{display:flex;gap:10px;margin-top:20px}
button{font:inherit;cursor:pointer;border:0;border-radius:10px;padding:12px 18px;font-weight:700}
.btn-primary{background:var(--go);color:#000;flex:1}.btn-primary:disabled{opacity:.45;cursor:not-allowed}
.btn-ghost{background:transparent;color:var(--sub);border:1px solid var(--line)}
.msg{font-size:13px;border-radius:9px;padding:10px 12px;margin-top:12px;display:none}
.msg.err{display:block;background:rgba(246,70,93,.12);color:var(--bad)}
.msg.ok{display:block;background:rgba(46,189,133,.12);color:var(--ok)}
small.hint{display:block;color:var(--sub);font-size:12px;margin-top:6px}
.step{display:none}.step.on{display:block}
</style></head>
<body><main>
<div class="brand"><span class="brand-mark">X</span>Rush<span class="brand-accent">X</span></div>
<div class="steps" id="dots"></div>
<section class="card">

@if(!$requirementsOk)
<div class="step on" data-step="0"><h1>Server requirements</h1><p class="sub">These must pass before setup can continue.</p>
@foreach($checks as $c)<div class="req-item {{ $c['ok']?'ok':'bad' }}"><b>{{ $c['ok']?'✓':'!' }}</b><span>{{ $c['label'] }}</span></div>@endforeach
<div class="actions"><button type="button" class="btn-primary" onclick="location.reload()">Recheck</button></div>
</div>
@endif

<form id="f" method="post" action="{{ route('install.run') }}" autocomplete="off">@csrf
<input type="hidden" name="install_token" value="{{ $installToken }}">
<input type="hidden" name="smtp_enabled" id="smtp_enabled_flag" value="0">

<div class="step {{ $requirementsOk?'on':'' }}" data-step="1">
<h1>Site & database</h1><p class="sub">Your public site URL, and the MySQL database to use.</p>
<label>Site URL<input type="url" name="app_url" id="app_url" value="{{ old('app_url', request()->getSchemeAndHttpHost()) }}" required></label>
<div class="grid2"><label>Database host<input type="text" name="db_host" id="db_host" value="{{ old('db_host','localhost') }}" required></label><label>Port<input type="number" name="db_port" id="db_port" value="{{ old('db_port','3306') }}" required></label></div>
<label>Database name<input type="text" name="db_name" id="db_name" value="{{ old('db_name') }}" required></label>
<label>Database username<input type="text" name="db_user" id="db_user" value="{{ old('db_user') }}" required></label>
<label>Database password<input type="password" name="db_password" id="db_password" autocomplete="new-password"></label>
<div class="msg" id="msg1"></div>
<div class="actions"><button type="button" class="btn-primary" onclick="testDb()">Test connection & continue</button></div>
</div>

<div class="step" data-step="2">
<h1>Administrator account</h1><p class="sub">You'll sign in with this after setup.</p>
<label>Full name<input type="text" name="admin_name" value="{{ old('admin_name') }}" required maxlength="100"></label>
<label>Email<input type="email" name="admin_email" id="admin_email" value="{{ old('admin_email') }}" required></label>
<label>Password<input type="password" name="admin_password" required minlength="12" autocomplete="new-password"><small class="hint">12 or more characters. Keep these credentials safe.</small></label>
<div class="actions"><button type="button" class="btn-ghost" onclick="go(1)">Back</button><button type="button" class="btn-primary" onclick="go(3)">Continue</button></div>
</div>

<div class="step" data-step="3">
<h1>Email (SMTP)</h1><p class="sub">Used for account and notification emails. Optional — you can set this up later from Admin → Settings instead.</p>
<label class="chk"><input type="checkbox" id="smtp_on" onchange="toggleSmtp()"> Configure email now</label>
<div id="smtp_fields" style="display:none">
<div class="grid2"><label>SMTP host<input type="text" id="smtp_host"></label><label>Port<input type="number" id="smtp_port" value="587"></label></div>
<label>Username<input type="text" id="smtp_user"></label>
<label>Password<input type="password" id="smtp_pass" autocomplete="new-password"></label>
<label>Security<select id="smtp_scheme" style="width:100%;background:#0b0c0e;border:1px solid #23262b;border-radius:9px;padding:11px 12px;color:#f2f2f3"><option value="">Auto</option><option value="smtp">STARTTLS (587)</option><option value="smtps">SSL (465)</option></select></label>
<label>From address<input type="email" id="mail_from"></label>
<label>From name<input type="text" id="mail_from_name" value="RushX"></label>
<label>Send a test email to<input type="email" id="smtp_test_to"></label>
<div class="msg" id="msg3"></div>
<div class="actions"><button type="button" class="btn-primary" onclick="testSmtp()">Send test email & continue</button></div>
</div>
<div class="actions" id="smtp_skip"><button type="button" class="btn-ghost" onclick="go(2)">Back</button><button type="button" class="btn-primary" onclick="go(4)">Skip for now</button></div>
</div>

<div class="step" data-step="4">
<h1>License key</h1><p class="sub">Enter the license key you received when you purchased this script.</p>
<label>License key<input type="text" name="license_key" id="license_key" placeholder="XXXX-XXXX-XXXX-XXXX" style="text-transform:uppercase" required></label>
<div class="msg" id="msg4"></div>
<div class="actions"><button type="button" class="btn-ghost" onclick="go(3)">Back</button><button type="button" class="btn-primary" id="license_btn" onclick="testLicense()">Verify key & continue</button></div>
</div>

<div class="step" data-step="5">
<h1>Ready to install</h1><p class="sub">Review your details above if needed, then finish setup. This writes your configuration and creates your admin account.</p>
@if($errors->any())<div class="msg err" style="display:block">{{ $errors->first() }}</div>@endif
<div class="actions"><button type="button" class="btn-ghost" onclick="go(4)">Back</button><button class="btn-primary" type="submit" id="install_btn">Install RushX</button></div>
</div>
</form>
</section>
<p style="text-align:center;color:#6b6b70;font-size:12px;margin-top:16px">Installer locks automatically after successful setup.</p>
</main>
<script>
const TOKEN='{{ $installToken }}', CSRF=document.querySelector('meta[name=csrf-token]').content;
const TOTAL=5, requirementsOk={{ $requirementsOk?'true':'false' }};
let licenseVerified=false, smtpPassed=false;
function dots(){const el=document.getElementById('dots');el.innerHTML='';for(let i=1;i<=TOTAL;i++){const s=document.createElement('span');s.id='dot'+i;el.appendChild(s);}paintDots(current());}
function current(){const on=document.querySelector('.step.on[data-step]');return on?parseInt(on.dataset.step):(requirementsOk?1:0);}
function paintDots(step){for(let i=1;i<=TOTAL;i++){const d=document.getElementById('dot'+i);if(!d)continue;d.className=i<step?'done':(i===step?'on':'');}}
function go(step){document.querySelectorAll('.step').forEach(s=>s.classList.remove('on'));const t=document.querySelector('.step[data-step="'+step+'"]');if(t)t.classList.add('on');paintDots(step);window.scrollTo({top:0,behavior:'smooth'});}
async function post(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':CSRF,'Accept':'application/json'},body:JSON.stringify(body)});let j={};try{j=await r.json();}catch(e){}return {ok:r.ok,status:r.status,data:j};}
function showMsg(id,text,ok){const el=document.getElementById(id);el.textContent=text;el.className='msg '+(ok?'ok':'err');}
async function testDb(){
 const d={install_token:TOKEN,db_host:v('db_host'),db_port:v('db_port'),db_name:v('db_name'),db_user:v('db_user'),db_password:v('db_password')};
 if(!v('app_url')||!d.db_host||!d.db_name||!d.db_user){showMsg('msg1','Fill in all required fields first.',false);return;}
 showMsg('msg1','Testing…',true);
 const r=await post('{{ route("install.test-db") }}',d);
 if(r.ok&&r.data.ok){showMsg('msg1','Connected.',true);go(2);}else{showMsg('msg1',(r.data&&r.data.message)||'Could not connect.',false);}
}
function toggleSmtp(){const on=document.getElementById('smtp_on').checked;document.getElementById('smtp_fields').style.display=on?'block':'none';document.getElementById('smtp_skip').style.display=on?'none':'flex';document.getElementById('smtp_enabled_flag').value=on?'1':'0';}
async function testSmtp(){
 const d={install_token:TOKEN,smtp_host:v('smtp_host'),smtp_port:v('smtp_port'),smtp_user:v('smtp_user'),smtp_pass:v('smtp_pass'),smtp_scheme:v('smtp_scheme'),mail_from:v('mail_from'),mail_from_name:v('mail_from_name'),test_to:v('smtp_test_to')};
 if(!d.smtp_host||!d.smtp_user||!d.smtp_pass||!d.mail_from||!d.test_to){showMsg('msg3','Fill in all fields, including a test recipient email.',false);return;}
 showMsg('msg3','Sending test email…',true);
 const r=await post('{{ route("install.test-smtp") }}',d);
 if(r.ok&&r.data.ok){showMsg('msg3','Sent — check the inbox.',true);smtpPassed=true;['smtp_host','smtp_port','smtp_user','smtp_pass','smtp_scheme','mail_from','mail_from_name'].forEach(copyToForm);go(4);}
 else{showMsg('msg3',(r.data&&r.data.message)||'Could not send.',false);}
}
function copyToForm(id){let el=document.getElementById(id+'_hidden');if(!el){el=document.createElement('input');el.type='hidden';el.name=id;el.id=id+'_hidden';document.getElementById('f').appendChild(el);}el.value=v(id);}
async function testLicense(){
 const key=v('license_key').toUpperCase(); document.getElementById('license_key').value=key;
 if(!key){showMsg('msg4','Enter your license key.',false);return;}
 showMsg('msg4','Verifying…',true); document.getElementById('license_btn').disabled=true;
 const r=await post('{{ route("install.test-license") }}',{install_token:TOKEN,app_url:v('app_url'),license_key:key});
 document.getElementById('license_btn').disabled=false;
 if(r.ok&&r.data.ok){showMsg('msg4','License verified.',true);licenseVerified=true;go(5);}
 else{showMsg('msg4',(r.data&&r.data.message)||'License key was not accepted.',false);}
}
function v(id){const el=document.getElementById(id);return el?el.value.trim():'';}
document.getElementById('f').addEventListener('submit',function(e){ if(!licenseVerified){e.preventDefault();go(4);showMsg('msg4','Verify your license key first.',false);} document.getElementById('install_btn').disabled=true; document.getElementById('install_btn').textContent='Installing…'; });
dots();
</script>
</body></html>
