<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#050505">
    <link rel="icon" type="image/svg+xml" href="/images/rushx-mark.svg">
    <script>try{if(localStorage.getItem('rushx-theme')==='light'){document.documentElement.dataset.theme='light';}}catch(e){}</script>
    <title>{{ config('app.name', 'RushX') }}</title>
    @viteReactRefresh
    @vite(['resources/css/app.css', 'resources/js/app.tsx'])
    @inertiaHead
</head>
<body>
    @inertia
    @unless(request()->is('admin*'))
    <script src="//code.tidio.co/u5f7hbutowdfkwq5oq5ni9u10yghjgp0.js" async></script>
    <script>
    /* Tidio stays hidden (bubble + greeting) until a message icon is clicked; closing hides it again. */
    (function(){
      var st=document.createElement('style');
      st.textContent='#tidio-chat,#tidio-chat-iframe,#tidio-chat-code{display:none!important}body.rx-chat-on #tidio-chat,body.rx-chat-on #tidio-chat-iframe{display:block!important}';
      document.head.appendChild(st);
      function api(){return window.tidioChatApi}
      function ready(){ var a=api(); if(!a) return; a.hide(); a.on('close',function(){ document.body.classList.remove('rx-chat-on'); a.hide(); }); }
      if(api()) ready(); else document.addEventListener('tidioChat-apiReady',ready);
      document.addEventListener('tidioChat-ready',function(){ if(api()&&!document.body.classList.contains('rx-chat-on')) api().hide(); });
      window.rushxChat=function(){ var a=api(); document.body.classList.add('rx-chat-on'); if(!a) return; a.show(); a.open(); };
    })();
    </script>
    @endunless
</body>
</html>
