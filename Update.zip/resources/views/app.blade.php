<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#050505">
    <link rel="icon" type="image/svg+xml" href="/images/rushx-mark.svg">
    <script>try{if(localStorage.getItem('rushx-theme')==='light'){document.documentElement.dataset.theme='light';}}catch(e){}</script>
    <title>{{ config('app.name', 'RushX') }}</title>
    @viteReactRefresh
    @vite(['resources/css/app.css', 'resources/js/app.tsx'])
    @inertiaHead
</head>
<body>
    @inertia
    <script src="//code.tidio.co/u5f7hbutowdfkwq5oq5ni9u10yghjgp0.js" async></script>
    <script>
    /* Phone: the Tidio launcher is hidden; the header chat icon opens it, closing it hides it again (no overlap with the bottom nav). */
    (function(){
      var mobile=function(){return window.matchMedia('(max-width:820px)').matches};
      function ready(){ var a=window.tidioChatApi; if(!a) return; if(mobile()) a.hide(); a.on('close',function(){ if(mobile()) a.hide(); }); }
      if(window.tidioChatApi) ready(); else document.addEventListener('tidioChat-apiReady',ready);
      document.addEventListener('tidioChat-ready',function(){ if(mobile()&&window.tidioChatApi) window.tidioChatApi.hide(); });
      window.rushxChat=function(){ var a=window.tidioChatApi; if(!a) return; a.show(); a.open(); };
    })();
    </script>
</body>
</html>
