<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Not licensed</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#000;color:#fff;font-family:Inter,system-ui,sans-serif;text-align:center;padding:24px}main{max-width:420px}h1{font-size:26px;margin:18px 0 10px}p{color:#9a9aa0;line-height:1.6}.dot{width:56px;height:56px;border-radius:16px;background:#f6465d;color:#fff;display:grid;place-items:center;font-weight:900;font-size:28px;margin:0 auto}</style></head>
<body><main><div class="dot">!</div><h1>Not licensed</h1><p>{{ $message }}</p></main></body></html>
