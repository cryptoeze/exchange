<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{ $heading }}</title></head>
<body style="margin:0;padding:0;background:#0b0c0e;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:#e8e8ea">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0b0c0e;padding:28px 12px"><tr><td align="center">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#111214;border:1px solid #232428;border-radius:18px;overflow:hidden">
    <tr><td style="padding:22px 28px;border-bottom:1px solid #232428;font-size:22px;font-weight:800;letter-spacing:-.5px;color:#fff">Rush<span style="color:#c1f033">X</span></td></tr>
    <tr><td style="padding:28px">
      <h1 style="margin:0 0 14px;font-size:21px;line-height:1.3;color:#fff">{{ $heading }}</h1>
      <div style="font-size:15px;line-height:1.65;color:#c9c9cd">{!! $bodyHtml !!}</div>
      @if (! empty($url))
        <p style="margin:26px 0 4px"><a href="{{ $url }}" style="display:inline-block;background:#c1f033;color:#000;text-decoration:none;font-weight:800;padding:13px 24px;border-radius:12px;font-size:15px">{{ $cta ?? 'Open RushX' }}</a></p>
      @endif
    </td></tr>
    <tr><td style="padding:18px 28px;border-top:1px solid #232428;font-size:12px;line-height:1.6;color:#7c7d84">You received this email because of activity on your RushX account. Never share your password or codes with anyone — RushX staff will never ask for them.<br>© {{ date('Y') }} RushX</td></tr>
  </table>
</td></tr></table></body></html>
